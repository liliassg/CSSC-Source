"""Transembly — CSSC-tailored runtime emitter.

Owns the production of the runtime support library that the user's
LLVM-IR-compiled code links against. Phase 1 emits the runtime as LLVM IR
(stops at `.ll` text, hands off to `llc` like the user code). Phase 2+
migrates the hot-path symbols (`cssc_release_internal`, `cssc_retain`,
`cssc_alloc`) to hand-tuned target assembly with a native COFF/ELF object
emitter — that's where CSSC-specific machine-code wins materialise.

Phase 1 surface:
  - `cssc_runtime_init`  — no-op (no global state yet)
  - `cssc_runtime_shutdown` — no-op
  - `cssc_print_int(i64)` — printf("%lld\n", n)
  - `cssc_print_bool(i1)`
  - `cssc_print_float(double)`
  - `cssc_print_str(ptr, i64)` — fwrite + putchar '\n'
  - `cssc_panic(ptr, i64)` — fwrite to stderr + exit(1)
"""
from . import x86_64
from . import avr

__all__ = ['x86_64', 'avr']
