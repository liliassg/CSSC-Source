"""Bare-metal Transembly runtime emitter — Phase 5.

Emits a libc-free CSSC runtime tuned for embedded targets that don't
have printf / malloc out of the box:

  * `esp8266` — Xtensa LX106 (NodeMCU / Wemos D1). UART0 TX FIFO at
                0x60000000. CPU clock 80 MHz; default boot baud 74880.
  * `esp32`   — Xtensa LX7 (ESP32-S3 etc.). UART0 TX FIFO at 0x3FF40000
                (LX6) or 0x60000000 (LX7); we use the LX7 mapping.
  * `avr`     — Arduino / AVR. Output via USART0 UDR0 register at 0xC6
                (atmega328p). Currently a stub — runs through clang's
                AVR backend but the boot vectors / IRQ table aren't yet
                wired, so flashing is not in scope for v6.0.

Allocator: a fixed-size `.bss` arena (default 8 KiB on ESP, 256 B on
AVR) walked by a global bump cursor. `free` is a no-op — Phase 5 owns
the lifecycle through CSSC's scope rules + manual `#delete`, the arena
is reused only when the program restarts.

The same `emit_runtime_ll(symbols, triple, module_id, profile)` entry
point used by the host runtime is exposed here so the driver can dispatch
without caring about runtime topology.
"""
from __future__ import annotations

from typing import Iterable, List, Set


# ---------------------------------------------------------------------------
# UART register maps per target profile (TX FIFO write address).
# ---------------------------------------------------------------------------
_UART_TX = {
    'esp8266': 0x60000000,
    'esp32':   0x60000000,
    'avr':     0x00C6,         # USART0 UDR0 on atmega328p
}

# Arena sizes (bytes) for each profile's bump allocator.
_ARENA_SIZE = {
    'esp8266': 8192,
    'esp32':   16384,
    'avr':     256,
}


# ---------------------------------------------------------------------------
# Symbol surface mirrored from the host runtime. Phase 5 minimum implements
# the I/O + alloc symbols. Vector/map/string heap kinds reuse the host
# layouts since they're libc-free already (only malloc/free are external).
# ---------------------------------------------------------------------------
_BAREMETAL_SYMBOLS = frozenset({
    'cssc_runtime_init',
    'cssc_runtime_shutdown',
    'cssc_print_int',
    'cssc_print_bool',
    'cssc_print_float',
    'cssc_print_str',
    'cssc_print_string',
    'cssc_panic',
    'cssc_obj_alloc',
    'cssc_obj_free',
    'cssc_string_lit',
    'cssc_string_free',
    'cssc_string_size',
    'cssc_string_data',
    'cssc_string_concat',
    # Time / sleep — ESP8266: rough busy-loop sleep + cycle-count uptime.
    # Real ports tie into FreeRTOS vTaskDelay or NMI timer ticks; this is
    # the minimum so the symbols resolve and the script can run.
    'cssc_sleep_ms', 'cssc_uptime', 'cssc_tick',
    # Stringify — small integer/float-to-string into the bump arena.
    'cssc_int_to_str', 'cssc_float_to_str', 'cssc_bool_to_str',
    # Sysout / sysarg — driven by the main shim. Sysout records the exit
    # code (no-op on bare metal — the chip just halts). Sysarg returns 0.
    'cssc_sysout', 'cssc_sysarg_int',
    # GPIO peripherals — handle-allocating no-op stubs so a script with
    # `#pin[13] led;` etc. links. Real MMIO ports come per-chip after
    # Phase 5c (clock setup, GPIO register addresses, etc.). For now
    # the script will link, the chip will boot, the peripheral calls
    # are silent — the script's logic runs, it just doesn't see/touch
    # hardware. Plenty for getting the build pipeline green.
    'cssc_pin_new',  'cssc_pin_free',  'cssc_pin_write',   'cssc_pin_read',
    'cssc_pin_mode', 'cssc_pin_toggle','cssc_pin_pullup',
    'cssc_i2c_new',  'cssc_i2c_free',  'cssc_i2c_begin',
    'cssc_i2c_write','cssc_i2c_read',
    'cssc_spi_new',  'cssc_spi_free',  'cssc_spi_begin', 'cssc_spi_transfer',
    'cssc_uart_new', 'cssc_uart_free', 'cssc_uart_begin',
    'cssc_uart_write','cssc_uart_read',
    'cssc_adc_new',  'cssc_adc_free',  'cssc_adc_read',
    'cssc_pwm_new',  'cssc_pwm_free',  'cssc_pwm_duty',
    'cssc_timer_new','cssc_timer_free','cssc_timer_start',
    'cssc_timer_stop','cssc_timer_read',
    # Display drivers — link-clean stubs. Real SSD1306 / ILI9341 / etc.
    # drivers land in a dedicated phase; for now the calls are silent
    # so a script using #tft/#oled.text/.fill/.show links and runs.
    'cssc_tft_new',  'cssc_tft_free',
    'cssc_tft_begin','cssc_tft_close','cssc_tft_show',
    'cssc_tft_fill', 'cssc_tft_pixel','cssc_tft_line',
    'cssc_tft_rect', 'cssc_tft_fillrect','cssc_tft_circle','cssc_tft_text',
    'cssc_oled_new', 'cssc_oled_free',
    'cssc_oled_begin','cssc_oled_close','cssc_oled_show',
    'cssc_oled_fill','cssc_oled_pixel','cssc_oled_line',
    'cssc_oled_rect','cssc_oled_fillrect','cssc_oled_circle','cssc_oled_text',
    'cssc_video_new','cssc_video_free','cssc_video_begin','cssc_video_close',
    'cssc_video_clear','cssc_video_present','cssc_video_is_open',
    'cssc_matrix_new','cssc_matrix_free',
    'cssc_matrix_fill','cssc_matrix_pixel','cssc_matrix_show',
    'cssc_framebuffer_new','cssc_framebuffer_free',
    'cssc_framebuffer_fill','cssc_framebuffer_pixel','cssc_framebuffer_present',
    'cssc_console_new','cssc_console_free',
    'cssc_console_write','cssc_console_clear','cssc_console_close',
    # Vector + map runtimes don't depend on libc beyond memcpy/memset/abort,
    # and we provide those ourselves below. Their group emitters from
    # x86_64.py are reused unchanged.
})


def supported_baremetal_symbols() -> Set[str]:
    return set(_BAREMETAL_SYMBOLS)


def emit_runtime_ll(symbols: Iterable[str],
                    target_triple: str,
                    module_id: str,
                    profile: str) -> str:
    """Bare-metal runtime emitter — UART-backed I/O, bump-alloc memory.

    Returns one self-contained `.ll` module that the driver hands to
    clang/llc with the right `-target=` triple.
    """
    if profile not in _UART_TX:
        raise RuntimeError(
            f'Transembly: unsupported embedded profile {profile!r}. '
            f'Known: {sorted(_UART_TX.keys())}'
        )

    requested = set(symbols)
    requested.add('cssc_runtime_init')
    requested.add('cssc_runtime_shutdown')

    out: List[str] = []
    out.append(f"; ModuleID = '{module_id}'")
    out.append(f'source_filename = "<transembly-baremetal-{profile}>"')
    out.append(f'target triple = "{target_triple}"')
    out.append('')
    out.append(f'; ----- bare-metal CSSC runtime ({profile}) -----')
    out.append(f'; UART TX FIFO: {hex(_UART_TX[profile])}  /  '
               f'arena: {_ARENA_SIZE[profile]} bytes')
    out.append('')

    # ---- Common helpers + arena globals + UART write ----
    out.extend(_emit_baremetal_prelude(profile))
    out.append('')

    # ---- Symbols ----
    if 'cssc_runtime_init' in requested:
        out.extend(_emit_runtime_init(profile))
        out.append('')
    if 'cssc_runtime_shutdown' in requested:
        out.extend(_emit_runtime_shutdown(profile))
        out.append('')
    if 'cssc_print_int' in requested:
        out.extend(_emit_print_int(profile))
        out.append('')
    if 'cssc_print_bool' in requested:
        out.extend(_emit_print_bool(profile))
        out.append('')
    if 'cssc_print_float' in requested:
        # Float printing on bare metal needs a runtime float-to-string
        # implementation. For Phase 5 we round to integer and print
        # an approximation, with a clear marker — finishing this needs
        # a dragon4 / ryu adaptation that's its own slice.
        out.extend(_emit_print_float_approx(profile))
        out.append('')
    if 'cssc_print_str' in requested:
        out.extend(_emit_print_str(profile))
        out.append('')
    if 'cssc_print_string' in requested:
        out.extend(_emit_print_string(profile))
        out.append('')
    if 'cssc_panic' in requested:
        out.extend(_emit_panic(profile))
        out.append('')
    if 'cssc_obj_alloc' in requested:
        out.extend(_emit_obj_alloc(profile))
        out.append('')
    if 'cssc_obj_free' in requested:
        out.extend(_emit_obj_free(profile))
        out.append('')
    if 'cssc_string_lit' in requested:
        out.extend(_emit_string_lit(profile))
        out.append('')
    if 'cssc_string_free' in requested:
        out.extend(_emit_string_free(profile))
        out.append('')
    if 'cssc_string_size' in requested:
        out.extend(_emit_string_size(profile))
        out.append('')
    if 'cssc_string_data' in requested:
        out.extend(_emit_string_data(profile))
        out.append('')
    if 'cssc_string_concat' in requested:
        out.extend(_emit_string_concat(profile))
        out.append('')

    # Time group: emit as a unit when any of its symbols is touched —
    # they share `@.cssc_uptime_ms` so co-emission is required.
    if requested & {'cssc_sleep_ms', 'cssc_uptime', 'cssc_tick'}:
        out.extend(_emit_time(profile))
        out.append('')

    # Stringify helpers — same co-emission pattern (share helpers).
    if requested & {'cssc_int_to_str', 'cssc_float_to_str', 'cssc_bool_to_str'}:
        out.extend(_emit_stringify(profile))
        out.append('')

    # sysout / sysarg — always emitted because the main shim references
    # @cssc_argc / @cssc_argv / @cssc_sysout_value unconditionally.
    out.extend(_emit_sysout_sysarg(profile))
    out.append('')

    # Peripheral stubs — emit as a unit when *any* peripheral symbol is
    # touched. Keeps the bare-metal IR self-contained.
    _peripheral_names = (
        'cssc_pin_', 'cssc_i2c_', 'cssc_spi_', 'cssc_uart_',
        'cssc_adc_', 'cssc_pwm_', 'cssc_timer_',
        'cssc_tft_', 'cssc_oled_', 'cssc_video_',
        'cssc_matrix_', 'cssc_framebuffer_', 'cssc_console_',
    )
    if any(sym.startswith(p) for sym in requested for p in _peripheral_names):
        out.extend(_emit_peripheral_stubs(profile))
        out.append('')

    return '\n'.join(out) + '\n'


# ---------------------------------------------------------------------------
# Shared prelude — arena bytes, bump cursor, raw UART byte-write helper.
# ---------------------------------------------------------------------------
def _emit_baremetal_prelude(profile: str) -> List[str]:
    arena = _ARENA_SIZE[profile]
    return [
        '; Static arena for the bump allocator. Zero-initialised in .bss.',
        f'@.cssc_arena      = internal global [{arena} x i8] zeroinitializer, '
        'align 8',
        '@.cssc_arena_off  = internal global i64 0, align 8',
        '',
        '; struct cssc_str { i64 size; i64 cap; ptr data; }',
        '%cssc_str = type { i64, i64, ptr }',
        '',
        '; UART TX FIFO single-byte write — pointer is a hardware address',
        '; cast to (i8*) and stored to. The "volatile" flag prevents the',
        '; optimiser from coalescing writes that need to land in MMIO order.',
        'define internal void @.cssc_uart_putc(i8 %b) {',
        'entry:',
        f'  %tx = inttoptr i64 {hex(_UART_TX[profile])} to ptr',
        '  store volatile i8 %b, ptr %tx, align 1',
        '  ret void',
        '}',
        '',
        '; Convenience: write a NUL-terminated message to the UART.',
        'define internal void @.cssc_uart_puts(ptr %s) {',
        'entry:',
        '  br label %loop',
        'loop:',
        '  %i = phi i64 [0, %entry], [%i.next, %step]',
        '  %p = getelementptr inbounds i8, ptr %s, i64 %i',
        '  %b = load i8, ptr %p, align 1',
        '  %z = icmp eq i8 %b, 0',
        '  br i1 %z, label %end, label %step',
        'step:',
        '  call void @.cssc_uart_putc(i8 %b)',
        '  %i.next = add i64 %i, 1',
        '  br label %loop',
        'end:',
        '  ret void',
        '}',
    ]


def _emit_runtime_init(profile: str) -> List[str]:
    # No baud-rate / pin setup here yet — assume the bootloader has
    # already configured UART0 (true for both NodeMCU and ESP-IDF default
    # boot images at 74880/115200 baud).
    return [
        'define void @cssc_runtime_init() {',
        'entry:',
        '  ret void',
        '}',
    ]


def _emit_runtime_shutdown(profile: str) -> List[str]:
    return [
        'define void @cssc_runtime_shutdown() {',
        'entry:',
        '  ret void',
        '}',
    ]


def _emit_print_int(profile: str) -> List[str]:
    """Bare-metal int printer.

    Converts i64 → ASCII into a 21-byte stack buffer (max signed decimal:
    -9223372036854775808 = 20 chars + NUL), then walks the buffer pushing
    each byte to the UART, finishing with a `\n`. No libc dependency.
    """
    return [
        'define void @cssc_print_int(i64 %n) {',
        'entry:',
        '  ; Stack buffer big enough for INT64_MIN + sign + NUL.',
        '  %buf = alloca [22 x i8], align 1',
        '  %neg = icmp slt i64 %n, 0',
        '  br i1 %neg, label %do_neg, label %abs',
        'do_neg:',
        '  %nn = sub i64 0, %n',
        '  br label %abs',
        'abs:',
        '  %abs_val = phi i64 [%nn, %do_neg], [%n, %entry]',
        '  ; Write digits in reverse from the end of the buffer.',
        '  %end_idx = add i64 20, 0',
        '  br label %digit',
        'digit:',
        '  %idx  = phi i64 [%end_idx, %abs], [%idx.next, %digit]',
        '  %cur  = phi i64 [%abs_val, %abs], [%div, %digit]',
        '  %div  = udiv i64 %cur, 10',
        '  %rem  = urem i64 %cur, 10',
        '  %rem8 = trunc i64 %rem to i8',
        '  %ch   = add i8 %rem8, 48',
        '  %p    = getelementptr inbounds [22 x i8], ptr %buf, i64 0, i64 %idx',
        '  store i8 %ch, ptr %p, align 1',
        '  %done = icmp eq i64 %div, 0',
        '  %idx.next = sub i64 %idx, 1',
        '  br i1 %done, label %sign, label %digit',
        'sign:',
        '  ; idx points one slot to the left of the first written digit.',
        '  ; If the number was negative, write a "-" there and back up; else',
        '  ; advance idx by 1 to point at the first digit.',
        '  br i1 %neg, label %put_sign, label %fwd',
        'put_sign:',
        '  %ps = getelementptr inbounds [22 x i8], ptr %buf, i64 0, i64 %idx.next',
        '  store i8 45, ptr %ps, align 1',
        '  %first.neg = sub i64 %idx.next, 0',
        '  br label %emit',
        'fwd:',
        '  %first.pos = add i64 %idx.next, 1',
        '  br label %emit',
        'emit:',
        '  %first = phi i64 [%first.neg, %put_sign], [%first.pos, %fwd]',
        '  br label %emit.loop',
        'emit.loop:',
        '  %ei   = phi i64 [%first, %emit], [%ei.next, %emit.step]',
        '  %past = icmp ugt i64 %ei, 20',
        '  br i1 %past, label %nl, label %emit.step',
        'emit.step:',
        '  %ep   = getelementptr inbounds [22 x i8], ptr %buf, i64 0, i64 %ei',
        '  %eb   = load i8, ptr %ep, align 1',
        '  call void @.cssc_uart_putc(i8 %eb)',
        '  %ei.next = add i64 %ei, 1',
        '  br label %emit.loop',
        'nl:',
        '  call void @.cssc_uart_putc(i8 10)',
        '  ret void',
        '}',
    ]


def _emit_print_bool(profile: str) -> List[str]:
    """Emits "true\\n" or "false\\n" via the UART."""
    return [
        '@.cssc_str_true_b  = internal constant [6 x i8] c"true\\0A\\00", align 1',
        '@.cssc_str_false_b = internal constant [7 x i8] c"false\\0A\\00", align 1',
        '',
        'define void @cssc_print_bool(i1 %b) {',
        'entry:',
        '  br i1 %b, label %t, label %f',
        't:',
        '  %tp = getelementptr inbounds [6 x i8], ptr @.cssc_str_true_b,  i64 0, i64 0',
        '  call void @.cssc_uart_puts(ptr %tp)',
        '  ret void',
        'f:',
        '  %fp = getelementptr inbounds [7 x i8], ptr @.cssc_str_false_b, i64 0, i64 0',
        '  call void @.cssc_uart_puts(ptr %fp)',
        '  ret void',
        '}',
    ]


def _emit_print_float_approx(profile: str) -> List[str]:
    """Float printer — Phase 5 approximation: print integer part only.

    Full float→string on bare-metal needs a Dragon4/Ryu adaptation that
    fits in the firmware footprint. For v6.0 we round towards zero and
    delegate to `cssc_print_int`. A clear marker (`~` prefix) makes it
    obvious in the UART log that this is a truncated print.
    """
    return [
        'define void @cssc_print_float(double %f) {',
        'entry:',
        '  %i  = fptosi double %f to i64',
        '  call void @.cssc_uart_putc(i8 126)   ; "~"',
        '  call void @cssc_print_int(i64 %i)',
        '  ret void',
        '}',
    ]


def _emit_print_str(profile: str) -> List[str]:
    return [
        'define void @cssc_print_str(ptr %s, i64 %len) {',
        'entry:',
        '  br label %loop',
        'loop:',
        '  %i = phi i64 [0, %entry], [%i.next, %step]',
        '  %done = icmp uge i64 %i, %len',
        '  br i1 %done, label %end, label %step',
        'step:',
        '  %p = getelementptr inbounds i8, ptr %s, i64 %i',
        '  %b = load i8, ptr %p, align 1',
        '  call void @.cssc_uart_putc(i8 %b)',
        '  %i.next = add i64 %i, 1',
        '  br label %loop',
        'end:',
        '  call void @.cssc_uart_putc(i8 10)',
        '  ret void',
        '}',
    ]


def _emit_print_string(profile: str) -> List[str]:
    return [
        'define void @cssc_print_string(ptr %s) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_str, ptr %s, i64 0, i32 0',
        '  %size   = load i64, ptr %size_p, align 8',
        '  %data_p = getelementptr inbounds %cssc_str, ptr %s, i64 0, i32 2',
        '  %data   = load ptr, ptr %data_p, align 8',
        '  call void @cssc_print_str(ptr %data, i64 %size)',
        '  ret void',
        '}',
    ]


def _emit_panic(profile: str) -> List[str]:
    """Panic: print "!! PANIC\\n", then halt by entering an infinite loop.

    The MCU's WDT will eventually trigger a reset; that's the standard
    bare-metal failure mode and the most useful behaviour without
    requiring `exit(1)` from libc.
    """
    return [
        '@.cssc_panic_msg = internal constant [10 x i8] c"!! PANIC\\0A\\00", align 1',
        '',
        'define void @cssc_panic(ptr %s, i64 %len) {',
        'entry:',
        '  %mp = getelementptr inbounds [10 x i8], ptr @.cssc_panic_msg, i64 0, i64 0',
        '  call void @.cssc_uart_puts(ptr %mp)',
        '  call void @cssc_print_str(ptr %s, i64 %len)',
        '  br label %halt',
        'halt:',
        '  br label %halt',
        '}',
    ]


def _emit_obj_alloc(profile: str) -> List[str]:
    """Bump-allocator backed by the static `.cssc_arena` buffer.

    Returns a pointer aligned to 8 bytes. On overflow returns null —
    the caller can panic on null if it cares; for v6.0 we leave that
    policy to the user code.
    """
    arena = _ARENA_SIZE[profile]
    return [
        f'define ptr @cssc_obj_alloc(i64 %size) {{',
        f'entry:',
        f'  %off_p = getelementptr inbounds i64, ptr @.cssc_arena_off, i64 0',
        f'  %off   = load i64, ptr %off_p, align 8',
        f'  ; round size up to 8 bytes',
        f'  %sz1   = add i64 %size, 7',
        f'  %sz    = and i64 %sz1, -8',
        f'  %next  = add i64 %off, %sz',
        f'  %over  = icmp ugt i64 %next, {arena}',
        f'  br i1 %over, label %oom, label %ok',
        f'ok:',
        f'  store i64 %next, ptr %off_p, align 8',
        f'  %base  = getelementptr inbounds [{arena} x i8], '
        f'ptr @.cssc_arena, i64 0, i64 %off',
        f'  ret ptr %base',
        f'oom:',
        f'  ret ptr null',
        f'}}',
    ]


def _emit_obj_free(profile: str) -> List[str]:
    """Bump allocator can't reclaim individual blocks — free is a no-op."""
    return [
        'define void @cssc_obj_free(ptr %p) {',
        'entry:',
        '  ret void',
        '}',
    ]


def _emit_string_lit(profile: str) -> List[str]:
    """Bare-metal cssc_string_lit — bump-allocs the header + data buffer."""
    return [
        'define ptr @cssc_string_lit(ptr %src, i64 %len) {',
        'entry:',
        '  ; Allocate a 24-byte cssc_str header via the arena.',
        '  %hdr = call ptr @cssc_obj_alloc(i64 24)',
        '  ; Allocate the data buffer; min 1 byte so even empty strings',
        '  ; have a non-null buffer pointer (matches host semantics).',
        '  %iszero = icmp eq i64 %len, 0',
        '  %dbytes = select i1 %iszero, i64 1, i64 %len',
        '  %data   = call ptr @cssc_obj_alloc(i64 %dbytes)',
        '  ; Manual memcpy — libc isn\'t present.',
        '  br label %cp',
        'cp:',
        '  %i = phi i64 [0, %entry], [%i.next, %step]',
        '  %done = icmp uge i64 %i, %len',
        '  br i1 %done, label %fill, label %step',
        'step:',
        '  %sp = getelementptr inbounds i8, ptr %src,  i64 %i',
        '  %dp = getelementptr inbounds i8, ptr %data, i64 %i',
        '  %b  = load i8, ptr %sp, align 1',
        '  store i8 %b, ptr %dp, align 1',
        '  %i.next = add i64 %i, 1',
        '  br label %cp',
        'fill:',
        '  %size_p = getelementptr inbounds %cssc_str, ptr %hdr, i64 0, i32 0',
        '  store i64 %len, ptr %size_p, align 8',
        '  %cap_p  = getelementptr inbounds %cssc_str, ptr %hdr, i64 0, i32 1',
        '  store i64 %len, ptr %cap_p,  align 8',
        '  %data_p = getelementptr inbounds %cssc_str, ptr %hdr, i64 0, i32 2',
        '  store ptr %data, ptr %data_p, align 8',
        '  ret ptr %hdr',
        '}',
    ]


def _emit_string_free(profile: str) -> List[str]:
    """No-op — arena can't reclaim individual blocks."""
    return [
        'define void @cssc_string_free(ptr %s) {',
        'entry:',
        '  ret void',
        '}',
    ]


def _emit_string_size(profile: str) -> List[str]:
    return [
        'define i64 @cssc_string_size(ptr %s) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_str, ptr %s, i64 0, i32 0',
        '  %size   = load i64, ptr %size_p, align 8',
        '  ret i64 %size',
        '}',
    ]


def _emit_string_data(profile: str) -> List[str]:
    return [
        'define ptr @cssc_string_data(ptr %s) {',
        'entry:',
        '  %data_p = getelementptr inbounds %cssc_str, ptr %s, i64 0, i32 2',
        '  %data   = load ptr, ptr %data_p, align 8',
        '  ret ptr %data',
        '}',
    ]


# ---------------------------------------------------------------------------
# String concat — allocate (size_a + size_b) bytes via the arena, copy
# each operand's bytes, build the cssc_str header.
# ---------------------------------------------------------------------------
def _emit_string_concat(profile: str) -> List[str]:
    return [
        'define ptr @cssc_string_concat(ptr %a, ptr %b) {',
        'entry:',
        '  ; Sizes.',
        '  %ap_size = getelementptr inbounds %cssc_str, ptr %a, i64 0, i32 0',
        '  %as = load i64, ptr %ap_size, align 8',
        '  %bp_size = getelementptr inbounds %cssc_str, ptr %b, i64 0, i32 0',
        '  %bs = load i64, ptr %bp_size, align 8',
        '  %total = add i64 %as, %bs',
        '  ; Data pointers.',
        '  %ap_data = getelementptr inbounds %cssc_str, ptr %a, i64 0, i32 2',
        '  %ad = load ptr, ptr %ap_data, align 8',
        '  %bp_data = getelementptr inbounds %cssc_str, ptr %b, i64 0, i32 2',
        '  %bd = load ptr, ptr %bp_data, align 8',
        '  ; Build a fresh cssc_str header + data buffer in the arena.',
        '  %hdr  = call ptr @cssc_obj_alloc(i64 24)   ; sizeof(cssc_str)',
        '  %dlen = add i64 %total, 1',
        '  %data = call ptr @cssc_obj_alloc(i64 %dlen)',
        '  ; copy A',
        '  br label %ca',
        'ca:',
        '  %ia = phi i64 [0, %entry], [%ian, %sa]',
        '  %adone = icmp uge i64 %ia, %as',
        '  br i1 %adone, label %cb_init, label %sa',
        'sa:',
        '  %asp = getelementptr inbounds i8, ptr %ad, i64 %ia',
        '  %adp = getelementptr inbounds i8, ptr %data, i64 %ia',
        '  %abyte = load i8, ptr %asp, align 1',
        '  store i8 %abyte, ptr %adp, align 1',
        '  %ian = add i64 %ia, 1',
        '  br label %ca',
        'cb_init:',
        '  br label %cb',
        'cb:',
        '  %ib = phi i64 [0, %cb_init], [%ibn, %sb]',
        '  %bdone = icmp uge i64 %ib, %bs',
        '  br i1 %bdone, label %fill, label %sb',
        'sb:',
        '  %bsp = getelementptr inbounds i8, ptr %bd, i64 %ib',
        '  %off = add i64 %as, %ib',
        '  %bdp = getelementptr inbounds i8, ptr %data, i64 %off',
        '  %bbyte = load i8, ptr %bsp, align 1',
        '  store i8 %bbyte, ptr %bdp, align 1',
        '  %ibn = add i64 %ib, 1',
        '  br label %cb',
        'fill:',
        '  %sp = getelementptr inbounds %cssc_str, ptr %hdr, i64 0, i32 0',
        '  store i64 %total, ptr %sp, align 8',
        '  %cp = getelementptr inbounds %cssc_str, ptr %hdr, i64 0, i32 1',
        '  store i64 %total, ptr %cp, align 8',
        '  %dp = getelementptr inbounds %cssc_str, ptr %hdr, i64 0, i32 2',
        '  store ptr %data, ptr %dp, align 8',
        '  ret ptr %hdr',
        '}',
    ]


# ---------------------------------------------------------------------------
# Time. Phase-5 stubs: rough busy-loop sleep, monotonic tick counter from
# a cycle-count global that the boot stub increments via a 1 kHz timer
# (we don't have that yet — for now sleep is a NOP loop and uptime counts
# how many ms the script has spent in cssc_sleep_ms, which approximates
# wall-clock for the typical "loop with mc::sleep(ticks)" shape).
# ---------------------------------------------------------------------------
def _emit_time(profile: str) -> List[str]:
    # Cycles-per-millisecond estimate per chip. ESP8266 default clock is
    # 80 MHz; ESP32 default is 160 MHz; AVR is 16 MHz. A tighter port
    # uses the chip's hardware timer block, but for compile-success this
    # gives the right order of magnitude.
    cycles_per_ms = {'esp8266': 80_000, 'esp32': 160_000, 'avr': 16_000}.get(profile, 80_000)
    return [
        '@.cssc_uptime_ms = internal global i64 0, align 8',
        '',
        'define void @cssc_sleep_ms(i64 %ms) {',
        'entry:',
        '  ; Busy-loop one millisecond at a time so the chip stays responsive',
        '  ; to NMIs / WDT feeds. The inner loop runs `cycles_per_ms` no-ops.',
        '  %nptr = alloca i64, align 8',
        '  store i64 %ms, ptr %nptr, align 8',
        '  br label %outer',
        'outer:',
        '  %n = load i64, ptr %nptr, align 8',
        '  %z = icmp eq i64 %n, 0',
        '  br i1 %z, label %done, label %inner_init',
        'inner_init:',
        '  %ip = alloca i64, align 8',
        f'  store i64 {cycles_per_ms}, ptr %ip, align 8',
        '  br label %inner',
        'inner:',
        '  %ic = load i64, ptr %ip, align 8',
        '  %izero = icmp eq i64 %ic, 0',
        '  br i1 %izero, label %tick, label %burn',
        'burn:',
        '  %ic2 = sub i64 %ic, 1',
        '  store i64 %ic2, ptr %ip, align 8',
        '  br label %inner',
        'tick:',
        '  %ut = load i64, ptr @.cssc_uptime_ms, align 8',
        '  %ut2 = add i64 %ut, 1',
        '  store i64 %ut2, ptr @.cssc_uptime_ms, align 8',
        '  %n2 = sub i64 %n, 1',
        '  store i64 %n2, ptr %nptr, align 8',
        '  br label %outer',
        'done:',
        '  ret void',
        '}',
        '',
        'define double @cssc_uptime() {',
        'entry:',
        '  %ms  = load i64, ptr @.cssc_uptime_ms, align 8',
        '  %msf = sitofp i64 %ms to double',
        '  %s   = fdiv double %msf, 1.000000e+03',
        '  ret double %s',
        '}',
        '',
        'define i64 @cssc_tick() {',
        'entry:',
        '  %ms = load i64, ptr @.cssc_uptime_ms, align 8',
        '  ret i64 %ms',
        '}',
    ]


# ---------------------------------------------------------------------------
# int / float / bool → string. The int formatter writes decimal digits
# into the arena; the float formatter formats as integer-part.dot-tenths
# (good enough for tick counters / uptime); bool returns one of two
# pre-built cssc_str literals.
# ---------------------------------------------------------------------------
def _emit_stringify(profile: str) -> List[str]:
    return [
        '@.cssc_str_true  = internal constant [5 x i8] c"true\\00", align 1',
        '@.cssc_str_false = internal constant [6 x i8] c"false\\00", align 1',
        '',
        'define ptr @cssc_int_to_str(i64 %n) {',
        'entry:',
        '  ; Allocate a 24-byte scratch into the arena; format digits',
        '  ; right-to-left, then materialise via cssc_string_lit.',
        '  %buf = call ptr @cssc_obj_alloc(i64 24)',
        '  %neg = icmp slt i64 %n, 0',
        '  %abs0 = sub i64 0, %n',
        '  %abs  = select i1 %neg, i64 %abs0, i64 %n',
        '  %ip = alloca i64, align 8',
        '  store i64 23, ptr %ip, align 8',
        '  %vp = alloca i64, align 8',
        '  store i64 %abs, ptr %vp, align 8',
        '  ; Place trailing NUL.',
        '  %tail = getelementptr inbounds i8, ptr %buf, i64 23',
        '  store i8 0, ptr %tail, align 1',
        '  br label %check',
        'check:',
        '  %v = load i64, ptr %vp, align 8',
        '  %vz = icmp eq i64 %v, 0',
        '  br i1 %vz, label %check_initial, label %digit',
        'check_initial:',
        '  ; If the value was 0 we still need a "0" digit.',
        '  %i0 = load i64, ptr %ip, align 8',
        '  %wrote = icmp slt i64 %i0, 23',
        '  br i1 %wrote, label %sign_branch, label %zero',
        'zero:',
        '  %ipos0 = sub i64 %i0, 1',
        '  store i64 %ipos0, ptr %ip, align 8',
        '  %dp0 = getelementptr inbounds i8, ptr %buf, i64 %ipos0',
        '  store i8 48, ptr %dp0, align 1',
        '  br label %sign_branch',
        'digit:',
        '  %i = load i64, ptr %ip, align 8',
        '  %ipos = sub i64 %i, 1',
        '  store i64 %ipos, ptr %ip, align 8',
        '  %vd = sdiv i64 %v, 10',
        '  %vm = urem i64 %v, 10',
        '  %ch_i = trunc i64 %vm to i8',
        '  %ch   = add i8 %ch_i, 48',
        '  %dp = getelementptr inbounds i8, ptr %buf, i64 %ipos',
        '  store i8 %ch, ptr %dp, align 1',
        '  store i64 %vd, ptr %vp, align 8',
        '  br label %check',
        'sign_branch:',
        '  br i1 %neg, label %signw, label %ret',
        'signw:',
        '  %is = load i64, ptr %ip, align 8',
        '  %ism = sub i64 %is, 1',
        '  store i64 %ism, ptr %ip, align 8',
        '  %dpm = getelementptr inbounds i8, ptr %buf, i64 %ism',
        '  store i8 45, ptr %dpm, align 1',
        '  br label %ret',
        'ret:',
        '  %fi = load i64, ptr %ip, align 8',
        '  %src = getelementptr inbounds i8, ptr %buf, i64 %fi',
        '  %s = call ptr @cssc_string_lit(ptr %src)',
        '  ret ptr %s',
        '}',
        '',
        'define ptr @cssc_float_to_str(double %x) {',
        'entry:',
        '  ; Approximate float→str: cast to int64, format that.',
        '  ; Real ryu/dragon4 belongs in a follow-up phase; this lets',
        '  ; scripts concatenate uptime/sensor floats with strings without',
        '  ; pulling in a libc dependency.',
        '  %i = fptosi double %x to i64',
        '  %s = call ptr @cssc_int_to_str(i64 %i)',
        '  ret ptr %s',
        '}',
        '',
        'define ptr @cssc_bool_to_str(i1 %b) {',
        'entry:',
        '  br i1 %b, label %tt, label %ff',
        'tt:',
        '  %s1 = call ptr @cssc_string_lit(ptr @.cssc_str_true)',
        '  ret ptr %s1',
        'ff:',
        '  %s2 = call ptr @cssc_string_lit(ptr @.cssc_str_false)',
        '  ret ptr %s2',
        '}',
    ]


# ---------------------------------------------------------------------------
# sysout / sysarg — recorded in chip-local statics. On bare metal the
# "exit code" is meaningless (the CPU just halts), but the symbol still
# has to resolve because the main shim references its global.
# ---------------------------------------------------------------------------
def _emit_sysout_sysarg(profile: str) -> List[str]:
    return [
        '@cssc_argc         = global i32 0, align 4',
        '@cssc_argv         = global ptr null, align 8',
        '@cssc_sysout_value = global i32 0, align 4',
        '',
        'define void @cssc_sysout(i64 %v) {',
        'entry:',
        '  %v32 = trunc i64 %v to i32',
        '  store i32 %v32, ptr @cssc_sysout_value, align 4',
        '  ret void',
        '}',
        '',
        'define i64 @cssc_sysarg_int(i64 %idx) {',
        'entry:',
        '  ; No args on a microcontroller — always 0.',
        '  ret i64 0',
        '}',
    ]


# ---------------------------------------------------------------------------
# Peripheral stubs. Each `_new` allocates an 8-byte arena block (records
# the params for future MMIO ports). Every method is a no-op so user
# code links and runs; the chip just doesn't see the bus / pin / display.
# Replace these per-chip with real MMIO once a target hardware reference
# is wired up.
# ---------------------------------------------------------------------------
def _emit_peripheral_stubs(profile: str) -> List[str]:
    lines: List[str] = [
        '; --- peripheral stubs (bare-metal, no-op until real MMIO lands) ---',
    ]
    # Group every (kind, method, args, retty) we need to define.
    # `_new` shapes follow `_GPIO_NEW_ARITY` from cir_lower.
    NEW_ARGS = {
        'pin':         [('pin', 'i64')],
        'i2c':         [('bus','i64'), ('sda','i64'), ('scl','i64')],
        'spi':         [('bus','i64'), ('sck','i64'), ('miso','i64'), ('mosi','i64')],
        'uart':        [('bus','i64'), ('tx','i64'), ('rx','i64')],
        'adc':         [('pin','i64')],
        'pwm':         [('pin','i64'), ('freq','i64'), ('res','i64')],
        'timer':       [('slot','i64'), ('hz','i64')],
        'tft':         [('ctrl','i64'), ('w','i64'), ('h','i64')],
        'oled':        [('ctrl','i64'), ('w','i64'), ('h','i64'),
                        ('sda','i64'), ('scl','i64'), ('addr','i64')],
        'video':       [('w','i64'), ('h','i64'), ('fps','i64')],
        'matrix':      [('w','i64'), ('h','i64'), ('scale','i64')],
        'framebuffer': [('w','i64'), ('h','i64')],
        'console':     [('w','i64'), ('h','i64')],
    }
    # Method shape: (kind, method, [arg_tys after handle], ret_ty)
    METHODS = [
        ('pin','write',    ['i64'], 'void'),
        ('pin','read',     [],      'i64'),
        ('pin','mode',     ['i64'], 'void'),
        ('pin','toggle',   [],      'void'),
        ('pin','pullup',   ['i64'], 'void'),
        ('i2c','begin',    ['i64'], 'void'),
        ('i2c','write',    ['i64','i64'], 'i64'),
        ('i2c','read',     ['i64'], 'i64'),
        ('spi','begin',    ['i64'], 'void'),
        ('spi','transfer', ['i64'], 'i64'),
        ('uart','begin',   ['i64'], 'void'),
        ('uart','write',   ['i64'], 'void'),
        ('uart','read',    [],      'i64'),
        ('adc','read',     [],      'i64'),
        ('pwm','duty',     ['i64'], 'void'),
        ('timer','start',  [],      'void'),
        ('timer','stop',   [],      'void'),
        ('timer','read',   [],      'i64'),
        ('tft','begin',    [],      'void'),
        ('tft','close',    [],      'void'),
        ('tft','show',     [],      'void'),
        ('tft','fill',     ['i64'], 'void'),
        ('tft','pixel',    ['i64','i64','i64'], 'void'),
        ('tft','line',     ['i64','i64','i64','i64','i64'], 'void'),
        ('tft','rect',     ['i64','i64','i64','i64','i64'], 'void'),
        ('tft','fillrect', ['i64','i64','i64','i64','i64'], 'void'),
        ('tft','circle',   ['i64','i64','i64','i64'], 'void'),
        ('tft','text',     ['i64','i64','ptr','i64','i64'], 'void'),
        ('oled','begin',   [],      'void'),
        ('oled','close',   [],      'void'),
        ('oled','show',    [],      'void'),
        ('oled','fill',    ['i64'], 'void'),
        ('oled','pixel',   ['i64','i64','i64'], 'void'),
        ('oled','line',    ['i64','i64','i64','i64','i64'], 'void'),
        ('oled','rect',    ['i64','i64','i64','i64','i64'], 'void'),
        ('oled','fillrect',['i64','i64','i64','i64','i64'], 'void'),
        ('oled','circle',  ['i64','i64','i64','i64'], 'void'),
        ('oled','text',    ['i64','i64','ptr','i64','i64'], 'void'),
        ('video','begin',  [],      'void'),
        ('video','close',  [],      'void'),
        ('video','clear',  ['i64'], 'void'),
        ('video','present',[],      'void'),
        ('video','is_open',[],      'i64'),
        ('matrix','fill',  ['i64'], 'void'),
        ('matrix','pixel', ['i64','i64','i64'], 'void'),
        ('matrix','show',  [],      'void'),
        ('framebuffer','fill',   ['i64'], 'void'),
        ('framebuffer','pixel',  ['i64','i64','i64'], 'void'),
        ('framebuffer','present',[],      'void'),
        ('console','write',['ptr'], 'void'),
        ('console','clear',[],      'void'),
        ('console','close',[],      'void'),
    ]
    for kind, params in NEW_ARGS.items():
        sig_params = ', '.join(f'{ty} %{nm}' for nm, ty in params)
        lines += [
            f'define ptr @cssc_{kind}_new({sig_params}) {{',
            'entry:',
            f'  %p = call ptr @cssc_obj_alloc(i64 8)',
            '  ret ptr %p',
            '}',
            f'define void @cssc_{kind}_free(ptr %p) {{',
            'entry:  ret void',
            '}',
        ]
    for kind, method, arg_tys, ret_ty in METHODS:
        params = ['ptr %p'] + [f'{t} %a{i}' for i, t in enumerate(arg_tys)]
        sig = f'@cssc_{kind}_{method}({", ".join(params)})'
        if ret_ty == 'void':
            lines += [
                f'define void {sig} {{',
                'entry:  ret void',
                '}',
            ]
        else:
            lines += [
                f'define {ret_ty} {sig} {{',
                f'entry:  ret {ret_ty} 0',
                '}',
            ]
    return lines


__all__ = ['emit_runtime_ll', 'supported_baremetal_symbols']
