/* ==========================================================================
 * cssc_rt_host.c -- HOST validation runtime for the self-hosted Transembly
 * compiler (CCOS project). Re-exports the SAME `cssc_*` ABI as the resident
 * CCOS kernel runtime `cssc_ccos_rt.c`, but backed by the host libc:
 *     serial_putc  -> fputc(stdout)
 *     cssc_obj_alloc -> malloc
 * so that machine code emitted by our compiler (compiler/x86.cssc) can be
 * loaded into executable memory on the host and RUN, with its cssc_* calls
 * resolved to these symbols -- the fast host-first behavioral-parity gate
 * (see harness/run.py). The string ABI is byte-identical:
 *     struct cssc_str { u32 refcount; u32 size; char data[]; }  (data at +8)
 * fmt_i64 / fmt_f64 are copied verbatim so numeric output matches the kernel
 * (and therefore matches `cssc run` for the parity comparison).
 *
 * CALLING CONVENTION (critical): our emitted code + the CCOS runtime use the
 * System V AMD64 ABI (args rdi/rsi/rdx/rcx/r8/r9). Windows uses Microsoft x64
 * (args rcx/rdx/r8/r9). So every runtime function our SysV code calls is
 * marked SYSV (__attribute__((sysv_abi))) on Windows so the host DLL matches
 * the CCOS convention and our backend can always emit SysV. The three
 * ctypes-facing entry points (cssc_rtsym, cssc_rt_call_entry, cssc_rt_flush)
 * stay in the platform-default (MS x64) convention so Python/ctypes can call
 * them; cssc_rt_call_entry is the MS-x64 -> SysV trampoline that invokes the
 * emitted program's entry. On CCOS everything is natively SysV (freestanding),
 * so SYSV is a no-op there and cssc_call_addr is the trivial trampoline.
 *
 * Build (host DLL, clang):
 *   clang -shared -O2 cssc_rt_host.c -o cssc_rt_host.dll   (or .so on posix)
 *
 * Symbol resolution: the compiler records each runtime call target by a fixed
 * small SYMBOL ID; `cssc_rtsym(id)` returns the function address. The harness
 * (or, on CCOS, the compiler itself) patches the emitted `mov rax, imm64`
 * placeholder with that address. Keep the id table APPEND-ONLY and identical
 * to the CCOS-side `cssc_rtsym` so one relocation scheme serves both targets.
 * ========================================================================== */
#include <stdio.h>
#include <stdlib.h>
#include "../cssc_fmt_f64.h" /* shared shortest-round-trip f64 formatter */

typedef unsigned char      u8;
typedef unsigned int       u32;
typedef unsigned long long u64;
typedef long long          i64;

#if defined(_WIN32)
#  define CSSC_EXPORT __declspec(dllexport)
#  define SYSV        __attribute__((sysv_abi))
#else
#  define CSSC_EXPORT __attribute__((visibility("default")))
#  define SYSV
#endif

/* ---- backing primitives (the only host-specific pieces) ------------------ */
static SYSV void serial_putc(char c) { fputc((unsigned char)c, stdout); }
static SYSV void serial_puts(const char *s) { while (*s) serial_putc(*s++); }

SYSV void *cssc_obj_alloc(i64 size) { return malloc((size_t)size); }
SYSV void  cssc_obj_free(void *p)   { free(p); }
SYSV u64   cssc_alloc_raw(u64 n)    { return (u64)cssc_obj_alloc((i64)n); }
SYSV void  cssc_free_raw(u64 p)     { cssc_obj_free((void *)p); }

/* ---- string heap kind (layout MUST match cssc_ccos_rt.c) ----------------- */
typedef struct { u32 refcount; u32 size; char data[]; } cssc_str;

SYSV void *cssc_string_lit(const char *src, i64 len) {
    u64 n = (u64)len;
    cssc_str *s = (cssc_str *)cssc_obj_alloc((i64)(8 + n + 1));
    s->refcount = 1;
    s->size = (u32)n;
    for (u64 i = 0; i < n; i++) s->data[i] = src[i];
    s->data[n] = 0;
    return s;
}
SYSV void  cssc_string_free(void *s) { cssc_obj_free(s); }
SYSV u32   cssc_string_size(void *s) { return ((cssc_str *)s)->size; }
/* Same value, but returned as a full i64 so the compiler's `select` length
 * compare (a signed 64-bit `cursor < len`) can't be fooled by stale high bits
 * of a u32 return. rtsym 41 points here, not at cssc_string_size. */
SYSV i64   cssc_string_len_i64(void *s) { return (i64)((cssc_str *)s)->size; }
/* `select` over a STRING iterates its characters -- the interpreter does
 * list("abc") = ['a','b','c'], a list of fresh 1-char strings. This returns the
 * i-th character as a freshly-allocated 1-char cssc_str (refcount 1), so the
 * loop body can compare it (`char != "%"`), concat it, or copy it. Out of range
 * yields an empty string rather than trapping. */
SYSV void *cssc_string_char_at(void *s, i64 i) {
    cssc_str *x = (cssc_str *)s;
    if (!x || i < 0 || (u64)i >= x->size) return cssc_string_lit("", 0);
    return cssc_string_lit(&x->data[i], 1);
}
SYSV void *cssc_string_data(void *s) { return (void *)((cssc_str *)s)->data; }
SYSV void *cssc_string_concat(void *a, void *b) {
    cssc_str *x = (cssc_str *)a, *y = (cssc_str *)b;
    u64 tot = (u64)x->size + (u64)y->size;
    cssc_str *r = (cssc_str *)cssc_obj_alloc((i64)(8 + tot + 1));
    r->refcount = 1; r->size = (u32)tot;
    for (u32 i = 0; i < x->size; i++) r->data[i] = x->data[i];
    for (u32 i = 0; i < y->size; i++) r->data[x->size + i] = y->data[i];
    r->data[tot] = 0;
    return r;
}
SYSV void *cssc_string_copy(void *s) {
    cssc_str *x = (cssc_str *)s;
    return cssc_string_lit(x->data, (i64)x->size);
}
/* Content equality for two heap strings -> 1/0. `==` on strings must compare
 * TEXT, not pointers (two equal strings are separate allocations). */
SYSV i64 cssc_string_eq(void *a, void *b) {
    cssc_str *x = (cssc_str *)a, *y = (cssc_str *)b;
    if (x == y) return 1;
    if (!x || !y) return 0;
    if (x->size != y->size) return 0;
    for (u32 i = 0; i < x->size; i++) if (x->data[i] != y->data[i]) return 0;
    return 1;
}
SYSV void  cssc_retain(void *s)  { if (s) ((cssc_str *)s)->refcount++; }
SYSV void  cssc_release(void *s) { if (s) { cssc_str *x=(cssc_str*)s; if (x->refcount) x->refcount--; if (x->refcount==0) cssc_obj_free(s); } }

/* ---- number/bool -> string (verbatim layout from cssc_ccos_rt.c) --------- */
static SYSV i64 fmt_i64(char *buf, i64 v) {
    int neg = 0; u64 u; char tmp[24]; int ti = 0, bi = 0;
    if (v < 0) { neg = 1; u = (u64)(-(v + 1)) + 1u; } else { u = (u64)v; }
    if (u == 0) tmp[ti++] = '0';
    while (u) { tmp[ti++] = (char)('0' + (int)(u % 10u)); u /= 10u; }
    if (neg) buf[bi++] = '-';
    while (ti) buf[bi++] = tmp[--ti];
    return bi;
}
SYSV void *cssc_int_to_str(i64 n)  { char b[24]; i64 l = fmt_i64(b, n); return cssc_string_lit(b, l); }
SYSV void *cssc_bool_to_str(int b) { return b ? cssc_string_lit("true", 4) : cssc_string_lit("false", 5); }
/* SHORTEST ROUND-TRIP formatting (Dragon4 + Python-repr presentation) lives in
 * cssc_fmt_f64.h so the host and the CCOS kernel runtime share ONE implementation.
 * The previous integer-part + 6-fixed-digit loop could never match the reference
 * (which prints `2.0`, `1.6`, `0.3333333333333333`, `1e-05`). */
static SYSV i64 fmt_f64(char *buf, double x) {
    return (i64)cssc_fmt_f64_shortest(buf, x);
}
SYSV void *cssc_float_to_str(double x) { char b[48]; i64 l = fmt_f64(b, x); return cssc_string_lit(b, l); }

/* ---- output routed to stdout (matches kernel's COM1 routing) ------------- */
SYSV void cssc_print_newline(void) { serial_putc('\n'); }
SYSV void cssc_out_int(i64 n)      { char b[24]; i64 l = fmt_i64(b, n); for (i64 i=0;i<l;i++) serial_putc(b[i]); }
SYSV void cssc_out_float(double f) { char b[48]; i64 l = fmt_f64(b, f); for (i64 i=0;i<l;i++) serial_putc(b[i]); }
SYSV void cssc_out_bool(int bb)    { serial_puts(bb ? "true" : "false"); }
SYSV void cssc_out_str(const char *s, i64 len) { for (i64 i=0;i<len;i++) serial_putc(s[i]); }
SYSV void cssc_out_string(void *s) { cssc_str *x = (cssc_str *)s; for (u32 i=0;i<x->size;i++) serial_putc(x->data[i]); }
SYSV void cssc_print_int(i64 n)       { cssc_out_int(n);    serial_putc('\n'); }
SYSV void cssc_print_float(double f)  { cssc_out_float(f);  serial_putc('\n'); }
SYSV void cssc_print_bool(int bb)     { cssc_out_bool(bb);  serial_putc('\n'); }
SYSV void cssc_print_str(const char *s, i64 len) { cssc_out_str(s, len); serial_putc('\n'); }
SYSV void cssc_print_string(void *s)  { cssc_out_string(s); serial_putc('\n'); }
/* Reading a name that was `#delete`d yields the literal text `0x0` -- the
 * UNBOUND state, which the reference distinguishes from a variable that merely
 * holds the value 0 (that one prints `0`). See docs/cssc-ownership.md section 6.
 * Type-independent on purpose: the compiler branches on the `alive` cell and
 * calls this instead of whichever typed printer it would otherwise use. */
SYSV void cssc_out_null(void)   { serial_puts("0x0"); }
SYSV void cssc_print_null(void) { serial_puts("0x0"); serial_putc('\n'); }

/* ==========================================================================
 * M7 containers -- growable vector of raw 64-bit cells. An element is just an
 * i64: an integer, an f64 bit pattern, or a heap pointer (string/vector). The
 * COMPILER tracks which, exactly as it does for slots, so the runtime stays
 * type-agnostic. Out-of-range reads return 0 rather than trapping (warn-not-
 * reject). MUST stay in lock-step with the copy in cssc_ccos_rt.c.
 * ========================================================================== */
typedef struct { i64 len; i64 cap; i64 *data; } cssc_vec;

SYSV void *cssc_vec_new(i64 cap) {
    if (cap < 4) cap = 4;
    cssc_vec *v = (cssc_vec *)cssc_obj_alloc((i64)sizeof(cssc_vec));
    v->len = 0; v->cap = cap;
    v->data = (i64 *)cssc_obj_alloc(cap * 8);
    return v;
}
SYSV void cssc_vec_push(void *p, i64 x) {
    cssc_vec *v = (cssc_vec *)p;
    if (!v) return;
    if (v->len == v->cap) {                       /* grow: allocate, copy, free */
        i64 nc = v->cap * 2;
        i64 *nd = (i64 *)cssc_obj_alloc(nc * 8);
        for (i64 i = 0; i < v->len; i++) nd[i] = v->data[i];
        cssc_obj_free(v->data);
        v->data = nd; v->cap = nc;
    }
    v->data[v->len++] = x;
}
SYSV i64 cssc_vec_at(void *p, i64 i) {
    cssc_vec *v = (cssc_vec *)p;
    if (!v || i < 0 || i >= v->len) return 0;
    return v->data[i];
}
SYSV i64 cssc_vec_size(void *p) { cssc_vec *v = (cssc_vec *)p; return v ? v->len : 0; }
SYSV void cssc_vec_set(void *p, i64 i, i64 x) {
    cssc_vec *v = (cssc_vec *)p;
    if (!v || i < 0 || i >= v->len) return;
    v->data[i] = x;
}

/* Remove and return the first / last element. Empty -> 0 (warn-not-reject).
 * pop_front shifts left; vectors here are short, so a memmove-style loop is
 * cheaper than maintaining a head index. */
SYSV i64 cssc_vec_pop_front(void *p) {
    cssc_vec *v = (cssc_vec *)p;
    if (!v || v->len == 0) return 0;
    i64 r = v->data[0];
    for (i64 i = 1; i < v->len; i++) v->data[i - 1] = v->data[i];
    v->len--;
    return r;
}
SYSV i64 cssc_vec_pop_back(void *p) {
    cssc_vec *v = (cssc_vec *)p;
    if (!v || v->len == 0) return 0;
    v->len--;
    return v->data[v->len];
}

/* Map with heap-string keys. Linear probe over parallel key/value arrays --
 * CSSC maps in practice hold a handful of entries, and a linear scan keeps the
 * runtime free of hashing/allocation policy. Keys compare by CONTENT
 * (cssc_string_eq), so a runtime-built key finds a literal-inserted one.
 * Missing key -> 0 (warn-not-reject). Lock-step with cssc_ccos_rt.c. */
typedef struct { i64 len; i64 cap; void **keys; i64 *vals; } cssc_map;

SYSV void *cssc_map_new(i64 cap) {
    if (cap < 4) cap = 4;
    cssc_map *m = (cssc_map *)cssc_obj_alloc((i64)sizeof(cssc_map));
    m->len = 0; m->cap = cap;
    m->keys = (void **)cssc_obj_alloc(cap * 8);
    m->vals = (i64 *)cssc_obj_alloc(cap * 8);
    return m;
}
SYSV void cssc_map_set(void *p, void *k, i64 v) {
    cssc_map *m = (cssc_map *)p;
    if (!m) return;
    for (i64 i = 0; i < m->len; i++)
        if (cssc_string_eq(m->keys[i], k)) { m->vals[i] = v; return; }
    if (m->len == m->cap) {
        i64 nc = m->cap * 2;
        void **nk = (void **)cssc_obj_alloc(nc * 8);
        i64 *nv = (i64 *)cssc_obj_alloc(nc * 8);
        for (i64 i = 0; i < m->len; i++) { nk[i] = m->keys[i]; nv[i] = m->vals[i]; }
        cssc_obj_free(m->keys); cssc_obj_free(m->vals);
        m->keys = nk; m->vals = nv; m->cap = nc;
    }
    m->keys[m->len] = k; m->vals[m->len] = v; m->len++;
}
SYSV i64 cssc_map_get(void *p, void *k) {
    cssc_map *m = (cssc_map *)p;
    if (!m) return 0;
    for (i64 i = 0; i < m->len; i++)
        if (cssc_string_eq(m->keys[i], k)) return m->vals[i];
    return 0;
}
SYSV i64 cssc_map_size(void *p) { cssc_map *m = (cssc_map *)p; return m ? m->len : 0; }
SYSV i64 cssc_map_has(void *p, void *k) {
    cssc_map *m = (cssc_map *)p;
    if (!m) return 0;
    for (i64 i = 0; i < m->len; i++) if (cssc_string_eq(m->keys[i], k)) return 1;
    return 0;
}

/* Tear down a container. The runtime cannot know whether a 64-bit cell is an
 * integer or a string pointer, so the COMPILER passes elemIsStr and we release
 * the elements only when told to. Map keys are always strings. */
SYSV void cssc_vec_free(void *p, i64 elemIsStr) {
    cssc_vec *v = (cssc_vec *)p;
    if (!v) return;
    if (elemIsStr) for (i64 i = 0; i < v->len; i++) cssc_release((void *)v->data[i]);
    cssc_obj_free(v->data);
    cssc_obj_free(v);
}
SYSV void cssc_map_free(void *p, i64 valIsStr) {
    cssc_map *m = (cssc_map *)p;
    if (!m) return;
    for (i64 i = 0; i < m->len; i++) {
        cssc_release(m->keys[i]);
        if (valIsStr) cssc_release((void *)m->vals[i]);
    }
    cssc_obj_free(m->keys);
    cssc_obj_free(m->vals);
    cssc_obj_free(m);
}

/* Deep copy of a container -- this is the `&x` operator. Spec 2.5: `&` is
 * `cssc::copy`, a RECURSIVE deep copy, so element strings are copied too and
 * the result shares nothing with the source. Measured against the reference in
 * docs/cssc-ownership.md (p_copy_vec / p_copy_map): mutating the copy must
 * leave the original untouched. elemIsStr / valIsStr come from the compiler --
 * the only side that knows a 64-bit cell's static type. */
SYSV void *cssc_vec_copy(void *p, i64 elemIsStr) {
    cssc_vec *v = (cssc_vec *)p;
    if (!v) return cssc_vec_new(4);
    cssc_vec *c = (cssc_vec *)cssc_vec_new(v->cap);
    for (i64 i = 0; i < v->len; i++) {
        i64 cell = v->data[i];
        c->data[i] = (elemIsStr && cell) ? (i64)cssc_string_copy((void *)cell)
                                         : cell;
    }
    c->len = v->len;
    return c;
}
SYSV void *cssc_map_copy(void *p, i64 valIsStr) {
    cssc_map *m = (cssc_map *)p;
    if (!m) return cssc_map_new(4);
    cssc_map *c = (cssc_map *)cssc_map_new(m->cap);
    for (i64 i = 0; i < m->len; i++) {
        c->keys[i] = m->keys[i] ? cssc_string_copy(m->keys[i]) : 0;
        i64 cell = m->vals[i];
        c->vals[i] = (valIsStr && cell) ? (i64)cssc_string_copy((void *)cell)
                                        : cell;
    }
    c->len = m->len;
    return c;
}

/* ==========================================================================
 * Runtime symbol table -- the CANONICAL id->function map shared by the host
 * harness and (mirrored) the CCOS `cssc_rtsym`. APPEND ONLY; never renumber.
 * The compiler emits `mov rax, imm64=<placeholder>` for a runtime call and
 * records (operand_offset, sym_id); the loader patches imm64 = cssc_rtsym(id).
 * (Default/MS-x64 convention -- called by Python/ctypes.)
 * ========================================================================== */
CSSC_EXPORT u64 cssc_rtsym(u64 id) {
    switch (id) {
        case 0:  return (u64)&cssc_print_int;
        case 1:  return (u64)&cssc_print_str;
        case 2:  return (u64)&cssc_out_string;
        case 3:  return (u64)&cssc_string_lit;
        case 4:  return (u64)&cssc_string_concat;
        case 5:  return (u64)&cssc_alloc_raw;
        case 6:  return (u64)&cssc_out_int;
        case 7:  return (u64)&cssc_print_string;
        case 8:  return (u64)&cssc_print_newline;
        case 9:  return (u64)&cssc_print_bool;
        case 10: return (u64)&cssc_out_bool;
        case 11: return (u64)&cssc_int_to_str;
        case 12: return (u64)&cssc_bool_to_str;
        case 13: return (u64)&cssc_string_free;
        case 14: return (u64)&cssc_string_copy;
        case 15: return (u64)&cssc_retain;
        case 16: return (u64)&cssc_release;
        case 17: return (u64)&cssc_out_str;
        case 18: return (u64)&cssc_float_to_str;
        case 19: return (u64)&cssc_string_eq;
        case 20: return (u64)&cssc_print_float;   /* arg in XMM0, not RDI */
        case 21: return (u64)&cssc_out_float;     /* arg in XMM0, not RDI */
        case 22: return (u64)&cssc_vec_new;
        case 23: return (u64)&cssc_vec_push;
        case 24: return (u64)&cssc_vec_at;
        case 25: return (u64)&cssc_vec_size;
        case 26: return (u64)&cssc_vec_set;
        case 27: return (u64)&cssc_map_new;
        case 28: return (u64)&cssc_map_set;
        case 29: return (u64)&cssc_map_get;
        case 30: return (u64)&cssc_map_size;
        case 31: return (u64)&cssc_map_has;
        case 32: return (u64)&cssc_vec_pop_front;
        case 33: return (u64)&cssc_vec_pop_back;
        case 34: return (u64)&cssc_vec_free;
        case 35: return (u64)&cssc_map_free;
        case 36: return (u64)&cssc_vec_copy;
        case 37: return (u64)&cssc_map_copy;
        case 38: return (u64)&cssc_print_null;
        case 39: return (u64)&cssc_out_null;
        case 40: return (u64)&cssc_string_char_at;
        case 41: return (u64)&cssc_string_len_i64;
        default: return 0;
    }
}

/* MS-x64 -> SysV trampoline: ctypes calls this (MS x64) with the address of
 * the emitted program's entry; it invokes the entry under the SysV ABI our
 * backend emits, so callee-saved-register expectations never mismatch. */
CSSC_EXPORT void cssc_rt_call_entry(u64 fn) { ((void (SYSV *)(void))fn)(); }

/* Harness flushes host stdout after running the emitted program so its output
 * is observable regardless of libc buffering. */
CSSC_EXPORT void cssc_rt_flush(void) { fflush(stdout); }
