"""x86_64 runtime emitter — Phase 1 emits LLVM IR text.

Produces the `.ll` for the CSSC runtime symbols that the user's compiled
module references. Filters by the symbol-set actually referenced — only
emits what the user's code calls (per-feature TU compilation, see
Doc 10.5b).

The runtime is intentionally tiny in Phase 1:

    cssc_runtime_init           — empty (no globals to initialise yet)
    cssc_runtime_shutdown       — empty (fflush is handled by libc atexit)
    cssc_print_int(i64)         — printf("%lld\n", n)
    cssc_print_bool(i1)         — printf("true\n" / "false\n")
    cssc_print_float(double)    — printf("%g\n", n)
    cssc_print_str(ptr, i64)    — fwrite to stdout + '\n'
    cssc_panic(ptr, i64)        — fwrite to stderr + exit(1)

Phase 2+ extends this with refcount cascade (`cssc_retain`,
`cssc_release`, `cssc_release_internal`), string interning
(`cssc_string_lit`), copy (`cssc_copy`), and over time these migrate from
LLVM IR to raw target-asm with CSSC-specific layout knowledge.
"""
from __future__ import annotations

import os
import platform
import sys
from typing import Iterable, List, Optional, Set


# ---------------------------------------------------------------------------
# Phase D — `-O1` opt-in. The CSSC CLI's `-O1` flag sets `CSSC_OPT_LEVEL=1`
# in the environment (see v6_driver.build_native). Per-helper emit sites
# consult `_opt1_active()` to gate aggressive transformations like
# `alwaysinline` on the refcount fast-paths. Default (no `-O1`) keeps the
# helpers as out-of-line functions so the runtime stays minimal-footprint
# per CSSC's identity. Single opt level only — `-O2`/`-O3` are LLVM-side
# flags driven by `--release`, orthogonal to this knob.
# ---------------------------------------------------------------------------
def _opt1_active() -> bool:
    """True iff the user invoked the build with `--O1` (or set
    `CSSC_OPT_LEVEL=1` in the env). Read fresh each emit so a single
    process can build with and without `-O1` back-to-back without state
    leaking between calls."""
    try:
        return int(os.environ.get('CSSC_OPT_LEVEL', '0') or '0') >= 1
    except (ValueError, TypeError):
        return False


def _opt1_inline_attrs() -> str:
    """Function-attribute string to splice into a `define` header when
    `-O1` is active. Returns ` alwaysinline` (leading space so callers
    can splice it directly into the signature) or empty string."""
    return ' alwaysinline' if _opt1_active() else ''


# ---------------------------------------------------------------------------
# Target triples — must match what cir_to_llvm.default_target_triple() picks.
# ---------------------------------------------------------------------------
def default_target_triple() -> str:
    if sys.platform == 'win32':
        return 'x86_64-pc-windows-msvc'
    if sys.platform == 'darwin':
        m = platform.machine().lower()
        if 'arm' in m or 'aarch64' in m:
            return 'arm64-apple-darwin'
        return 'x86_64-apple-darwin'
    if sys.platform.startswith('linux'):
        return 'x86_64-pc-linux-gnu'
    return 'x86_64-pc-windows-msvc'


# ---------------------------------------------------------------------------
# Runtime symbol registry — every symbol that Phase 1 owns.
# Each entry: emitter function that returns a list of LLVM-IR lines.
# Header globals (format strings, ...) are emitted once per build.
# ---------------------------------------------------------------------------
def _fmt_int() -> str:
    # "%lld\n\0" as a 6-byte private constant.
    return '@.cssc_fmt_int = private unnamed_addr constant [6 x i8] c"%lld\\0A\\00"'


def _fmt_float() -> str:
    return '@.cssc_fmt_float = private unnamed_addr constant [4 x i8] c"%g\\0A\\00"'


def _fmt_true() -> str:
    return '@.cssc_str_true  = private unnamed_addr constant [6 x i8] c"true\\0A\\00"'


def _fmt_false() -> str:
    return '@.cssc_str_false = private unnamed_addr constant [7 x i8] c"false\\0A\\00"'


def _emit_cssc_runtime_init() -> List[str]:
    return [
        'define void @cssc_runtime_init() {',
        'entry:',
        '  ret void',
        '}',
    ]


def _emit_cssc_runtime_shutdown() -> List[str]:
    return [
        'define void @cssc_runtime_shutdown() {',
        'entry:',
        '  ret void',
        '}',
    ]


def _emit_cssc_exit() -> List[str]:
    # `exit(code)` / `cssc::exit(code)` — flush + terminate with the given
    # status. Truncates the i64 CSSC int to the libc `int` exit code.
    return [
        'declare void @exit(i32) noreturn',
        'define void @cssc_exit(i64 %code) {',
        'entry:',
        '  call void @cssc_runtime_shutdown()',
        '  %c32 = trunc i64 %code to i32',
        '  call void @exit(i32 %c32)',
        '  unreachable',
        '}',
    ]


def _emit_cssc_print_int() -> List[str]:
    return [
        'define void @cssc_print_int(i64 %n) {',
        'entry:',
        '  %fmt = getelementptr inbounds [6 x i8], ptr @.cssc_fmt_int, i64 0, i64 0',
        '  %r = call i32 (ptr, ...) @printf(ptr %fmt, i64 %n)',
        '  ret void',
        '}',
    ]


def _emit_cssc_print_newline() -> List[str]:
    """A.3.17: standalone newline emit for `cssc::outln()` with no args.
    Cheaper than going through `printf("%lld\\n", 0)` which printed "0\\n"."""
    return [
        'declare i32 @putchar(i32)',
        'define void @cssc_print_newline() {',
        'entry:',
        '  %r = call i32 @putchar(i32 10)',
        '  ret void',
        '}',
    ]


def _emit_cssc_out_int() -> List[str]:
    return [
        '@.cssc_fmt_int_nl = private unnamed_addr constant [5 x i8] c"%lld\\00"',
        'define void @cssc_out_int(i64 %n) {',
        'entry:',
        '  %fmt = getelementptr inbounds [5 x i8], ptr @.cssc_fmt_int_nl, i64 0, i64 0',
        '  %r = call i32 (ptr, ...) @printf(ptr %fmt, i64 %n)',
        '  ret void',
        '}',
    ]


def _emit_cssc_out_float() -> List[str]:
    return [
        # Same shortest-round-trip repr() logic as cssc_print_float, without the
        # trailing newline. Deliberately INLINED rather than sharing a helper:
        # each runtime symbol is emitted independently on demand, so a shared
        # definition would either be missing or defined twice.
        '@.cssc_repr_gstar_o = private unnamed_addr constant [5 x i8] c"%.*g\\00"',
        '@.cssc_repr_s_o     = private unnamed_addr constant [3 x i8] c"%s\\00"',
        'declare i32 @snprintf(ptr, i64, ptr, ...)',
        'declare double @strtod(ptr, ptr)',
        'define void @cssc_out_float(double %f) {',
        'entry:',
        '  %buf = alloca [64 x i8], align 16',
        '  %bp = getelementptr inbounds [64 x i8], ptr %buf, i64 0, i64 0',
        '  %gf = getelementptr inbounds [5 x i8], ptr @.cssc_repr_gstar_o, i64 0, i64 0',
        '  br label %loop',
        'loop:',
        '  %p = phi i32 [ 1, %entry ], [ %pn, %next ]',
        '  %n = call i32 (ptr, i64, ptr, ...) @snprintf(ptr %bp, i64 64, ptr %gf, i32 %p, double %f)',
        '  %d = call double @strtod(ptr %bp, ptr null)',
        '  %eq = fcmp oeq double %d, %f',
        '  %mx = icmp sge i32 %p, 17',
        '  %st = or i1 %eq, %mx',
        '  br i1 %st, label %scan, label %next',
        'next:',
        '  %pn = add i32 %p, 1',
        '  br label %loop',
        'scan:',
        '  %i = phi i64 [ 0, %loop ], [ %i1, %sn ]',
        '  %pc = getelementptr inbounds i8, ptr %bp, i64 %i',
        '  %c = load i8, ptr %pc',
        '  %z = icmp eq i8 %c, 0',
        '  br i1 %z, label %addz, label %chk',
        'chk:',
        '  %c1 = icmp eq i8 %c, 46',
        '  %c2 = icmp eq i8 %c, 101',
        '  %c3 = icmp eq i8 %c, 110',
        '  %c4 = icmp eq i8 %c, 105',
        '  %o1 = or i1 %c1, %c2',
        '  %o2 = or i1 %c3, %c4',
        '  %any = or i1 %o1, %o2',
        '  br i1 %any, label %out, label %sn',
        'sn:',
        '  %i1 = add i64 %i, 1',
        '  br label %scan',
        'addz:',
        '  %e0 = getelementptr inbounds i8, ptr %bp, i64 %i',
        '  store i8 46, ptr %e0',
        '  %j1 = add i64 %i, 1',
        '  %e1 = getelementptr inbounds i8, ptr %bp, i64 %j1',
        '  store i8 48, ptr %e1',
        '  %j2 = add i64 %i, 2',
        '  %e2 = getelementptr inbounds i8, ptr %bp, i64 %j2',
        '  store i8 0, ptr %e2',
        '  br label %out',
        'out:',
        '  %sf = getelementptr inbounds [3 x i8], ptr @.cssc_repr_s_o, i64 0, i64 0',
        '  %r = call i32 (ptr, ...) @printf(ptr %sf, ptr %bp)',
        '  ret void',
        '}',
    ]


def _emit_cssc_out_bool() -> List[str]:
    return [
        '@.cssc_str_true_nl  = private unnamed_addr constant [5 x i8] c"true\\00"',
        '@.cssc_str_false_nl = private unnamed_addr constant [6 x i8] c"false\\00"',
        'define void @cssc_out_bool(i1 %b) {',
        'entry:',
        '  br i1 %b, label %yes, label %no',
        'yes:',
        '  %fy = getelementptr inbounds [5 x i8], ptr @.cssc_str_true_nl, i64 0, i64 0',
        '  %ry = call i32 (ptr, ...) @printf(ptr %fy)',
        '  ret void',
        'no:',
        '  %fn = getelementptr inbounds [6 x i8], ptr @.cssc_str_false_nl, i64 0, i64 0',
        '  %rn = call i32 (ptr, ...) @printf(ptr %fn)',
        '  ret void',
        '}',
    ]


def _emit_cssc_out_str() -> List[str]:
    """Write `len` bytes of `s` to stdout WITHOUT a trailing newline."""
    if sys.platform == 'win32':
        return [
            'declare ptr @__acrt_iob_func(i32)',
            'declare i64 @fwrite(ptr, i64, i64, ptr)',
            'define void @cssc_out_str(ptr %s, i64 %len) {',
            'entry:',
            '  %io = call ptr @__acrt_iob_func(i32 1)',
            '  %w = call i64 @fwrite(ptr %s, i64 1, i64 %len, ptr %io)',
            '  ret void',
            '}',
        ]
    return [
        '@stdout = external global ptr',
        'declare i64 @fwrite(ptr, i64, i64, ptr)',
        'define void @cssc_out_str(ptr %s, i64 %len) {',
        'entry:',
        '  %io = load ptr, ptr @stdout',
        '  %w = call i64 @fwrite(ptr %s, i64 1, i64 %len, ptr %io)',
        '  ret void',
        '}',
    ]


def _emit_cssc_out_string() -> List[str]:
    # `cssc_out_string` lives outside the string group so the `%cssc_str`
    # type isn't declared in this TU. Route through the public helpers
    # `cssc_string_size` / `cssc_string_data` instead of direct struct
    # GEPs — those helpers ARE in the string group and the emitter's
    # dup-declare elision keeps the IR from carrying duplicate
    # `declare`s when both groups are pulled in.
    return [
        'define void @cssc_out_string(ptr %s) {',
        'entry:',
        '  %is_null = icmp eq ptr %s, null',
        '  br i1 %is_null, label %done, label %live',
        'live:',
        '  %size = call i64 @cssc_string_size(ptr %s)',
        '  %data = call ptr @cssc_string_data(ptr %s)',
        '  call void @cssc_out_str(ptr %data, i64 %size)',
        '  br label %done',
        'done:',
        '  ret void',
        '}',
    ]


def _emit_cssc_print_float() -> List[str]:
    return [
        # SHORTEST ROUND-TRIP, matching the reference interpreter's repr():
        # plain "%g" prints 2.0 as "2" and 1/3 as "0.333333". Try increasing
        # precision until the text parses back to the SAME double (snprintf %g
        # and strtod are both correctly rounded, so the first hit is the
        # shortest), then force a ".0" when the result carries no '.', 'e',
        # 'n'(an) or 'i'(nf). %.{p}g additionally reproduces repr()'s
        # fixed/exponent switch, so no extra presentation logic is needed.
        '@.cssc_repr_gstar = private unnamed_addr constant [5 x i8] c"%.*g\\00"',
        '@.cssc_repr_snl   = private unnamed_addr constant [4 x i8] c"%s\\0A\\00"',
        'declare i32 @snprintf(ptr, i64, ptr, ...)',
        'declare double @strtod(ptr, ptr)',
        'define void @cssc_print_float(double %f) {',
        'entry:',
        '  %buf = alloca [64 x i8], align 16',
        '  %bp = getelementptr inbounds [64 x i8], ptr %buf, i64 0, i64 0',
        '  %gf = getelementptr inbounds [5 x i8], ptr @.cssc_repr_gstar, i64 0, i64 0',
        '  br label %loop',
        'loop:',
        '  %p = phi i32 [ 1, %entry ], [ %pn, %next ]',
        '  %n = call i32 (ptr, i64, ptr, ...) @snprintf(ptr %bp, i64 64, ptr %gf, i32 %p, double %f)',
        '  %d = call double @strtod(ptr %bp, ptr null)',
        '  %eq = fcmp oeq double %d, %f',
        '  %mx = icmp sge i32 %p, 17',
        '  %st = or i1 %eq, %mx',
        '  br i1 %st, label %scan, label %next',
        'next:',
        '  %pn = add i32 %p, 1',
        '  br label %loop',
        'scan:',
        '  %i = phi i64 [ 0, %loop ], [ %i1, %sn ]',
        '  %pc = getelementptr inbounds i8, ptr %bp, i64 %i',
        '  %c = load i8, ptr %pc',
        '  %z = icmp eq i8 %c, 0',
        '  br i1 %z, label %addz, label %chk',
        'chk:',
        '  %c1 = icmp eq i8 %c, 46',
        '  %c2 = icmp eq i8 %c, 101',
        '  %c3 = icmp eq i8 %c, 110',
        '  %c4 = icmp eq i8 %c, 105',
        '  %o1 = or i1 %c1, %c2',
        '  %o2 = or i1 %c3, %c4',
        '  %any = or i1 %o1, %o2',
        '  br i1 %any, label %out, label %sn',
        'sn:',
        '  %i1 = add i64 %i, 1',
        '  br label %scan',
        'addz:',
        '  %e0 = getelementptr inbounds i8, ptr %bp, i64 %i',
        '  store i8 46, ptr %e0',
        '  %j1 = add i64 %i, 1',
        '  %e1 = getelementptr inbounds i8, ptr %bp, i64 %j1',
        '  store i8 48, ptr %e1',
        '  %j2 = add i64 %i, 2',
        '  %e2 = getelementptr inbounds i8, ptr %bp, i64 %j2',
        '  store i8 0, ptr %e2',
        '  br label %out',
        'out:',
        '  %sf = getelementptr inbounds [4 x i8], ptr @.cssc_repr_snl, i64 0, i64 0',
        '  %r = call i32 (ptr, ...) @printf(ptr %sf, ptr %bp)',
        '  ret void',
        '}',
    ]


def _emit_cssc_print_bool() -> List[str]:
    return [
        'define void @cssc_print_bool(i1 %b) {',
        'entry:',
        '  br i1 %b, label %yes, label %no',
        'yes:',
        '  %fy = getelementptr inbounds [6 x i8], ptr @.cssc_str_true, i64 0, i64 0',
        '  %ry = call i32 (ptr, ...) @printf(ptr %fy)',
        '  ret void',
        'no:',
        '  %fn = getelementptr inbounds [7 x i8], ptr @.cssc_str_false, i64 0, i64 0',
        '  %rn = call i32 (ptr, ...) @printf(ptr %fn)',
        '  ret void',
        '}',
    ]


def _emit_cssc_print_str() -> List[str]:
    # fwrite(s, 1, len, stdout); putchar('\n');
    # On Windows msvcrt, stdout is `__acrt_iob_func(1)`; on POSIX libc, `stdout`
    # is a real global. We use `fwrite` against a per-platform shim:
    # - Windows: declare __acrt_iob_func(i32) and call fwrite(..., %iob)
    # - Linux/macOS: declare @stdout as external global and load it
    if sys.platform == 'win32':
        return [
            'declare ptr @__acrt_iob_func(i32)',
            'declare i64 @fwrite(ptr, i64, i64, ptr)',
            'declare i32 @fputc(i32, ptr)',
            '',
            'define void @cssc_print_str(ptr %s, i64 %len) {',
            'entry:',
            '  %io = call ptr @__acrt_iob_func(i32 1)',
            '  %w = call i64 @fwrite(ptr %s, i64 1, i64 %len, ptr %io)',
            '  %nl = call i32 @fputc(i32 10, ptr %io)',
            '  ret void',
            '}',
        ]
    return [
        '@stdout = external global ptr',
        'declare i64 @fwrite(ptr, i64, i64, ptr)',
        'declare i32 @fputc(i32, ptr)',
        '',
        'define void @cssc_print_str(ptr %s, i64 %len) {',
        'entry:',
        '  %io = load ptr, ptr @stdout',
        '  %w = call i64 @fwrite(ptr %s, i64 1, i64 %len, ptr %io)',
        '  %nl = call i32 @fputc(i32 10, ptr %io)',
        '  ret void',
        '}',
    ]


def _emit_cssc_panic() -> List[str]:
    """`cssc_panic(ptr msg, i64 len)` — print to stdout and exit(1).

    Uses printf (declared at the top of the runtime) for portability —
    `@__acrt_iob_func`/`fwrite` differ between MSVC and MinGW link
    targets, but `printf` with a `%.*s` format works on every libc.
    """
    return [
        '@.panic_fmt = private unnamed_addr constant [6 x i8] c"%.*s\\0A\\00"',
        'declare void @exit(i32) noreturn',
        '',
        'define void @cssc_panic(ptr %s, i64 %len) {',
        'entry:',
        '  %len32 = trunc i64 %len to i32',
        '  %r = call i32 (ptr, ...) @printf(ptr @.panic_fmt, i32 %len32, ptr %s)',
        '  call void @exit(i32 1)',
        '  unreachable',
        '}',
    ]


def _emit_cssc_vector_int() -> List[str]:
    """Phase 3 — vector<int> runtime as LLVM IR over libc malloc/realloc/free.

    Header layout (24 bytes):
        struct cssc_vec_int {
            i64 size;       // offset 0
            i64 capacity;   // offset 8
            ptr data;       // offset 16 — heap-allocated int64 array
        };

    Symbols emitted as a group: new / free / size / push / get / set.
    """
    # All five functions share the malloc/realloc/free import, plus the
    # internal header GEPs. We emit them as a single block of IR.
    return [
        'declare ptr @malloc(i64)',
        'declare ptr @realloc(ptr, i64)',
        'declare void @free(ptr)',
        'declare void @abort() noreturn',
        '',
        '; struct cssc_vec_int { i64 size; i64 cap; ptr data; }',
        '%cssc_vec_int = type { i64, i64, ptr }',
        '',
        'define ptr @cssc_vector_new_int(i64 %cap_hint) {',
        'entry:',
        '  %hdr = call ptr @malloc(i64 24)',
        '  %cap0 = icmp sgt i64 %cap_hint, 0',
        '  %cap = select i1 %cap0, i64 %cap_hint, i64 4',
        '  %data_bytes = mul i64 %cap, 8',
        '  %data = call ptr @malloc(i64 %data_bytes)',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %hdr, i64 0, i32 0',
        '  store i64 0, ptr %size_p',
        '  %cap_p = getelementptr inbounds %cssc_vec_int, ptr %hdr, i64 0, i32 1',
        '  store i64 %cap, ptr %cap_p',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %hdr, i64 0, i32 2',
        '  store ptr %data, ptr %data_p',
        '  ret ptr %hdr',
        '}',
        '',
        'define void @cssc_vector_free_int(ptr %v) {',
        'entry:',
        '  %is_null = icmp eq ptr %v, null',
        '  br i1 %is_null, label %done, label %free.it',
        'free.it:',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p',
        '  call void @free(ptr %data)',
        '  call void @free(ptr %v)',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        'define i64 @cssc_vector_size_int(ptr %v) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  ret i64 %size',
        '}',
        '',
        'define void @cssc_vector_push_int(ptr %v, i64 %val) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %cap_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %full = icmp eq i64 %size, %cap',
        '  br i1 %full, label %grow, label %store',
        'grow:',
        '  %newcap = shl i64 %cap, 1',
        '  %newbytes = mul i64 %newcap, 8',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %old_data = load ptr, ptr %data_p',
        '  %new_data = call ptr @realloc(ptr %old_data, i64 %newbytes)',
        '  store ptr %new_data, ptr %data_p',
        '  store i64 %newcap, ptr %cap_p',
        '  br label %store',
        'store:',
        '  %data_p2 = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p2',
        '  %slot = getelementptr inbounds i64, ptr %data, i64 %size',
        '  store i64 %val, ptr %slot',
        '  %new_size = add i64 %size, 1',
        '  store i64 %new_size, ptr %size_p',
        '  ret void',
        '}',
        '',
        'define i64 @cssc_vector_get_int(ptr %v, i64 %idx) {',
        'entry:',
        '  ; raw index: no bounds check (CSSC vision: OOB is UB like a C array)',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p',
        '  %slot = getelementptr inbounds i64, ptr %data, i64 %idx',
        '  %val = load i64, ptr %slot',
        '  ret i64 %val',
        '}',
        '',
        'define void @cssc_vector_set_int(ptr %v, i64 %idx, i64 %val) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %neg = icmp slt i64 %idx, 0',
        '  %oob = icmp sge i64 %idx, %size',
        '  %bad = or i1 %neg, %oob',
        '  br i1 %bad, label %panic, label %ok',
        'panic:',
        '  call void @abort()',
        '  unreachable',
        'ok:',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p',
        '  %slot = getelementptr inbounds i64, ptr %data, i64 %idx',
        '  store i64 %val, ptr %slot',
        '  ret void',
        '}',
        '',
        'define i64 @cssc_vector_pop_back_int(ptr %v) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %empty = icmp eq i64 %size, 0',
        '  br i1 %empty, label %panic, label %ok',
        'panic:',
        '  call void @abort()',
        '  unreachable',
        'ok:',
        '  %new_size = sub i64 %size, 1',
        '  store i64 %new_size, ptr %size_p',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p',
        '  %slot = getelementptr inbounds i64, ptr %data, i64 %new_size',
        '  %val = load i64, ptr %slot',
        '  ret i64 %val',
        '}',
        '',
        'define void @cssc_vector_clear_int(ptr %v) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  store i64 0, ptr %size_p',
        '  ret void',
        '}',
        '',
        # pop_front: return element 0, shift the rest left by one, size--.
        # O(n) but matches the interpreter's `pop_front` / `takeout(0)`.
        # Element slot is i64 (a raw int OR a cssc_str* for the
        # vector<auto> collapse), so the same shift moves both.
        'define i64 @cssc_vector_pop_front_int(ptr %v) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %empty = icmp eq i64 %size, 0',
        '  br i1 %empty, label %panic, label %ok',
        'panic:',
        '  call void @abort()',
        '  unreachable',
        'ok:',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p',
        '  %first = load i64, ptr %data',
        '  %new_size = sub i64 %size, 1',
        '  br label %loop',
        'loop:',
        '  %i = phi i64 [ 0, %ok ], [ %inext, %body ]',
        '  %cont = icmp ult i64 %i, %new_size',
        '  br i1 %cont, label %body, label %done',
        'body:',
        '  %inext = add i64 %i, 1',
        '  %src = getelementptr inbounds i64, ptr %data, i64 %inext',
        '  %dst = getelementptr inbounds i64, ptr %data, i64 %i',
        '  %sv = load i64, ptr %src',
        '  store i64 %sv, ptr %dst',
        '  br label %loop',
        'done:',
        '  store i64 %new_size, ptr %size_p',
        '  ret i64 %first',
        '}',
    ]


# Vector symbols are emitted as a group from a single emitter — they share
# the %cssc_vec_int struct declaration. We register each public name to the
# same group-emitter and dedupe in emit_runtime_ll.
_VECTOR_INT_SYMBOLS = frozenset({
    'cssc_vector_new_int',
    'cssc_vector_free_int',
    'cssc_vector_size_int',
    'cssc_vector_push_int',
    'cssc_vector_get_int',
    'cssc_vector_set_int',
    'cssc_vector_pop_back_int',
    'cssc_vector_pop_front_int',
    'cssc_vector_clear_int',
})


def _emit_cssc_vector_float() -> List[str]:
    """Phase 3 — vector<float> runtime, parallel to vector<int>.

    Layout is identical except `data` points to a heap-allocated `double[]`
    (also 8 bytes per element, so malloc/realloc math reuses the int math).

    Emits a self-contained prelude (libc decls + struct) so this group can
    stand alone when vector<int> isn't referenced. The module-level
    deduper (`_dedupe_declares`) collapses duplicates when both groups
    are emitted together.
    """
    return [
        'declare ptr @malloc(i64)',
        'declare ptr @realloc(ptr, i64)',
        'declare void @free(ptr)',
        'declare void @abort() noreturn',
        '',
        '; struct cssc_vec_int { i64 size; i64 cap; ptr data; }',
        '%cssc_vec_int = type { i64, i64, ptr }',
        '',
        '; vector<float> — parallels the vector<int> runtime; reuses %cssc_vec_int',
        '; layout since `data` is just a heap-allocated array of 8-byte values.',
        '',
        'define ptr @cssc_vector_new_float(i64 %cap_hint) {',
        'entry:',
        '  %hdr = call ptr @malloc(i64 24)',
        '  %cap0 = icmp sgt i64 %cap_hint, 0',
        '  %cap = select i1 %cap0, i64 %cap_hint, i64 4',
        '  %data_bytes = mul i64 %cap, 8',
        '  %data = call ptr @malloc(i64 %data_bytes)',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %hdr, i64 0, i32 0',
        '  store i64 0, ptr %size_p',
        '  %cap_p = getelementptr inbounds %cssc_vec_int, ptr %hdr, i64 0, i32 1',
        '  store i64 %cap, ptr %cap_p',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %hdr, i64 0, i32 2',
        '  store ptr %data, ptr %data_p',
        '  ret ptr %hdr',
        '}',
        '',
        'define void @cssc_vector_free_float(ptr %v) {',
        'entry:',
        '  %is_null = icmp eq ptr %v, null',
        '  br i1 %is_null, label %done, label %free.it',
        'free.it:',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p',
        '  call void @free(ptr %data)',
        '  call void @free(ptr %v)',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        'define i64 @cssc_vector_size_float(ptr %v) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  ret i64 %size',
        '}',
        '',
        'define void @cssc_vector_push_float(ptr %v, double %val) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %cap_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %full = icmp eq i64 %size, %cap',
        '  br i1 %full, label %grow, label %store',
        'grow:',
        '  %newcap = shl i64 %cap, 1',
        '  %newbytes = mul i64 %newcap, 8',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %old_data = load ptr, ptr %data_p',
        '  %new_data = call ptr @realloc(ptr %old_data, i64 %newbytes)',
        '  store ptr %new_data, ptr %data_p',
        '  store i64 %newcap, ptr %cap_p',
        '  br label %store',
        'store:',
        '  %data_p2 = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p2',
        '  %slot = getelementptr inbounds double, ptr %data, i64 %size',
        '  store double %val, ptr %slot',
        '  %new_size = add i64 %size, 1',
        '  store i64 %new_size, ptr %size_p',
        '  ret void',
        '}',
        '',
        'define double @cssc_vector_get_float(ptr %v, i64 %idx) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %neg = icmp slt i64 %idx, 0',
        '  %oob = icmp sge i64 %idx, %size',
        '  %bad = or i1 %neg, %oob',
        '  br i1 %bad, label %panic, label %ok',
        'panic:',
        '  call void @abort()',
        '  unreachable',
        'ok:',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p',
        '  %slot = getelementptr inbounds double, ptr %data, i64 %idx',
        '  %val = load double, ptr %slot',
        '  ret double %val',
        '}',
        '',
        'define void @cssc_vector_set_float(ptr %v, i64 %idx, double %val) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %neg = icmp slt i64 %idx, 0',
        '  %oob = icmp sge i64 %idx, %size',
        '  %bad = or i1 %neg, %oob',
        '  br i1 %bad, label %panic, label %ok',
        'panic:',
        '  call void @abort()',
        '  unreachable',
        'ok:',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p',
        '  %slot = getelementptr inbounds double, ptr %data, i64 %idx',
        '  store double %val, ptr %slot',
        '  ret void',
        '}',
        '',
        'define double @cssc_vector_pop_back_float(ptr %v) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %empty = icmp eq i64 %size, 0',
        '  br i1 %empty, label %panic, label %ok',
        'panic:',
        '  call void @abort()',
        '  unreachable',
        'ok:',
        '  %new_size = sub i64 %size, 1',
        '  store i64 %new_size, ptr %size_p',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p',
        '  %slot = getelementptr inbounds double, ptr %data, i64 %new_size',
        '  %val = load double, ptr %slot',
        '  ret double %val',
        '}',
        '',
        'define void @cssc_vector_clear_float(ptr %v) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  store i64 0, ptr %size_p',
        '  ret void',
        '}',
    ]


_VECTOR_FLOAT_SYMBOLS = frozenset({
    'cssc_vector_new_float',
    'cssc_vector_free_float',
    'cssc_vector_size_float',
    'cssc_vector_push_float',
    'cssc_vector_get_float',
    'cssc_vector_set_float',
    'cssc_vector_pop_back_float',
    'cssc_vector_clear_float',
})


def _emit_cssc_vector_bool() -> List[str]:
    """Phase A.1 — vector<bool> / array<bool> runtime.

    Storage layout mirrors `%cssc_vec_int` (i64 size + i64 cap + ptr data),
    but `data` is a flat `i8[]` heap buffer — 1 byte per bool. The ABI
    accepts i1 on push/set; LLVM zero-extends to i8 on the store, and
    truncs back to i1 on the load. `cssc_array_bool_free` is registered
    as an alias so array_bool (immutable) shares the same free helper.
    """
    return [
        'declare ptr @malloc(i64)',
        'declare ptr @realloc(ptr, i64)',
        'declare void @free(ptr)',
        'declare void @abort() noreturn',
        '',
        '; struct cssc_vec_int { i64 size; i64 cap; ptr data; }',
        '%cssc_vec_int = type { i64, i64, ptr }',
        '',
        '; vector<bool> / array<bool> — 1 byte per element (no bitpacking;',
        '; aim for simplicity + uniform GEP-by-i8 arithmetic).',
        '',
        'define ptr @cssc_vector_new_bool(i64 %cap_hint) {',
        'entry:',
        '  %hdr = call ptr @malloc(i64 24)',
        '  %cap0 = icmp sgt i64 %cap_hint, 0',
        '  %cap = select i1 %cap0, i64 %cap_hint, i64 4',
        '  %data = call ptr @malloc(i64 %cap)',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %hdr, i64 0, i32 0',
        '  store i64 0, ptr %size_p',
        '  %cap_p = getelementptr inbounds %cssc_vec_int, ptr %hdr, i64 0, i32 1',
        '  store i64 %cap, ptr %cap_p',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %hdr, i64 0, i32 2',
        '  store ptr %data, ptr %data_p',
        '  ret ptr %hdr',
        '}',
        '',
        'define void @cssc_vector_free_bool(ptr %v) {',
        'entry:',
        '  %is_null = icmp eq ptr %v, null',
        '  br i1 %is_null, label %done, label %free.it',
        'free.it:',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p',
        '  call void @free(ptr %data)',
        '  call void @free(ptr %v)',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        '; cssc_array_bool_free — alias used by the immutable array<bool>',
        '; lowering path; identical semantics to cssc_vector_free_bool.',
        'define void @cssc_array_bool_free(ptr %v) {',
        'entry:',
        '  call void @cssc_vector_free_bool(ptr %v)',
        '  ret void',
        '}',
        '',
        'define i64 @cssc_vector_size_bool(ptr %v) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  ret i64 %size',
        '}',
        '',
        'define void @cssc_vector_push_bool(ptr %v, i1 %val) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %cap_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %full = icmp eq i64 %size, %cap',
        '  br i1 %full, label %grow, label %store',
        'grow:',
        '  %newcap = shl i64 %cap, 1',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %old_data = load ptr, ptr %data_p',
        '  %new_data = call ptr @realloc(ptr %old_data, i64 %newcap)',
        '  store ptr %new_data, ptr %data_p',
        '  store i64 %newcap, ptr %cap_p',
        '  br label %store',
        'store:',
        '  %data_p2 = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p2',
        '  %slot = getelementptr inbounds i8, ptr %data, i64 %size',
        '  %val_i8 = zext i1 %val to i8',
        '  store i8 %val_i8, ptr %slot',
        '  %new_size = add i64 %size, 1',
        '  store i64 %new_size, ptr %size_p',
        '  ret void',
        '}',
        '',
        'define i1 @cssc_vector_get_bool(ptr %v, i64 %idx) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %neg = icmp slt i64 %idx, 0',
        '  %oob = icmp sge i64 %idx, %size',
        '  %bad = or i1 %neg, %oob',
        '  br i1 %bad, label %panic, label %ok',
        'panic:',
        '  call void @abort()',
        '  unreachable',
        'ok:',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p',
        '  %slot = getelementptr inbounds i8, ptr %data, i64 %idx',
        '  %val_i8 = load i8, ptr %slot',
        '  %val = trunc i8 %val_i8 to i1',
        '  ret i1 %val',
        '}',
        '',
        'define void @cssc_vector_set_bool(ptr %v, i64 %idx, i1 %val) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %neg = icmp slt i64 %idx, 0',
        '  %oob = icmp sge i64 %idx, %size',
        '  %bad = or i1 %neg, %oob',
        '  br i1 %bad, label %panic, label %ok',
        'panic:',
        '  call void @abort()',
        '  unreachable',
        'ok:',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p',
        '  %slot = getelementptr inbounds i8, ptr %data, i64 %idx',
        '  %val_i8 = zext i1 %val to i8',
        '  store i8 %val_i8, ptr %slot',
        '  ret void',
        '}',
        '',
        'define i1 @cssc_vector_pop_back_bool(ptr %v) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %empty = icmp eq i64 %size, 0',
        '  br i1 %empty, label %panic, label %ok',
        'panic:',
        '  call void @abort()',
        '  unreachable',
        'ok:',
        '  %new_size = sub i64 %size, 1',
        '  store i64 %new_size, ptr %size_p',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p',
        '  %slot = getelementptr inbounds i8, ptr %data, i64 %new_size',
        '  %val_i8 = load i8, ptr %slot',
        '  %val = trunc i8 %val_i8 to i1',
        '  ret i1 %val',
        '}',
        '',
        'define void @cssc_vector_clear_bool(ptr %v) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  store i64 0, ptr %size_p',
        '  ret void',
        '}',
    ]


_VECTOR_BOOL_SYMBOLS = frozenset({
    'cssc_vector_new_bool',
    'cssc_vector_free_bool',
    'cssc_vector_size_bool',
    'cssc_vector_push_bool',
    'cssc_vector_get_bool',
    'cssc_vector_set_bool',
    'cssc_vector_pop_back_bool',
    'cssc_vector_clear_bool',
    'cssc_array_bool_free',
})


def _emit_cssc_vector_string() -> List[str]:
    """Phase 5b — vector<string> / array<string> runtime.

    Storage layout mirrors %cssc_vec_int exactly — `data` is a flat
    `ptr[]` of `cssc_str*` entries (8 bytes per slot on host, 4 bytes
    on Xtensa; this is host so 8). Each entry is refcount-managed:
      * `push_string` adopts the caller's refcount (no extra retain;
        the call site cssc_releases the local SSA after push to keep
        the net refcount unchanged).
      * `free_string` walks every live entry and cssc_releases it
        before freeing the header + data buffer.
      * `null_at` cssc_releases the entry at idx and writes a null
        ptr — slot stays live, size/cap unchanged (analogous to
        cssc_vector_int_null_at writing 0).

    The runtime suffix is `string`, matching `_vector_traits('array_
    string')['rt']` so the existing `_init_vector` lowering routes
    pushes via `cssc_vector_push_string`.
    """
    return [
        'declare ptr @malloc(i64)',
        'declare ptr @realloc(ptr, i64)',
        'declare void @free(ptr)',
        'declare void @abort() noreturn',
        '; cssc_release: defined by the `string` group (which always',
        '; co-emits in the same runtime.ll). No declare here — clang',
        '; treats `declare X` + `define X` in the same module as a',
        '; redefinition on the Windows host triple. The string group',
        '; is forced into the requested-set below to guarantee the',
        '; define lands before this group consumes the symbol.',
        '',
        '; struct cssc_vec_int { i64 size; i64 cap; ptr data; }',
        '%cssc_vec_int = type { i64, i64, ptr }',
        '',
        '; vector<string> — entries are cssc_str* (heap-allocated, refcount-',
        '; managed). The container owns ONE ref per stored entry.',
        '',
        'define ptr @cssc_vector_new_string(i64 %cap_hint) {',
        'entry:',
        '  %hdr = call ptr @malloc(i64 24)',
        '  %cap0 = icmp sgt i64 %cap_hint, 0',
        '  %cap = select i1 %cap0, i64 %cap_hint, i64 4',
        '  %data_bytes = mul i64 %cap, 8',   # ptr is 8 bytes on host
        '  %data = call ptr @malloc(i64 %data_bytes)',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %hdr, i64 0, i32 0',
        '  store i64 0, ptr %size_p',
        '  %cap_p = getelementptr inbounds %cssc_vec_int, ptr %hdr, i64 0, i32 1',
        '  store i64 %cap, ptr %cap_p',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %hdr, i64 0, i32 2',
        '  store ptr %data, ptr %data_p',
        '  ; Zero-init the data buffer so iteration over an unpopulated tail',
        '  ; sees NULL (cssc_release tolerates NULL). Same loop pattern as the',
        '  ; push grow path; small fixed cap keeps init cost low.',
        '  br label %zero.loop',
        'zero.loop:',
        '  %i = phi i64 [ 0, %entry ], [ %i.next, %zero.body ]',
        '  %done = icmp uge i64 %i, %cap',
        '  br i1 %done, label %zero.exit, label %zero.body',
        'zero.body:',
        '  %slot = getelementptr inbounds ptr, ptr %data, i64 %i',
        '  store ptr null, ptr %slot',
        '  %i.next = add i64 %i, 1',
        '  br label %zero.loop',
        'zero.exit:',
        '  ret ptr %hdr',
        '}',
        '',
        'define void @cssc_vector_free_string(ptr %v) {',
        'entry:',
        '  %is_null = icmp eq ptr %v, null',
        '  br i1 %is_null, label %done, label %free.it',
        'free.it:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p',
        '  br label %rel.loop',
        'rel.loop:',
        '  %i = phi i64 [ 0, %free.it ], [ %i.next, %rel.body ]',
        '  %past = icmp uge i64 %i, %size',
        '  br i1 %past, label %rel.exit, label %rel.body',
        'rel.body:',
        '  %slot = getelementptr inbounds ptr, ptr %data, i64 %i',
        '  %entry_ptr = load ptr, ptr %slot',
        '  call void @cssc_release(ptr %entry_ptr)',
        '  %i.next = add i64 %i, 1',
        '  br label %rel.loop',
        'rel.exit:',
        '  call void @free(ptr %data)',
        '  call void @free(ptr %v)',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        '; cssc_array_string_free — alias used by the Xtensa-paired',
        '; release dispatch (`_h_slot_release` sym_map). Same impl.',
        'define void @cssc_array_string_free(ptr %v) {',
        'entry:',
        '  call void @cssc_vector_free_string(ptr %v)',
        '  ret void',
        '}',
        '',
        'define i64 @cssc_vector_size_string(ptr %v) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  ret i64 %size',
        '}',
        '',
        'define void @cssc_vector_push_string(ptr %v, ptr %s) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %cap_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %full = icmp eq i64 %size, %cap',
        '  br i1 %full, label %grow, label %store',
        'grow:',
        '  %newcap = shl i64 %cap, 1',
        '  %newbytes = mul i64 %newcap, 8',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %old_data = load ptr, ptr %data_p',
        '  %new_data = call ptr @realloc(ptr %old_data, i64 %newbytes)',
        '  ; Zero-init the freshly-grown half so unpopulated tail entries',
        '  ; are NULL (next free pass cssc_releases NULL safely).',
        '  br label %zfill.loop',
        'zfill.loop:',
        '  %zi = phi i64 [ %cap, %grow ], [ %zi.next, %zfill.body ]',
        '  %zdone = icmp uge i64 %zi, %newcap',
        '  br i1 %zdone, label %zfill.exit, label %zfill.body',
        'zfill.body:',
        '  %zslot = getelementptr inbounds ptr, ptr %new_data, i64 %zi',
        '  store ptr null, ptr %zslot',
        '  %zi.next = add i64 %zi, 1',
        '  br label %zfill.loop',
        'zfill.exit:',
        '  store ptr %new_data, ptr %data_p',
        '  store i64 %newcap, ptr %cap_p',
        '  br label %store',
        'store:',
        '  %data_p2 = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p2',
        '  %slot = getelementptr inbounds ptr, ptr %data, i64 %size',
        '  store ptr %s, ptr %slot',
        '  %new_size = add i64 %size, 1',
        '  store i64 %new_size, ptr %size_p',
        '  ret void',
        '}',
        '',
        'define ptr @cssc_vector_get_string(ptr %v, i64 %idx) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %neg = icmp slt i64 %idx, 0',
        '  %oob = icmp sge i64 %idx, %size',
        '  %bad = or i1 %neg, %oob',
        '  br i1 %bad, label %panic, label %ok',
        'panic:',
        '  call void @abort()',
        '  unreachable',
        'ok:',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p',
        '  %slot = getelementptr inbounds ptr, ptr %data, i64 %idx',
        '  %val = load ptr, ptr %slot',
        '  ret ptr %val',
        '}',
        '',
        'define void @cssc_vector_set_string(ptr %v, i64 %idx, ptr %s) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %neg = icmp slt i64 %idx, 0',
        '  %oob = icmp sge i64 %idx, %size',
        '  %bad = or i1 %neg, %oob',
        '  br i1 %bad, label %panic, label %ok',
        'panic:',
        '  call void @abort()',
        '  unreachable',
        'ok:',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p',
        '  %slot = getelementptr inbounds ptr, ptr %data, i64 %idx',
        '  ; Release the old entry before overwriting so the container',
        '  ; never leaks. NULL-safe (cssc_release tolerates NULL).',
        '  %old = load ptr, ptr %slot',
        '  call void @cssc_release(ptr %old)',
        '  store ptr %s, ptr %slot',
        '  ret void',
        '}',
        '',
        'define void @cssc_vector_null_at_string(ptr %v, i64 %idx) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %neg = icmp slt i64 %idx, 0',
        '  %oob = icmp sge i64 %idx, %size',
        '  %bad = or i1 %neg, %oob',
        '  br i1 %bad, label %done, label %ok',
        'ok:',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p',
        '  %slot = getelementptr inbounds ptr, ptr %data, i64 %idx',
        '  %old = load ptr, ptr %slot',
        '  call void @cssc_release(ptr %old)',
        '  store ptr null, ptr %slot',
        '  br label %done',
        'done:',
        '  ret void',
        '}',
        '',
        'define void @cssc_vector_null_all_string(ptr %v) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p',
        '  br label %loop',
        'loop:',
        '  %i = phi i64 [ 0, %entry ], [ %i.next, %body ]',
        '  %done2 = icmp uge i64 %i, %size',
        '  br i1 %done2, label %exit, label %body',
        'body:',
        '  %slot = getelementptr inbounds ptr, ptr %data, i64 %i',
        '  %old = load ptr, ptr %slot',
        '  call void @cssc_release(ptr %old)',
        '  store ptr null, ptr %slot',
        '  %i.next = add i64 %i, 1',
        '  br label %loop',
        'exit:',
        '  ret void',
        '}',
        '',
        'define void @cssc_vector_clear_string(ptr %v) {',
        'entry:',
        '  ; clear = null every entry + reset size to 0',
        '  call void @cssc_vector_null_all_string(ptr %v)',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  store i64 0, ptr %size_p',
        '  ret void',
        '}',
        '',
        '; Phase A.2: pop_back_string TRANSFERS ownership — vector forgets the',
        '; entry (size -= 1, slot nulled WITHOUT release) so the returned ptr',
        '; keeps its existing refcount and lands in the caller as a live owner.',
        '; Caller must cssc_release the result when done. Returns NULL on empty.',
        'define ptr @cssc_vector_pop_back_string(ptr %v) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %empty = icmp eq i64 %size, 0',
        '  br i1 %empty, label %empty_ret, label %ok',
        'empty_ret:',
        '  ret ptr null',
        'ok:',
        '  %new_size = sub i64 %size, 1',
        '  store i64 %new_size, ptr %size_p',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p',
        '  %slot = getelementptr inbounds ptr, ptr %data, i64 %new_size',
        '  %val = load ptr, ptr %slot',
        '  store ptr null, ptr %slot           ; vector forgets without release',
        '  ret ptr %val',
        '}',
    ]


_VECTOR_STRING_SYMBOLS = frozenset({
    'cssc_vector_new_string',
    'cssc_vector_free_string',
    'cssc_vector_size_string',
    'cssc_vector_push_string',
    'cssc_vector_get_string',
    'cssc_vector_set_string',
    'cssc_vector_pop_back_string',  # Phase A.2 — owner-transfer pop
    'cssc_vector_null_at_string',
    'cssc_vector_null_all_string',
    'cssc_vector_clear_string',
    # Alias used by the slot-release dispatch for `array_string`.
    'cssc_array_string_free',
})


def _emit_cssc_string() -> List[str]:
    """Phase 3 — heap-allocated UTF-8 string runtime with refcount cascade.

    Layout (A.3.4 refcount cascade; 32 bytes with padding on 64-bit):
        struct cssc_str {
            i32 refcount;     // own + slot-adoptions (1 on fresh alloc)
            i32 size;         // bytes used (no terminator)
            i32 capacity;     // bytes allocated
            // 4 bytes implicit padding for ptr alignment
            ptr data;         // heap byte buffer
        };

    The refcount lives in field index 0 so the same `getelementptr ... i32 0`
    works on every cssc_str regardless of architecture pointer size. Size/cap
    follow at field indices 1/2; data is field index 3.

    Symbols emitted as a group:
      cssc_string_lit(ptr lit, i64 len) -> ptr     ; copy literal into fresh heap str (refcount=1)
      cssc_string_free(ptr s)                       ; frees data + struct (called by cssc_release@0)
      cssc_retain(ptr s)                            ; refcount++ (NULL-safe)
      cssc_release(ptr s)                           ; refcount--; if 0 -> cssc_string_free
      cssc_print_string(ptr s)                      ; fwrite s.data of s.size + '\n'
      cssc_string_size(ptr s) -> i64                ; reads size field

    Empty strings still allocate a 1-byte data buffer so the slot_release
    path always has a non-null pointer to free without special-casing.
    """
    # The stdio shim is platform-dependent: Windows uses __acrt_iob_func(1)
    # to fetch stdout; POSIX libc has a real `stdout` global.
    if sys.platform == 'win32':
        io_get = '  %io = call ptr @__acrt_iob_func(i32 1)'
        stdio_decl = ['declare ptr @__acrt_iob_func(i32)']
    else:
        io_get = '  %io = load ptr, ptr @stdout'
        stdio_decl = ['@stdout = external global ptr']
    return [
        '',
        '; --- cssc_str: heap-allocated UTF-8 string (refcount cascade) ---',
        ';',
        '; Layout (B1+B2 RSS optimisation):',
        ';   { i32 refcount, i32 size, [0 x i8] data_inline }',
        ';',
        '; B1: dropped the unused `capacity` field (was always == size on',
        ';     fresh alloc; strings are immutable in v6 so it never updates).',
        '; B2: dropped the separate `ptr data` field — inline the data',
        ';     buffer using the LLVM `[0 x i8]` flexible-array idiom. The',
        ';     whole string is now ONE malloc instead of two. Cuts per-',
        ';     string allocator overhead in half (one malloc bucket per',
        ';     string instead of two) AND drops 12 B per string from the',
        ';     header (8 B was capacity+data; +4 B alignment hole gone).',
        ';',
        '; Header total: 8 bytes. Field offsets are LOAD-BEARING — every',
        '; emit site below uses field indices 0 (refcount), 1 (size), 2',
        '; (data_inline). The previous layout had 4 fields (refcount=0,',
        '; size=1, cap=2, data=3); after B1+B2 it has 3 (refcount=0,',
        '; size=1, data_inline=2). If you reshape further, update EVERY',
        '; cssc_str GEP in this file in lockstep.',
        '%cssc_str = type { i32, i32, [0 x i8] }',
        '',
        'declare ptr @malloc(i64)',
        'declare void @free(ptr)',
        'declare ptr @memcpy(ptr, ptr, i64)',
        'declare i64 @fwrite(ptr, i64, i64, ptr)',
        'declare i32 @fputc(i32, ptr)',
        *stdio_decl,
        '',
        'define ptr @cssc_string_lit(ptr %src, i64 %len) {',
        'entry:',
        '  ; B2 + NUL-termination: allocate len+1 bytes for data so the',
        '  ; buffer is a valid C string. `size` still tracks `len` (no',
        '  ; terminator); the trailing byte at data[len] = 0 lets C code',
        '  ; that expects a NUL-terminated string (strlen, PlaySoundA,',
        '  ; my host_extras drawText) work correctly on cssc_string_data',
        '  ; output. Empty strings still allocate 1 byte for the sentinel.',
        '  %data_bytes = add i64 %len, 1',
        '  %total = add i64 8, %data_bytes',
        '  %hdr = call ptr @malloc(i64 %total)',
        '  %rc_p = getelementptr inbounds %cssc_str, ptr %hdr, i64 0, i32 0',
        '  store i32 1, ptr %rc_p',
        '  %size_p = getelementptr inbounds %cssc_str, ptr %hdr, i64 0, i32 1',
        '  %len32 = trunc i64 %len to i32',
        '  store i32 %len32, ptr %size_p',
        '  %data_inline = getelementptr inbounds %cssc_str, ptr %hdr, i64 0, i32 2',
        '  %cpy = call ptr @memcpy(ptr %data_inline, ptr %src, i64 %len)',
        '  %nul_p = getelementptr inbounds i8, ptr %data_inline, i64 %len',
        '  store i8 0, ptr %nul_p',
        '  ret ptr %hdr',
        '}',
        '',
        'define void @cssc_string_free(ptr %s) {',
        'entry:',
        '  %is_null = icmp eq ptr %s, null',
        '  br i1 %is_null, label %done, label %free.it',
        'free.it:',
        '  ; B2: single free (data is inline in the same block as the header).',
        '  call void @free(ptr %s)',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        '; cssc_retain: refcount++ (NULL-safe). Emitted whenever a slot',
        '; adopts a shared heap pointer (string-slot init from identifier,',
        '; arrow_assign aliasing, etc.).',
        ';',
        '; Phase D1 (`--O1`): when the user opts into CSSC\'s -O1, mark',
        '; the function `alwaysinline` so LLVM inlines every call site.',
        '; Saves ~7-12 bytes per call site (no call/ret overhead) and a',
        '; pipeline stall for the indirect branch — string-heavy code',
        '; sees measurable speedup. Default (no -O1): plain function so',
        '; the runtime stays minimal-footprint per CSSC\'s identity.',
        'define void @cssc_retain(ptr %s)' + _opt1_inline_attrs() + ' {',
        'entry:',
        '  %is_null = icmp eq ptr %s, null',
        '  br i1 %is_null, label %done, label %bump',
        'bump:',
        '  %rc_p = getelementptr inbounds %cssc_str, ptr %s, i64 0, i32 0',
        '  %rc = load i32, ptr %rc_p',
        '  %rc_n = add i32 %rc, 1',
        '  store i32 %rc_n, ptr %rc_p',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        '; cssc_release: refcount--; if it hit zero call cssc_string_free.',
        '; The branch lets slot_release fire unconditionally without any',
        '; CIR-side liveness analysis — sharing is encoded in the refcount.',
        'define void @cssc_release(ptr %s) {',
        'entry:',
        '  %is_null = icmp eq ptr %s, null',
        '  br i1 %is_null, label %done, label %decr',
        'decr:',
        '  %rc_p = getelementptr inbounds %cssc_str, ptr %s, i64 0, i32 0',
        '  %rc = load i32, ptr %rc_p',
        '  %rc_n = sub i32 %rc, 1',
        '  store i32 %rc_n, ptr %rc_p',
        '  %zero = icmp eq i32 %rc_n, 0',
        '  br i1 %zero, label %free.it, label %done',
        'free.it:',
        '  call void @cssc_string_free(ptr %s)',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        '; cssc_scope_push / cssc_scope_pop — host pair are stubs because',
        '; the host runtime uses libc malloc with refcount-driven release.',
        '; Transient heap-temps without owner are released explicitly by',
        '; the CIR-lowering at the call site. The symbols still exist so',
        '; the cir_to_llvm scope-wrap can call them uniformly across',
        '; targets (Xtensa/AVR provide the arena-rewind implementation).',
        'define void @cssc_scope_push() {',
        'entry:',
        '  call void @cssc_alias_open_frame()',
        '  ret void',
        '}',
        '',
        'define void @cssc_scope_pop() {',
        'entry:',
        '  call void @cssc_alias_close_frame()',
        '  ret void',
        '}',
        '',
        ';; v6 ref-by-default plumbing (spec §2.5). Production-quality',
        ';; host implementation: a fixed-size pending-link queue + a',
        ';; per-call-frame alias table. Cross-frame `#delete[param]`',
        ';; zeroes the caller-slot\'s 8 bytes (matching the interpreter\'s',
        ';; cross-frame invalidation rule).',
        ';;',
        ';; Data layout:',
        ';;   @.cssc_pending_links   — array of {param_ptr, caller_addr}',
        ';;                            pairs awaiting consumption by',
        ';;                            the next scope_push.',
        ';;   @.cssc_pending_count   — number of entries currently in',
        ';;                            the pending queue.',
        ';;   @.cssc_alias_frames    — stack of N alias tables (one',
        ';;                            per active call frame). Each',
        ';;                            entry is {param_ptr, caller_addr}.',
        ';;   @.cssc_alias_frame_starts — start-index into',
        ';;                            cssc_alias_frames per frame.',
        ';;   @.cssc_alias_depth     — current frame count.',
        ';;',
        ';; Caps: CSSC_MAX_PENDING=4 per call, CSSC_MAX_ALIASES=16 across',
        ';; all live frames, CSSC_MAX_FRAMES=8 (matches typical max scope',
        ';; depth — was 32, audit-shrunk after typical-program profiling',
        ';; showed <10 aliases + <8 nested frames). Total static cost:',
        ';;   pending  = 4 × 16 = 64 B',
        ';;   frames   = 16 × 16 = 256 B',
        ';;   starts   = 8 × 4 = 32 B',
        ';;   ends     = 8 × 4 = 32 B',
        ';;   depth/total = 8 B',
        ';;   ──────── total 392 B (was ~1416 B, -1024 B saved per binary).',
        ';; Overflow paths in cssc_arg_link / cssc_alias_open_frame skip',
        ';; the entry instead of corrupting — deep-recursion programs see',
        ';; lost aliases (silent NULLs from cross-frame delete) rather',
        ';; than memory corruption. Sizes can be re-raised per-program',
        ';; via a future build-flag if a script genuinely needs them.',
        '%struct.cssc_link = type { ptr, ptr }',
        '@.cssc_pending_links = global [4 x %struct.cssc_link] zeroinitializer',
        '@.cssc_pending_count = global i32 0',
        '@.cssc_alias_frames  = global [16 x %struct.cssc_link] zeroinitializer',
        '@.cssc_alias_frame_starts = global [8 x i32] zeroinitializer',
        '@.cssc_alias_frame_ends   = global [8 x i32] zeroinitializer',
        '@.cssc_alias_depth   = global i32 0',
        '@.cssc_alias_total   = global i32 0',
        '',
        'define void @cssc_arg_link(ptr %param, ptr %caller) {',
        'entry:',
        '  %cnt = load i32, ptr @.cssc_pending_count, align 4',
        '  %full = icmp uge i32 %cnt, 4',
        '  br i1 %full, label %done, label %store',
        'store:',
        '  %slot = getelementptr inbounds [4 x %struct.cssc_link], '
            'ptr @.cssc_pending_links, i32 0, i32 %cnt',
        '  %p_field = getelementptr inbounds %struct.cssc_link, '
            'ptr %slot, i32 0, i32 0',
        '  store ptr %param, ptr %p_field, align 8',
        '  %c_field = getelementptr inbounds %struct.cssc_link, '
            'ptr %slot, i32 0, i32 1',
        '  store ptr %caller, ptr %c_field, align 8',
        '  %cnt1 = add i32 %cnt, 1',
        '  store i32 %cnt1, ptr @.cssc_pending_count, align 4',
        '  br label %done',
        'done:',
        '  ret void',
        '}',
        '',
        ';; Internal helper: consume pending links into a new alias frame.',
        ';; Called from cssc_scope_push (which is a no-op for storage but',
        ';; now also opens a new alias frame).',
        'define internal void @cssc_alias_open_frame() {',
        'entry:',
        '  %depth = load i32, ptr @.cssc_alias_depth, align 4',
        '  %depth_full = icmp uge i32 %depth, 8',
        '  br i1 %depth_full, label %skip, label %open',
        'open:',
        '  %total = load i32, ptr @.cssc_alias_total, align 4',
        '  %start_slot = getelementptr inbounds [8 x i32], '
            'ptr @.cssc_alias_frame_starts, i32 0, i32 %depth',
        '  store i32 %total, ptr %start_slot, align 4',
        '  ;; Copy pending → frame entries.',
        '  %pcnt = load i32, ptr @.cssc_pending_count, align 4',
        '  %end = add i32 %total, %pcnt',
        '  %end_full = icmp ugt i32 %end, 16',
        '  br i1 %end_full, label %clear_pending, label %copy',
        'copy:',
        '  br label %loop',
        'loop:',
        '  %i = phi i32 [0, %copy], [%i1, %loop_body]',
        '  %done_i = icmp uge i32 %i, %pcnt',
        '  br i1 %done_i, label %finish, label %loop_body',
        'loop_body:',
        '  %src = getelementptr inbounds [4 x %struct.cssc_link], '
            'ptr @.cssc_pending_links, i32 0, i32 %i',
        '  %src_p = getelementptr inbounds %struct.cssc_link, '
            'ptr %src, i32 0, i32 0',
        '  %src_c = getelementptr inbounds %struct.cssc_link, '
            'ptr %src, i32 0, i32 1',
        '  %pp = load ptr, ptr %src_p, align 8',
        '  %cc = load ptr, ptr %src_c, align 8',
        '  %dst_idx = add i32 %total, %i',
        '  %dst = getelementptr inbounds [16 x %struct.cssc_link], '
            'ptr @.cssc_alias_frames, i32 0, i32 %dst_idx',
        '  %dst_p = getelementptr inbounds %struct.cssc_link, '
            'ptr %dst, i32 0, i32 0',
        '  %dst_c = getelementptr inbounds %struct.cssc_link, '
            'ptr %dst, i32 0, i32 1',
        '  store ptr %pp, ptr %dst_p, align 8',
        '  store ptr %cc, ptr %dst_c, align 8',
        '  %i1 = add i32 %i, 1',
        '  br label %loop',
        'finish:',
        '  %end_slot = getelementptr inbounds [8 x i32], '
            'ptr @.cssc_alias_frame_ends, i32 0, i32 %depth',
        '  store i32 %end, ptr %end_slot, align 4',
        '  store i32 %end, ptr @.cssc_alias_total, align 4',
        '  %depth1 = add i32 %depth, 1',
        '  store i32 %depth1, ptr @.cssc_alias_depth, align 4',
        '  br label %clear_pending',
        'clear_pending:',
        '  store i32 0, ptr @.cssc_pending_count, align 4',
        '  br label %skip',
        'skip:',
        '  ret void',
        '}',
        '',
        ';; Internal helper: close the topmost alias frame. Called from',
        ';; cssc_scope_pop.',
        'define internal void @cssc_alias_close_frame() {',
        'entry:',
        '  %depth = load i32, ptr @.cssc_alias_depth, align 4',
        '  %empty = icmp eq i32 %depth, 0',
        '  br i1 %empty, label %done, label %close',
        'close:',
        '  %depth1 = sub i32 %depth, 1',
        '  store i32 %depth1, ptr @.cssc_alias_depth, align 4',
        '  ;; Roll back cssc_alias_total to this frame\'s start so the',
        '  ;; next push reuses the slots.',
        '  %start_slot = getelementptr inbounds [8 x i32], '
            'ptr @.cssc_alias_frame_starts, i32 0, i32 %depth1',
        '  %start = load i32, ptr %start_slot, align 4',
        '  store i32 %start, ptr @.cssc_alias_total, align 4',
        '  br label %done',
        'done:',
        '  ret void',
        '}',
        '',
        ';; cssc_scope_delete_aliased(name) — look up `name` in the TOP',
        ';; alias frame; if found, zero 8 bytes at the caller slot\'s',
        ';; address. The caller\'s slot is now "deleted" — subsequent',
        ';; reads return 0 / 0x0, matching the spec §2.5 invariant.',
        ';;',
        ';; Name comparison is pointer-equality on interned strings. The',
        ';; cssc_string_lit emitter de-dupes identical literals into one',
        ';; pointer, so `cssc_arg_link(p,..)` and the matching',
        ';; `cssc_scope_delete_aliased(p)` always see the same `p` value.',
        'define void @cssc_scope_delete_aliased(ptr %name) {',
        'entry:',
        '  %depth = load i32, ptr @.cssc_alias_depth, align 4',
        '  %empty = icmp eq i32 %depth, 0',
        '  br i1 %empty, label %done, label %lookup',
        'lookup:',
        '  %depth_m1 = sub i32 %depth, 1',
        '  %start_slot = getelementptr inbounds [8 x i32], '
            'ptr @.cssc_alias_frame_starts, i32 0, i32 %depth_m1',
        '  %end_slot = getelementptr inbounds [8 x i32], '
            'ptr @.cssc_alias_frame_ends, i32 0, i32 %depth_m1',
        '  %start = load i32, ptr %start_slot, align 4',
        '  %end = load i32, ptr %end_slot, align 4',
        '  br label %loop',
        'loop:',
        '  %i = phi i32 [%start, %lookup], [%i1, %loop_continue]',
        '  %done_i = icmp uge i32 %i, %end',
        '  br i1 %done_i, label %done, label %check',
        'check:',
        '  %ent = getelementptr inbounds [16 x %struct.cssc_link], '
            'ptr @.cssc_alias_frames, i32 0, i32 %i',
        '  %ent_p = getelementptr inbounds %struct.cssc_link, '
            'ptr %ent, i32 0, i32 0',
        '  %p = load ptr, ptr %ent_p, align 8',
        '  %match = icmp eq ptr %p, %name',
        '  br i1 %match, label %zero_caller, label %loop_continue',
        'zero_caller:',
        '  %ent_c = getelementptr inbounds %struct.cssc_link, '
            'ptr %ent, i32 0, i32 1',
        '  %caller_addr = load ptr, ptr %ent_c, align 8',
        '  ;; Zero 8 bytes at the caller slot\'s address.',
        '  store i64 0, ptr %caller_addr, align 1',
        '  ;; Wipe this alias entry so we don\'t re-trigger on a later',
        '  ;; same-named delete (defensive — should not happen in well-',
        '  ;; formed code but matches the runtime\'s "one-shot" semantics).',
        '  store ptr null, ptr %ent_p, align 8',
        '  br label %done',
        'loop_continue:',
        '  %i1 = add i32 %i, 1',
        '  br label %loop',
        'done:',
        '  ret void',
        '}',
        '',
        ';; v6 mirror live-ref re-fetch helper. Called by the function',
        ';; epilogue (`_emit_mirror_epilogue_ret` in cir_lower.py) when a',
        ';; `mirror x;` (bare-ident ref form) was emitted in the body.',
        ';; addr=0 means "no live ref" → return 0. Otherwise dereference',
        ';; the 8 bytes at the address. CSSC `#delete` zeroes the slot',
        ';; before releasing the heap header, so re-fetching after a delete',
        ';; reliably gives 0 — matches interpreter invalidation semantics.',
        'define i64 @cssc_load_i64_at(i64 %addr) {',
        'entry:',
        '  %is_null = icmp eq i64 %addr, 0',
        '  br i1 %is_null, label %zero, label %deref',
        'deref:',
        '  %p = inttoptr i64 %addr to ptr',
        '  %v = load i64, ptr %p, align 1',
        '  ret i64 %v',
        'zero:',
        '  ret i64 0',
        '}',
        '',
        'define i64 @cssc_string_size(ptr %s) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_str, ptr %s, i64 0, i32 1',
        '  %size32 = load i32, ptr %size_p',
        '  %size = zext i32 %size32 to i64',
        '  ret i64 %size',
        '}',
        '',
        'define ptr @cssc_string_data(ptr %s) {',
        'entry:',
        '  ; B2: data lives inline at field 2 — just GEP, no load.',
        '  %data = getelementptr inbounds %cssc_str, ptr %s, i64 0, i32 2',
        '  ret ptr %data',
        '}',
        '',
        # Doc §3.3 byte-level string mutation: `s[i] = c;`. Writes one
        # byte at offset `i` of the cssc_str's inline data buffer.
        # NULL-safe + bounds-checked silent-ignore (mismatching writes
        # silently no-op rather than corrupting adjacent heap).
        'define void @cssc_string_set_byte(ptr %s, i64 %i, i64 %c) {',
        'entry:',
        '  %is_null = icmp eq ptr %s, null',
        '  br i1 %is_null, label %done, label %check',
        'check:',
        '  %size_p = getelementptr inbounds %cssc_str, ptr %s, i64 0, i32 1',
        '  %size32 = load i32, ptr %size_p',
        '  %size = zext i32 %size32 to i64',
        '  %ok = icmp ult i64 %i, %size',
        '  br i1 %ok, label %store, label %done',
        'store:',
        '  %data = getelementptr inbounds %cssc_str, ptr %s, i64 0, i32 2',
        '  %slot = getelementptr inbounds i8, ptr %data, i64 %i',
        '  %byte = trunc i64 %c to i8',
        '  store i8 %byte, ptr %slot',
        '  br label %done',
        'done:',
        '  ret void',
        '}',
        '',
        'define i64 @cssc_string_get_byte(ptr %s, i64 %i) {',
        'entry:',
        '  %is_null = icmp eq ptr %s, null',
        '  br i1 %is_null, label %null, label %check',
        'null:',
        '  ret i64 0',
        'check:',
        '  %size_p = getelementptr inbounds %cssc_str, ptr %s, i64 0, i32 1',
        '  %size32 = load i32, ptr %size_p',
        '  %size = zext i32 %size32 to i64',
        '  %ok = icmp ult i64 %i, %size',
        '  br i1 %ok, label %load, label %oob',
        'oob:',
        '  ret i64 0',
        'load:',
        '  %data = getelementptr inbounds %cssc_str, ptr %s, i64 0, i32 2',
        '  %slot = getelementptr inbounds i8, ptr %data, i64 %i',
        '  %byte = load i8, ptr %slot',
        '  %asciiDigit = sub i8 %byte, 48',
        '  %inRange = icmp ult i8 %asciiDigit, 10',
        '  %digit = select i1 %inRange, i8 %asciiDigit, i8 %byte',
        '  %val = zext i8 %digit to i64',
        '  ret i64 %val',
        '}',
        '',
        'define void @cssc_print_string(ptr %s) {',
        'entry:',
        '  ; Spec §5.4 bare-block fallback: outer-scope reads without',
        '  ; `#req` resolve to a null cssc_str* sentinel. Dereferencing',
        '  ; that null below would segfault; short-circuit to print the',
        '  ; literal "0x0" + newline so the user sees the value the',
        '  ; compiler warned about.',
        '  %is_null = icmp eq ptr %s, null',
        '  br i1 %is_null, label %nullpath, label %live',
        'nullpath:',
        io_get.replace('%io ', '%io_null ') + '  ; fetch stdout (null branch)',
        '  %w0 = call i64 @fwrite(ptr @.str.cssc_null_sentinel, i64 1, i64 3, ptr %io_null)',
        '  %nl0 = call i32 @fputc(i32 10, ptr %io_null)',
        '  ret void',
        'live:',
        '  %size_p = getelementptr inbounds %cssc_str, ptr %s, i64 0, i32 1',
        '  %size32 = load i32, ptr %size_p',
        '  %size = zext i32 %size32 to i64',
        '  %data = getelementptr inbounds %cssc_str, ptr %s, i64 0, i32 2',
        io_get + '  ; fetch stdout',
        '  %w = call i64 @fwrite(ptr %data, i64 1, i64 %size, ptr %io)',
        '  %nl = call i32 @fputc(i32 10, ptr %io)',
        '  ret void',
        '}',
        '',
        # `select (string) ?ch` yields each character as a fresh 1-char
        # cssc_str (Doc §3.3: `s[i]` is a 1-char string, both engines).
        # Built from the inline data ptr + cssc_string_lit(src, 1), which
        # deep-copies the single byte into a new heap string the caller
        # owns. Callers must release it (the select label release does).
        'define ptr @cssc_string_char_at(ptr %s, i64 %i) {',
        'entry:',
        '  %is_null = icmp eq ptr %s, null',
        '  br i1 %is_null, label %nul, label %ok',
        'nul:',
        '  %e = call ptr @cssc_string_lit(ptr null, i64 0)',
        '  ret ptr %e',
        'ok:',
        '  %data = call ptr @cssc_string_data(ptr %s)',
        '  %cp = getelementptr inbounds i8, ptr %data, i64 %i',
        '  %r = call ptr @cssc_string_lit(ptr %cp, i64 1)',
        '  ret ptr %r',
        '}',
        '',
        '@.str.cssc_null_sentinel = private unnamed_addr constant [3 x i8] c"0x0", align 1',
    ]


_STRING_SYMBOLS = frozenset({
    'cssc_string_lit',
    'cssc_string_free',
    'cssc_string_size',
    'cssc_string_data',
    'cssc_string_set_byte',
    'cssc_string_get_byte',
    'cssc_string_char_at',
    'cssc_print_string',
    'cssc_string_concat',
    'cssc_string_concat_n',         # B4: variadic concat for + chains
    'cssc_string_eq',
    'cssc_string_starts_with',
    'cssc_string_ends_with',
    'cssc_string_copy',
    # A.3.4 refcount cascade — defined alongside cssc_string_free in the
    # core string emitter (they share the %cssc_str layout, so emitting
    # them as a single group avoids duplicate `%cssc_str = type ...`
    # declarations in the IR text).
    'cssc_retain',
    'cssc_release',
    # A.3.6 scope-wrap stubs — emitted from the same group so the
    # scope-runtime symbols always resolve on the host LLVM path.
    'cssc_scope_push',
    'cssc_scope_pop',
    'cssc_arg_link',                 # v6 ref-by-default (host stub)
    'cssc_scope_delete_aliased',     # v6 ref-by-default (host stub)
    'cssc_load_i64_at',              # v6 mirror live-ref re-fetch
})


def _emit_cssc_string_full() -> List[str]:
    """Combined string group emitter — core (lit/free/size/data/print) +
    extras (concat/eq/copy). Single entry so the group dispatcher only
    needs one symbol set + one emitter."""
    return list(_emit_cssc_string()) + list(_emit_cssc_string_extras())


def _emit_cssc_string_extras() -> List[str]:
    """Phase 4g extras: concat / equality / deep-copy on heap cssc_str.

    Each emits as a separate `define` so the deduper / per-feature
    emission stays clean. Both inputs must be heap cssc_str* (the
    parser/lowerer ensures literals are materialised via cssc_string_lit
    before they reach these helpers).

    A.3.4: all newly-allocated strings carry refcount=1; field indices
    shifted (refcount=0, size=1, cap=2, data=3) — readers of size/data
    must match.
    """
    return [
        '',
        '; --- cssc_str: concat / equality / deep-copy (refcount cascade) ---',
        'declare ptr @malloc(i64)',
        'declare ptr @memcpy(ptr, ptr, i64)',
        'declare i32 @memcmp(ptr, ptr, i64)',
        '',
        '; concat(a, b) -> new heap cssc_str = a.bytes ++ b.bytes (refcount=1)',
        '; B2: single malloc for header + inline data, matching cssc_string_lit.',
        'define ptr @cssc_string_concat(ptr %a, ptr %b) {',
        'entry:',
        '  %a_sz_p = getelementptr inbounds %cssc_str, ptr %a, i64 0, i32 1',
        '  %a_sz32 = load i32, ptr %a_sz_p',
        '  %a_sz   = zext i32 %a_sz32 to i64',
        '  %a_data = getelementptr inbounds %cssc_str, ptr %a, i64 0, i32 2',
        '  %b_sz_p = getelementptr inbounds %cssc_str, ptr %b, i64 0, i32 1',
        '  %b_sz32 = load i32, ptr %b_sz_p',
        '  %b_sz   = zext i32 %b_sz32 to i64',
        '  %b_data = getelementptr inbounds %cssc_str, ptr %b, i64 0, i32 2',
        '  %total  = add i64 %a_sz, %b_sz',
        '  %dbytes = add i64 %total, 1',
        '  %alloc_total = add i64 8, %dbytes',
        '  %hdr    = call ptr @malloc(i64 %alloc_total)',
        '  %data_inline = getelementptr inbounds %cssc_str, ptr %hdr, i64 0, i32 2',
        '  call ptr @memcpy(ptr %data_inline, ptr %a_data, i64 %a_sz)',
        '  %data_b = getelementptr inbounds i8, ptr %data_inline, i64 %a_sz',
        '  call ptr @memcpy(ptr %data_b, ptr %b_data, i64 %b_sz)',
        '  %nul_p = getelementptr inbounds i8, ptr %data_inline, i64 %total',
        '  store i8 0, ptr %nul_p',
        '  %h_rc_p = getelementptr inbounds %cssc_str, ptr %hdr, i64 0, i32 0',
        '  store i32 1, ptr %h_rc_p',
        '  %total32 = trunc i64 %total to i32',
        '  %h_sz_p = getelementptr inbounds %cssc_str, ptr %hdr, i64 0, i32 1',
        '  store i32 %total32, ptr %h_sz_p',
        '  ret ptr %hdr',
        '}',
        '',
        '; B4: variadic concat — fuse an N-way `a + b + c + …` chain',
        '; into a single allocation + N memcpy. Caller passes a flat',
        '; array of `cssc_str*` ptrs and the count. Returns a fresh',
        '; cssc_str with refcount=1 containing the joined bytes.',
        ';',
        '; Cost vs. (N-1) × cssc_string_concat:',
        ';   * mallocs: 1   (was N-1; each old call mallocs its own)',
        ';   * frees:   N-1 intermediate (none here)',
        ';   * memcpy passes: N      (was N-1 + N-2 + ... = O(N^2) bytes)',
        ';',
        '; For a 3-way `"a" + b + "c"` chain this saves 2 mallocs and',
        ';   N-2 intermediate frees, plus quadratic-byte savings.',
        'define ptr @cssc_string_concat_n(ptr %parts, i64 %n) {',
        'entry:',
        '  ; Sum total bytes in pass 1.',
        '  %total_p = alloca i64, align 8',
        '  store i64 0, ptr %total_p',
        '  %i_p = alloca i64, align 8',
        '  store i64 0, ptr %i_p',
        '  br label %sum_loop',
        'sum_loop:',
        '  %i = load i64, ptr %i_p',
        '  %done = icmp uge i64 %i, %n',
        '  br i1 %done, label %alloc, label %sum_step',
        'sum_step:',
        '  %slot = getelementptr inbounds ptr, ptr %parts, i64 %i',
        '  %s = load ptr, ptr %slot',
        '  %sz_p = getelementptr inbounds %cssc_str, ptr %s, i64 0, i32 1',
        '  %sz32 = load i32, ptr %sz_p',
        '  %sz = zext i32 %sz32 to i64',
        '  %t = load i64, ptr %total_p',
        '  %t1 = add i64 %t, %sz',
        '  store i64 %t1, ptr %total_p',
        '  %i1 = add i64 %i, 1',
        '  store i64 %i1, ptr %i_p',
        '  br label %sum_loop',
        'alloc:',
        '  %total = load i64, ptr %total_p',
        '  %dbytes = add i64 %total, 1',
        '  %alloc_total = add i64 8, %dbytes',
        '  %hdr = call ptr @malloc(i64 %alloc_total)',
        '  %h_rc_p = getelementptr inbounds %cssc_str, ptr %hdr, i64 0, i32 0',
        '  store i32 1, ptr %h_rc_p',
        '  %total32 = trunc i64 %total to i32',
        '  %h_sz_p = getelementptr inbounds %cssc_str, ptr %hdr, i64 0, i32 1',
        '  store i32 %total32, ptr %h_sz_p',
        '  %dst_base = getelementptr inbounds %cssc_str, ptr %hdr, i64 0, i32 2',
        '  ; Pass 2: copy bytes from each input into the inline data buffer.',
        '  %off_p = alloca i64, align 8',
        '  store i64 0, ptr %off_p',
        '  %j_p = alloca i64, align 8',
        '  store i64 0, ptr %j_p',
        '  br label %cp_loop',
        'cp_loop:',
        '  %j = load i64, ptr %j_p',
        '  %cp_done = icmp uge i64 %j, %n',
        '  br i1 %cp_done, label %finish, label %cp_step',
        'cp_step:',
        '  %slot2 = getelementptr inbounds ptr, ptr %parts, i64 %j',
        '  %s2 = load ptr, ptr %slot2',
        '  %s2_sz_p = getelementptr inbounds %cssc_str, ptr %s2, i64 0, i32 1',
        '  %s2_sz32 = load i32, ptr %s2_sz_p',
        '  %s2_sz = zext i32 %s2_sz32 to i64',
        '  %s2_data = getelementptr inbounds %cssc_str, ptr %s2, i64 0, i32 2',
        '  %off = load i64, ptr %off_p',
        '  %dst = getelementptr inbounds i8, ptr %dst_base, i64 %off',
        '  call ptr @memcpy(ptr %dst, ptr %s2_data, i64 %s2_sz)',
        '  %off1 = add i64 %off, %s2_sz',
        '  store i64 %off1, ptr %off_p',
        '  %j1 = add i64 %j, 1',
        '  store i64 %j1, ptr %j_p',
        '  br label %cp_loop',
        'finish:',
        '  %total_f = load i64, ptr %total_p',
        '  %nul_p_f = getelementptr inbounds i8, ptr %dst_base, i64 %total_f',
        '  store i8 0, ptr %nul_p_f',
        '  ret ptr %hdr',
        '}',
        '',
        '; eq(a, b) -> i1 — true iff byte sequences match',
        'define i1 @cssc_string_eq(ptr %a, ptr %b) {',
        'entry:',
        '  %a_sz_p = getelementptr inbounds %cssc_str, ptr %a, i64 0, i32 1',
        '  %a_sz32 = load i32, ptr %a_sz_p',
        '  %b_sz_p = getelementptr inbounds %cssc_str, ptr %b, i64 0, i32 1',
        '  %b_sz32 = load i32, ptr %b_sz_p',
        '  %len_eq = icmp eq i32 %a_sz32, %b_sz32',
        '  br i1 %len_eq, label %bcmp, label %ret_false',
        'bcmp:',
        '  %a_data = getelementptr inbounds %cssc_str, ptr %a, i64 0, i32 2',
        '  %b_data = getelementptr inbounds %cssc_str, ptr %b, i64 0, i32 2',
        '  %a_sz   = zext i32 %a_sz32 to i64',
        '  %cmp    = call i32 @memcmp(ptr %a_data, ptr %b_data, i64 %a_sz)',
        '  %z      = icmp eq i32 %cmp, 0',
        '  ret i1 %z',
        'ret_false:',
        '  ret i1 false',
        '}',
        '',
        '; copy(s) -> new heap cssc_str (deep copy, refcount=1)',
        'define ptr @cssc_string_copy(ptr %s) {',
        'entry:',
        '  %sz_p   = getelementptr inbounds %cssc_str, ptr %s, i64 0, i32 1',
        '  %sz32   = load i32, ptr %sz_p',
        '  %sz     = zext i32 %sz32 to i64',
        '  %src    = getelementptr inbounds %cssc_str, ptr %s, i64 0, i32 2',
        '  %hdr    = call ptr @cssc_string_lit(ptr %src, i64 %sz)',
        '  ret ptr %hdr',
        '}',
        '',
        '; starts_with(s, suf) -> i1 (prefix byte-compare)',
        'define i1 @cssc_string_starts_with(ptr %s, ptr %suf) {',
        'entry:',
        '  %s_sz_p = getelementptr inbounds %cssc_str, ptr %s, i64 0, i32 1',
        '  %s_sz32 = load i32, ptr %s_sz_p',
        '  %f_sz_p = getelementptr inbounds %cssc_str, ptr %suf, i64 0, i32 1',
        '  %f_sz32 = load i32, ptr %f_sz_p',
        '  %fits = icmp ule i32 %f_sz32, %s_sz32',
        '  br i1 %fits, label %cmp, label %rf',
        'cmp:',
        '  %s_data = getelementptr inbounds %cssc_str, ptr %s, i64 0, i32 2',
        '  %f_data = getelementptr inbounds %cssc_str, ptr %suf, i64 0, i32 2',
        '  %f_sz = zext i32 %f_sz32 to i64',
        '  %c = call i32 @memcmp(ptr %s_data, ptr %f_data, i64 %f_sz)',
        '  %z = icmp eq i32 %c, 0',
        '  ret i1 %z',
        'rf:',
        '  ret i1 false',
        '}',
        '',
        '; ends_with(s, suf) -> i1 (suffix byte-compare at offset len-suflen)',
        'define i1 @cssc_string_ends_with(ptr %s, ptr %suf) {',
        'entry:',
        '  %s_sz_p = getelementptr inbounds %cssc_str, ptr %s, i64 0, i32 1',
        '  %s_sz32 = load i32, ptr %s_sz_p',
        '  %f_sz_p = getelementptr inbounds %cssc_str, ptr %suf, i64 0, i32 1',
        '  %f_sz32 = load i32, ptr %f_sz_p',
        '  %fits = icmp ule i32 %f_sz32, %s_sz32',
        '  br i1 %fits, label %cmp, label %rf',
        'cmp:',
        '  %off32 = sub i32 %s_sz32, %f_sz32',
        '  %off = zext i32 %off32 to i64',
        '  %s_data = getelementptr inbounds %cssc_str, ptr %s, i64 0, i32 2',
        '  %s_at = getelementptr inbounds i8, ptr %s_data, i64 %off',
        '  %f_data = getelementptr inbounds %cssc_str, ptr %suf, i64 0, i32 2',
        '  %f_sz = zext i32 %f_sz32 to i64',
        '  %c = call i32 @memcmp(ptr %s_at, ptr %f_data, i64 %f_sz)',
        '  %z = icmp eq i32 %c, 0',
        '  ret i1 %z',
        'rf:',
        '  ret i1 false',
        '}',
    ]


def _map_bucket_readers(v: str, key_str: bool, val_ll: str,
                        sidx: int) -> List[str]:
    """Generate the whole-map bucket-walk readers (cap / bstate /
    bkey[ptr|len] / bval) for map variant `v`, mirroring the hand-written
    map_ii readers. cir_lower's `_emit_map_to_str` / `_emit_map_copy` walk
    the open-addressing table by raw bucket index (state==1 → occupied);
    these readers expose the entry fields by index without a probe.

      key_str  — True: string key stored as raw (ptr,len) → bkeyptr/bkeylen
                 False: int key at field 0 → bkey (i64)
      val_ll   — LLVM type of the value field ('i64' | 'double' | 'ptr')
      sidx     — state field index (2 for i-key entries, 3 for s-key entries)
    """
    st = '%cssc_map_' + v
    en = '%cssc_map_' + v + '_entry'
    vidx = 2 if key_str else 1
    out = [
        '',
        '; --- bucket-walk readers for map_' + v + ' (stringify / copy) ---',
        'define i64 @cssc_map_' + v + '_cap(ptr %m) {',
        'entry:',
        '  %isn = icmp eq ptr %m, null',
        '  br i1 %isn, label %z, label %r',
        'r:',
        '  %cap_p = getelementptr inbounds ' + st + ', ptr %m, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  ret i64 %cap',
        'z:',
        '  ret i64 0',
        '}',
        '',
        'define i64 @cssc_map_' + v + '_bstate(ptr %m, i64 %i) {',
        'entry:',
        '  %isn = icmp eq ptr %m, null',
        '  br i1 %isn, label %z, label %r',
        'r:',
        '  %ep = getelementptr inbounds ' + st + ', ptr %m, i64 0, i32 2',
        '  %entries = load ptr, ptr %ep',
        '  %e = getelementptr inbounds ' + en + ', ptr %entries, i64 %i',
        '  %sp = getelementptr inbounds ' + en + ', ptr %e, i64 0, i32 ' + str(sidx),
        '  %s = load i64, ptr %sp',
        '  ret i64 %s',
        'z:',
        '  ret i64 0',
        '}',
        '',
    ]
    if key_str:
        out += [
            'define ptr @cssc_map_' + v + '_bkeyptr(ptr %m, i64 %i) {',
            'entry:',
            '  %ep = getelementptr inbounds ' + st + ', ptr %m, i64 0, i32 2',
            '  %entries = load ptr, ptr %ep',
            '  %e = getelementptr inbounds ' + en + ', ptr %entries, i64 %i',
            '  %kp = getelementptr inbounds ' + en + ', ptr %e, i64 0, i32 0',
            '  %k = load ptr, ptr %kp',
            '  ret ptr %k',
            '}',
            '',
            'define i64 @cssc_map_' + v + '_bkeylen(ptr %m, i64 %i) {',
            'entry:',
            '  %ep = getelementptr inbounds ' + st + ', ptr %m, i64 0, i32 2',
            '  %entries = load ptr, ptr %ep',
            '  %e = getelementptr inbounds ' + en + ', ptr %entries, i64 %i',
            '  %lp = getelementptr inbounds ' + en + ', ptr %e, i64 0, i32 1',
            '  %l = load i64, ptr %lp',
            '  ret i64 %l',
            '}',
            '',
        ]
    else:
        out += [
            'define i64 @cssc_map_' + v + '_bkey(ptr %m, i64 %i) {',
            'entry:',
            '  %ep = getelementptr inbounds ' + st + ', ptr %m, i64 0, i32 2',
            '  %entries = load ptr, ptr %ep',
            '  %e = getelementptr inbounds ' + en + ', ptr %entries, i64 %i',
            '  %kp = getelementptr inbounds ' + en + ', ptr %e, i64 0, i32 0',
            '  %k = load i64, ptr %kp',
            '  ret i64 %k',
            '}',
            '',
        ]
    out += [
        'define ' + val_ll + ' @cssc_map_' + v + '_bval(ptr %m, i64 %i) {',
        'entry:',
        '  %ep = getelementptr inbounds ' + st + ', ptr %m, i64 0, i32 2',
        '  %entries = load ptr, ptr %ep',
        '  %e = getelementptr inbounds ' + en + ', ptr %entries, i64 %i',
        '  %vp = getelementptr inbounds ' + en + ', ptr %e, i64 0, i32 ' + str(vidx),
        '  %val = load ' + val_ll + ', ptr %vp',
        '  ret ' + val_ll + ' %val',
        '}',
        '',
    ]
    return out


def _emit_cssc_map_si() -> List[str]:
    """Phase 3 — map<string, int> runtime: open-addressed hash table.

    Header layout (24 bytes):
        struct cssc_map_si {
            i64 size;        // occupied entries
            i64 capacity;    // total slots — power of 2
            ptr entries;     // array of cssc_map_si_entry
        };

    Entry layout (40 bytes):
        struct cssc_map_si_entry {
            ptr key_data;    // heap-allocated byte buffer (NULL = empty)
            i64 key_len;     // bytes (without NUL)
            i64 value;       // user's i64 value
            i64 state;       // 0 = empty, 1 = occupied  (no tombstones in Phase 3)
            i64 seq;         // insertion sequence (0-based) — preserves order
                             // so .keys()/select iterate like the interpreter's
                             // insertion-ordered dict rather than bucket order.
        };

    Keys are passed in as raw (data, len) pairs (typically pointing at a
    parser-emitted `.str.N` global). The runtime *copies* the key bytes
    into its own heap buffer so the caller never needs to manage key
    lifetime.

    Hash: 64-bit FNV-1a over the byte sequence.

    Load-factor threshold for grow: size * 4 >= capacity * 3 (≈ 75 %).
    Grow doubles the capacity and rehashes every occupied entry.
    """
    return [
        '',
        '; --- cssc_map_si: hash table for map<string, int> ---',
        '%cssc_map_si       = type { i64, i64, ptr }',
        '%cssc_map_si_entry = type { ptr, i64, i64, i64, i64 }',
        '',
        'declare ptr @malloc(i64)',
        'declare void @free(ptr)',
        'declare ptr @memcpy(ptr, ptr, i64)',
        'declare i32 @memcmp(ptr, ptr, i64)',
        'declare void @abort() noreturn',
        '',
        # ---- internal: 64-bit FNV-1a hash of (data, len) ----
        'define i64 @cssc_map_si_hash(ptr %data, i64 %len) {',
        'entry:',
        '  br label %loop',
        'loop:',
        '  %h   = phi i64 [ 14695981039346656037, %entry ], [ %h.next, %step ]',
        '  %i   = phi i64 [ 0, %entry ],                   [ %i.next, %step ]',
        '  %done = icmp uge i64 %i, %len',
        '  br i1 %done, label %end, label %step',
        'step:',
        '  %byte_p = getelementptr inbounds i8, ptr %data, i64 %i',
        '  %byte   = load i8, ptr %byte_p',
        '  %byte64 = zext i8 %byte to i64',
        '  %h.xor  = xor i64 %h, %byte64',
        '  %h.next = mul i64 %h.xor, 1099511628211',
        '  %i.next = add i64 %i, 1',
        '  br label %loop',
        'end:',
        '  ret i64 %h',
        '}',
        '',
        # ---- new(cap_hint) ----
        'define ptr @cssc_map_si_new(i64 %cap_hint) {',
        'entry:',
        '  %cap0 = icmp sgt i64 %cap_hint, 7',
        '  %cap1 = select i1 %cap0, i64 %cap_hint, i64 8',  # min 8
        '  ; round up to next pow-of-2 not needed for FNV linear probe; keep cap1.',
        '  %hdr = call ptr @malloc(i64 24)',
        '  %size_p = getelementptr inbounds %cssc_map_si, ptr %hdr, i64 0, i32 0',
        '  store i64 0, ptr %size_p',
        '  %cap_p = getelementptr inbounds %cssc_map_si, ptr %hdr, i64 0, i32 1',
        '  store i64 %cap1, ptr %cap_p',
        '  %entry_bytes = mul i64 %cap1, 40',
        '  %entries = call ptr @malloc(i64 %entry_bytes)',
        '  ; zero-initialise: state=0 across all entries.',
        '  call ptr @memset(ptr %entries, i32 0, i64 %entry_bytes)',
        '  %entries_p = getelementptr inbounds %cssc_map_si, ptr %hdr, i64 0, i32 2',
        '  store ptr %entries, ptr %entries_p',
        '  ret ptr %hdr',
        '}',
        '',
        'declare ptr @memset(ptr, i32, i64)',
        '',
        # ---- free(map) — frees every key buffer + entries + header ----
        'define void @cssc_map_si_free(ptr %m) {',
        'entry:',
        '  %is_null = icmp eq ptr %m, null',
        '  br i1 %is_null, label %done, label %loop.start',
        'loop.start:',
        '  %cap_p = getelementptr inbounds %cssc_map_si, ptr %m, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %entries_p = getelementptr inbounds %cssc_map_si, ptr %m, i64 0, i32 2',
        '  %entries = load ptr, ptr %entries_p',
        '  br label %loop',
        'loop:',
        '  %i = phi i64 [ 0, %loop.start ], [ %i.next, %i_next ]',
        '  %finished = icmp uge i64 %i, %cap',
        '  br i1 %finished, label %tail, label %step',
        'step:',
        '  %entry_p = getelementptr inbounds %cssc_map_si_entry, ptr %entries, i64 %i',
        '  %state_p = getelementptr inbounds %cssc_map_si_entry, ptr %entry_p, i64 0, i32 3',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  br i1 %occ, label %free_key, label %i_next',
        'free_key:',
        '  %key_p = getelementptr inbounds %cssc_map_si_entry, ptr %entry_p, i64 0, i32 0',
        '  %key = load ptr, ptr %key_p',
        '  call void @free(ptr %key)',
        '  br label %i_next',
        'i_next:',
        '  %i.next = add i64 %i, 1',
        '  br label %loop',
        'tail:',
        '  call void @free(ptr %entries)',
        '  call void @free(ptr %m)',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        # ---- clone(map) — deep copy: fresh map with independent key buffers ----
        # Used when a map<string,int> is stored as a nested cell inside an
        # `array<auto>` (map_si has no refcount, and the source may be
        # #delete'd right after), so the array<auto> cell owns its own copy.
        # Re-inserts every occupied entry via set(), which heap-copies keys.
        'define ptr @cssc_map_si_clone(ptr %src) {',
        'entry:',
        '  %isnull = icmp eq ptr %src, null',
        '  br i1 %isnull, label %ret_null, label %go',
        'ret_null:',
        '  ret ptr null',
        'go:',
        '  %cap_p = getelementptr inbounds %cssc_map_si, ptr %src, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %dst = call ptr @cssc_map_si_new(i64 %cap)',
        '  %entries_p = getelementptr inbounds %cssc_map_si, ptr %src, i64 0, i32 2',
        '  %entries = load ptr, ptr %entries_p',
        '  br label %loop',
        'loop:',
        '  %i = phi i64 [ 0, %go ], [ %i.next, %inext ]',
        '  %fin = icmp uge i64 %i, %cap',
        '  br i1 %fin, label %cdone, label %step',
        'step:',
        '  %ep = getelementptr inbounds %cssc_map_si_entry, ptr %entries, i64 %i',
        '  %stp = getelementptr inbounds %cssc_map_si_entry, ptr %ep, i64 0, i32 3',
        '  %st = load i64, ptr %stp',
        '  %occ = icmp eq i64 %st, 1',
        '  br i1 %occ, label %copy, label %inext',
        'copy:',
        '  %kp = getelementptr inbounds %cssc_map_si_entry, ptr %ep, i64 0, i32 0',
        '  %k = load ptr, ptr %kp',
        '  %klp = getelementptr inbounds %cssc_map_si_entry, ptr %ep, i64 0, i32 1',
        '  %kl = load i64, ptr %klp',
        '  %vvp = getelementptr inbounds %cssc_map_si_entry, ptr %ep, i64 0, i32 2',
        '  %vv = load i64, ptr %vvp',
        '  %cseqp = getelementptr inbounds %cssc_map_si_entry, ptr %ep, i64 0, i32 4',
        '  %cseq = load i64, ptr %cseqp',
        '  ; independent key buffer + preserved insertion sequence, so the',
        '  ; clone iterates keys() in the SAME order as the source (dst has',
        '  ; the same capacity as src, so place_raw never needs to grow).',
        '  %cisz = icmp eq i64 %kl, 0',
        '  %cbytes = select i1 %cisz, i64 1, i64 %kl',
        '  %ckbuf = call ptr @malloc(i64 %cbytes)',
        '  %ccpy = call ptr @memcpy(ptr %ckbuf, ptr %k, i64 %kl)',
        '  call void @cssc_map_si_place_raw(ptr %dst, ptr %ckbuf, i64 %kl, i64 %vv, i64 %cseq)',
        '  br label %inext',
        'inext:',
        '  %i.next = add i64 %i, 1',
        '  br label %loop',
        'cdone:',
        '  ret ptr %dst',
        '}',
        '',
        # ---- internal: probe — given map, key, len → entry ptr OR null on full-miss ----
        # Returns either the matching entry or the first empty entry.
        'define ptr @cssc_map_si_probe(ptr %m, ptr %kd, i64 %klen) {',
        'entry:',
        '  %cap_p = getelementptr inbounds %cssc_map_si, ptr %m, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %entries_p = getelementptr inbounds %cssc_map_si, ptr %m, i64 0, i32 2',
        '  %entries = load ptr, ptr %entries_p',
        '  %h = call i64 @cssc_map_si_hash(ptr %kd, i64 %klen)',
        '  %h_mod_init = urem i64 %h, %cap',
        '  br label %loop',
        'loop:',
        '  %i  = phi i64 [ 0, %entry ], [ %i.next, %miss ]',
        '  %slot = phi i64 [ %h_mod_init, %entry ], [ %slot.next, %miss ]',
        '  %entry_p = getelementptr inbounds %cssc_map_si_entry, ptr %entries, i64 %slot',
        '  %state_p = getelementptr inbounds %cssc_map_si_entry, ptr %entry_p, i64 0, i32 3',
        '  %state = load i64, ptr %state_p',
        '  %is_empty = icmp eq i64 %state, 0',
        '  br i1 %is_empty, label %ret_empty, label %check_match',
        'check_match:',
        '  %ek_p   = getelementptr inbounds %cssc_map_si_entry, ptr %entry_p, i64 0, i32 0',
        '  %ek     = load ptr, ptr %ek_p',
        '  %elen_p = getelementptr inbounds %cssc_map_si_entry, ptr %entry_p, i64 0, i32 1',
        '  %elen   = load i64, ptr %elen_p',
        '  %len_eq = icmp eq i64 %elen, %klen',
        '  br i1 %len_eq, label %bcmp, label %miss',
        'bcmp:',
        '  %cmp = call i32 @memcmp(ptr %ek, ptr %kd, i64 %klen)',
        '  %cmp_eq = icmp eq i32 %cmp, 0',
        '  br i1 %cmp_eq, label %ret_match, label %miss',
        'miss:',
        '  %i.next = add i64 %i, 1',
        '  %tmp = add i64 %slot, 1',
        '  %slot.next = urem i64 %tmp, %cap',
        '  br label %loop',
        'ret_empty:',
        '  ret ptr %entry_p',
        'ret_match:',
        '  ret ptr %entry_p',
        '}',
        '',
        # ---- size(map) ----
        'define i64 @cssc_map_si_size(ptr %m) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_map_si, ptr %m, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  ret i64 %size',
        '}',
        '',
        # ---- has(map, key, len) ----
        'define i1 @cssc_map_si_has(ptr %m, ptr %kd, i64 %klen) {',
        'entry:',
        '  %slot = call ptr @cssc_map_si_probe(ptr %m, ptr %kd, i64 %klen)',
        '  %state_p = getelementptr inbounds %cssc_map_si_entry, ptr %slot, i64 0, i32 3',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  ret i1 %occ',
        '}',
        '',
        # ---- get(map, key, len) — 0 on miss (matches interpreter default) ----
        'define i64 @cssc_map_si_get(ptr %m, ptr %kd, i64 %klen) {',
        'entry:',
        '  %slot = call ptr @cssc_map_si_probe(ptr %m, ptr %kd, i64 %klen)',
        '  %state_p = getelementptr inbounds %cssc_map_si_entry, ptr %slot, i64 0, i32 3',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  br i1 %occ, label %ok, label %miss',
        'miss:',
        '  ret i64 0',
        'ok:',
        '  %val_p = getelementptr inbounds %cssc_map_si_entry, ptr %slot, i64 0, i32 2',
        '  %val = load i64, ptr %val_p',
        '  ret i64 %val',
        '}',
        '',
        # ---- internal: place a pre-owned (already heap-allocated) key into
        #      the first empty slot without copying. Used by grow's rehash;
        #      the key is known-unique and the table is known to have room. ----
        'define void @cssc_map_si_place_raw(ptr %m, ptr %key, i64 %klen, i64 %val, i64 %seq) {',
        'entry:',
        '  %cap_p = getelementptr inbounds %cssc_map_si, ptr %m, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %entries_p = getelementptr inbounds %cssc_map_si, ptr %m, i64 0, i32 2',
        '  %entries = load ptr, ptr %entries_p',
        '  %h = call i64 @cssc_map_si_hash(ptr %key, i64 %klen)',
        '  %slot0 = urem i64 %h, %cap',
        '  br label %loop',
        'loop:',
        '  %slot = phi i64 [ %slot0, %entry ], [ %slot.next, %miss ]',
        '  %ep = getelementptr inbounds %cssc_map_si_entry, ptr %entries, i64 %slot',
        '  %stp = getelementptr inbounds %cssc_map_si_entry, ptr %ep, i64 0, i32 3',
        '  %st = load i64, ptr %stp',
        '  %empty = icmp eq i64 %st, 0',
        '  br i1 %empty, label %place, label %miss',
        'miss:',
        '  %t = add i64 %slot, 1',
        '  %slot.next = urem i64 %t, %cap',
        '  br label %loop',
        'place:',
        '  %kp = getelementptr inbounds %cssc_map_si_entry, ptr %ep, i64 0, i32 0',
        '  store ptr %key, ptr %kp',
        '  %klp = getelementptr inbounds %cssc_map_si_entry, ptr %ep, i64 0, i32 1',
        '  store i64 %klen, ptr %klp',
        '  %vp = getelementptr inbounds %cssc_map_si_entry, ptr %ep, i64 0, i32 2',
        '  store i64 %val, ptr %vp',
        '  store i64 1, ptr %stp',
        '  %seqp = getelementptr inbounds %cssc_map_si_entry, ptr %ep, i64 0, i32 4',
        '  store i64 %seq, ptr %seqp',
        '  %sz_p = getelementptr inbounds %cssc_map_si, ptr %m, i64 0, i32 0',
        '  %sz = load i64, ptr %sz_p',
        '  %sz1 = add i64 %sz, 1',
        '  store i64 %sz1, ptr %sz_p',
        '  ret void',
        '}',
        '',
        # ---- internal: grow — double capacity and rehash occupied entries. ----
        # Open addressing with no tombstones cannot terminate a probe once the
        # table is full, so the table MUST grow before it fills. Key buffers are
        # moved (not re-copied) into the new table; only the entries array is
        # freed. Called by set() when the load factor would exceed ~75 %.
        'define void @cssc_map_si_grow(ptr %m) {',
        'entry:',
        '  %ocap_p = getelementptr inbounds %cssc_map_si, ptr %m, i64 0, i32 1',
        '  %ocap = load i64, ptr %ocap_p',
        '  %oent_p = getelementptr inbounds %cssc_map_si, ptr %m, i64 0, i32 2',
        '  %oent = load ptr, ptr %oent_p',
        '  %ncap = shl i64 %ocap, 1',
        '  %nbytes = mul i64 %ncap, 40',
        '  %nent = call ptr @malloc(i64 %nbytes)',
        '  call ptr @memset(ptr %nent, i32 0, i64 %nbytes)',
        '  store i64 %ncap, ptr %ocap_p',
        '  store ptr %nent, ptr %oent_p',
        '  %nsz_p = getelementptr inbounds %cssc_map_si, ptr %m, i64 0, i32 0',
        '  store i64 0, ptr %nsz_p',
        '  br label %loop',
        'loop:',
        '  %i = phi i64 [ 0, %entry ], [ %i.next, %inext ]',
        '  %done = icmp uge i64 %i, %ocap',
        '  br i1 %done, label %tail, label %step',
        'step:',
        '  %oe = getelementptr inbounds %cssc_map_si_entry, ptr %oent, i64 %i',
        '  %ostp = getelementptr inbounds %cssc_map_si_entry, ptr %oe, i64 0, i32 3',
        '  %ost = load i64, ptr %ostp',
        '  %occ2 = icmp eq i64 %ost, 1',
        '  br i1 %occ2, label %reins, label %inext',
        'reins:',
        '  %okp = getelementptr inbounds %cssc_map_si_entry, ptr %oe, i64 0, i32 0',
        '  %ok = load ptr, ptr %okp',
        '  %oklp = getelementptr inbounds %cssc_map_si_entry, ptr %oe, i64 0, i32 1',
        '  %okl = load i64, ptr %oklp',
        '  %ovp = getelementptr inbounds %cssc_map_si_entry, ptr %oe, i64 0, i32 2',
        '  %ov = load i64, ptr %ovp',
        '  %oseqp = getelementptr inbounds %cssc_map_si_entry, ptr %oe, i64 0, i32 4',
        '  %oseq = load i64, ptr %oseqp',
        '  call void @cssc_map_si_place_raw(ptr %m, ptr %ok, i64 %okl, i64 %ov, i64 %oseq)',
        '  br label %inext',
        'inext:',
        '  %i.next = add i64 %i, 1',
        '  br label %loop',
        'tail:',
        '  call void @free(ptr %oent)',
        '  ret void',
        '}',
        '',
        # ---- set(map, key, len, val) — insert or update ----
        # Grows first when the load factor would exceed ~75 %, guaranteeing the
        # subsequent probe always finds an empty slot on a miss (open addressing
        # with no tombstones loops forever on a full table). On insert the slot
        # is empty → allocate a key buffer + memcpy + size++; on match overwrite.
        'define void @cssc_map_si_set(ptr %m, ptr %kd, i64 %klen, i64 %val) {',
        'entry:',
        '  %sz_p0 = getelementptr inbounds %cssc_map_si, ptr %m, i64 0, i32 0',
        '  %sz0 = load i64, ptr %sz_p0',
        '  %cap_p0 = getelementptr inbounds %cssc_map_si, ptr %m, i64 0, i32 1',
        '  %cap0 = load i64, ptr %cap_p0',
        '  %sz_plus1 = add i64 %sz0, 1',
        '  %lhs = mul i64 %sz_plus1, 4',
        '  %rhs = mul i64 %cap0, 3',
        '  %needgrow = icmp uge i64 %lhs, %rhs',
        '  br i1 %needgrow, label %grow, label %after',
        'grow:',
        '  call void @cssc_map_si_grow(ptr %m)',
        '  br label %after',
        'after:',
        '  %slot = call ptr @cssc_map_si_probe(ptr %m, ptr %kd, i64 %klen)',
        '  %state_p = getelementptr inbounds %cssc_map_si_entry, ptr %slot, i64 0, i32 3',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  br i1 %occ, label %update, label %insert',
        'update:',
        '  %val_p = getelementptr inbounds %cssc_map_si_entry, ptr %slot, i64 0, i32 2',
        '  store i64 %val, ptr %val_p',
        '  ret void',
        'insert:',
        '  ; duplicate the key bytes into a freshly malloc-ed buffer.',
        '  %iszero = icmp eq i64 %klen, 0',
        '  %alloc_bytes = select i1 %iszero, i64 1, i64 %klen',
        '  %key_buf = call ptr @malloc(i64 %alloc_bytes)',
        '  %cpy = call ptr @memcpy(ptr %key_buf, ptr %kd, i64 %klen)',
        '  %k_p   = getelementptr inbounds %cssc_map_si_entry, ptr %slot, i64 0, i32 0',
        '  store ptr %key_buf, ptr %k_p',
        '  %klen_p = getelementptr inbounds %cssc_map_si_entry, ptr %slot, i64 0, i32 1',
        '  store i64 %klen, ptr %klen_p',
        '  %valp_i = getelementptr inbounds %cssc_map_si_entry, ptr %slot, i64 0, i32 2',
        '  store i64 %val, ptr %valp_i',
        '  store i64 1, ptr %state_p',
        '  ; size++ and record the insertion sequence (= old size).',
        '  %size_p = getelementptr inbounds %cssc_map_si, ptr %m, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %seq_p = getelementptr inbounds %cssc_map_si_entry, ptr %slot, i64 0, i32 4',
        '  store i64 %size, ptr %seq_p',
        '  %size.next = add i64 %size, 1',
        '  store i64 %size.next, ptr %size_p',
        '  ret void',
        '}',
        '',
        # ---- bseq(map, i) — insertion sequence of bucket i (map_si only, as
        #      its entry carries a 5th `seq` field). Lets the keys()/values()
        #      snapshot emit in insertion order instead of bucket order. ----
        'define i64 @cssc_map_si_bseq(ptr %m, i64 %i) {',
        'entry:',
        '  %isn = icmp eq ptr %m, null',
        '  br i1 %isn, label %z, label %r',
        'r:',
        '  %ep = getelementptr inbounds %cssc_map_si, ptr %m, i64 0, i32 2',
        '  %entries = load ptr, ptr %ep',
        '  %e = getelementptr inbounds %cssc_map_si_entry, ptr %entries, i64 %i',
        '  %sp = getelementptr inbounds %cssc_map_si_entry, ptr %e, i64 0, i32 4',
        '  %s = load i64, ptr %sp',
        '  ret i64 %s',
        'z:',
        '  ret i64 0',
        '}',
    ] + _map_bucket_readers('si', True, 'i64', 3)


_MAP_SI_SYMBOLS = frozenset({
    'cssc_map_si_new',
    'cssc_map_si_free',
    'cssc_map_si_clone',
    'cssc_map_si_size',
    'cssc_map_si_has',
    'cssc_map_si_get',
    'cssc_map_si_set',
    'cssc_map_si_grow',
    'cssc_map_si_place_raw',
    'cssc_map_si_hash',
    'cssc_map_si_probe',
    'cssc_map_si_cap',
    'cssc_map_si_bstate',
    'cssc_map_si_bseq',
    'cssc_map_si_bkeyptr',
    'cssc_map_si_bkeylen',
    'cssc_map_si_bval',
})


def _emit_cssc_map_ss() -> List[str]:
    """Phase 6 — map<string, string> host runtime.

    Header (24 B): { i64 size, i64 capacity, ptr entries }
    Entry  (32 B): { ptr key_data, i64 key_len, ptr val_cssc_str, i64 state }

    Lifecycle invariants (per synthesis A.0/A.1.3):
      - No grow. Cap-hint = max(2*N_init, 8).
      - No tombstones. null_at/null_all preserve key + state, only release
        + zero the value field.
      - Host duplicates key bytes (malloc+memcpy) on set.
      - Host miss on get -> @abort().
      - Container OWNS one ref on each occupied cssc_str* value:
          * set on occupied slot: cssc_release(old) BEFORE store.
          * free: cssc_release every occupied value, then free key bufs,
            then free entries, then free header.
          * null_at: cssc_release value, zero value field; key/state stay.
      - Hash is 64-bit FNV-1a over the key byte buffer (verbatim from map_si).
    """
    return [
        '',
        '; --- cssc_map_ss: hash table for map<string, string> ---',
        '%cssc_map_ss       = type { i64, i64, ptr }',
        '%cssc_map_ss_entry = type { ptr, i64, ptr, i64 }',
        '',
        'declare ptr @malloc(i64)',
        'declare void @free(ptr)',
        'declare ptr @memcpy(ptr, ptr, i64)',
        'declare ptr @memset(ptr, i32, i64)',
        'declare i32 @memcmp(ptr, ptr, i64)',
        'declare void @abort() noreturn',
        '; cssc_release: defined by the `string` group; no declare here.',
        '',
        # ---- internal: 64-bit FNV-1a hash of (data, len) ----
        'define i64 @cssc_map_ss_hash(ptr %data, i64 %len) {',
        'entry:',
        '  br label %loop',
        'loop:',
        '  %h   = phi i64 [ 14695981039346656037, %entry ], [ %h.next, %step ]',
        '  %i   = phi i64 [ 0, %entry ],                   [ %i.next, %step ]',
        '  %done = icmp uge i64 %i, %len',
        '  br i1 %done, label %end, label %step',
        'step:',
        '  %byte_p = getelementptr inbounds i8, ptr %data, i64 %i',
        '  %byte   = load i8, ptr %byte_p',
        '  %byte64 = zext i8 %byte to i64',
        '  %h.xor  = xor i64 %h, %byte64',
        '  %h.next = mul i64 %h.xor, 1099511628211',
        '  %i.next = add i64 %i, 1',
        '  br label %loop',
        'end:',
        '  ret i64 %h',
        '}',
        '',
        # ---- new(cap_hint) ----
        'define ptr @cssc_map_ss_new(i64 %cap_hint) {',
        'entry:',
        '  %cap0 = icmp sgt i64 %cap_hint, 7',
        '  %cap1 = select i1 %cap0, i64 %cap_hint, i64 8',
        '  %hdr = call ptr @malloc(i64 24)',
        '  %size_p = getelementptr inbounds %cssc_map_ss, ptr %hdr, i64 0, i32 0',
        '  store i64 0, ptr %size_p',
        '  %cap_p = getelementptr inbounds %cssc_map_ss, ptr %hdr, i64 0, i32 1',
        '  store i64 %cap1, ptr %cap_p',
        '  %entry_bytes = mul i64 %cap1, 32',
        '  %entries = call ptr @malloc(i64 %entry_bytes)',
        '  call ptr @memset(ptr %entries, i32 0, i64 %entry_bytes)',
        '  %entries_p = getelementptr inbounds %cssc_map_ss, ptr %hdr, i64 0, i32 2',
        '  store ptr %entries, ptr %entries_p',
        '  ret ptr %hdr',
        '}',
        '',
        # ---- free(map) ----
        # Walk every slot: release val (if occupied), free key buffer, then
        # free entries + header.
        'define void @cssc_map_ss_free(ptr %m) {',
        'entry:',
        '  %is_null = icmp eq ptr %m, null',
        '  br i1 %is_null, label %done, label %loop.start',
        'loop.start:',
        '  %cap_p = getelementptr inbounds %cssc_map_ss, ptr %m, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %entries_p = getelementptr inbounds %cssc_map_ss, ptr %m, i64 0, i32 2',
        '  %entries = load ptr, ptr %entries_p',
        '  br label %loop',
        'loop:',
        '  %i = phi i64 [ 0, %loop.start ], [ %i.next, %i_next ]',
        '  %finished = icmp uge i64 %i, %cap',
        '  br i1 %finished, label %tail, label %step',
        'step:',
        '  %entry_p = getelementptr inbounds %cssc_map_ss_entry, ptr %entries, i64 %i',
        '  %state_p = getelementptr inbounds %cssc_map_ss_entry, ptr %entry_p, i64 0, i32 3',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  br i1 %occ, label %release_val, label %i_next',
        'release_val:',
        '  %val_p = getelementptr inbounds %cssc_map_ss_entry, ptr %entry_p, i64 0, i32 2',
        '  %val = load ptr, ptr %val_p',
        '  call void @cssc_release(ptr %val)',
        '  %key_p = getelementptr inbounds %cssc_map_ss_entry, ptr %entry_p, i64 0, i32 0',
        '  %key = load ptr, ptr %key_p',
        '  call void @free(ptr %key)',
        '  br label %i_next',
        'i_next:',
        '  %i.next = add i64 %i, 1',
        '  br label %loop',
        'tail:',
        '  call void @free(ptr %entries)',
        '  call void @free(ptr %m)',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        # ---- internal: probe(map, kd, klen) -> entry ptr ----
        'define ptr @cssc_map_ss_probe(ptr %m, ptr %kd, i64 %klen) {',
        'entry:',
        '  %cap_p = getelementptr inbounds %cssc_map_ss, ptr %m, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %entries_p = getelementptr inbounds %cssc_map_ss, ptr %m, i64 0, i32 2',
        '  %entries = load ptr, ptr %entries_p',
        '  %h = call i64 @cssc_map_ss_hash(ptr %kd, i64 %klen)',
        '  %h_mod_init = urem i64 %h, %cap',
        '  br label %loop',
        'loop:',
        '  %i  = phi i64 [ 0, %entry ], [ %i.next, %miss ]',
        '  %slot = phi i64 [ %h_mod_init, %entry ], [ %slot.next, %miss ]',
        '  %entry_p = getelementptr inbounds %cssc_map_ss_entry, ptr %entries, i64 %slot',
        '  %state_p = getelementptr inbounds %cssc_map_ss_entry, ptr %entry_p, i64 0, i32 3',
        '  %state = load i64, ptr %state_p',
        '  %is_empty = icmp eq i64 %state, 0',
        '  br i1 %is_empty, label %ret_empty, label %check_match',
        'check_match:',
        '  %ek_p   = getelementptr inbounds %cssc_map_ss_entry, ptr %entry_p, i64 0, i32 0',
        '  %ek     = load ptr, ptr %ek_p',
        '  %elen_p = getelementptr inbounds %cssc_map_ss_entry, ptr %entry_p, i64 0, i32 1',
        '  %elen   = load i64, ptr %elen_p',
        '  %len_eq = icmp eq i64 %elen, %klen',
        '  br i1 %len_eq, label %bcmp, label %miss',
        'bcmp:',
        '  %cmp = call i32 @memcmp(ptr %ek, ptr %kd, i64 %klen)',
        '  %cmp_eq = icmp eq i32 %cmp, 0',
        '  br i1 %cmp_eq, label %ret_match, label %miss',
        'miss:',
        '  %i.next = add i64 %i, 1',
        '  %tmp = add i64 %slot, 1',
        '  %slot.next = urem i64 %tmp, %cap',
        '  br label %loop',
        'ret_empty:',
        '  ret ptr %entry_p',
        'ret_match:',
        '  ret ptr %entry_p',
        '}',
        '',
        # ---- size(map) ----
        'define i64 @cssc_map_ss_size(ptr %m) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_map_ss, ptr %m, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  ret i64 %size',
        '}',
        '',
        # ---- has(map, kd, klen) ----
        'define i1 @cssc_map_ss_has(ptr %m, ptr %kd, i64 %klen) {',
        'entry:',
        '  %slot = call ptr @cssc_map_ss_probe(ptr %m, ptr %kd, i64 %klen)',
        '  %state_p = getelementptr inbounds %cssc_map_ss_entry, ptr %slot, i64 0, i32 3',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  ret i1 %occ',
        '}',
        '',
        # ---- get(map, kd, klen) — panic on miss ----
        'define ptr @cssc_map_ss_get(ptr %m, ptr %kd, i64 %klen) {',
        'entry:',
        '  %slot = call ptr @cssc_map_ss_probe(ptr %m, ptr %kd, i64 %klen)',
        '  %state_p = getelementptr inbounds %cssc_map_ss_entry, ptr %slot, i64 0, i32 3',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  br i1 %occ, label %ok, label %panic',
        'panic:',
        '  call void @abort()',
        '  unreachable',
        'ok:',
        '  %val_p = getelementptr inbounds %cssc_map_ss_entry, ptr %slot, i64 0, i32 2',
        '  %val = load ptr, ptr %val_p',
        '  ret ptr %val',
        '}',
        '',
        # ---- set(map, kd, klen, val) — value is cssc_str*; release old. ----
        'define void @cssc_map_ss_set(ptr %m, ptr %kd, i64 %klen, ptr %val) {',
        'entry:',
        '  %slot = call ptr @cssc_map_ss_probe(ptr %m, ptr %kd, i64 %klen)',
        '  %state_p = getelementptr inbounds %cssc_map_ss_entry, ptr %slot, i64 0, i32 3',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  br i1 %occ, label %update, label %insert',
        'update:',
        '  %val_p = getelementptr inbounds %cssc_map_ss_entry, ptr %slot, i64 0, i32 2',
        '  %old = load ptr, ptr %val_p',
        '  call void @cssc_release(ptr %old)',
        '  store ptr %val, ptr %val_p',
        '  ret void',
        'insert:',
        '  %iszero = icmp eq i64 %klen, 0',
        '  %alloc_bytes = select i1 %iszero, i64 1, i64 %klen',
        '  %key_buf = call ptr @malloc(i64 %alloc_bytes)',
        '  %cpy = call ptr @memcpy(ptr %key_buf, ptr %kd, i64 %klen)',
        '  %k_p   = getelementptr inbounds %cssc_map_ss_entry, ptr %slot, i64 0, i32 0',
        '  store ptr %key_buf, ptr %k_p',
        '  %klen_p = getelementptr inbounds %cssc_map_ss_entry, ptr %slot, i64 0, i32 1',
        '  store i64 %klen, ptr %klen_p',
        '  %valp = getelementptr inbounds %cssc_map_ss_entry, ptr %slot, i64 0, i32 2',
        '  store ptr %val, ptr %valp',
        '  store i64 1, ptr %state_p',
        '  %size_p = getelementptr inbounds %cssc_map_ss, ptr %m, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %size.next = add i64 %size, 1',
        '  store i64 %size.next, ptr %size_p',
        '  ret void',
        '}',
        '',
        # ---- null_at(map, capacity_idx) ----
        # idx is raw entry index (capacity-space, not size-space) since this
        # is a hash table. Releases the value and zeros the value field;
        # key + state are preserved (no tombstones).
        'define void @cssc_map_ss_null_at(ptr %m, i64 %i) {',
        'entry:',
        '  %is_null = icmp eq ptr %m, null',
        '  br i1 %is_null, label %done, label %do',
        'do:',
        '  %cap_p = getelementptr inbounds %cssc_map_ss, ptr %m, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %ok = icmp ult i64 %i, %cap',
        '  br i1 %ok, label %check, label %done',
        'check:',
        '  %ent_p = getelementptr inbounds %cssc_map_ss, ptr %m, i64 0, i32 2',
        '  %ent = load ptr, ptr %ent_p',
        '  %slot = getelementptr inbounds %cssc_map_ss_entry, ptr %ent, i64 %i',
        '  %state_p = getelementptr inbounds %cssc_map_ss_entry, ptr %slot, i64 0, i32 3',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  br i1 %occ, label %wipe, label %done',
        'wipe:',
        '  %val_p = getelementptr inbounds %cssc_map_ss_entry, ptr %slot, i64 0, i32 2',
        '  %old = load ptr, ptr %val_p',
        '  call void @cssc_release(ptr %old)',
        '  store ptr null, ptr %val_p',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        # ---- null_all(map) ----
        'define void @cssc_map_ss_null_all(ptr %m) {',
        'entry:',
        '  %is_null = icmp eq ptr %m, null',
        '  br i1 %is_null, label %done, label %read',
        'read:',
        '  %cap_p = getelementptr inbounds %cssc_map_ss, ptr %m, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %ent_p = getelementptr inbounds %cssc_map_ss, ptr %m, i64 0, i32 2',
        '  %ent = load ptr, ptr %ent_p',
        '  br label %loop',
        'loop:',
        '  %i = phi i64 [ 0, %read ], [ %i.next, %step ]',
        '  %fin = icmp uge i64 %i, %cap',
        '  br i1 %fin, label %done, label %body',
        'body:',
        '  %slot = getelementptr inbounds %cssc_map_ss_entry, ptr %ent, i64 %i',
        '  %state_p = getelementptr inbounds %cssc_map_ss_entry, ptr %slot, i64 0, i32 3',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  br i1 %occ, label %wipe, label %step',
        'wipe:',
        '  %val_p = getelementptr inbounds %cssc_map_ss_entry, ptr %slot, i64 0, i32 2',
        '  %old = load ptr, ptr %val_p',
        '  call void @cssc_release(ptr %old)',
        '  store ptr null, ptr %val_p',
        '  br label %step',
        'step:',
        '  %i.next = add i64 %i, 1',
        '  br label %loop',
        'done:',
        '  ret void',
        '}',
    ] + _map_bucket_readers('ss', True, 'ptr', 3)


_MAP_SS_SYMBOLS = frozenset({
    'cssc_map_ss_new',
    'cssc_map_ss_free',
    'cssc_map_ss_size',
    'cssc_map_ss_has',
    'cssc_map_ss_get',
    'cssc_map_ss_set',
    'cssc_map_ss_hash',
    'cssc_map_ss_probe',
    'cssc_map_ss_null_at',
    'cssc_map_ss_null_all',
    'cssc_map_ss_cap',
    'cssc_map_ss_bstate',
    'cssc_map_ss_bkeyptr',
    'cssc_map_ss_bkeylen',
    'cssc_map_ss_bval',
})


def _emit_cssc_map_is() -> List[str]:
    """Phase 6 — map<int, string> host runtime.

    Header (24 B): { i64 size, i64 capacity, ptr entries }
    Entry  (24 B): { i64 key, ptr val_cssc_str, i64 state }

    Hash: splitmix64(key).
    Value is refcount-managed cssc_str*; container owns one ref.
    Set on occupied -> release old. Free -> release every occupied value.
    null_at/null_all -> release value, zero value field, preserve key+state.
    """
    return [
        '',
        '; --- cssc_map_is: hash table for map<int, string> ---',
        '%cssc_map_is       = type { i64, i64, ptr }',
        '%cssc_map_is_entry = type { i64, ptr, i64 }',
        '',
        'declare ptr @malloc(i64)',
        'declare void @free(ptr)',
        'declare ptr @memset(ptr, i32, i64)',
        'declare void @abort() noreturn',
        '; cssc_release: defined by the `string` group; no declare here.',
        '',
        # ---- internal: splitmix64 hash ----
        'define i64 @cssc_map_is_hash(i64 %k) {',
        'entry:',
        '  %s1 = lshr i64 %k, 30',
        '  %x1 = xor i64 %k, %s1',
        '  %m1 = mul i64 %x1, -4658895280553007687',     # 0xbf58476d1ce4e5b9
        '  %s2 = lshr i64 %m1, 27',
        '  %x2 = xor i64 %m1, %s2',
        '  %m2 = mul i64 %x2, -6298703610411919841',     # 0x94d049bb133111eb
        '  %s3 = lshr i64 %m2, 31',
        '  %x3 = xor i64 %m2, %s3',
        '  ret i64 %x3',
        '}',
        '',
        # ---- new(cap_hint) ----
        'define ptr @cssc_map_is_new(i64 %cap_hint) {',
        'entry:',
        '  %cap0 = icmp sgt i64 %cap_hint, 7',
        '  %cap1 = select i1 %cap0, i64 %cap_hint, i64 8',
        '  %hdr = call ptr @malloc(i64 24)',
        '  %size_p = getelementptr inbounds %cssc_map_is, ptr %hdr, i64 0, i32 0',
        '  store i64 0, ptr %size_p',
        '  %cap_p = getelementptr inbounds %cssc_map_is, ptr %hdr, i64 0, i32 1',
        '  store i64 %cap1, ptr %cap_p',
        '  %entry_bytes = mul i64 %cap1, 24',
        '  %entries = call ptr @malloc(i64 %entry_bytes)',
        '  call ptr @memset(ptr %entries, i32 0, i64 %entry_bytes)',
        '  %entries_p = getelementptr inbounds %cssc_map_is, ptr %hdr, i64 0, i32 2',
        '  store ptr %entries, ptr %entries_p',
        '  ret ptr %hdr',
        '}',
        '',
        # ---- free(map) ----
        'define void @cssc_map_is_free(ptr %m) {',
        'entry:',
        '  %is_null = icmp eq ptr %m, null',
        '  br i1 %is_null, label %done, label %loop.start',
        'loop.start:',
        '  %cap_p = getelementptr inbounds %cssc_map_is, ptr %m, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %entries_p = getelementptr inbounds %cssc_map_is, ptr %m, i64 0, i32 2',
        '  %entries = load ptr, ptr %entries_p',
        '  br label %loop',
        'loop:',
        '  %i = phi i64 [ 0, %loop.start ], [ %i.next, %i_next ]',
        '  %finished = icmp uge i64 %i, %cap',
        '  br i1 %finished, label %tail, label %step',
        'step:',
        '  %entry_p = getelementptr inbounds %cssc_map_is_entry, ptr %entries, i64 %i',
        '  %state_p = getelementptr inbounds %cssc_map_is_entry, ptr %entry_p, i64 0, i32 2',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  br i1 %occ, label %release_val, label %i_next',
        'release_val:',
        '  %val_p = getelementptr inbounds %cssc_map_is_entry, ptr %entry_p, i64 0, i32 1',
        '  %val = load ptr, ptr %val_p',
        '  call void @cssc_release(ptr %val)',
        '  br label %i_next',
        'i_next:',
        '  %i.next = add i64 %i, 1',
        '  br label %loop',
        'tail:',
        '  call void @free(ptr %entries)',
        '  call void @free(ptr %m)',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        # ---- internal: probe(map, key) ----
        'define ptr @cssc_map_is_probe(ptr %m, i64 %key) {',
        'entry:',
        '  %cap_p = getelementptr inbounds %cssc_map_is, ptr %m, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %entries_p = getelementptr inbounds %cssc_map_is, ptr %m, i64 0, i32 2',
        '  %entries = load ptr, ptr %entries_p',
        '  %h = call i64 @cssc_map_is_hash(i64 %key)',
        '  %h_mod_init = urem i64 %h, %cap',
        '  br label %loop',
        'loop:',
        '  %i  = phi i64 [ 0, %entry ], [ %i.next, %miss ]',
        '  %slot = phi i64 [ %h_mod_init, %entry ], [ %slot.next, %miss ]',
        '  %entry_p = getelementptr inbounds %cssc_map_is_entry, ptr %entries, i64 %slot',
        '  %state_p = getelementptr inbounds %cssc_map_is_entry, ptr %entry_p, i64 0, i32 2',
        '  %state = load i64, ptr %state_p',
        '  %is_empty = icmp eq i64 %state, 0',
        '  br i1 %is_empty, label %ret_empty, label %check_match',
        'check_match:',
        '  %ek_p = getelementptr inbounds %cssc_map_is_entry, ptr %entry_p, i64 0, i32 0',
        '  %ek   = load i64, ptr %ek_p',
        '  %key_eq = icmp eq i64 %ek, %key',
        '  br i1 %key_eq, label %ret_match, label %miss',
        'miss:',
        '  %i.next = add i64 %i, 1',
        '  %tmp = add i64 %slot, 1',
        '  %slot.next = urem i64 %tmp, %cap',
        '  br label %loop',
        'ret_empty:',
        '  ret ptr %entry_p',
        'ret_match:',
        '  ret ptr %entry_p',
        '}',
        '',
        # ---- size ----
        'define i64 @cssc_map_is_size(ptr %m) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_map_is, ptr %m, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  ret i64 %size',
        '}',
        '',
        # ---- has ----
        'define i1 @cssc_map_is_has(ptr %m, i64 %key) {',
        'entry:',
        '  %slot = call ptr @cssc_map_is_probe(ptr %m, i64 %key)',
        '  %state_p = getelementptr inbounds %cssc_map_is_entry, ptr %slot, i64 0, i32 2',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  ret i1 %occ',
        '}',
        '',
        # ---- get — panic on miss ----
        'define ptr @cssc_map_is_get(ptr %m, i64 %key) {',
        'entry:',
        '  %slot = call ptr @cssc_map_is_probe(ptr %m, i64 %key)',
        '  %state_p = getelementptr inbounds %cssc_map_is_entry, ptr %slot, i64 0, i32 2',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  br i1 %occ, label %ok, label %panic',
        'panic:',
        '  call void @abort()',
        '  unreachable',
        'ok:',
        '  %val_p = getelementptr inbounds %cssc_map_is_entry, ptr %slot, i64 0, i32 1',
        '  %val = load ptr, ptr %val_p',
        '  ret ptr %val',
        '}',
        '',
        # ---- set: release old value if occupied. ----
        'define void @cssc_map_is_set(ptr %m, i64 %key, ptr %val) {',
        'entry:',
        '  %slot = call ptr @cssc_map_is_probe(ptr %m, i64 %key)',
        '  %state_p = getelementptr inbounds %cssc_map_is_entry, ptr %slot, i64 0, i32 2',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  br i1 %occ, label %update, label %insert',
        'update:',
        '  %val_p = getelementptr inbounds %cssc_map_is_entry, ptr %slot, i64 0, i32 1',
        '  %old = load ptr, ptr %val_p',
        '  call void @cssc_release(ptr %old)',
        '  store ptr %val, ptr %val_p',
        '  ret void',
        'insert:',
        '  %k_p = getelementptr inbounds %cssc_map_is_entry, ptr %slot, i64 0, i32 0',
        '  store i64 %key, ptr %k_p',
        '  %valp = getelementptr inbounds %cssc_map_is_entry, ptr %slot, i64 0, i32 1',
        '  store ptr %val, ptr %valp',
        '  store i64 1, ptr %state_p',
        '  %size_p = getelementptr inbounds %cssc_map_is, ptr %m, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %size.next = add i64 %size, 1',
        '  store i64 %size.next, ptr %size_p',
        '  ret void',
        '}',
        '',
        # ---- null_at ----
        'define void @cssc_map_is_null_at(ptr %m, i64 %i) {',
        'entry:',
        '  %is_null = icmp eq ptr %m, null',
        '  br i1 %is_null, label %done, label %do',
        'do:',
        '  %cap_p = getelementptr inbounds %cssc_map_is, ptr %m, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %ok = icmp ult i64 %i, %cap',
        '  br i1 %ok, label %check, label %done',
        'check:',
        '  %ent_p = getelementptr inbounds %cssc_map_is, ptr %m, i64 0, i32 2',
        '  %ent = load ptr, ptr %ent_p',
        '  %slot = getelementptr inbounds %cssc_map_is_entry, ptr %ent, i64 %i',
        '  %state_p = getelementptr inbounds %cssc_map_is_entry, ptr %slot, i64 0, i32 2',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  br i1 %occ, label %wipe, label %done',
        'wipe:',
        '  %val_p = getelementptr inbounds %cssc_map_is_entry, ptr %slot, i64 0, i32 1',
        '  %old = load ptr, ptr %val_p',
        '  call void @cssc_release(ptr %old)',
        '  store ptr null, ptr %val_p',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        # ---- null_all ----
        'define void @cssc_map_is_null_all(ptr %m) {',
        'entry:',
        '  %is_null = icmp eq ptr %m, null',
        '  br i1 %is_null, label %done, label %read',
        'read:',
        '  %cap_p = getelementptr inbounds %cssc_map_is, ptr %m, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %ent_p = getelementptr inbounds %cssc_map_is, ptr %m, i64 0, i32 2',
        '  %ent = load ptr, ptr %ent_p',
        '  br label %loop',
        'loop:',
        '  %i = phi i64 [ 0, %read ], [ %i.next, %step ]',
        '  %fin = icmp uge i64 %i, %cap',
        '  br i1 %fin, label %done, label %body',
        'body:',
        '  %slot = getelementptr inbounds %cssc_map_is_entry, ptr %ent, i64 %i',
        '  %state_p = getelementptr inbounds %cssc_map_is_entry, ptr %slot, i64 0, i32 2',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  br i1 %occ, label %wipe, label %step',
        'wipe:',
        '  %val_p = getelementptr inbounds %cssc_map_is_entry, ptr %slot, i64 0, i32 1',
        '  %old = load ptr, ptr %val_p',
        '  call void @cssc_release(ptr %old)',
        '  store ptr null, ptr %val_p',
        '  br label %step',
        'step:',
        '  %i.next = add i64 %i, 1',
        '  br label %loop',
        'done:',
        '  ret void',
        '}',
    ] + _map_bucket_readers('is', False, 'ptr', 2)


_MAP_IS_SYMBOLS = frozenset({
    'cssc_map_is_new',
    'cssc_map_is_free',
    'cssc_map_is_size',
    'cssc_map_is_has',
    'cssc_map_is_get',
    'cssc_map_is_set',
    'cssc_map_is_hash',
    'cssc_map_is_probe',
    'cssc_map_is_null_at',
    'cssc_map_is_null_all',
    'cssc_map_is_cap',
    'cssc_map_is_bstate',
    'cssc_map_is_bkey',
    'cssc_map_is_bval',
})


def _emit_cssc_map_ii() -> List[str]:
    """Phase 6 — map<int, int> host runtime.

    Header (24 B): { i64 size, i64 capacity, ptr entries }
    Entry  (24 B): { i64 key, i64 val, i64 state }

    Hash: splitmix64(key). Pure POD — no refcount work anywhere.
    """
    return [
        '',
        '; --- cssc_map_ii: hash table for map<int, int> ---',
        '%cssc_map_ii       = type { i64, i64, ptr }',
        '%cssc_map_ii_entry = type { i64, i64, i64 }',
        '',
        'declare ptr @malloc(i64)',
        'declare void @free(ptr)',
        'declare ptr @memset(ptr, i32, i64)',
        'declare void @abort() noreturn',
        '',
        # ---- splitmix64 ----
        'define i64 @cssc_map_ii_hash(i64 %k) {',
        'entry:',
        '  %s1 = lshr i64 %k, 30',
        '  %x1 = xor i64 %k, %s1',
        '  %m1 = mul i64 %x1, -4658895280553007687',
        '  %s2 = lshr i64 %m1, 27',
        '  %x2 = xor i64 %m1, %s2',
        '  %m2 = mul i64 %x2, -6298703610411919841',
        '  %s3 = lshr i64 %m2, 31',
        '  %x3 = xor i64 %m2, %s3',
        '  ret i64 %x3',
        '}',
        '',
        # ---- new ----
        'define ptr @cssc_map_ii_new(i64 %cap_hint) {',
        'entry:',
        '  %cap0 = icmp sgt i64 %cap_hint, 7',
        '  %cap1 = select i1 %cap0, i64 %cap_hint, i64 8',
        '  %hdr = call ptr @malloc(i64 24)',
        '  %size_p = getelementptr inbounds %cssc_map_ii, ptr %hdr, i64 0, i32 0',
        '  store i64 0, ptr %size_p',
        '  %cap_p = getelementptr inbounds %cssc_map_ii, ptr %hdr, i64 0, i32 1',
        '  store i64 %cap1, ptr %cap_p',
        '  %entry_bytes = mul i64 %cap1, 24',
        '  %entries = call ptr @malloc(i64 %entry_bytes)',
        '  call ptr @memset(ptr %entries, i32 0, i64 %entry_bytes)',
        '  %entries_p = getelementptr inbounds %cssc_map_ii, ptr %hdr, i64 0, i32 2',
        '  store ptr %entries, ptr %entries_p',
        '  ret ptr %hdr',
        '}',
        '',
        # ---- free: POD; just free entries + header ----
        'define void @cssc_map_ii_free(ptr %m) {',
        'entry:',
        '  %is_null = icmp eq ptr %m, null',
        '  br i1 %is_null, label %done, label %do',
        'do:',
        '  %entries_p = getelementptr inbounds %cssc_map_ii, ptr %m, i64 0, i32 2',
        '  %entries = load ptr, ptr %entries_p',
        '  call void @free(ptr %entries)',
        '  call void @free(ptr %m)',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        # ---- probe ----
        'define ptr @cssc_map_ii_probe(ptr %m, i64 %key) {',
        'entry:',
        '  %cap_p = getelementptr inbounds %cssc_map_ii, ptr %m, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %entries_p = getelementptr inbounds %cssc_map_ii, ptr %m, i64 0, i32 2',
        '  %entries = load ptr, ptr %entries_p',
        '  %h = call i64 @cssc_map_ii_hash(i64 %key)',
        '  %h_mod_init = urem i64 %h, %cap',
        '  br label %loop',
        'loop:',
        '  %i  = phi i64 [ 0, %entry ], [ %i.next, %miss ]',
        '  %slot = phi i64 [ %h_mod_init, %entry ], [ %slot.next, %miss ]',
        '  %entry_p = getelementptr inbounds %cssc_map_ii_entry, ptr %entries, i64 %slot',
        '  %state_p = getelementptr inbounds %cssc_map_ii_entry, ptr %entry_p, i64 0, i32 2',
        '  %state = load i64, ptr %state_p',
        '  %is_empty = icmp eq i64 %state, 0',
        '  br i1 %is_empty, label %ret_empty, label %check_match',
        'check_match:',
        '  %ek_p = getelementptr inbounds %cssc_map_ii_entry, ptr %entry_p, i64 0, i32 0',
        '  %ek   = load i64, ptr %ek_p',
        '  %key_eq = icmp eq i64 %ek, %key',
        '  br i1 %key_eq, label %ret_match, label %miss',
        'miss:',
        '  %i.next = add i64 %i, 1',
        '  %tmp = add i64 %slot, 1',
        '  %slot.next = urem i64 %tmp, %cap',
        '  br label %loop',
        'ret_empty:',
        '  ret ptr %entry_p',
        'ret_match:',
        '  ret ptr %entry_p',
        '}',
        '',
        # ---- size ----
        'define i64 @cssc_map_ii_size(ptr %m) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_map_ii, ptr %m, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  ret i64 %size',
        '}',
        '',
        # ---- bucket-walk readers (for whole-map stringify / copy) ----
        # cap = bucket count (struct field 1). NULL → 0.
        'define i64 @cssc_map_ii_cap(ptr %m) {',
        'entry:',
        '  %isn = icmp eq ptr %m, null',
        '  br i1 %isn, label %z, label %r',
        'r:',
        '  %cap_p = getelementptr inbounds %cssc_map_ii, ptr %m, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  ret i64 %cap',
        'z:',
        '  ret i64 0',
        '}',
        '',
        # bstate(m,i) = entries[i].state (1 = occupied). NULL/OOB → 0.
        'define i64 @cssc_map_ii_bstate(ptr %m, i64 %i) {',
        'entry:',
        '  %isn = icmp eq ptr %m, null',
        '  br i1 %isn, label %z, label %r',
        'r:',
        '  %ep = getelementptr inbounds %cssc_map_ii, ptr %m, i64 0, i32 2',
        '  %entries = load ptr, ptr %ep',
        '  %e = getelementptr inbounds %cssc_map_ii_entry, ptr %entries, i64 %i',
        '  %sp = getelementptr inbounds %cssc_map_ii_entry, ptr %e, i64 0, i32 2',
        '  %s = load i64, ptr %sp',
        '  ret i64 %s',
        'z:',
        '  ret i64 0',
        '}',
        '',
        # bkey(m,i) = entries[i].key (i64, field 0).
        'define i64 @cssc_map_ii_bkey(ptr %m, i64 %i) {',
        'entry:',
        '  %ep = getelementptr inbounds %cssc_map_ii, ptr %m, i64 0, i32 2',
        '  %entries = load ptr, ptr %ep',
        '  %e = getelementptr inbounds %cssc_map_ii_entry, ptr %entries, i64 %i',
        '  %kp = getelementptr inbounds %cssc_map_ii_entry, ptr %e, i64 0, i32 0',
        '  %k = load i64, ptr %kp',
        '  ret i64 %k',
        '}',
        '',
        # bval(m,i) = entries[i].val (i64, field 1).
        'define i64 @cssc_map_ii_bval(ptr %m, i64 %i) {',
        'entry:',
        '  %ep = getelementptr inbounds %cssc_map_ii, ptr %m, i64 0, i32 2',
        '  %entries = load ptr, ptr %ep',
        '  %e = getelementptr inbounds %cssc_map_ii_entry, ptr %entries, i64 %i',
        '  %vp = getelementptr inbounds %cssc_map_ii_entry, ptr %e, i64 0, i32 1',
        '  %v = load i64, ptr %vp',
        '  ret i64 %v',
        '}',
        '',
        # ---- has ----
        'define i1 @cssc_map_ii_has(ptr %m, i64 %key) {',
        'entry:',
        '  %slot = call ptr @cssc_map_ii_probe(ptr %m, i64 %key)',
        '  %state_p = getelementptr inbounds %cssc_map_ii_entry, ptr %slot, i64 0, i32 2',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  ret i1 %occ',
        '}',
        '',
        # ---- get ----
        'define i64 @cssc_map_ii_get(ptr %m, i64 %key) {',
        'entry:',
        '  %slot = call ptr @cssc_map_ii_probe(ptr %m, i64 %key)',
        '  %state_p = getelementptr inbounds %cssc_map_ii_entry, ptr %slot, i64 0, i32 2',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  br i1 %occ, label %ok, label %panic',
        'panic:',
        '  call void @abort()',
        '  unreachable',
        'ok:',
        '  %val_p = getelementptr inbounds %cssc_map_ii_entry, ptr %slot, i64 0, i32 1',
        '  %val = load i64, ptr %val_p',
        '  ret i64 %val',
        '}',
        '',
        # ---- set ----
        'define void @cssc_map_ii_set(ptr %m, i64 %key, i64 %val) {',
        'entry:',
        '  %slot = call ptr @cssc_map_ii_probe(ptr %m, i64 %key)',
        '  %state_p = getelementptr inbounds %cssc_map_ii_entry, ptr %slot, i64 0, i32 2',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  br i1 %occ, label %update, label %insert',
        'update:',
        '  %val_p = getelementptr inbounds %cssc_map_ii_entry, ptr %slot, i64 0, i32 1',
        '  store i64 %val, ptr %val_p',
        '  ret void',
        'insert:',
        '  %k_p = getelementptr inbounds %cssc_map_ii_entry, ptr %slot, i64 0, i32 0',
        '  store i64 %key, ptr %k_p',
        '  %valp = getelementptr inbounds %cssc_map_ii_entry, ptr %slot, i64 0, i32 1',
        '  store i64 %val, ptr %valp',
        '  store i64 1, ptr %state_p',
        '  %size_p = getelementptr inbounds %cssc_map_ii, ptr %m, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %size.next = add i64 %size, 1',
        '  store i64 %size.next, ptr %size_p',
        '  ret void',
        '}',
        '',
        # ---- null_at: zero val only, preserve key+state ----
        'define void @cssc_map_ii_null_at(ptr %m, i64 %i) {',
        'entry:',
        '  %is_null = icmp eq ptr %m, null',
        '  br i1 %is_null, label %done, label %do',
        'do:',
        '  %cap_p = getelementptr inbounds %cssc_map_ii, ptr %m, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %ok = icmp ult i64 %i, %cap',
        '  br i1 %ok, label %check, label %done',
        'check:',
        '  %ent_p = getelementptr inbounds %cssc_map_ii, ptr %m, i64 0, i32 2',
        '  %ent = load ptr, ptr %ent_p',
        '  %slot = getelementptr inbounds %cssc_map_ii_entry, ptr %ent, i64 %i',
        '  %state_p = getelementptr inbounds %cssc_map_ii_entry, ptr %slot, i64 0, i32 2',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  br i1 %occ, label %wipe, label %done',
        'wipe:',
        '  %val_p = getelementptr inbounds %cssc_map_ii_entry, ptr %slot, i64 0, i32 1',
        '  store i64 0, ptr %val_p',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        # ---- null_all ----
        'define void @cssc_map_ii_null_all(ptr %m) {',
        'entry:',
        '  %is_null = icmp eq ptr %m, null',
        '  br i1 %is_null, label %done, label %read',
        'read:',
        '  %cap_p = getelementptr inbounds %cssc_map_ii, ptr %m, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %ent_p = getelementptr inbounds %cssc_map_ii, ptr %m, i64 0, i32 2',
        '  %ent = load ptr, ptr %ent_p',
        '  br label %loop',
        'loop:',
        '  %i = phi i64 [ 0, %read ], [ %i.next, %step ]',
        '  %fin = icmp uge i64 %i, %cap',
        '  br i1 %fin, label %done, label %body',
        'body:',
        '  %slot = getelementptr inbounds %cssc_map_ii_entry, ptr %ent, i64 %i',
        '  %state_p = getelementptr inbounds %cssc_map_ii_entry, ptr %slot, i64 0, i32 2',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  br i1 %occ, label %wipe, label %step',
        'wipe:',
        '  %val_p = getelementptr inbounds %cssc_map_ii_entry, ptr %slot, i64 0, i32 1',
        '  store i64 0, ptr %val_p',
        '  br label %step',
        'step:',
        '  %i.next = add i64 %i, 1',
        '  br label %loop',
        'done:',
        '  ret void',
        '}',
    ]


_MAP_II_SYMBOLS = frozenset({
    'cssc_map_ii_new',
    'cssc_map_ii_free',
    'cssc_map_ii_size',
    'cssc_map_ii_has',
    'cssc_map_ii_get',
    'cssc_map_ii_set',
    'cssc_map_ii_hash',
    'cssc_map_ii_probe',
    'cssc_map_ii_null_at',
    'cssc_map_ii_null_all',
    'cssc_map_ii_cap',
    'cssc_map_ii_bstate',
    'cssc_map_ii_bkey',
    'cssc_map_ii_bval',
})


def _emit_cssc_map_sf() -> List[str]:
    """Phase 6 — map<string, float(f64)> host runtime.

    Header (24 B): { i64 size, i64 capacity, ptr entries }
    Entry  (32 B): { ptr key_data, i64 key_len, double val, i64 state }

    Hash: FNV-1a over key bytes. Value is POD (double); no refcount.
    Host duplicates key bytes on set; free walks keys.
    """
    return [
        '',
        '; --- cssc_map_sf: hash table for map<string, float(f64)> ---',
        '%cssc_map_sf       = type { i64, i64, ptr }',
        '%cssc_map_sf_entry = type { ptr, i64, double, i64 }',
        '',
        'declare ptr @malloc(i64)',
        'declare void @free(ptr)',
        'declare ptr @memcpy(ptr, ptr, i64)',
        'declare ptr @memset(ptr, i32, i64)',
        'declare i32 @memcmp(ptr, ptr, i64)',
        'declare void @abort() noreturn',
        '',
        # ---- FNV-1a hash ----
        'define i64 @cssc_map_sf_hash(ptr %data, i64 %len) {',
        'entry:',
        '  br label %loop',
        'loop:',
        '  %h   = phi i64 [ 14695981039346656037, %entry ], [ %h.next, %step ]',
        '  %i   = phi i64 [ 0, %entry ],                   [ %i.next, %step ]',
        '  %done = icmp uge i64 %i, %len',
        '  br i1 %done, label %end, label %step',
        'step:',
        '  %byte_p = getelementptr inbounds i8, ptr %data, i64 %i',
        '  %byte   = load i8, ptr %byte_p',
        '  %byte64 = zext i8 %byte to i64',
        '  %h.xor  = xor i64 %h, %byte64',
        '  %h.next = mul i64 %h.xor, 1099511628211',
        '  %i.next = add i64 %i, 1',
        '  br label %loop',
        'end:',
        '  ret i64 %h',
        '}',
        '',
        # ---- new ----
        'define ptr @cssc_map_sf_new(i64 %cap_hint) {',
        'entry:',
        '  %cap0 = icmp sgt i64 %cap_hint, 7',
        '  %cap1 = select i1 %cap0, i64 %cap_hint, i64 8',
        '  %hdr = call ptr @malloc(i64 24)',
        '  %size_p = getelementptr inbounds %cssc_map_sf, ptr %hdr, i64 0, i32 0',
        '  store i64 0, ptr %size_p',
        '  %cap_p = getelementptr inbounds %cssc_map_sf, ptr %hdr, i64 0, i32 1',
        '  store i64 %cap1, ptr %cap_p',
        '  %entry_bytes = mul i64 %cap1, 32',
        '  %entries = call ptr @malloc(i64 %entry_bytes)',
        '  call ptr @memset(ptr %entries, i32 0, i64 %entry_bytes)',
        '  %entries_p = getelementptr inbounds %cssc_map_sf, ptr %hdr, i64 0, i32 2',
        '  store ptr %entries, ptr %entries_p',
        '  ret ptr %hdr',
        '}',
        '',
        # ---- free: walk entries; free key bufs (POD val); then entries + header ----
        'define void @cssc_map_sf_free(ptr %m) {',
        'entry:',
        '  %is_null = icmp eq ptr %m, null',
        '  br i1 %is_null, label %done, label %loop.start',
        'loop.start:',
        '  %cap_p = getelementptr inbounds %cssc_map_sf, ptr %m, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %entries_p = getelementptr inbounds %cssc_map_sf, ptr %m, i64 0, i32 2',
        '  %entries = load ptr, ptr %entries_p',
        '  br label %loop',
        'loop:',
        '  %i = phi i64 [ 0, %loop.start ], [ %i.next, %i_next ]',
        '  %finished = icmp uge i64 %i, %cap',
        '  br i1 %finished, label %tail, label %step',
        'step:',
        '  %entry_p = getelementptr inbounds %cssc_map_sf_entry, ptr %entries, i64 %i',
        '  %state_p = getelementptr inbounds %cssc_map_sf_entry, ptr %entry_p, i64 0, i32 3',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  br i1 %occ, label %free_key, label %i_next',
        'free_key:',
        '  %key_p = getelementptr inbounds %cssc_map_sf_entry, ptr %entry_p, i64 0, i32 0',
        '  %key = load ptr, ptr %key_p',
        '  call void @free(ptr %key)',
        '  br label %i_next',
        'i_next:',
        '  %i.next = add i64 %i, 1',
        '  br label %loop',
        'tail:',
        '  call void @free(ptr %entries)',
        '  call void @free(ptr %m)',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        # ---- probe ----
        'define ptr @cssc_map_sf_probe(ptr %m, ptr %kd, i64 %klen) {',
        'entry:',
        '  %cap_p = getelementptr inbounds %cssc_map_sf, ptr %m, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %entries_p = getelementptr inbounds %cssc_map_sf, ptr %m, i64 0, i32 2',
        '  %entries = load ptr, ptr %entries_p',
        '  %h = call i64 @cssc_map_sf_hash(ptr %kd, i64 %klen)',
        '  %h_mod_init = urem i64 %h, %cap',
        '  br label %loop',
        'loop:',
        '  %i  = phi i64 [ 0, %entry ], [ %i.next, %miss ]',
        '  %slot = phi i64 [ %h_mod_init, %entry ], [ %slot.next, %miss ]',
        '  %entry_p = getelementptr inbounds %cssc_map_sf_entry, ptr %entries, i64 %slot',
        '  %state_p = getelementptr inbounds %cssc_map_sf_entry, ptr %entry_p, i64 0, i32 3',
        '  %state = load i64, ptr %state_p',
        '  %is_empty = icmp eq i64 %state, 0',
        '  br i1 %is_empty, label %ret_empty, label %check_match',
        'check_match:',
        '  %ek_p   = getelementptr inbounds %cssc_map_sf_entry, ptr %entry_p, i64 0, i32 0',
        '  %ek     = load ptr, ptr %ek_p',
        '  %elen_p = getelementptr inbounds %cssc_map_sf_entry, ptr %entry_p, i64 0, i32 1',
        '  %elen   = load i64, ptr %elen_p',
        '  %len_eq = icmp eq i64 %elen, %klen',
        '  br i1 %len_eq, label %bcmp, label %miss',
        'bcmp:',
        '  %cmp = call i32 @memcmp(ptr %ek, ptr %kd, i64 %klen)',
        '  %cmp_eq = icmp eq i32 %cmp, 0',
        '  br i1 %cmp_eq, label %ret_match, label %miss',
        'miss:',
        '  %i.next = add i64 %i, 1',
        '  %tmp = add i64 %slot, 1',
        '  %slot.next = urem i64 %tmp, %cap',
        '  br label %loop',
        'ret_empty:',
        '  ret ptr %entry_p',
        'ret_match:',
        '  ret ptr %entry_p',
        '}',
        '',
        # ---- size ----
        'define i64 @cssc_map_sf_size(ptr %m) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_map_sf, ptr %m, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  ret i64 %size',
        '}',
        '',
        # ---- has ----
        'define i1 @cssc_map_sf_has(ptr %m, ptr %kd, i64 %klen) {',
        'entry:',
        '  %slot = call ptr @cssc_map_sf_probe(ptr %m, ptr %kd, i64 %klen)',
        '  %state_p = getelementptr inbounds %cssc_map_sf_entry, ptr %slot, i64 0, i32 3',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  ret i1 %occ',
        '}',
        '',
        # ---- get — panic on miss ----
        'define double @cssc_map_sf_get(ptr %m, ptr %kd, i64 %klen) {',
        'entry:',
        '  %slot = call ptr @cssc_map_sf_probe(ptr %m, ptr %kd, i64 %klen)',
        '  %state_p = getelementptr inbounds %cssc_map_sf_entry, ptr %slot, i64 0, i32 3',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  br i1 %occ, label %ok, label %panic',
        'panic:',
        '  call void @abort()',
        '  unreachable',
        'ok:',
        '  %val_p = getelementptr inbounds %cssc_map_sf_entry, ptr %slot, i64 0, i32 2',
        '  %val = load double, ptr %val_p',
        '  ret double %val',
        '}',
        '',
        # ---- set ----
        'define void @cssc_map_sf_set(ptr %m, ptr %kd, i64 %klen, double %val) {',
        'entry:',
        '  %slot = call ptr @cssc_map_sf_probe(ptr %m, ptr %kd, i64 %klen)',
        '  %state_p = getelementptr inbounds %cssc_map_sf_entry, ptr %slot, i64 0, i32 3',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  br i1 %occ, label %update, label %insert',
        'update:',
        '  %val_p = getelementptr inbounds %cssc_map_sf_entry, ptr %slot, i64 0, i32 2',
        '  store double %val, ptr %val_p',
        '  ret void',
        'insert:',
        '  %iszero = icmp eq i64 %klen, 0',
        '  %alloc_bytes = select i1 %iszero, i64 1, i64 %klen',
        '  %key_buf = call ptr @malloc(i64 %alloc_bytes)',
        '  %cpy = call ptr @memcpy(ptr %key_buf, ptr %kd, i64 %klen)',
        '  %k_p   = getelementptr inbounds %cssc_map_sf_entry, ptr %slot, i64 0, i32 0',
        '  store ptr %key_buf, ptr %k_p',
        '  %klen_p = getelementptr inbounds %cssc_map_sf_entry, ptr %slot, i64 0, i32 1',
        '  store i64 %klen, ptr %klen_p',
        '  %valp = getelementptr inbounds %cssc_map_sf_entry, ptr %slot, i64 0, i32 2',
        '  store double %val, ptr %valp',
        '  store i64 1, ptr %state_p',
        '  %size_p = getelementptr inbounds %cssc_map_sf, ptr %m, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %size.next = add i64 %size, 1',
        '  store i64 %size.next, ptr %size_p',
        '  ret void',
        '}',
        '',
        # ---- null_at: zero double, preserve key+state ----
        'define void @cssc_map_sf_null_at(ptr %m, i64 %i) {',
        'entry:',
        '  %is_null = icmp eq ptr %m, null',
        '  br i1 %is_null, label %done, label %do',
        'do:',
        '  %cap_p = getelementptr inbounds %cssc_map_sf, ptr %m, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %ok = icmp ult i64 %i, %cap',
        '  br i1 %ok, label %check, label %done',
        'check:',
        '  %ent_p = getelementptr inbounds %cssc_map_sf, ptr %m, i64 0, i32 2',
        '  %ent = load ptr, ptr %ent_p',
        '  %slot = getelementptr inbounds %cssc_map_sf_entry, ptr %ent, i64 %i',
        '  %state_p = getelementptr inbounds %cssc_map_sf_entry, ptr %slot, i64 0, i32 3',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  br i1 %occ, label %wipe, label %done',
        'wipe:',
        '  %val_p = getelementptr inbounds %cssc_map_sf_entry, ptr %slot, i64 0, i32 2',
        '  store double 0.0, ptr %val_p',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        # ---- null_all ----
        'define void @cssc_map_sf_null_all(ptr %m) {',
        'entry:',
        '  %is_null = icmp eq ptr %m, null',
        '  br i1 %is_null, label %done, label %read',
        'read:',
        '  %cap_p = getelementptr inbounds %cssc_map_sf, ptr %m, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %ent_p = getelementptr inbounds %cssc_map_sf, ptr %m, i64 0, i32 2',
        '  %ent = load ptr, ptr %ent_p',
        '  br label %loop',
        'loop:',
        '  %i = phi i64 [ 0, %read ], [ %i.next, %step ]',
        '  %fin = icmp uge i64 %i, %cap',
        '  br i1 %fin, label %done, label %body',
        'body:',
        '  %slot = getelementptr inbounds %cssc_map_sf_entry, ptr %ent, i64 %i',
        '  %state_p = getelementptr inbounds %cssc_map_sf_entry, ptr %slot, i64 0, i32 3',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  br i1 %occ, label %wipe, label %step',
        'wipe:',
        '  %val_p = getelementptr inbounds %cssc_map_sf_entry, ptr %slot, i64 0, i32 2',
        '  store double 0.0, ptr %val_p',
        '  br label %step',
        'step:',
        '  %i.next = add i64 %i, 1',
        '  br label %loop',
        'done:',
        '  ret void',
        '}',
    ] + _map_bucket_readers('sf', True, 'double', 3)


_MAP_SF_SYMBOLS = frozenset({
    'cssc_map_sf_new',
    'cssc_map_sf_free',
    'cssc_map_sf_size',
    'cssc_map_sf_has',
    'cssc_map_sf_get',
    'cssc_map_sf_set',
    'cssc_map_sf_hash',
    'cssc_map_sf_probe',
    'cssc_map_sf_null_at',
    'cssc_map_sf_null_all',
    'cssc_map_sf_cap',
    'cssc_map_sf_bstate',
    'cssc_map_sf_bkeyptr',
    'cssc_map_sf_bkeylen',
    'cssc_map_sf_bval',
})


def _emit_cssc_map_if() -> List[str]:
    """Phase 6 — map<int, float(f64)> host runtime.

    Header (24 B): { i64 size, i64 capacity, ptr entries }
    Entry  (24 B): { i64 key, double val, i64 state }

    Hash: splitmix64. Pure POD — no refcount work.
    """
    return [
        '',
        '; --- cssc_map_if: hash table for map<int, float(f64)> ---',
        '%cssc_map_if       = type { i64, i64, ptr }',
        '%cssc_map_if_entry = type { i64, double, i64 }',
        '',
        'declare ptr @malloc(i64)',
        'declare void @free(ptr)',
        'declare ptr @memset(ptr, i32, i64)',
        'declare void @abort() noreturn',
        '',
        # ---- splitmix64 ----
        'define i64 @cssc_map_if_hash(i64 %k) {',
        'entry:',
        '  %s1 = lshr i64 %k, 30',
        '  %x1 = xor i64 %k, %s1',
        '  %m1 = mul i64 %x1, -4658895280553007687',
        '  %s2 = lshr i64 %m1, 27',
        '  %x2 = xor i64 %m1, %s2',
        '  %m2 = mul i64 %x2, -6298703610411919841',
        '  %s3 = lshr i64 %m2, 31',
        '  %x3 = xor i64 %m2, %s3',
        '  ret i64 %x3',
        '}',
        '',
        # ---- new ----
        'define ptr @cssc_map_if_new(i64 %cap_hint) {',
        'entry:',
        '  %cap0 = icmp sgt i64 %cap_hint, 7',
        '  %cap1 = select i1 %cap0, i64 %cap_hint, i64 8',
        '  %hdr = call ptr @malloc(i64 24)',
        '  %size_p = getelementptr inbounds %cssc_map_if, ptr %hdr, i64 0, i32 0',
        '  store i64 0, ptr %size_p',
        '  %cap_p = getelementptr inbounds %cssc_map_if, ptr %hdr, i64 0, i32 1',
        '  store i64 %cap1, ptr %cap_p',
        '  %entry_bytes = mul i64 %cap1, 24',
        '  %entries = call ptr @malloc(i64 %entry_bytes)',
        '  call ptr @memset(ptr %entries, i32 0, i64 %entry_bytes)',
        '  %entries_p = getelementptr inbounds %cssc_map_if, ptr %hdr, i64 0, i32 2',
        '  store ptr %entries, ptr %entries_p',
        '  ret ptr %hdr',
        '}',
        '',
        # ---- free (POD) ----
        'define void @cssc_map_if_free(ptr %m) {',
        'entry:',
        '  %is_null = icmp eq ptr %m, null',
        '  br i1 %is_null, label %done, label %do',
        'do:',
        '  %entries_p = getelementptr inbounds %cssc_map_if, ptr %m, i64 0, i32 2',
        '  %entries = load ptr, ptr %entries_p',
        '  call void @free(ptr %entries)',
        '  call void @free(ptr %m)',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        # ---- probe ----
        'define ptr @cssc_map_if_probe(ptr %m, i64 %key) {',
        'entry:',
        '  %cap_p = getelementptr inbounds %cssc_map_if, ptr %m, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %entries_p = getelementptr inbounds %cssc_map_if, ptr %m, i64 0, i32 2',
        '  %entries = load ptr, ptr %entries_p',
        '  %h = call i64 @cssc_map_if_hash(i64 %key)',
        '  %h_mod_init = urem i64 %h, %cap',
        '  br label %loop',
        'loop:',
        '  %i  = phi i64 [ 0, %entry ], [ %i.next, %miss ]',
        '  %slot = phi i64 [ %h_mod_init, %entry ], [ %slot.next, %miss ]',
        '  %entry_p = getelementptr inbounds %cssc_map_if_entry, ptr %entries, i64 %slot',
        '  %state_p = getelementptr inbounds %cssc_map_if_entry, ptr %entry_p, i64 0, i32 2',
        '  %state = load i64, ptr %state_p',
        '  %is_empty = icmp eq i64 %state, 0',
        '  br i1 %is_empty, label %ret_empty, label %check_match',
        'check_match:',
        '  %ek_p = getelementptr inbounds %cssc_map_if_entry, ptr %entry_p, i64 0, i32 0',
        '  %ek   = load i64, ptr %ek_p',
        '  %key_eq = icmp eq i64 %ek, %key',
        '  br i1 %key_eq, label %ret_match, label %miss',
        'miss:',
        '  %i.next = add i64 %i, 1',
        '  %tmp = add i64 %slot, 1',
        '  %slot.next = urem i64 %tmp, %cap',
        '  br label %loop',
        'ret_empty:',
        '  ret ptr %entry_p',
        'ret_match:',
        '  ret ptr %entry_p',
        '}',
        '',
        # ---- size ----
        'define i64 @cssc_map_if_size(ptr %m) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_map_if, ptr %m, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  ret i64 %size',
        '}',
        '',
        # ---- has ----
        'define i1 @cssc_map_if_has(ptr %m, i64 %key) {',
        'entry:',
        '  %slot = call ptr @cssc_map_if_probe(ptr %m, i64 %key)',
        '  %state_p = getelementptr inbounds %cssc_map_if_entry, ptr %slot, i64 0, i32 2',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  ret i1 %occ',
        '}',
        '',
        # ---- get ----
        'define double @cssc_map_if_get(ptr %m, i64 %key) {',
        'entry:',
        '  %slot = call ptr @cssc_map_if_probe(ptr %m, i64 %key)',
        '  %state_p = getelementptr inbounds %cssc_map_if_entry, ptr %slot, i64 0, i32 2',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  br i1 %occ, label %ok, label %panic',
        'panic:',
        '  call void @abort()',
        '  unreachable',
        'ok:',
        '  %val_p = getelementptr inbounds %cssc_map_if_entry, ptr %slot, i64 0, i32 1',
        '  %val = load double, ptr %val_p',
        '  ret double %val',
        '}',
        '',
        # ---- set ----
        'define void @cssc_map_if_set(ptr %m, i64 %key, double %val) {',
        'entry:',
        '  %slot = call ptr @cssc_map_if_probe(ptr %m, i64 %key)',
        '  %state_p = getelementptr inbounds %cssc_map_if_entry, ptr %slot, i64 0, i32 2',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  br i1 %occ, label %update, label %insert',
        'update:',
        '  %val_p = getelementptr inbounds %cssc_map_if_entry, ptr %slot, i64 0, i32 1',
        '  store double %val, ptr %val_p',
        '  ret void',
        'insert:',
        '  %k_p = getelementptr inbounds %cssc_map_if_entry, ptr %slot, i64 0, i32 0',
        '  store i64 %key, ptr %k_p',
        '  %valp = getelementptr inbounds %cssc_map_if_entry, ptr %slot, i64 0, i32 1',
        '  store double %val, ptr %valp',
        '  store i64 1, ptr %state_p',
        '  %size_p = getelementptr inbounds %cssc_map_if, ptr %m, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %size.next = add i64 %size, 1',
        '  store i64 %size.next, ptr %size_p',
        '  ret void',
        '}',
        '',
        # ---- null_at: zero double, preserve key+state ----
        'define void @cssc_map_if_null_at(ptr %m, i64 %i) {',
        'entry:',
        '  %is_null = icmp eq ptr %m, null',
        '  br i1 %is_null, label %done, label %do',
        'do:',
        '  %cap_p = getelementptr inbounds %cssc_map_if, ptr %m, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %ok = icmp ult i64 %i, %cap',
        '  br i1 %ok, label %check, label %done',
        'check:',
        '  %ent_p = getelementptr inbounds %cssc_map_if, ptr %m, i64 0, i32 2',
        '  %ent = load ptr, ptr %ent_p',
        '  %slot = getelementptr inbounds %cssc_map_if_entry, ptr %ent, i64 %i',
        '  %state_p = getelementptr inbounds %cssc_map_if_entry, ptr %slot, i64 0, i32 2',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  br i1 %occ, label %wipe, label %done',
        'wipe:',
        '  %val_p = getelementptr inbounds %cssc_map_if_entry, ptr %slot, i64 0, i32 1',
        '  store double 0.0, ptr %val_p',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        # ---- null_all ----
        'define void @cssc_map_if_null_all(ptr %m) {',
        'entry:',
        '  %is_null = icmp eq ptr %m, null',
        '  br i1 %is_null, label %done, label %read',
        'read:',
        '  %cap_p = getelementptr inbounds %cssc_map_if, ptr %m, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %ent_p = getelementptr inbounds %cssc_map_if, ptr %m, i64 0, i32 2',
        '  %ent = load ptr, ptr %ent_p',
        '  br label %loop',
        'loop:',
        '  %i = phi i64 [ 0, %read ], [ %i.next, %step ]',
        '  %fin = icmp uge i64 %i, %cap',
        '  br i1 %fin, label %done, label %body',
        'body:',
        '  %slot = getelementptr inbounds %cssc_map_if_entry, ptr %ent, i64 %i',
        '  %state_p = getelementptr inbounds %cssc_map_if_entry, ptr %slot, i64 0, i32 2',
        '  %state = load i64, ptr %state_p',
        '  %occ = icmp eq i64 %state, 1',
        '  br i1 %occ, label %wipe, label %step',
        'wipe:',
        '  %val_p = getelementptr inbounds %cssc_map_if_entry, ptr %slot, i64 0, i32 1',
        '  store double 0.0, ptr %val_p',
        '  br label %step',
        'step:',
        '  %i.next = add i64 %i, 1',
        '  br label %loop',
        'done:',
        '  ret void',
        '}',
    ] + _map_bucket_readers('if', False, 'double', 2)


_MAP_IF_SYMBOLS = frozenset({
    'cssc_map_if_new',
    'cssc_map_if_free',
    'cssc_map_if_size',
    'cssc_map_if_has',
    'cssc_map_if_get',
    'cssc_map_if_set',
    'cssc_map_if_hash',
    'cssc_map_if_probe',
    'cssc_map_if_null_at',
    'cssc_map_if_null_all',
    'cssc_map_if_cap',
    'cssc_map_if_bstate',
    'cssc_map_if_bkey',
    'cssc_map_if_bval',
})


def _emit_cssc_bind_ss() -> List[str]:
    """Phase 3 — bind (string→string pair list) runtime.

    Bind preserves insertion order and allows duplicate keys (it's
    fundamentally a list of pairs, not a deduplicated map). Each entry
    holds two `cssc_str*` heap pointers (key + value), both owned by
    the bind itself; free walks all pairs and calls cssc_string_free
    on each.

    Header layout (24 bytes — shares the %cssc_vec_int shape):
        struct cssc_bind_ss { i64 size; i64 cap; ptr entries; }
    Entry layout (16 bytes):
        struct cssc_bind_ss_entry { ptr key; ptr val; }
    """
    return [
        '',
        '; --- cssc_bind_ss: ordered pair-list, string -> string ---',
        # Self-contained prelude — the deduper collapses duplicates when
        # bind_ss is emitted alongside vector_*/string runtime groups.
        '%cssc_vec_int       = type { i64, i64, ptr }',
        '%cssc_bind_ss_entry = type { ptr, ptr }',
        '',
        'declare ptr @malloc(i64)',
        'declare ptr @realloc(ptr, i64)',
        'declare void @free(ptr)',
        'declare ptr @memset(ptr, i32, i64)',
        # cssc_string_free is defined in the string runtime group, which
        # is always co-emitted with bind_ss (the bind always owns heap
        # cssc_str pointers, so the user code triggers cssc_string_lit
        # at init, which pulls the string group in).
        '',
        'define ptr @cssc_bind_ss_new(i64 %cap_hint) {',
        'entry:',
        '  %cap0 = icmp sgt i64 %cap_hint, 0',
        '  %cap = select i1 %cap0, i64 %cap_hint, i64 4',
        '  %hdr = call ptr @malloc(i64 24)',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %hdr, i64 0, i32 0',
        '  store i64 0, ptr %size_p',
        '  %cap_p = getelementptr inbounds %cssc_vec_int, ptr %hdr, i64 0, i32 1',
        '  store i64 %cap, ptr %cap_p',
        '  %entry_bytes = mul i64 %cap, 16',
        '  %entries = call ptr @malloc(i64 %entry_bytes)',
        '  call ptr @memset(ptr %entries, i32 0, i64 %entry_bytes)',
        '  %entries_p = getelementptr inbounds %cssc_vec_int, ptr %hdr, i64 0, i32 2',
        '  store ptr %entries, ptr %entries_p',
        '  ret ptr %hdr',
        '}',
        '',
        'define void @cssc_bind_ss_free(ptr %b) {',
        'entry:',
        '  %is_null = icmp eq ptr %b, null',
        '  br i1 %is_null, label %done, label %loop.start',
        'loop.start:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %b, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %entries_p = getelementptr inbounds %cssc_vec_int, ptr %b, i64 0, i32 2',
        '  %entries = load ptr, ptr %entries_p',
        '  br label %loop',
        'loop:',
        '  %i = phi i64 [ 0, %loop.start ], [ %i.next, %i_next ]',
        '  %finished = icmp uge i64 %i, %size',
        '  br i1 %finished, label %tail, label %step',
        'step:',
        '  %entry_p = getelementptr inbounds %cssc_bind_ss_entry, ptr %entries, i64 %i',
        '  %k_p = getelementptr inbounds %cssc_bind_ss_entry, ptr %entry_p, i64 0, i32 0',
        '  %k = load ptr, ptr %k_p',
        '  call void @cssc_string_free(ptr %k)',
        '  %v_p = getelementptr inbounds %cssc_bind_ss_entry, ptr %entry_p, i64 0, i32 1',
        '  %v = load ptr, ptr %v_p',
        '  call void @cssc_string_free(ptr %v)',
        '  br label %i_next',
        'i_next:',
        '  %i.next = add i64 %i, 1',
        '  br label %loop',
        'tail:',
        '  call void @free(ptr %entries)',
        '  call void @free(ptr %b)',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        'define i64 @cssc_bind_ss_size(ptr %b) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %b, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  ret i64 %size',
        '}',
        '',
        # push_back takes ownership of both heap cssc_str pointers.
        'define void @cssc_bind_ss_push_back(ptr %b, ptr %k, ptr %v) {',
        'entry:',
        '  %size_p = getelementptr inbounds %cssc_vec_int, ptr %b, i64 0, i32 0',
        '  %size = load i64, ptr %size_p',
        '  %cap_p = getelementptr inbounds %cssc_vec_int, ptr %b, i64 0, i32 1',
        '  %cap = load i64, ptr %cap_p',
        '  %full = icmp eq i64 %size, %cap',
        '  br i1 %full, label %grow, label %store',
        'grow:',
        '  %newcap = shl i64 %cap, 1',
        '  %newbytes = mul i64 %newcap, 16',
        '  %entries_p = getelementptr inbounds %cssc_vec_int, ptr %b, i64 0, i32 2',
        '  %old_entries = load ptr, ptr %entries_p',
        '  %new_entries = call ptr @realloc(ptr %old_entries, i64 %newbytes)',
        '  store ptr %new_entries, ptr %entries_p',
        '  store i64 %newcap, ptr %cap_p',
        '  br label %store',
        'store:',
        '  %entries_p2 = getelementptr inbounds %cssc_vec_int, ptr %b, i64 0, i32 2',
        '  %entries = load ptr, ptr %entries_p2',
        '  %slot = getelementptr inbounds %cssc_bind_ss_entry, ptr %entries, i64 %size',
        '  %k_dst = getelementptr inbounds %cssc_bind_ss_entry, ptr %slot, i64 0, i32 0',
        '  store ptr %k, ptr %k_dst',
        '  %v_dst = getelementptr inbounds %cssc_bind_ss_entry, ptr %slot, i64 0, i32 1',
        '  store ptr %v, ptr %v_dst',
        '  %new_size = add i64 %size, 1',
        '  store i64 %new_size, ptr %size_p',
        '  ret void',
        '}',
    ]


_BIND_SS_SYMBOLS = frozenset({
    'cssc_bind_ss_new',
    'cssc_bind_ss_free',
    'cssc_bind_ss_size',
    'cssc_bind_ss_push_back',
})


def _emit_cssc_array_bind() -> List[str]:
    """Heterogeneous tuple-array runtime (`array<bind>`).

    Layout:
        %cssc_array_bind = type { i32 refcount, i32 size, i32 cap,
                                  ptr entries }
        entries[i] -> %cssc_bind_entry*
        %cssc_bind_entry = type { i32 refcount, i32 ncells,
                                  ptr vals_i64, ptr tags_i8,
                                  i32 pair_width }

    `vals_i64` holds the raw 64-bit bit-pattern of each cell, `tags_i8`
    the matching type tag (1=int, 2=float, 3=string, 4=bool, 5=ptr).
    For string cells, the value is a cssc_str* pointer that the bind
    entry owns — `cssc_array_bind_release` cascades cssc_release on each
    string cell when the array's refcount hits zero.

    `pair_width` records the cells-per-pair of the source literal: 0
    means the literal was the flat form `{a, b, c}` (array_literal),
    N>0 means the structured form `{a, b; c, d; e, f}` with N cells
    per pair (bind_literal). The runtime `cssc_bind_entry_pair_cell_*`
    helpers honour this to translate `i[row][col]` chained-index access
    into `vals[row * pair_width + col]`.

    The push-back ABI uses a builder buffer allocated by
    `cssc_array_bind_cells_new`. The buffer is
    `[i32 ncells][i32 pair_width][i64 vals[N]][i8 tags[N]]` — a fixed
    8-byte header followed by the cell payloads. The CIR lowering calls
    `cssc_array_bind_cells_set_pair_width` after `cells_new` whenever
    the source literal was the `;`-separated form; for array_literal
    sources the slot stays at its zero-init default.
    """
    return [
        '',
        '; --- cssc_array_bind: heterogeneous N-cell tuple array ---',
        '%cssc_array_bind = type { i32, i32, i32, ptr }',
        '%cssc_bind_entry = type { i32, i32, ptr, ptr, i32 }',
        # The `cssc_vec_int` + `cssc_bind_ss_entry` shells are also
        # referenced by the #delmember helpers below for vector / map /
        # bind kinds. Declare them here so a program that only uses one
        # of those containers (and so doesn\'t pull the bind_ss / map_si
        # groups) still sees the types. Duplicate definitions across
        # groups are collapsed by the dedup pass at the bottom of
        # emit_runtime_ll, so re-declaring is harmless.
        '%cssc_vec_int = type { i64, i64, ptr }',
        '%cssc_bind_ss_entry = type { ptr, ptr }',
        '',
        'declare ptr @malloc(i64)',
        'declare ptr @realloc(ptr, i64)',
        'declare void @free(ptr)',
        'declare ptr @memcpy(ptr, ptr, i64)',
        'declare ptr @memset(ptr, i32, i64)',
        # cssc_retain and cssc_release are *defined* by the string runtime
        # group (the bind's heap cells are cssc_str* whose refcounts go
        # through that group's release path). No redeclare here — clang
        # rejects declare-after-define for the same symbol.
        '',
        # ---- Builder buffer (cells_new / set_val / set_tag / set_pair_width) ----
        # Layout: [i32 ncells][i32 pair_width][i64 vals[N]][i8 tags[N]]
        # — a single malloc the runtime owns and frees in push_back.
        # pair_width is initialised to 0; the CIR lowering calls
        # `cssc_array_bind_cells_set_pair_width(buf, N)` whenever the
        # source literal used the `;`-separated structured form.
        'define ptr @cssc_array_bind_cells_new(i64 %n) {',
        'entry:',
        '  %sz_vals = mul i64 %n, 8',
        '  %tail    = add i64 %sz_vals, %n',
        '  %total   = add i64 8, %tail',
        '  %buf     = call ptr @malloc(i64 %total)',
        '  %n32 = trunc i64 %n to i32',
        '  store i32 %n32, ptr %buf',
        # Zero-init the pair_width slot at +4. Without this, an uninit
        # malloc could leave a junk pair_width that downstream
        # `cssc_bind_entry_pair_cell_*` reads, producing the same kind
        # of small-int-as-pointer crash as the SCOPE_POP_UAF class.
        '  %pw_p = getelementptr inbounds i8, ptr %buf, i64 4',
        '  store i32 0, ptr %pw_p',
        '  ret ptr %buf',
        '}',
        '',
        'define void @cssc_array_bind_cells_set_pair_width(ptr %buf, i64 %pw) {',
        'entry:',
        '  %is_null = icmp eq ptr %buf, null',
        '  br i1 %is_null, label %done, label %store',
        'store:',
        '  %pw_p = getelementptr inbounds i8, ptr %buf, i64 4',
        '  %pw32 = trunc i64 %pw to i32',
        '  store i32 %pw32, ptr %pw_p',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        'define void @cssc_array_bind_cells_set_val(ptr %buf, i64 %idx, i64 %v) {',
        'entry:',
        '  %vals = getelementptr inbounds i8, ptr %buf, i64 8',
        '  %slot = getelementptr inbounds i64, ptr %vals, i64 %idx',
        '  store i64 %v, ptr %slot',
        '  ret void',
        '}',
        '',
        'define void @cssc_array_bind_cells_set_tag(ptr %buf, i64 %idx, i64 %tag) {',
        'entry:',
        # Tag i8 buffer starts after the ncells-sized i64 region. The runtime
        # consumer (push_back) knows ncells so we just write here at offset
        # `8*ncells + idx`. But this function doesn't know ncells — instead
        # we encode tags into a separate stride; push_back will resolve.
        # To keep the IR simple, we stash tags in the upper byte of each
        # i64 slot's high nibble. But that conflicts with int values.
        # Use a different scheme: cells_new actually allocates a struct
        # with both arrays plus a leading ncells field. Re-define layout:
        #   [i32 ncells][padding 4][i64 vals[N]][i8 tags[N]]
        # cells_new sized the buffer at total = 8 (header) + 8*N + N.
        # Update cells_new to add 8-byte header.
        '  %buf_i8 = bitcast ptr %buf to ptr',
        # tag offset from buf base = 8 (hdr) + 8*N + idx ; N stored at +0.
        '  %n_ptr  = bitcast ptr %buf_i8 to ptr',
        '  %n32    = load i32, ptr %n_ptr',
        '  %n64    = zext i32 %n32 to i64',
        '  %vals_off = add i64 8, 0',
        '  %tag_off0 = mul i64 %n64, 8',
        '  %tag_off  = add i64 %vals_off, %tag_off0',
        '  %tag_off2 = add i64 %tag_off, %idx',
        '  %tag_slot = getelementptr inbounds i8, ptr %buf_i8, i64 %tag_off2',
        '  %tag_b    = trunc i64 %tag to i8',
        '  store i8 %tag_b, ptr %tag_slot',
        '  ret void',
        '}',
        '',
        # ---- Array constructor / size ----
        'define ptr @cssc_array_bind_new(i64 %cap_hint) {',
        'entry:',
        '  %is_pos = icmp sgt i64 %cap_hint, 0',
        '  %cap = select i1 %is_pos, i64 %cap_hint, i64 4',
        '  %hdr = call ptr @malloc(i64 16)',
        '  %rc_p = getelementptr inbounds %cssc_array_bind, ptr %hdr, i64 0, i32 0',
        '  store i32 1, ptr %rc_p',
        '  %sz_p = getelementptr inbounds %cssc_array_bind, ptr %hdr, i64 0, i32 1',
        '  store i32 0, ptr %sz_p',
        '  %cap_p = getelementptr inbounds %cssc_array_bind, ptr %hdr, i64 0, i32 2',
        '  %cap32 = trunc i64 %cap to i32',
        '  store i32 %cap32, ptr %cap_p',
        '  %ent_bytes = mul i64 %cap, 8',
        '  %ent = call ptr @malloc(i64 %ent_bytes)',
        '  call ptr @memset(ptr %ent, i32 0, i64 %ent_bytes)',
        '  %ent_p = getelementptr inbounds %cssc_array_bind, ptr %hdr, i64 0, i32 3',
        '  store ptr %ent, ptr %ent_p',
        '  ret ptr %hdr',
        '}',
        '',
        'define i64 @cssc_array_bind_size(ptr %a) {',
        'entry:',
        '  %sz_p = getelementptr inbounds %cssc_array_bind, ptr %a, i64 0, i32 1',
        '  %sz32 = load i32, ptr %sz_p',
        '  %sz64 = zext i32 %sz32 to i64',
        '  ret i64 %sz64',
        '}',
        '',
        # ---- Entry free (releases string cells then frees buffers) ----
        'define void @cssc_bind_entry_free(ptr %e) {',
        'entry:',
        '  %is_null = icmp eq ptr %e, null',
        '  br i1 %is_null, label %done, label %read',
        'read:',
        '  %n_p = getelementptr inbounds %cssc_bind_entry, ptr %e, i64 0, i32 1',
        '  %n32 = load i32, ptr %n_p',
        '  %vals_p = getelementptr inbounds %cssc_bind_entry, ptr %e, i64 0, i32 2',
        '  %vals = load ptr, ptr %vals_p',
        '  %tags_p = getelementptr inbounds %cssc_bind_entry, ptr %e, i64 0, i32 3',
        '  %tags = load ptr, ptr %tags_p',
        '  br label %loop',
        'loop:',
        '  %i = phi i32 [ 0, %read ], [ %i.next, %step ]',
        '  %fin = icmp uge i32 %i, %n32',
        '  br i1 %fin, label %tail, label %body',
        'body:',
        '  %i64 = zext i32 %i to i64',
        '  %tslot = getelementptr inbounds i8, ptr %tags, i64 %i64',
        '  %tag = load i8, ptr %tslot',
        '  %vslot = getelementptr inbounds i64, ptr %vals, i64 %i64',
        '  %vbits = load i64, ptr %vslot',
        '  %vp = inttoptr i64 %vbits to ptr',
        # tag 3 = heap string (cssc_release); tag 6 = nested array_bind
        # (cssc_array_bind_release — refcount cascade); tag 7 = nested map_si
        # (cssc_map_si_free — the array<auto> cell owns an independent clone).
        # Scalar tags 1/2/4 own nothing.
        '  %is_str = icmp eq i8 %tag, 3',
        '  br i1 %is_str, label %rel_str, label %chk6',
        'chk6:',
        '  %is_arr = icmp eq i8 %tag, 6',
        '  br i1 %is_arr, label %rel_arr, label %chk7',
        'chk7:',
        '  %is_map = icmp eq i8 %tag, 7',
        '  br i1 %is_map, label %rel_map, label %step',
        'rel_str:',
        '  call void @cssc_release(ptr %vp)',
        '  br label %step',
        'rel_arr:',
        '  call void @cssc_array_bind_release(ptr %vp)',
        '  br label %step',
        'rel_map:',
        '  call void @cssc_map_si_free(ptr %vp)',
        '  br label %step',
        'step:',
        '  %i.next = add i32 %i, 1',
        '  br label %loop',
        'tail:',
        '  call void @free(ptr %vals)',
        '  call void @free(ptr %tags)',
        '  call void @free(ptr %e)',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        # ---- push_back: copies (vals, tags) from builder buf into a new entry ----
        'define void @cssc_array_bind_push_back(ptr %a, i64 %n, ptr %buf) {',
        'entry:',
        # Grow if needed.
        '  %sz_p = getelementptr inbounds %cssc_array_bind, ptr %a, i64 0, i32 1',
        '  %cap_p = getelementptr inbounds %cssc_array_bind, ptr %a, i64 0, i32 2',
        '  %ent_p = getelementptr inbounds %cssc_array_bind, ptr %a, i64 0, i32 3',
        '  %sz32 = load i32, ptr %sz_p',
        '  %cap32 = load i32, ptr %cap_p',
        '  %full = icmp eq i32 %sz32, %cap32',
        '  br i1 %full, label %grow, label %store',
        'grow:',
        '  %newcap32 = shl i32 %cap32, 1',
        '  %newcap64 = zext i32 %newcap32 to i64',
        '  %new_bytes = mul i64 %newcap64, 8',
        '  %old_ent = load ptr, ptr %ent_p',
        '  %new_ent = call ptr @realloc(ptr %old_ent, i64 %new_bytes)',
        '  store ptr %new_ent, ptr %ent_p',
        '  store i32 %newcap32, ptr %cap_p',
        '  br label %store',
        'store:',
        # Allocate the new entry, copy vals + tags from builder, copy
        # pair_width from buf header.
        # Struct shape `{i32, i32, ptr, ptr, i32}` is 32 bytes on
        # 64-bit (8-byte ptr alignment + trailing pad after i32).
        '  %e = call ptr @malloc(i64 32)',
        '  %erc = getelementptr inbounds %cssc_bind_entry, ptr %e, i64 0, i32 0',
        '  store i32 1, ptr %erc',
        '  %en  = getelementptr inbounds %cssc_bind_entry, ptr %e, i64 0, i32 1',
        '  %n32 = trunc i64 %n to i32',
        '  store i32 %n32, ptr %en',
        '  %vals_bytes = mul i64 %n, 8',
        '  %new_vals = call ptr @malloc(i64 %vals_bytes)',
        '  %new_tags = call ptr @malloc(i64 %n)',
        # buf layout: [i32 ncells][i32 pair_width][i64 vals[n]][i8 tags[n]]
        '  %buf_vals_off = add i64 8, 0',
        '  %buf_vals = getelementptr inbounds i8, ptr %buf, i64 %buf_vals_off',
        '  call ptr @memcpy(ptr %new_vals, ptr %buf_vals, i64 %vals_bytes)',
        '  %buf_tags_off = add i64 %buf_vals_off, %vals_bytes',
        '  %buf_tags = getelementptr inbounds i8, ptr %buf, i64 %buf_tags_off',
        '  call ptr @memcpy(ptr %new_tags, ptr %buf_tags, i64 %n)',
        '  %evp = getelementptr inbounds %cssc_bind_entry, ptr %e, i64 0, i32 2',
        '  store ptr %new_vals, ptr %evp',
        '  %etp = getelementptr inbounds %cssc_bind_entry, ptr %e, i64 0, i32 3',
        '  store ptr %new_tags, ptr %etp',
        # Copy pair_width from buf header (+4) into entry field i32 #4.
        '  %buf_pw_p = getelementptr inbounds i8, ptr %buf, i64 4',
        '  %buf_pw = load i32, ptr %buf_pw_p',
        '  %epwp = getelementptr inbounds %cssc_bind_entry, ptr %e, i64 0, i32 4',
        '  store i32 %buf_pw, ptr %epwp',
        # Append entry-ptr to array.
        '  %ent_now = load ptr, ptr %ent_p',
        '  %sz_now = load i32, ptr %sz_p',
        '  %sz64 = zext i32 %sz_now to i64',
        '  %slot = getelementptr inbounds ptr, ptr %ent_now, i64 %sz64',
        '  store ptr %e, ptr %slot',
        '  %sz_inc = add i32 %sz_now, 1',
        '  store i32 %sz_inc, ptr %sz_p',
        '  call void @free(ptr %buf)',
        '  ret void',
        '}',
        '',
        # ---- bind_entry: standalone heterogeneous record ----
        # Takes a builder buffer (see cssc_array_bind_cells_new) and
        # converts it to a cssc_bind_entry the caller owns. Mirrors the
        # entry-creation half of cssc_array_bind_push_back but doesn't
        # push into any array — used by `#stack[bind, …] m = {…};`.
        'define ptr @cssc_bind_entry_from_buf(i64 %n, ptr %buf) {',
        'entry:',
        # Struct {i32, i32, ptr, ptr, i32} → 32 bytes on 64-bit.
        '  %e = call ptr @malloc(i64 32)',
        '  %erc = getelementptr inbounds %cssc_bind_entry, ptr %e, i64 0, i32 0',
        '  store i32 1, ptr %erc',
        '  %en  = getelementptr inbounds %cssc_bind_entry, ptr %e, i64 0, i32 1',
        '  %n32 = trunc i64 %n to i32',
        '  store i32 %n32, ptr %en',
        '  %vals_bytes = mul i64 %n, 8',
        '  %new_vals = call ptr @malloc(i64 %vals_bytes)',
        '  %new_tags = call ptr @malloc(i64 %n)',
        '  %buf_vals_off = add i64 8, 0',
        '  %buf_vals = getelementptr inbounds i8, ptr %buf, i64 %buf_vals_off',
        '  call ptr @memcpy(ptr %new_vals, ptr %buf_vals, i64 %vals_bytes)',
        '  %buf_tags_off = add i64 %buf_vals_off, %vals_bytes',
        '  %buf_tags = getelementptr inbounds i8, ptr %buf, i64 %buf_tags_off',
        '  call ptr @memcpy(ptr %new_tags, ptr %buf_tags, i64 %n)',
        '  %evp = getelementptr inbounds %cssc_bind_entry, ptr %e, i64 0, i32 2',
        '  store ptr %new_vals, ptr %evp',
        '  %etp = getelementptr inbounds %cssc_bind_entry, ptr %e, i64 0, i32 3',
        '  store ptr %new_tags, ptr %etp',
        # Copy pair_width from buf header (+4) into entry.
        '  %buf_pw_p = getelementptr inbounds i8, ptr %buf, i64 4',
        '  %buf_pw = load i32, ptr %buf_pw_p',
        '  %epwp = getelementptr inbounds %cssc_bind_entry, ptr %e, i64 0, i32 4',
        '  store i32 %buf_pw, ptr %epwp',
        '  call void @free(ptr %buf)',
        '  ret ptr %e',
        '}',
        '',
        # ---- array<bind>.push_back(bind_handle) ----
        # Clone the cells of `ent` into a new bind_entry owned by `a`.
        # The caller\'s `ent` stays valid (and still needs its own free
        # later) — clone semantics avoids tricky ownership transfer
        # when the user does `#stack[bind, …] m = {…}; arr.push_back(m);
        # #delete[m];`.
        'define void @cssc_array_bind_push_entry(ptr %a, ptr %ent) {',
        'entry:',
        '  %is_null_a = icmp eq ptr %a, null',
        '  %is_null_e = icmp eq ptr %ent, null',
        '  %any_null = or i1 %is_null_a, %is_null_e',
        '  br i1 %any_null, label %done, label %read',
        'read:',
        '  %en_p = getelementptr inbounds %cssc_bind_entry, ptr %ent, i64 0, i32 1',
        '  %n32 = load i32, ptr %en_p',
        '  %n64 = zext i32 %n32 to i64',
        '  %src_vals_p = getelementptr inbounds %cssc_bind_entry, ptr %ent, i64 0, i32 2',
        '  %src_vals = load ptr, ptr %src_vals_p',
        '  %src_tags_p = getelementptr inbounds %cssc_bind_entry, ptr %ent, i64 0, i32 3',
        '  %src_tags = load ptr, ptr %src_tags_p',
        # Grow array if needed (mirrors cssc_array_bind_push_back logic).
        '  %sz_p = getelementptr inbounds %cssc_array_bind, ptr %a, i64 0, i32 1',
        '  %cap_p = getelementptr inbounds %cssc_array_bind, ptr %a, i64 0, i32 2',
        '  %ent_arr_p = getelementptr inbounds %cssc_array_bind, ptr %a, i64 0, i32 3',
        '  %sz_now = load i32, ptr %sz_p',
        '  %cap_now = load i32, ptr %cap_p',
        '  %full = icmp eq i32 %sz_now, %cap_now',
        '  br i1 %full, label %grow, label %alloc_ent',
        'grow:',
        '  %newcap32 = shl i32 %cap_now, 1',
        '  %newcap64 = zext i32 %newcap32 to i64',
        '  %new_bytes = mul i64 %newcap64, 8',
        '  %old_ent_arr = load ptr, ptr %ent_arr_p',
        '  %new_ent_arr = call ptr @realloc(ptr %old_ent_arr, i64 %new_bytes)',
        '  store ptr %new_ent_arr, ptr %ent_arr_p',
        '  store i32 %newcap32, ptr %cap_p',
        '  br label %alloc_ent',
        'alloc_ent:',
        # Struct {i32, i32, ptr, ptr, i32} → 32 bytes on 64-bit
        # (i32 + i32 + 8-byte-aligned ptr + ptr + i32 + 4-byte tail pad).
        '  %new_e = call ptr @malloc(i64 32)',
        '  %new_erc = getelementptr inbounds %cssc_bind_entry, ptr %new_e, i64 0, i32 0',
        '  store i32 1, ptr %new_erc',
        '  %new_en = getelementptr inbounds %cssc_bind_entry, ptr %new_e, i64 0, i32 1',
        '  store i32 %n32, ptr %new_en',
        '  %vbytes = mul i64 %n64, 8',
        '  %dst_vals = call ptr @malloc(i64 %vbytes)',
        '  %dst_tags = call ptr @malloc(i64 %n64)',
        '  call ptr @memcpy(ptr %dst_vals, ptr %src_vals, i64 %vbytes)',
        '  call ptr @memcpy(ptr %dst_tags, ptr %src_tags, i64 %n64)',
        '  %new_evp = getelementptr inbounds %cssc_bind_entry, ptr %new_e, i64 0, i32 2',
        '  store ptr %dst_vals, ptr %new_evp',
        '  %new_etp = getelementptr inbounds %cssc_bind_entry, ptr %new_e, i64 0, i32 3',
        '  store ptr %dst_tags, ptr %new_etp',
        # Copy pair_width from src entry → new entry. Clones preserve
        # the literal shape so `i[row][col]` continues working after
        # array<bind>.push_back(handle).
        '  %src_pw_p = getelementptr inbounds %cssc_bind_entry, ptr %ent, i64 0, i32 4',
        '  %src_pw = load i32, ptr %src_pw_p',
        '  %new_pwp = getelementptr inbounds %cssc_bind_entry, ptr %new_e, i64 0, i32 4',
        '  store i32 %src_pw, ptr %new_pwp',
        # Retain string cells we copied (clone-semantics requires that
        # both `ent` and the new array entry own valid refs).
        '  br label %ref_loop',
        'ref_loop:',
        '  %ri = phi i32 [ 0, %alloc_ent ], [ %ri.next, %ref_step ]',
        '  %r_fin = icmp uge i32 %ri, %n32',
        '  br i1 %r_fin, label %store_slot, label %ref_body',
        'ref_body:',
        '  %ri64 = zext i32 %ri to i64',
        '  %rtslot = getelementptr inbounds i8, ptr %dst_tags, i64 %ri64',
        '  %rtag = load i8, ptr %rtslot',
        '  %is_str = icmp eq i8 %rtag, 3',
        '  br i1 %is_str, label %do_retain, label %ref_step',
        'do_retain:',
        '  %rvslot = getelementptr inbounds i64, ptr %dst_vals, i64 %ri64',
        '  %rvbits = load i64, ptr %rvslot',
        '  %rvp = inttoptr i64 %rvbits to ptr',
        '  call void @cssc_retain(ptr %rvp)',
        '  br label %ref_step',
        'ref_step:',
        '  %ri.next = add i32 %ri, 1',
        '  br label %ref_loop',
        'store_slot:',
        '  %ent_arr_now = load ptr, ptr %ent_arr_p',
        '  %sz64 = zext i32 %sz_now to i64',
        '  %slot = getelementptr inbounds ptr, ptr %ent_arr_now, i64 %sz64',
        '  store ptr %new_e, ptr %slot',
        '  %sz_inc = add i32 %sz_now, 1',
        '  store i32 %sz_inc, ptr %sz_p',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        # ---- select-iteration helpers ----
        # `cssc_array_bind_get_entry(arr, i)` — returns entries[i] or
        # NULL when i is out of bounds. The NULL return is also what
        # `#delmember[arr[i]]` leaves behind, so a `if (i == 0x0)
        # break;` inside the select body cleanly terminates the loop.
        'define ptr @cssc_array_bind_get_entry(ptr %a, i64 %i) {',
        'entry:',
        '  %is_null = icmp eq ptr %a, null',
        '  br i1 %is_null, label %ret_null, label %check',
        'check:',
        '  %sz_p = getelementptr inbounds %cssc_array_bind, ptr %a, i64 0, i32 1',
        '  %sz32 = load i32, ptr %sz_p',
        '  %sz64 = zext i32 %sz32 to i64',
        '  %ok = icmp ult i64 %i, %sz64',
        '  br i1 %ok, label %load, label %ret_null',
        'load:',
        '  %ent_p = getelementptr inbounds %cssc_array_bind, ptr %a, i64 0, i32 3',
        '  %ent_arr = load ptr, ptr %ent_p',
        '  %slot = getelementptr inbounds ptr, ptr %ent_arr, i64 %i',
        '  %ep = load ptr, ptr %slot',
        '  ret ptr %ep',
        'ret_null:',
        '  ret ptr null',
        '}',
        '',
        # `cssc_array_bind_get_str(arr, i)` — read element i as a string,
        # returning a FRESH empty heap string on out-of-bounds (or a void
        # cell). This mirrors the interpreter, whose `array<auto>[oob]`
        # yields "" (a valid empty string) rather than trapping — so
        # `flag = args[i]` on a missing arg is safe to compare and #delete.
        'define ptr @cssc_array_bind_get_str(ptr %a, i64 %i) {',
        'entry:',
        '  %ent = call ptr @cssc_array_bind_get_entry(ptr %a, i64 %i)',
        '  %isn = icmp eq ptr %ent, null',
        '  br i1 %isn, label %empty, label %read',
        'read:',
        '  %v = call ptr @cssc_bind_entry_cell_val(ptr %ent, i64 0)',
        '  %isn2 = icmp eq ptr %v, null',
        '  br i1 %isn2, label %empty, label %retv',
        'retv:',
        '  ret ptr %v',
        'empty:',
        '  %e = call ptr @cssc_string_lit(ptr null, i64 0)',
        '  ret ptr %e',
        '}',
        '',
        # `cssc_bind_entry_cell_int(ent, i)` — raw 64-bit cell value
        # interpreted as int. For numeric cells the bits are the
        # value directly; for ptr cells the result is the ptr cast to
        # i64 (rarely useful — callers should hit `_cell_val` for
        # those). Caller picks the right helper based on context.
        'define i64 @cssc_bind_entry_cell_int(ptr %ent, i64 %i) {',
        'entry:',
        '  %is_null = icmp eq ptr %ent, null',
        '  br i1 %is_null, label %ret_zero, label %check',
        'check:',
        '  %n_p = getelementptr inbounds %cssc_bind_entry, ptr %ent, i64 0, i32 1',
        '  %n32 = load i32, ptr %n_p',
        '  %n64 = zext i32 %n32 to i64',
        '  %ok = icmp ult i64 %i, %n64',
        '  br i1 %ok, label %load, label %ret_zero',
        'load:',
        '  %v_p = getelementptr inbounds %cssc_bind_entry, ptr %ent, i64 0, i32 2',
        '  %vals = load ptr, ptr %v_p',
        '  %slot = getelementptr inbounds i64, ptr %vals, i64 %i',
        '  %v = load i64, ptr %slot',
        '  ret i64 %v',
        'ret_zero:',
        '  ret i64 0',
        '}',
        '',
        # `cssc_bind_entry_cell_val(ent, i)` — returns the i-th cell\'s
        # raw 64-bit value bits as a ptr. Tag-discrimination is the
        # caller\'s responsibility; for string cells, the returned ptr
        # IS a cssc_str* directly. For int cells, the lower 64 bits of
        # the ptr-cast i64 carry the value (use ptrtoint).
        'define ptr @cssc_bind_entry_cell_val(ptr %ent, i64 %i) {',
        'entry:',
        '  %is_null = icmp eq ptr %ent, null',
        '  br i1 %is_null, label %ret_null, label %check',
        'check:',
        '  %n_p = getelementptr inbounds %cssc_bind_entry, ptr %ent, i64 0, i32 1',
        '  %n32 = load i32, ptr %n_p',
        '  %n64 = zext i32 %n32 to i64',
        '  %ok = icmp ult i64 %i, %n64',
        '  br i1 %ok, label %load, label %ret_null',
        'load:',
        '  %v_p = getelementptr inbounds %cssc_bind_entry, ptr %ent, i64 0, i32 2',
        '  %vals = load ptr, ptr %v_p',
        '  %slot = getelementptr inbounds i64, ptr %vals, i64 %i',
        '  %vbits = load i64, ptr %slot',
        '  %vp = inttoptr i64 %vbits to ptr',
        '  ret ptr %vp',
        'ret_null:',
        '  ret ptr null',
        '}',
        '',
        # `cssc_bind_entry_pair_width(ent)` — returns the pair_width
        # field. NULL-safe. 0 means flat (array_literal source); N>0
        # means N cells per pair (bind_literal source).
        'define i64 @cssc_bind_entry_pair_width(ptr %ent) {',
        'entry:',
        '  %is_null = icmp eq ptr %ent, null',
        '  br i1 %is_null, label %ret_zero, label %read',
        'read:',
        '  %pw_p = getelementptr inbounds %cssc_bind_entry, ptr %ent, i64 0, i32 4',
        '  %pw = load i32, ptr %pw_p',
        '  %pw64 = zext i32 %pw to i64',
        '  ret i64 %pw64',
        'ret_zero:',
        '  ret i64 0',
        '}',
        '',
        # `cssc_bind_entry_ncells(ent)` — total cell count (struct field 1).
        # NULL-safe. Used by the container stringify to iterate every cell.
        'define i64 @cssc_bind_entry_ncells(ptr %ent) {',
        'entry:',
        '  %is_null = icmp eq ptr %ent, null',
        '  br i1 %is_null, label %ret_zero, label %read',
        'read:',
        '  %n_p = getelementptr inbounds %cssc_bind_entry, ptr %ent, i64 0, i32 1',
        '  %n32 = load i32, ptr %n_p',
        '  %n64 = zext i32 %n32 to i64',
        '  ret i64 %n64',
        'ret_zero:',
        '  ret i64 0',
        '}',
        '',
        # `cssc_bind_entry_cell_tag(ent, i)` — the i-th cell\'s type tag
        # (tags[] is struct field 3, a byte array — 1 byte per tag:
        # 1=int 2=float 3=string 4=bool 5=ptr). NULL-safe + bounds-checked.
        'define i64 @cssc_bind_entry_cell_tag(ptr %ent, i64 %i) {',
        'entry:',
        '  %is_null = icmp eq ptr %ent, null',
        '  br i1 %is_null, label %ret_zero, label %check',
        'check:',
        '  %n_p = getelementptr inbounds %cssc_bind_entry, ptr %ent, i64 0, i32 1',
        '  %n32 = load i32, ptr %n_p',
        '  %n64 = zext i32 %n32 to i64',
        '  %ok = icmp ult i64 %i, %n64',
        '  br i1 %ok, label %load, label %ret_zero',
        'load:',
        '  %t_p = getelementptr inbounds %cssc_bind_entry, ptr %ent, i64 0, i32 3',
        '  %tags = load ptr, ptr %t_p',
        '  %slot = getelementptr inbounds i8, ptr %tags, i64 %i',
        '  %t8 = load i8, ptr %slot',
        '  %t64 = zext i8 %t8 to i64',
        '  ret i64 %t64',
        'ret_zero:',
        '  ret i64 0',
        '}',
        '',
        # `cssc_bind_entry_pair_cell_val(ent, row, col)` — chained-index
        # access. Computes flat_idx = row * pair_width + col; returns
        # vals[flat_idx] as ptr. If pair_width == 0 the entry is a flat
        # array_literal — fall back to row as the linear index and ignore
        # col (this lets `i[row][col]` against a flat source degrade
        # gracefully rather than corrupting). NULL-safe, bounds-checked.
        'define ptr @cssc_bind_entry_pair_cell_val(ptr %ent, i64 %row, i64 %col) {',
        'entry:',
        '  %is_null = icmp eq ptr %ent, null',
        '  br i1 %is_null, label %ret_null, label %check',
        'check:',
        '  %pw_p = getelementptr inbounds %cssc_bind_entry, ptr %ent, i64 0, i32 4',
        '  %pw32 = load i32, ptr %pw_p',
        '  %pw64 = zext i32 %pw32 to i64',
        '  %is_flat = icmp eq i64 %pw64, 0',
        '  br i1 %is_flat, label %flat_idx, label %compute',
        'flat_idx:',
        '  br label %use_idx',
        'compute:',
        '  %rxw = mul i64 %row, %pw64',
        '  %idx_struct = add i64 %rxw, %col',
        '  br label %use_idx',
        'use_idx:',
        '  %idx = phi i64 [ %row, %flat_idx ], [ %idx_struct, %compute ]',
        '  %n_p = getelementptr inbounds %cssc_bind_entry, ptr %ent, i64 0, i32 1',
        '  %n32 = load i32, ptr %n_p',
        '  %n64 = zext i32 %n32 to i64',
        '  %ok = icmp ult i64 %idx, %n64',
        '  br i1 %ok, label %load, label %ret_null',
        'load:',
        '  %v_p = getelementptr inbounds %cssc_bind_entry, ptr %ent, i64 0, i32 2',
        '  %vals = load ptr, ptr %v_p',
        '  %slot = getelementptr inbounds i64, ptr %vals, i64 %idx',
        '  %vbits = load i64, ptr %slot',
        '  %vp = inttoptr i64 %vbits to ptr',
        '  ret ptr %vp',
        'ret_null:',
        '  ret ptr null',
        '}',
        '',
        # `cssc_bind_entry_pair_cell_int(ent, row, col)` — same as
        # pair_cell_val but returns the full 64-bit cell as i64.
        'define i64 @cssc_bind_entry_pair_cell_int(ptr %ent, i64 %row, i64 %col) {',
        'entry:',
        '  %is_null = icmp eq ptr %ent, null',
        '  br i1 %is_null, label %ret_zero, label %check',
        'check:',
        '  %pw_p = getelementptr inbounds %cssc_bind_entry, ptr %ent, i64 0, i32 4',
        '  %pw32 = load i32, ptr %pw_p',
        '  %pw64 = zext i32 %pw32 to i64',
        '  %is_flat = icmp eq i64 %pw64, 0',
        '  br i1 %is_flat, label %flat_idx, label %compute',
        'flat_idx:',
        '  br label %use_idx',
        'compute:',
        '  %rxw = mul i64 %row, %pw64',
        '  %idx_struct = add i64 %rxw, %col',
        '  br label %use_idx',
        'use_idx:',
        '  %idx = phi i64 [ %row, %flat_idx ], [ %idx_struct, %compute ]',
        '  %n_p = getelementptr inbounds %cssc_bind_entry, ptr %ent, i64 0, i32 1',
        '  %n32 = load i32, ptr %n_p',
        '  %n64 = zext i32 %n32 to i64',
        '  %ok = icmp ult i64 %idx, %n64',
        '  br i1 %ok, label %load, label %ret_zero',
        'load:',
        '  %v_p = getelementptr inbounds %cssc_bind_entry, ptr %ent, i64 0, i32 2',
        '  %vals = load ptr, ptr %v_p',
        '  %slot = getelementptr inbounds i64, ptr %vals, i64 %idx',
        '  %v = load i64, ptr %slot',
        '  ret i64 %v',
        'ret_zero:',
        '  ret i64 0',
        '}',
        '',
        # `cssc_bind_entry_pair_cell_set(ent, row, col, val_i64)` — write
        # the raw 64-bit cell value at the (row, col) position. Caller is
        # responsible for bitcasting the source value to i64 first
        # (float → bitcast; bool → zext; ptr → ptrtoint). The cell's
        # tag is left UNCHANGED — homogeneous slots stay homogeneous.
        # NULL-safe + bounds-checked silent-ignore (parallels the read
        # path's `ret 0`).
        'define void @cssc_bind_entry_pair_cell_set(ptr %ent, i64 %row, i64 %col, i64 %val) {',
        'entry:',
        '  %is_null = icmp eq ptr %ent, null',
        '  br i1 %is_null, label %done, label %check',
        'check:',
        '  %pw_p = getelementptr inbounds %cssc_bind_entry, ptr %ent, i64 0, i32 4',
        '  %pw32 = load i32, ptr %pw_p',
        '  %pw64 = zext i32 %pw32 to i64',
        '  %is_flat = icmp eq i64 %pw64, 0',
        '  br i1 %is_flat, label %flat_idx, label %compute',
        'flat_idx:',
        '  br label %use_idx',
        'compute:',
        '  %rxw = mul i64 %row, %pw64',
        '  %idx_struct = add i64 %rxw, %col',
        '  br label %use_idx',
        'use_idx:',
        '  %idx = phi i64 [ %row, %flat_idx ], [ %idx_struct, %compute ]',
        '  %n_p = getelementptr inbounds %cssc_bind_entry, ptr %ent, i64 0, i32 1',
        '  %n32 = load i32, ptr %n_p',
        '  %n64 = zext i32 %n32 to i64',
        '  %ok = icmp ult i64 %idx, %n64',
        '  br i1 %ok, label %store, label %done',
        'store:',
        '  %v_p = getelementptr inbounds %cssc_bind_entry, ptr %ent, i64 0, i32 2',
        '  %vals = load ptr, ptr %v_p',
        '  %slot = getelementptr inbounds i64, ptr %vals, i64 %idx',
        '  store i64 %val, ptr %slot',
        '  br label %done',
        'done:',
        '  ret void',
        '}',
        '',
        # `cssc_bind_entry_cell_set(ent, idx, val_i64)` — flat-index
        # write sibling of `cssc_bind_entry_cell_int`. Same semantics:
        # raw 64-bit value, tag unchanged, null/bounds-safe silent-ignore.
        'define void @cssc_bind_entry_cell_set(ptr %ent, i64 %i, i64 %val) {',
        'entry:',
        '  %is_null = icmp eq ptr %ent, null',
        '  br i1 %is_null, label %done, label %check',
        'check:',
        '  %n_p = getelementptr inbounds %cssc_bind_entry, ptr %ent, i64 0, i32 1',
        '  %n32 = load i32, ptr %n_p',
        '  %n64 = zext i32 %n32 to i64',
        '  %ok = icmp ult i64 %i, %n64',
        '  br i1 %ok, label %store, label %done',
        'store:',
        '  %v_p = getelementptr inbounds %cssc_bind_entry, ptr %ent, i64 0, i32 2',
        '  %vals = load ptr, ptr %v_p',
        '  %slot = getelementptr inbounds i64, ptr %vals, i64 %i',
        '  store i64 %val, ptr %slot',
        '  br label %done',
        'done:',
        '  ret void',
        '}',
        '',
        # `cssc_array_bind_set_entry(a, i, val, tag)` — REPLACE cell 0 of
        # entry `i` with a new tagged value, releasing whatever the cell
        # owned before. This is the `array<auto>` element-reassign primitive
        # (`tok[0] = TEXT`): it writes BOTH the value AND the tag (unlike
        # cssc_bind_entry_cell_set, which never touches the tag). Assumes the
        # entry has ncells==1 (true for array<auto>/vector<auto> elements).
        # Old-cell teardown: tag 3 string→cssc_release, tag 6 array_bind→
        # cssc_array_bind_release, tag 7 map_si→cssc_map_si_free.
        'define void @cssc_array_bind_set_entry(ptr %a, i64 %i, i64 %val, i64 %tag) {',
        'entry:',
        '  %e = call ptr @cssc_array_bind_get_entry(ptr %a, i64 %i)',
        '  %enull = icmp eq ptr %e, null',
        '  br i1 %enull, label %done, label %go',
        'go:',
        '  %vp = getelementptr inbounds %cssc_bind_entry, ptr %e, i64 0, i32 2',
        '  %vals = load ptr, ptr %vp',
        '  %tp = getelementptr inbounds %cssc_bind_entry, ptr %e, i64 0, i32 3',
        '  %tags = load ptr, ptr %tp',
        '  %oldtag = load i8, ptr %tags',
        '  %oldval = load i64, ptr %vals',
        '  %oldptr = inttoptr i64 %oldval to ptr',
        '  %o3 = icmp eq i8 %oldtag, 3',
        '  br i1 %o3, label %rel_str, label %ochk6',
        'ochk6:',
        '  %o6 = icmp eq i8 %oldtag, 6',
        '  br i1 %o6, label %rel_arr, label %ochk7',
        'ochk7:',
        '  %o7 = icmp eq i8 %oldtag, 7',
        '  br i1 %o7, label %rel_map, label %write',
        'rel_str:',
        '  call void @cssc_release(ptr %oldptr)',
        '  br label %write',
        'rel_arr:',
        '  call void @cssc_array_bind_release(ptr %oldptr)',
        '  br label %write',
        'rel_map:',
        '  call void @cssc_map_si_free(ptr %oldptr)',
        '  br label %write',
        'write:',
        '  store i64 %val, ptr %vals',
        '  %tag8 = trunc i64 %tag to i8',
        '  store i8 %tag8, ptr %tags',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        # ---- retain / release / clear / free ----
        'define void @cssc_array_bind_retain(ptr %a) {',
        'entry:',
        '  %is_null = icmp eq ptr %a, null',
        '  br i1 %is_null, label %done, label %inc',
        'inc:',
        '  %rc_p = getelementptr inbounds %cssc_array_bind, ptr %a, i64 0, i32 0',
        '  %rc = load i32, ptr %rc_p',
        '  %rc_inc = add i32 %rc, 1',
        '  store i32 %rc_inc, ptr %rc_p',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        'define void @cssc_array_bind_release(ptr %a) {',
        'entry:',
        '  %is_null = icmp eq ptr %a, null',
        '  br i1 %is_null, label %done, label %dec',
        'dec:',
        '  %rc_p = getelementptr inbounds %cssc_array_bind, ptr %a, i64 0, i32 0',
        '  %rc = load i32, ptr %rc_p',
        '  %rc_dec = sub i32 %rc, 1',
        '  store i32 %rc_dec, ptr %rc_p',
        '  %zero = icmp sle i32 %rc_dec, 0',
        '  br i1 %zero, label %free_all, label %done',
        'free_all:',
        '  %sz_p = getelementptr inbounds %cssc_array_bind, ptr %a, i64 0, i32 1',
        '  %sz32 = load i32, ptr %sz_p',
        '  %ent_p = getelementptr inbounds %cssc_array_bind, ptr %a, i64 0, i32 3',
        '  %ent = load ptr, ptr %ent_p',
        '  br label %loop',
        'loop:',
        '  %i = phi i32 [ 0, %free_all ], [ %i.next, %step ]',
        '  %fin = icmp uge i32 %i, %sz32',
        '  br i1 %fin, label %tail, label %body',
        'body:',
        '  %i64 = zext i32 %i to i64',
        '  %eslot = getelementptr inbounds ptr, ptr %ent, i64 %i64',
        '  %ep = load ptr, ptr %eslot',
        '  call void @cssc_bind_entry_free(ptr %ep)',
        '  br label %step',
        'step:',
        '  %i.next = add i32 %i, 1',
        '  br label %loop',
        'tail:',
        '  call void @free(ptr %ent)',
        '  call void @free(ptr %a)',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        'define void @cssc_array_bind_clear(ptr %a) {',
        'entry:',
        '  %is_null = icmp eq ptr %a, null',
        '  br i1 %is_null, label %done, label %read',
        'read:',
        '  %sz_p = getelementptr inbounds %cssc_array_bind, ptr %a, i64 0, i32 1',
        '  %sz32 = load i32, ptr %sz_p',
        '  %ent_p = getelementptr inbounds %cssc_array_bind, ptr %a, i64 0, i32 3',
        '  %ent = load ptr, ptr %ent_p',
        '  br label %loop',
        'loop:',
        '  %i = phi i32 [ 0, %read ], [ %i.next, %step ]',
        '  %fin = icmp uge i32 %i, %sz32',
        '  br i1 %fin, label %tail, label %body',
        'body:',
        '  %i64 = zext i32 %i to i64',
        '  %eslot = getelementptr inbounds ptr, ptr %ent, i64 %i64',
        '  %ep = load ptr, ptr %eslot',
        '  call void @cssc_bind_entry_free(ptr %ep)',
        '  br label %step',
        'step:',
        '  %i.next = add i32 %i, 1',
        '  br label %loop',
        'tail:',
        '  store i32 0, ptr %sz_p',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        # pop_front for the heterogeneous vector<auto> backing: return
        # entries[0] (caller adopts + frees it), shift the rest left, size--.
        'define ptr @cssc_array_bind_pop_front(ptr %a) {',
        'entry:',
        '  %sz_p = getelementptr inbounds %cssc_array_bind, ptr %a, i64 0, i32 1',
        '  %sz32 = load i32, ptr %sz_p',
        '  %empty = icmp eq i32 %sz32, 0',
        '  br i1 %empty, label %nul, label %ok',
        'nul:',
        '  ret ptr null',
        'ok:',
        '  %ent_p = getelementptr inbounds %cssc_array_bind, ptr %a, i64 0, i32 3',
        '  %ent = load ptr, ptr %ent_p',
        '  %first = load ptr, ptr %ent',
        '  %newsz = sub i32 %sz32, 1',
        '  br label %loop',
        'loop:',
        '  %i = phi i32 [ 0, %ok ], [ %inext, %body ]',
        '  %cont = icmp ult i32 %i, %newsz',
        '  br i1 %cont, label %body, label %fin',
        'body:',
        '  %inext = add i32 %i, 1',
        '  %i64n = zext i32 %inext to i64',
        '  %i64c = zext i32 %i to i64',
        '  %src = getelementptr inbounds ptr, ptr %ent, i64 %i64n',
        '  %dst = getelementptr inbounds ptr, ptr %ent, i64 %i64c',
        '  %sv = load ptr, ptr %src',
        '  store ptr %sv, ptr %dst',
        '  br label %loop',
        'fin:',
        '  store i32 %newsz, ptr %sz_p',
        '  ret ptr %first',
        '}',
        '',
        # Consume a (1-cell) bind entry as a bare string — the scalar-value
        # primitive for vector<auto> elements. Tag-dispatch cell 0:
        # string→copy, float/int/bool→stringify. Result is a fresh heap
        # cssc_str the caller owns.
        '@.cssc_bind_ph_array = private unnamed_addr constant [8 x i8] c"[array]\\00"',
        '@.cssc_bind_ph_map   = private unnamed_addr constant [6 x i8] c"[map]\\00"',
        'define ptr @cssc_bind_entry_as_string(ptr %e) {',
        'entry:',
        '  %isnull = icmp eq ptr %e, null',
        '  br i1 %isnull, label %emp, label %go',
        'emp:',
        '  %z = call ptr @cssc_string_lit(ptr null, i64 0)',
        '  ret ptr %z',
        'go:',
        '  %tag = call i64 @cssc_bind_entry_cell_tag(ptr %e, i64 0)',
        '  %isstr = icmp eq i64 %tag, 3',
        '  br i1 %isstr, label %str, label %notstr',
        'str:',
        '  %sv = call ptr @cssc_bind_entry_cell_val(ptr %e, i64 0)',
        '  %sc = call ptr @cssc_string_copy(ptr %sv)',
        '  ret ptr %sc',
        'notstr:',
        '  %isflt = icmp eq i64 %tag, 2',
        '  br i1 %isflt, label %flt, label %notflt',
        'flt:',
        '  %fraw = call i64 @cssc_bind_entry_cell_int(ptr %e, i64 0)',
        '  %fv = call double @__cssc_bitcast_i64_f64(i64 %fraw)',
        '  %fs = call ptr @cssc_float_to_str(double %fv)',
        '  ret ptr %fs',
        'notflt:',
        '  %isbool = icmp eq i64 %tag, 4',
        '  br i1 %isbool, label %bl, label %notbool',
        'notbool:',
        # Nested-container cells (tag 6 = array_bind, tag 7 = map_si) hold a
        # raw ptr — never stringify it as an integer. Emit a typed placeholder
        # so `print("%", tok_elem)` stays safe. (Faithful recursive container
        # stringify is a separate enhancement.)
        '  %is6 = icmp eq i64 %tag, 6',
        '  br i1 %is6, label %arr, label %chk7',
        'chk7:',
        '  %is7 = icmp eq i64 %tag, 7',
        '  br i1 %is7, label %mp, label %it',
        'arr:',
        '  %acv = call ptr @cssc_bind_entry_cell_val(ptr %e, i64 0)',
        '  %as = call ptr @cssc_array_bind_repr(ptr %acv)',
        '  ret ptr %as',
        'mp:',
        '  %mcv = call ptr @cssc_bind_entry_cell_val(ptr %e, i64 0)',
        '  %ms = call ptr @cssc_map_si_repr(ptr %mcv)',
        '  ret ptr %ms',
        'bl:',
        '  %braw = call i64 @cssc_bind_entry_cell_int(ptr %e, i64 0)',
        '  %blv = icmp ne i64 %braw, 0',
        '  %bs = call ptr @cssc_bool_to_str(i1 %blv)',
        '  ret ptr %bs',
        'it:',
        '  %iraw = call i64 @cssc_bind_entry_cell_int(ptr %e, i64 0)',
        '  %is = call ptr @cssc_int_to_str(i64 %iraw)',
        '  ret ptr %is',
        '}',
        '',
        # ---- Helper bit-cast / zext stubs used by bind cells. ----
        'define i64 @__cssc_bitcast_ptr_i64(ptr %p) {',
        'entry:',
        '  %r = ptrtoint ptr %p to i64',
        '  ret i64 %r',
        '}',
        '',
        'define i64 @__cssc_bitcast_f64_i64(double %d) {',
        'entry:',
        '  %r = bitcast double %d to i64',
        '  ret i64 %r',
        '}',
        '',
        'define double @__cssc_bitcast_i64_f64(i64 %v) {',
        'entry:',
        '  %r = bitcast i64 %v to double',
        '  ret double %r',
        '}',
        '',
        'define i64 @__cssc_zext_i32_i64(i64 %v) {',
        'entry:',
        # In practice the caller passes an already-i64 value; this is a no-op
        # the optimiser folds away. Kept to match the CIR helper's signature.
        '  ret i64 %v',
        '}',
        '',
        'define i64 @__cssc_zext_i1_i64(i1 %v) {',
        'entry:',
        '  %r = zext i1 %v to i64',
        '  ret i64 %r',
        '}',
        '',
        'define ptr @__cssc_int_to_ptr(i64 %v) {',
        'entry:',
        '  %r = inttoptr i64 %v to ptr',
        '  ret ptr %r',
        '}',
        '',
        # ---- #delmember runtime: indexed + container-wide null wipes ----
        # Per the spec: size/cap stay; only the heap content of the
        # targeted entry/entries gets released and the slot reset to
        # the empty/null value. Re-use of the container is safe.
        'define void @cssc_array_bind_null_at(ptr %a, i64 %i) {',
        'entry:',
        '  %is_null = icmp eq ptr %a, null',
        '  br i1 %is_null, label %done, label %check',
        'check:',
        '  %sz_p = getelementptr inbounds %cssc_array_bind, ptr %a, i64 0, i32 1',
        '  %sz32 = load i32, ptr %sz_p',
        '  %sz64 = zext i32 %sz32 to i64',
        '  %inrange = icmp ult i64 %i, %sz64',
        '  br i1 %inrange, label %do_null, label %done',
        'do_null:',
        '  %ent_p = getelementptr inbounds %cssc_array_bind, ptr %a, i64 0, i32 3',
        '  %ent = load ptr, ptr %ent_p',
        '  %eslot = getelementptr inbounds ptr, ptr %ent, i64 %i',
        '  %old = load ptr, ptr %eslot',
        '  call void @cssc_bind_entry_free(ptr %old)',
        '  store ptr null, ptr %eslot',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        'define void @cssc_array_bind_null_all(ptr %a) {',
        'entry:',
        '  %is_null = icmp eq ptr %a, null',
        '  br i1 %is_null, label %done, label %read',
        'read:',
        '  %sz_p = getelementptr inbounds %cssc_array_bind, ptr %a, i64 0, i32 1',
        '  %sz32 = load i32, ptr %sz_p',
        '  %ent_p = getelementptr inbounds %cssc_array_bind, ptr %a, i64 0, i32 3',
        '  %ent = load ptr, ptr %ent_p',
        '  br label %loop',
        'loop:',
        '  %i = phi i32 [ 0, %read ], [ %i.next, %step ]',
        '  %fin = icmp uge i32 %i, %sz32',
        '  br i1 %fin, label %done, label %body',
        'body:',
        '  %i64 = zext i32 %i to i64',
        '  %eslot = getelementptr inbounds ptr, ptr %ent, i64 %i64',
        '  %old = load ptr, ptr %eslot',
        '  call void @cssc_bind_entry_free(ptr %old)',
        '  store ptr null, ptr %eslot',
        '  br label %step',
        'step:',
        '  %i.next = add i32 %i, 1',
        '  br label %loop',
        'done:',
        '  ret void',
        '}',
        '',
        # Vector POD — `null_at` zeros one slot, `null_all` memsets the
        # whole storage. Size/cap stay so existing iterators keep their
        # bounds.
        'define void @cssc_vector_int_null_at(ptr %v, i64 %i) {',
        'entry:',
        '  %is_null = icmp eq ptr %v, null',
        '  br i1 %is_null, label %done, label %do',
        'do:',
        '  %sz_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %sz = load i64, ptr %sz_p',
        '  %ok = icmp ult i64 %i, %sz',
        '  br i1 %ok, label %store, label %done',
        'store:',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p',
        '  %slot = getelementptr inbounds i64, ptr %data, i64 %i',
        '  store i64 0, ptr %slot',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        'define void @cssc_vector_int_null_all(ptr %v) {',
        'entry:',
        '  %is_null = icmp eq ptr %v, null',
        '  br i1 %is_null, label %done, label %do',
        'do:',
        '  %sz_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %sz = load i64, ptr %sz_p',
        '  %bytes = mul i64 %sz, 8',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p',
        '  call ptr @memset(ptr %data, i32 0, i64 %bytes)',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        'define void @cssc_vector_float_null_at(ptr %v, i64 %i) {',
        'entry:',
        '  %is_null = icmp eq ptr %v, null',
        '  br i1 %is_null, label %done, label %do',
        'do:',
        '  %sz_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %sz = load i64, ptr %sz_p',
        '  %ok = icmp ult i64 %i, %sz',
        '  br i1 %ok, label %store, label %done',
        'store:',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p',
        '  %slot = getelementptr inbounds double, ptr %data, i64 %i',
        '  store double 0.0, ptr %slot',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        'define void @cssc_vector_float_null_all(ptr %v) {',
        'entry:',
        '  %is_null = icmp eq ptr %v, null',
        '  br i1 %is_null, label %done, label %do',
        'do:',
        '  %sz_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 0',
        '  %sz = load i64, ptr %sz_p',
        '  %bytes = mul i64 %sz, 8',
        '  %data_p = getelementptr inbounds %cssc_vec_int, ptr %v, i64 0, i32 2',
        '  %data = load ptr, ptr %data_p',
        '  call ptr @memset(ptr %data, i32 0, i64 %bytes)',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        # Map<string,int> — `null_at(idx)` releases the key at idx and
        # zeros the value; `null_all` does the same for every entry.
        # Entry count stays so the map's iteration order is preserved
        # — wiped entries appear with key=NULL/val=0.
        # Map layout (Phase 3): same shell as %cssc_vec_int — { i64 size,
        # i64 cap, ptr entries }. Each entry is { ptr key, i64 val }
        # i.e. 16 bytes; we treat that as a pair-stride 16.
        'define void @cssc_map_si_null_at(ptr %m, i64 %i) {',
        'entry:',
        '  %is_null = icmp eq ptr %m, null',
        '  br i1 %is_null, label %done, label %do',
        'do:',
        '  %sz_p = getelementptr inbounds %cssc_vec_int, ptr %m, i64 0, i32 0',
        '  %sz = load i64, ptr %sz_p',
        '  %ok = icmp ult i64 %i, %sz',
        '  br i1 %ok, label %wipe, label %done',
        'wipe:',
        '  %ent_p = getelementptr inbounds %cssc_vec_int, ptr %m, i64 0, i32 2',
        '  %ent = load ptr, ptr %ent_p',
        '  %off = mul i64 %i, 16',
        '  %slot = getelementptr inbounds i8, ptr %ent, i64 %off',
        '  %k = load ptr, ptr %slot',
        '  call void @cssc_release(ptr %k)',
        '  store ptr null, ptr %slot',
        '  %vslot = getelementptr inbounds i8, ptr %slot, i64 8',
        '  store i64 0, ptr %vslot',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        'define void @cssc_map_si_null_all(ptr %m) {',
        'entry:',
        '  %is_null = icmp eq ptr %m, null',
        '  br i1 %is_null, label %done, label %read',
        'read:',
        '  %sz_p = getelementptr inbounds %cssc_vec_int, ptr %m, i64 0, i32 0',
        '  %sz = load i64, ptr %sz_p',
        '  %ent_p = getelementptr inbounds %cssc_vec_int, ptr %m, i64 0, i32 2',
        '  %ent = load ptr, ptr %ent_p',
        '  br label %loop',
        'loop:',
        '  %i = phi i64 [ 0, %read ], [ %i.next, %step ]',
        '  %fin = icmp uge i64 %i, %sz',
        '  br i1 %fin, label %done, label %body',
        'body:',
        '  %off = mul i64 %i, 16',
        '  %slot = getelementptr inbounds i8, ptr %ent, i64 %off',
        '  %k = load ptr, ptr %slot',
        '  call void @cssc_release(ptr %k)',
        '  store ptr null, ptr %slot',
        '  %vslot = getelementptr inbounds i8, ptr %slot, i64 8',
        '  store i64 0, ptr %vslot',
        '  br label %step',
        'step:',
        '  %i.next = add i64 %i, 1',
        '  br label %loop',
        'done:',
        '  ret void',
        '}',
        '',
        # bind<string,string> — `null_at(idx)` releases both strings of
        # the pair at idx; `null_all` does the same for every pair.
        'define void @cssc_bind_ss_null_at(ptr %b, i64 %i) {',
        'entry:',
        '  %is_null = icmp eq ptr %b, null',
        '  br i1 %is_null, label %done, label %do',
        'do:',
        '  %sz_p = getelementptr inbounds %cssc_vec_int, ptr %b, i64 0, i32 0',
        '  %sz = load i64, ptr %sz_p',
        '  %ok = icmp ult i64 %i, %sz',
        '  br i1 %ok, label %wipe, label %done',
        'wipe:',
        '  %ent_p = getelementptr inbounds %cssc_vec_int, ptr %b, i64 0, i32 2',
        '  %ent = load ptr, ptr %ent_p',
        '  %slot = getelementptr inbounds %cssc_bind_ss_entry, ptr %ent, i64 %i',
        '  %k_p = getelementptr inbounds %cssc_bind_ss_entry, ptr %slot, i64 0, i32 0',
        '  %k = load ptr, ptr %k_p',
        '  call void @cssc_release(ptr %k)',
        '  store ptr null, ptr %k_p',
        '  %v_p = getelementptr inbounds %cssc_bind_ss_entry, ptr %slot, i64 0, i32 1',
        '  %v = load ptr, ptr %v_p',
        '  call void @cssc_release(ptr %v)',
        '  store ptr null, ptr %v_p',
        '  ret void',
        'done:',
        '  ret void',
        '}',
        '',
        'define void @cssc_bind_ss_null_all(ptr %b) {',
        'entry:',
        '  %is_null = icmp eq ptr %b, null',
        '  br i1 %is_null, label %done, label %read',
        'read:',
        '  %sz_p = getelementptr inbounds %cssc_vec_int, ptr %b, i64 0, i32 0',
        '  %sz = load i64, ptr %sz_p',
        '  %ent_p = getelementptr inbounds %cssc_vec_int, ptr %b, i64 0, i32 2',
        '  %ent = load ptr, ptr %ent_p',
        '  br label %loop',
        'loop:',
        '  %i = phi i64 [ 0, %read ], [ %i.next, %step ]',
        '  %fin = icmp uge i64 %i, %sz',
        '  br i1 %fin, label %done, label %body',
        'body:',
        '  %slot = getelementptr inbounds %cssc_bind_ss_entry, ptr %ent, i64 %i',
        '  %k_p = getelementptr inbounds %cssc_bind_ss_entry, ptr %slot, i64 0, i32 0',
        '  %k = load ptr, ptr %k_p',
        '  call void @cssc_release(ptr %k)',
        '  store ptr null, ptr %k_p',
        '  %v_p = getelementptr inbounds %cssc_bind_ss_entry, ptr %slot, i64 0, i32 1',
        '  %v = load ptr, ptr %v_p',
        '  call void @cssc_release(ptr %v)',
        '  store ptr null, ptr %v_p',
        '  br label %step',
        'step:',
        '  %i.next = add i64 %i, 1',
        '  br label %loop',
        'done:',
        '  ret void',
        '}',
    ]


_ARRAY_BIND_SYMBOLS = frozenset({
    'cssc_array_bind_new',
    'cssc_array_bind_size',
    'cssc_array_bind_pop_front',
    'cssc_bind_entry_as_string',
    'cssc_array_bind_push_back',
    'cssc_array_bind_retain',
    'cssc_array_bind_release',
    'cssc_array_bind_clear',
    'cssc_array_bind_cells_new',
    'cssc_array_bind_cells_set_val',
    'cssc_array_bind_cells_set_tag',
    'cssc_array_bind_cells_set_pair_width',
    'cssc_bind_entry_free',
    'cssc_bind_entry_from_buf',
    'cssc_array_bind_push_entry',
    'cssc_array_bind_get_entry',
    'cssc_array_bind_get_str',
    'cssc_bind_entry_cell_val',
    'cssc_bind_entry_cell_int',
    'cssc_bind_entry_pair_cell_val',
    'cssc_bind_entry_pair_cell_int',
    'cssc_bind_entry_pair_cell_set',
    'cssc_bind_entry_cell_set',
    'cssc_array_bind_set_entry',
    'cssc_bind_entry_pair_width',
    'cssc_bind_entry_ncells',
    'cssc_bind_entry_cell_tag',
    '__cssc_int_to_ptr',
    '__cssc_bitcast_ptr_i64',
    '__cssc_bitcast_f64_i64',
    '__cssc_bitcast_i64_f64',
    '__cssc_zext_i32_i64',
    '__cssc_zext_i1_i64',
    # #delmember runtime helpers — the array_bind group hosts the
    # whole `null_*` family because every container kind reuses the
    # %cssc_vec_int / %cssc_bind_ss_entry shells declared inside this
    # block. Pulling any one of these symbols triggers the whole
    # group emit so the helpers, types, and `cssc_release` declare
    # all land together.
    'cssc_array_bind_null_at',
    'cssc_array_bind_null_all',
    'cssc_vector_int_null_at',
    'cssc_vector_int_null_all',
    'cssc_vector_float_null_at',
    'cssc_vector_float_null_all',
    'cssc_map_si_null_at',
    'cssc_map_si_null_all',
    'cssc_bind_ss_null_at',
    'cssc_bind_ss_null_all',
})


def _emit_cssc_obj_alloc() -> List[str]:
    """Phase 4d — per-instance object alloc/free.

    `cssc_obj_alloc(size) -> ptr` mallocs `size` bytes and zero-initialises
    them so unset POD members start as int 0 / bool false / float 0.0.
    `cssc_obj_free(ptr)` is just libc `free`.
    """
    return [
        '',
        '; --- per-instance object alloc / free (Phase 4d) ---',
        'declare ptr @malloc(i64)',
        'declare void @free(ptr)',
        'declare ptr @memset(ptr, i32, i64)',
        '',
        'define ptr @cssc_obj_alloc(i64 %size) {',
        'entry:',
        '  %buf = call ptr @malloc(i64 %size)',
        '  call ptr @memset(ptr %buf, i32 0, i64 %size)',
        '  ret ptr %buf',
        '}',
        '',
        'define void @cssc_obj_free(ptr %p) {',
        'entry:',
        '  call void @free(ptr %p)',
        '  ret void',
        '}',
    ]


_OBJ_ALLOC_SYMBOLS = frozenset({
    'cssc_obj_alloc',
    'cssc_obj_free',
})


# ---------------------------------------------------------------------------
# Process-startup state — `cssc_argc`/`cssc_argv` saved by the main shim
# (see [cir_to_llvm._emit_main_shim]), `cssc_sysout_value` driving the
# program exit code.
#
# We emit the globals + helpers as ONE group so the user module's
# `@cssc_argc` / `@cssc_argv` / `@cssc_sysout_value` `external` decls
# always resolve, even when the user code never calls `cssc_sysarg_int`
# or `cssc_sysout` directly — the main shim still loads `cssc_sysout_value`
# on every program exit and stores `argc`/`argv` on every program entry.
# ---------------------------------------------------------------------------
def _emit_startup_state() -> List[str]:
    return _emit_startup_globals_and_sysout() + _emit_startup_sysarg()


def _emit_startup_globals_and_sysout() -> List[str]:
    return [
        '; --- process startup state (always linked) ---',
        '@cssc_argc = global i32 0',
        '@cssc_argv = global ptr null',
        '@cssc_sysout_value = global i32 0',
        '',
        'define void @cssc_sysout(i64 %v) {',
        'entry:',
        '  %v32 = trunc i64 %v to i32',
        '  store i32 %v32, ptr @cssc_sysout_value, align 4',
        '  ret void',
        '}',
    ]


def _emit_startup_sysarg() -> List[str]:
    return [
        '',
        'declare i64 @strtoll(ptr, ptr, i32)',
        '',
        'define i64 @cssc_sysarg_int(i64 %idx) {',
        'entry:',
        '  %ac = load i32, ptr @cssc_argc, align 4',
        '  %ac64 = sext i32 %ac to i64',
        '  %ok = icmp slt i64 %idx, %ac64',
        '  br i1 %ok, label %have, label %miss',
        'have:',
        '  %av = load ptr, ptr @cssc_argv, align 8',
        '  %ip = getelementptr inbounds ptr, ptr %av, i64 %idx',
        '  %s = load ptr, ptr %ip, align 8',
        '  %n = call i64 @strtoll(ptr %s, ptr null, i32 10)',
        '  ret i64 %n',
        'miss:',
        '  ret i64 0',
        '}',
    ]


_STARTUP_SYMBOLS = frozenset({
    'cssc_sysout',
})


def _emit_cssc_sys_argv() -> List[str]:
    # `sys::argv()` — the user command-line args as an `array<auto>`
    # (array_bind of 1-cell string entries). Skips argv[0] (the program
    # name) so it matches the interpreter, which returns only the args that
    # follow the script. Each arg becomes a heap cssc_str (tag 3) cell.
    return [
        'declare i64 @strlen(ptr)',
        'define ptr @cssc_sys_argv() {',
        'entry:',
        '  %ac = load i32, ptr @cssc_argc, align 4',
        '  %ac64 = sext i32 %ac to i64',
        '  %av = load ptr, ptr @cssc_argv, align 8',
        '  %arr = call ptr @cssc_array_bind_new(i64 8)',
        '  br label %head',
        'head:',
        '  %i = phi i64 [ 1, %entry ], [ %inext, %step ]',
        '  %done = icmp sge i64 %i, %ac64',
        '  br i1 %done, label %end, label %body',
        'body:',
        '  %ip = getelementptr inbounds ptr, ptr %av, i64 %i',
        '  %cstr = load ptr, ptr %ip, align 8',
        '  %len = call i64 @strlen(ptr %cstr)',
        '  %s = call ptr @cssc_string_lit(ptr %cstr, i64 %len)',
        '  %sbits = call i64 @__cssc_bitcast_ptr_i64(ptr %s)',
        '  %buf = call ptr @cssc_array_bind_cells_new(i64 1)',
        '  call void @cssc_array_bind_cells_set_val(ptr %buf, i64 0, i64 %sbits)',
        '  call void @cssc_array_bind_cells_set_tag(ptr %buf, i64 0, i64 3)',
        '  call void @cssc_array_bind_push_back(ptr %arr, i64 1, ptr %buf)',
        '  br label %step',
        'step:',
        '  %inext = add i64 %i, 1',
        '  br label %head',
        'end:',
        '  ret ptr %arr',
        '}',
    ]


_STARTUP_SYSARG_SYMBOLS = frozenset({
    'cssc_sysarg_int',
})

_SYS_ARGV_SYMBOLS = frozenset({
    'cssc_sys_argv',
})


# ---------------------------------------------------------------------------
# Time / sleep — `cssc::sleep` blocks the calling thread, `cssc::uptime`
# returns monotonic seconds-since-start as f64, `cssc::tick` returns ms.
# On Windows we wire through `Sleep(DWORD)` and `QueryPerformanceCounter`;
# the runtime initialiser records the start counter so uptime is relative.
# Embedded targets replace the group with their own MMIO-backed clock.
# ---------------------------------------------------------------------------
def _emit_cssc_time() -> List[str]:
    return [
        '; --- time: cssc::sleep / cssc::uptime / cssc::tick ---',
        '@.cssc_qpc_freq  = global i64 0',
        '@.cssc_qpc_start = global i64 0',
        'declare void @Sleep(i32)',
        'declare i32  @QueryPerformanceCounter(ptr)',
        'declare i32  @QueryPerformanceFrequency(ptr)',
        '',
        '; Lazy-init the QPC anchor on first call so the order of static',
        '; initialisers across translation units does not matter.',
        'define void @cssc_time_init() {',
        'entry:',
        '  %fp = load i64, ptr @.cssc_qpc_freq, align 8',
        '  %z  = icmp eq i64 %fp, 0',
        '  br i1 %z, label %init, label %done',
        'init:',
        '  %fr = call i32 @QueryPerformanceFrequency(ptr @.cssc_qpc_freq)',
        '  %sr = call i32 @QueryPerformanceCounter(ptr @.cssc_qpc_start)',
        '  br label %done',
        'done:',
        '  ret void',
        '}',
        '',
        'define void @cssc_sleep_ms(i64 %ms) {',
        'entry:',
        '  %m32 = trunc i64 %ms to i32',
        '  call void @Sleep(i32 %m32)',
        '  ret void',
        '}',
        '',
        'define double @cssc_uptime() {',
        'entry:',
        '  call void @cssc_time_init()',
        '  %nowp = alloca i64, align 8',
        '  %r = call i32 @QueryPerformanceCounter(ptr %nowp)',
        '  %now = load i64, ptr %nowp, align 8',
        '  %st = load i64, ptr @.cssc_qpc_start, align 8',
        '  %fr = load i64, ptr @.cssc_qpc_freq, align 8',
        '  %d  = sub i64 %now, %st',
        '  %df = sitofp i64 %d to double',
        '  %ff = sitofp i64 %fr to double',
        '  %s  = fdiv double %df, %ff',
        '  ret double %s',
        '}',
        '',
        'define i64 @cssc_tick() {',
        'entry:',
        '  call void @cssc_time_init()',
        '  %nowp = alloca i64, align 8',
        '  %r = call i32 @QueryPerformanceCounter(ptr %nowp)',
        '  %now = load i64, ptr %nowp, align 8',
        '  %st = load i64, ptr @.cssc_qpc_start, align 8',
        '  %fr = load i64, ptr @.cssc_qpc_freq, align 8',
        '  %d  = sub i64 %now, %st',
        '  ; ms = d * 1000 / freq   (signed math, fits comfortably in i64)',
        '  %dm = mul i64 %d, 1000',
        '  %ms = sdiv i64 %dm, %fr',
        '  ret i64 %ms',
        '}',
    ]


_TIME_SYMBOLS = frozenset({
    'cssc_sleep_ms', 'cssc_uptime', 'cssc_tick', 'cssc_time_init',
})


def _emit_cssc_math() -> List[str]:
    """Math + RNG builtins: cssc::sqrt, cssc::random, cssc::random_int.

    `cssc_sqrt` forwards to libm's `sqrt` directly so the host build
    picks up SSE2's `sqrtsd` via clang's lowering — no software loop
    needed. The RNG is a small xorshift64* — fast, well-distributed,
    deterministic seed across runs (matches the embedded softfloat
    impl byte-for-byte so program output is comparable host vs chip).
    """
    return [
        '; --- math + RNG: cssc::sqrt / cssc::random / cssc::random_int ---',
        '@cssc_rng_state = global i64 -7046029254386353131  ; 0x9E3779B97F4A7C15',
        'declare double @sqrt(double)',
        '',
        'define double @cssc_sqrt(double %x) {',
        'entry:',
        '  %r = call double @sqrt(double %x)',
        '  ret double %r',
        '}',
        '',
        '; xorshift64* core. Returns a uniform i64; callers slice it.',
        'define i64 @cssc_rng_next() {',
        'entry:',
        '  %s0 = load i64, ptr @cssc_rng_state, align 8',
        '  %z  = icmp eq i64 %s0, 0',
        '  %s1 = select i1 %z, i64 -7046029254386353131, i64 %s0',
        '  %a  = lshr i64 %s1, 12',
        '  %s2 = xor  i64 %s1, %a',
        '  %b  = shl  i64 %s2, 25',
        '  %s3 = xor  i64 %s2, %b',
        '  %c  = lshr i64 %s3, 27',
        '  %s4 = xor  i64 %s3, %c',
        '  store i64 %s4, ptr @cssc_rng_state, align 8',
        '  %r  = mul i64 %s4, 2685821657736338717  ; 0x2545F4914F6CDD1D',
        '  ret i64 %r',
        '}',
        '',
        'define double @cssc_random() {',
        'entry:',
        '  %r  = call i64 @cssc_rng_next()',
        '  %u  = lshr i64 %r, 11                ; 53 random bits',
        '  %d  = uitofp i64 %u to double',
        '  %s  = fdiv double %d, 0x4340000000000000  ; 2^53',
        '  ret double %s',
        '}',
        '',
        'define i64 @cssc_random_int(i64 %a, i64 %b) {',
        'entry:',
        '  %swap = icmp slt i64 %b, %a',
        '  br i1 %swap, label %fallback, label %ok',
        'fallback:',
        '  ret i64 %a',
        'ok:',
        '  %diff = sub i64 %b, %a',
        '  %range = add i64 %diff, 1',
        '  %r = call i64 @cssc_rng_next()',
        '  %m = urem i64 %r, %range',
        '  %out = add i64 %a, %m',
        '  ret i64 %out',
        '}',
        '',
        '; --- extended math (external runtime — cssc_host_game.c) ---',
        '; libm-backed wrappers plus a seed hook that writes the same',
        '; @cssc_rng_state global we defined above. Emitting these as',
        '; `declare` keeps them out of user.ll bodies; the definitions',
        '; ship in cssc_host_game.o linked in by v6_driver.',
        'declare double @cssc_sin  (double)',
        'declare double @cssc_cos  (double)',
        'declare double @cssc_tan  (double)',
        'declare double @cssc_atan2(double, double)',
        'declare double @cssc_floor(double)',
        'declare double @cssc_ceil (double)',
        'declare double @cssc_round(double)',
        'declare double @cssc_pow  (double, double)',
        'declare double @cssc_exp  (double)',
        'declare double @cssc_log  (double)',
        'declare double @cssc_fabs (double)',
        'declare double @cssc_fmin (double, double)',
        'declare double @cssc_fmax (double, double)',
        'declare void   @cssc_seed (i64)',
    ]


_MATH_SYMBOLS = frozenset({
    'cssc_sqrt', 'cssc_random', 'cssc_random_int', 'cssc_rng_next',
    # Extended math surface backed by cssc_host_game.c (host build).
    # These are declared here so the CIR-emitted user.ll and the linked
    # cssc_host_game.o share a single ABI. Attribute-tagging (readnone
    # nounwind willreturn) is applied by `_apply_runtime_define_attrs`
    # for the declare lines that model pure libm wrappers.
    'cssc_sin', 'cssc_cos', 'cssc_tan', 'cssc_atan2',
    'cssc_floor', 'cssc_ceil', 'cssc_round',
    'cssc_pow', 'cssc_exp', 'cssc_log',
    'cssc_fabs', 'cssc_fmin', 'cssc_fmax',
    'cssc_seed',
})


# ---------------------------------------------------------------------------
# Stringify helpers — turn an int / float / bool into a fresh heap
# cssc_str. Used by string-concat lowering when one operand is a
# non-string primitive (e.g. `"frame=" + count`).
#
# All three rely on snprintf into a 64-byte stack buffer, then
# materialise the result via `cssc_string_lit` so the caller owns a
# real heap cssc_str (refcountable + `cssc_string_free`-able).
# ---------------------------------------------------------------------------
def _emit_stringify_helpers() -> List[str]:
    return [
        '; --- stringify: cssc_int_to_str / cssc_float_to_str / cssc_bool_to_str ---',
        '@.fmt_lld   = private unnamed_addr constant [5 x i8] c"%lld\\00"',
        '@.fmt_dbl   = private unnamed_addr constant [3 x i8] c"%g\\00"',
        '@.fmt_starg = private unnamed_addr constant [5 x i8] c"%.*g\\00"',
        '@.fmt_0f    = private unnamed_addr constant [5 x i8] c"%.0f\\00"',
        '@.str_true  = private unnamed_addr constant [5 x i8] c"true\\00"',
        '@.str_false = private unnamed_addr constant [6 x i8] c"false\\00"',
        'declare i32 @snprintf(ptr, i64, ptr, ...)',
        'declare double @trunc(double)',
        'declare double @fabs(double)',
        '',
        '; cssc_string_lit on the host takes (ptr src, i64 len). The helpers',
        '; below get the length from snprintf\'s return value (which is the',
        '; number of bytes that WOULD have been written excluding NUL — for',
        '; our fixed 64-byte buffer that is always the actual length).',
        'define ptr @cssc_int_to_str(i64 %n) {',
        'entry:',
        '  %buf = alloca [64 x i8], align 1',
        '  %bp = getelementptr inbounds [64 x i8], ptr %buf, i64 0, i64 0',
        '  %r = call i32 (ptr, i64, ptr, ...) @snprintf(ptr %bp, i64 64, ptr @.fmt_lld, i64 %n)',
        '  %len = sext i32 %r to i64',
        '  %s = call ptr @cssc_string_lit(ptr %bp, i64 %len)',
        '  ret ptr %s',
        '}',
        '',
        # Python-`repr(float)`-compatible: integer-valued floats (|x| < 1e16)
        # print in fixed notation with a trailing ".0" (4.0 -> "4.0",
        # 100.0 -> "100.0"); everything else uses the SHORTEST `%.*g` that
        # round-trips (0.1 -> "0.1", 4.5 -> "4.5", 1e16 -> "1e+16"). Matches
        # `cssc run` (Python str/repr of the float) byte-for-byte.
        'define ptr @cssc_float_to_str(double %x) {',
        'entry:',
        '  %buf = alloca [64 x i8], align 1',
        '  %bp = getelementptr inbounds [64 x i8], ptr %buf, i64 0, i64 0',
        '  %tr = call double @trunc(double %x)',
        '  %isint = fcmp oeq double %x, %tr',
        '  %absx = call double @fabs(double %x)',
        '  %inrange = fcmp olt double %absx, 1.000000e16',
        '  %usefixed = and i1 %isint, %inrange',
        '  br i1 %usefixed, label %fixed, label %shortest',
        'fixed:',
        '  %rf = call i32 (ptr, i64, ptr, ...) @snprintf(ptr %bp, i64 64, ptr @.fmt_0f, double %x)',
        '  %lenf = sext i32 %rf to i64',
        '  %dotp = getelementptr inbounds i8, ptr %bp, i64 %lenf',
        '  store i8 46, ptr %dotp',
        '  %lenf1 = add i64 %lenf, 1',
        '  %zerop = getelementptr inbounds i8, ptr %bp, i64 %lenf1',
        '  store i8 48, ptr %zerop',
        '  %lenf2 = add i64 %lenf, 2',
        '  %sf = call ptr @cssc_string_lit(ptr %bp, i64 %lenf2)',
        '  ret ptr %sf',
        'shortest:',
        '  br label %sloop',
        'sloop:',
        '  %p = phi i32 [ 1, %shortest ], [ %pnext, %scont ]',
        '  %rg = call i32 (ptr, i64, ptr, ...) @snprintf(ptr %bp, i64 64, ptr @.fmt_starg, i32 %p, double %x)',
        '  %v = call double @strtod(ptr %bp, ptr null)',
        '  %ok = fcmp oeq double %v, %x',
        '  %atmax = icmp uge i32 %p, 17',
        '  %stop = or i1 %ok, %atmax',
        '  br i1 %stop, label %sdone, label %scont',
        'scont:',
        '  %pnext = add i32 %p, 1',
        '  br label %sloop',
        'sdone:',
        '  %leng = sext i32 %rg to i64',
        '  %sg = call ptr @cssc_string_lit(ptr %bp, i64 %leng)',
        '  ret ptr %sg',
        '}',
        '',
        'define ptr @cssc_bool_to_str(i1 %b) {',
        'entry:',
        '  br i1 %b, label %tt, label %ff',
        'tt:',
        '  %tp = getelementptr inbounds [5 x i8], ptr @.str_true, i64 0, i64 0',
        '  %s1 = call ptr @cssc_string_lit(ptr %tp, i64 4)',
        '  ret ptr %s1',
        'ff:',
        '  %fp = getelementptr inbounds [6 x i8], ptr @.str_false, i64 0, i64 0',
        '  %s2 = call ptr @cssc_string_lit(ptr %fp, i64 5)',
        '  ret ptr %s2',
        '}',
        '',
        '; A.3.16: parse-back helpers for cssc::int(s) / cssc::float(s).',
        'declare i64 @strtoll(ptr, ptr, i32)',
        'declare double @strtod(ptr, ptr)',
        '',
        'define i64 @cssc_string_to_int(ptr %s) {',
        'entry:',
        '  %is_null = icmp eq ptr %s, null',
        '  br i1 %is_null, label %ret0, label %parse',
        'parse:',
        '  ; B2: inline data at field 2 (no ptr load).',
        '  %data = getelementptr inbounds %cssc_str, ptr %s, i64 0, i32 2',
        '  %end_ptr = alloca ptr, align 8',
        '  %v = call i64 @strtoll(ptr %data, ptr %end_ptr, i32 10)',
        '  ret i64 %v',
        'ret0:',
        '  ret i64 0',
        '}',
        '',
        'define double @cssc_string_to_float(ptr %s) {',
        'entry:',
        '  %is_null = icmp eq ptr %s, null',
        '  br i1 %is_null, label %ret0, label %parse',
        'parse:',
        '  ; B2: inline data at field 2 (no ptr load).',
        '  %data = getelementptr inbounds %cssc_str, ptr %s, i64 0, i32 2',
        '  %end_ptr = alloca ptr, align 8',
        '  %v = call double @strtod(ptr %data, ptr %end_ptr)',
        '  ret double %v',
        'ret0:',
        '  ret double 0.0',
        '}',
    ]


_STRINGIFY_SYMBOLS = frozenset({
    'cssc_int_to_str', 'cssc_float_to_str', 'cssc_bool_to_str',
    # A.3.16: round-trip helpers for cssc::int(s) and cssc::float(s) live
    # in the same emit group so the %cssc_str struct type isn't redeclared.
    'cssc_string_to_int', 'cssc_string_to_float',
})


# ---------------------------------------------------------------------------
# `#pin` peripheral — host stub. Stores last-written value in a
# malloc'd 16-byte struct so `read()` can observe what `write()` set.
# Embedded targets replace this group with chip-specific MMIO writes
# (ESP8266: GPIO_OUT_REG @ 0x60000300, etc.) — host stays pure libc.
# ---------------------------------------------------------------------------
def _emit_cssc_pin() -> List[str]:
    return [
        '; --- gipeo: #pin (host stub) ---',
        '%cssc_pin = type { i64, i64 }   ; pin_number, last_value',
        'declare ptr @malloc(i64)',
        'declare void @free(ptr)',
        '',
        'define ptr @cssc_pin_new(i64 %pin) {',
        'entry:',
        '  %p = call ptr @malloc(i64 16)',
        '  store i64 %pin, ptr %p, align 8',
        '  %vp = getelementptr inbounds %cssc_pin, ptr %p, i64 0, i32 1',
        '  store i64 0, ptr %vp, align 8',
        '  ret ptr %p',
        '}',
        '',
        'define void @cssc_pin_free(ptr %p) {',
        'entry:',
        '  call void @free(ptr %p)',
        '  ret void',
        '}',
        '',
        'define void @cssc_pin_write(ptr %p, i64 %v) {',
        'entry:',
        '  %vp = getelementptr inbounds %cssc_pin, ptr %p, i64 0, i32 1',
        '  store i64 %v, ptr %vp, align 8',
        '  ret void',
        '}',
        '',
        'define i64 @cssc_pin_read(ptr %p) {',
        'entry:',
        '  %vp = getelementptr inbounds %cssc_pin, ptr %p, i64 0, i32 1',
        '  %v = load i64, ptr %vp, align 8',
        '  ret i64 %v',
        '}',
        '',
        'define void @cssc_pin_mode(ptr %p, i64 %m) {',
        'entry:',
        '  ret void   ; host stub: no hardware to configure',
        '}',
        '',
        'define void @cssc_pin_toggle(ptr %p) {',
        'entry:',
        '  %vp = getelementptr inbounds %cssc_pin, ptr %p, i64 0, i32 1',
        '  %cur = load i64, ptr %vp, align 8',
        '  %tog = xor i64 %cur, 1',
        '  store i64 %tog, ptr %vp, align 8',
        '  ret void',
        '}',
        '',
        'define void @cssc_pin_pullup(ptr %p, i64 %v) {',
        'entry:',
        '  ret void   ; host stub: no internal pull resistor to configure',
        '}',
    ]


_PIN_SYMBOLS = frozenset({
    'cssc_pin_new',
    'cssc_pin_free',
    'cssc_pin_write',
    'cssc_pin_read',
    'cssc_pin_mode',
    'cssc_pin_toggle',
    'cssc_pin_pullup',
})


# ---------------------------------------------------------------------------
# Bus peripherals — host stubs. Each kind keeps a tiny malloc'd state
# block (config params + last-transferred byte) so the host run doesn't
# need real hardware; the embedded transembly variants replace these
# with chip-specific MMIO writes. Tree-shaken per symbol.
#
# Layouts:
#   %cssc_i2c   = { i64 bus, i64 sda, i64 scl, i64 last }      (32 B)
#   %cssc_spi   = { i64 bus, i64 sck, i64 miso, i64 mosi,
#                   i64 last }                                 (40 B)
#   %cssc_uart  = { i64 bus, i64 tx, i64 rx, i64 baud,
#                   i64 last }                                 (40 B)
#   %cssc_adc   = { i64 pin, i64 last }                        (16 B)
#   %cssc_pwm   = { i64 pin, i64 freq, i64 res, i64 duty }     (32 B)
#   %cssc_timer = { i64 slot, i64 hz, i64 running, i64 ticks } (32 B)
# ---------------------------------------------------------------------------
def _emit_cssc_i2c() -> List[str]:
    return [
        '; --- gipeo: #i2c (host stub) ---',
        '%cssc_i2c = type { i64, i64, i64, i64 }',
        'declare ptr @malloc(i64)',
        'declare void @free(ptr)',
        '',
        'define ptr @cssc_i2c_new(i64 %bus, i64 %sda, i64 %scl) {',
        'entry:',
        '  %p = call ptr @malloc(i64 32)',
        '  store i64 %bus, ptr %p, align 8',
        '  %p1 = getelementptr inbounds %cssc_i2c, ptr %p, i64 0, i32 1',
        '  store i64 %sda, ptr %p1, align 8',
        '  %p2 = getelementptr inbounds %cssc_i2c, ptr %p, i64 0, i32 2',
        '  store i64 %scl, ptr %p2, align 8',
        '  %p3 = getelementptr inbounds %cssc_i2c, ptr %p, i64 0, i32 3',
        '  store i64 0, ptr %p3, align 8',
        '  ret ptr %p',
        '}',
        '',
        'define void @cssc_i2c_free(ptr %p) {',
        'entry:',
        '  call void @free(ptr %p)',
        '  ret void',
        '}',
        '',
        'define void @cssc_i2c_begin(ptr %p, i64 %freq) { entry: ret void }',
        '',
        'define i64 @cssc_i2c_write(ptr %p, i64 %addr, i64 %byte) {',
        'entry:',
        '  %lp = getelementptr inbounds %cssc_i2c, ptr %p, i64 0, i32 3',
        '  store i64 %byte, ptr %lp, align 8',
        '  ret i64 1',
        '}',
        '',
        'define i64 @cssc_i2c_read(ptr %p, i64 %addr) {',
        'entry:',
        '  %lp = getelementptr inbounds %cssc_i2c, ptr %p, i64 0, i32 3',
        '  %v = load i64, ptr %lp, align 8',
        '  ret i64 %v',
        '}',
    ]


_I2C_SYMBOLS = frozenset({
    'cssc_i2c_new', 'cssc_i2c_free',
    'cssc_i2c_begin', 'cssc_i2c_write', 'cssc_i2c_read',
})


def _emit_cssc_spi() -> List[str]:
    return [
        '; --- gipeo: #spi (host stub) ---',
        '%cssc_spi = type { i64, i64, i64, i64, i64 }',
        'declare ptr @malloc(i64)',
        'declare void @free(ptr)',
        '',
        'define ptr @cssc_spi_new(i64 %bus, i64 %sck, i64 %miso, i64 %mosi) {',
        'entry:',
        '  %p = call ptr @malloc(i64 40)',
        '  store i64 %bus, ptr %p, align 8',
        '  %p1 = getelementptr inbounds %cssc_spi, ptr %p, i64 0, i32 1',
        '  store i64 %sck, ptr %p1, align 8',
        '  %p2 = getelementptr inbounds %cssc_spi, ptr %p, i64 0, i32 2',
        '  store i64 %miso, ptr %p2, align 8',
        '  %p3 = getelementptr inbounds %cssc_spi, ptr %p, i64 0, i32 3',
        '  store i64 %mosi, ptr %p3, align 8',
        '  %p4 = getelementptr inbounds %cssc_spi, ptr %p, i64 0, i32 4',
        '  store i64 0, ptr %p4, align 8',
        '  ret ptr %p',
        '}',
        '',
        'define void @cssc_spi_free(ptr %p) { entry: call void @free(ptr %p) ret void }',
        'define void @cssc_spi_begin(ptr %p, i64 %freq) { entry: ret void }',
        '',
        'define i64 @cssc_spi_transfer(ptr %p, i64 %byte) {',
        'entry:',
        '  %lp = getelementptr inbounds %cssc_spi, ptr %p, i64 0, i32 4',
        '  store i64 %byte, ptr %lp, align 8',
        '  ret i64 %byte',
        '}',
    ]


_SPI_SYMBOLS = frozenset({
    'cssc_spi_new', 'cssc_spi_free',
    'cssc_spi_begin', 'cssc_spi_transfer',
})


def _emit_cssc_uart() -> List[str]:
    return [
        '; --- gipeo: #uart (host stub) ---',
        '%cssc_uart = type { i64, i64, i64, i64, i64 }',
        'declare ptr @malloc(i64)',
        'declare void @free(ptr)',
        '',
        'define ptr @cssc_uart_new(i64 %bus, i64 %tx, i64 %rx) {',
        'entry:',
        '  %p = call ptr @malloc(i64 40)',
        '  store i64 %bus, ptr %p, align 8',
        '  %p1 = getelementptr inbounds %cssc_uart, ptr %p, i64 0, i32 1',
        '  store i64 %tx, ptr %p1, align 8',
        '  %p2 = getelementptr inbounds %cssc_uart, ptr %p, i64 0, i32 2',
        '  store i64 %rx, ptr %p2, align 8',
        '  %p3 = getelementptr inbounds %cssc_uart, ptr %p, i64 0, i32 3',
        '  store i64 0, ptr %p3, align 8',
        '  %p4 = getelementptr inbounds %cssc_uart, ptr %p, i64 0, i32 4',
        '  store i64 0, ptr %p4, align 8',
        '  ret ptr %p',
        '}',
        '',
        'define void @cssc_uart_free(ptr %p) { entry: call void @free(ptr %p) ret void }',
        '',
        'define void @cssc_uart_begin(ptr %p, i64 %baud) {',
        'entry:',
        '  %bp = getelementptr inbounds %cssc_uart, ptr %p, i64 0, i32 3',
        '  store i64 %baud, ptr %bp, align 8',
        '  ret void',
        '}',
        '',
        'define void @cssc_uart_write(ptr %p, i64 %byte) {',
        'entry:',
        '  %lp = getelementptr inbounds %cssc_uart, ptr %p, i64 0, i32 4',
        '  store i64 %byte, ptr %lp, align 8',
        '  ret void',
        '}',
        '',
        'define i64 @cssc_uart_read(ptr %p) {',
        'entry:',
        '  %lp = getelementptr inbounds %cssc_uart, ptr %p, i64 0, i32 4',
        '  %v = load i64, ptr %lp, align 8',
        '  ret i64 %v',
        '}',
    ]


_UART_SYMBOLS = frozenset({
    'cssc_uart_new', 'cssc_uart_free',
    'cssc_uart_begin', 'cssc_uart_write', 'cssc_uart_read',
})


def _emit_cssc_adc() -> List[str]:
    return [
        '; --- gipeo: #adc (host stub) ---',
        '%cssc_adc = type { i64, i64 }',
        'declare ptr @malloc(i64)',
        'declare void @free(ptr)',
        '',
        'define ptr @cssc_adc_new(i64 %pin) {',
        'entry:',
        '  %p = call ptr @malloc(i64 16)',
        '  store i64 %pin, ptr %p, align 8',
        '  %vp = getelementptr inbounds %cssc_adc, ptr %p, i64 0, i32 1',
        '  store i64 0, ptr %vp, align 8',
        '  ret ptr %p',
        '}',
        '',
        'define void @cssc_adc_free(ptr %p) { entry: call void @free(ptr %p) ret void }',
        '',
        'define i64 @cssc_adc_read(ptr %p) {',
        'entry:',
        '  %vp = getelementptr inbounds %cssc_adc, ptr %p, i64 0, i32 1',
        '  %v = load i64, ptr %vp, align 8',
        '  ret i64 %v',
        '}',
    ]


_ADC_SYMBOLS = frozenset({
    'cssc_adc_new', 'cssc_adc_free', 'cssc_adc_read',
})


def _emit_cssc_pwm() -> List[str]:
    return [
        '; --- gipeo: #pwm (host stub) ---',
        '%cssc_pwm = type { i64, i64, i64, i64 }',
        'declare ptr @malloc(i64)',
        'declare void @free(ptr)',
        '',
        'define ptr @cssc_pwm_new(i64 %pin, i64 %freq, i64 %res) {',
        'entry:',
        '  %p = call ptr @malloc(i64 32)',
        '  store i64 %pin, ptr %p, align 8',
        '  %p1 = getelementptr inbounds %cssc_pwm, ptr %p, i64 0, i32 1',
        '  store i64 %freq, ptr %p1, align 8',
        '  %p2 = getelementptr inbounds %cssc_pwm, ptr %p, i64 0, i32 2',
        '  store i64 %res, ptr %p2, align 8',
        '  %p3 = getelementptr inbounds %cssc_pwm, ptr %p, i64 0, i32 3',
        '  store i64 0, ptr %p3, align 8',
        '  ret ptr %p',
        '}',
        '',
        'define void @cssc_pwm_free(ptr %p) { entry: call void @free(ptr %p) ret void }',
        '',
        'define void @cssc_pwm_duty(ptr %p, i64 %d) {',
        'entry:',
        '  %dp = getelementptr inbounds %cssc_pwm, ptr %p, i64 0, i32 3',
        '  store i64 %d, ptr %dp, align 8',
        '  ret void',
        '}',
    ]


_PWM_SYMBOLS = frozenset({
    'cssc_pwm_new', 'cssc_pwm_free', 'cssc_pwm_duty',
})


def _emit_cssc_timer() -> List[str]:
    return [
        '; --- gipeo: #timer (host stub) ---',
        '%cssc_timer = type { i64, i64, i64, i64 }',
        'declare ptr @malloc(i64)',
        'declare void @free(ptr)',
        '',
        'define ptr @cssc_timer_new(i64 %slot, i64 %hz) {',
        'entry:',
        '  %p = call ptr @malloc(i64 32)',
        '  store i64 %slot, ptr %p, align 8',
        '  %p1 = getelementptr inbounds %cssc_timer, ptr %p, i64 0, i32 1',
        '  store i64 %hz, ptr %p1, align 8',
        '  %p2 = getelementptr inbounds %cssc_timer, ptr %p, i64 0, i32 2',
        '  store i64 0, ptr %p2, align 8',
        '  %p3 = getelementptr inbounds %cssc_timer, ptr %p, i64 0, i32 3',
        '  store i64 0, ptr %p3, align 8',
        '  ret ptr %p',
        '}',
        '',
        'define void @cssc_timer_free(ptr %p) { entry: call void @free(ptr %p) ret void }',
        '',
        'define void @cssc_timer_start(ptr %p) {',
        'entry:',
        '  %rp = getelementptr inbounds %cssc_timer, ptr %p, i64 0, i32 2',
        '  store i64 1, ptr %rp, align 8',
        '  ret void',
        '}',
        '',
        'define void @cssc_timer_stop(ptr %p) {',
        'entry:',
        '  %rp = getelementptr inbounds %cssc_timer, ptr %p, i64 0, i32 2',
        '  store i64 0, ptr %rp, align 8',
        '  ret void',
        '}',
        '',
        'define i64 @cssc_timer_read(ptr %p) {',
        'entry:',
        '  %tp = getelementptr inbounds %cssc_timer, ptr %p, i64 0, i32 3',
        '  %t = load i64, ptr %tp, align 8',
        '  %t2 = add i64 %t, 1',
        '  store i64 %t2, ptr %tp, align 8   ; host stub: synthetic monotonic tick',
        '  ret i64 %t2',
        '}',
    ]


_TIMER_SYMBOLS = frozenset({
    'cssc_timer_new', 'cssc_timer_free',
    'cssc_timer_start', 'cssc_timer_stop', 'cssc_timer_read',
})


# ---------------------------------------------------------------------------
# Display peripherals — host stubs. The mod's actual rendering happens
# on real hardware (SPI bus on ESP, native window on Win32). On the
# host these stubs accept every call, store the last-known state, and
# track a synthetic "is_open" flag so scripts behave predictably.
#
# `cssc_tft_*` is shared between `#tft` and `#oled` (oled is a thin
# alias). The first ctor arg is the controller-id enum from
# `_TFT_CTRL_IDS`; later ctor args are dimensions / bus pins.
# ---------------------------------------------------------------------------
def _emit_cssc_tft() -> List[str]:
    return [
        '; --- gipeo: #tft / #oled (host stub — silent no-op) ---',
        '%cssc_tft = type { i64, i64, i64, i64 }   ; ctrl, w, h, last_color',
        'declare ptr @malloc(i64)',
        'declare void @free(ptr)',
        '',
        'define ptr @cssc_tft_new(i64 %ctrl, i64 %w, i64 %h) {',
        'entry:',
        '  %p = call ptr @malloc(i64 32)',
        '  store i64 %ctrl, ptr %p, align 8',
        '  %p1 = getelementptr inbounds %cssc_tft, ptr %p, i64 0, i32 1',
        '  store i64 %w, ptr %p1, align 8',
        '  %p2 = getelementptr inbounds %cssc_tft, ptr %p, i64 0, i32 2',
        '  store i64 %h, ptr %p2, align 8',
        '  %p3 = getelementptr inbounds %cssc_tft, ptr %p, i64 0, i32 3',
        '  store i64 0, ptr %p3, align 8',
        '  ret ptr %p',
        '}',
        '',
        '; #oled[ctrl, w, h, sda, scl, addr] forwards to the same struct;',
        '; the I²C wiring is ignored on host (no real bus), but we record',
        '; the ctrl + dimensions so reads observe what writes set.',
        'define ptr @cssc_oled_new(i64 %ctrl, i64 %w, i64 %h, i64 %sda, i64 %scl, i64 %addr) {',
        'entry:',
        '  %p = call ptr @cssc_tft_new(i64 %ctrl, i64 %w, i64 %h)',
        '  ret ptr %p',
        '}',
        '',
        'define void @cssc_tft_free(ptr %p) {',
        'entry:',
        '  call void @free(ptr %p)',
        '  ret void',
        '}',
        '',
        'define void @cssc_tft_begin(ptr %p) { entry: ret void }',
        'define void @cssc_tft_close(ptr %p) { entry: ret void }',
        'define void @cssc_tft_show(ptr %p)  { entry: ret void }',
        '',
        'define void @cssc_tft_fill(ptr %p, i64 %color) {',
        'entry:',
        '  %cp = getelementptr inbounds %cssc_tft, ptr %p, i64 0, i32 3',
        '  store i64 %color, ptr %cp, align 8',
        '  ret void',
        '}',
        '',
        'define void @cssc_tft_pixel(ptr %p, i64 %x, i64 %y, i64 %color) {',
        'entry: ret void',
        '}',
        'define void @cssc_tft_line(ptr %p, i64 %x0, i64 %y0, i64 %x1, i64 %y1, i64 %color) {',
        'entry: ret void',
        '}',
        'define void @cssc_tft_rect(ptr %p, i64 %x, i64 %y, i64 %w, i64 %h, i64 %color) {',
        'entry: ret void',
        '}',
        'define void @cssc_tft_fillrect(ptr %p, i64 %x, i64 %y, i64 %w, i64 %h, i64 %color) {',
        'entry: ret void',
        '}',
        'define void @cssc_tft_circle(ptr %p, i64 %cx, i64 %cy, i64 %r, i64 %color) {',
        'entry: ret void',
        '}',
        '',
        '; `text(x, y, str, color, scale)` — str arrives as a heap cssc_str ptr.',
        '; Host stub: no glyph rendering. Just accept the call silently.',
        'define void @cssc_tft_text(ptr %p, i64 %x, i64 %y, ptr %s, i64 %color, i64 %scale) {',
        'entry: ret void',
        '}',
        '',
        '; #oled aliases — point at the tft impls.',
        'define void @cssc_oled_free(ptr %p)     { entry: call void @cssc_tft_free(ptr %p)     ret void }',
        'define void @cssc_oled_begin(ptr %p)    { entry: ret void }',
        'define void @cssc_oled_close(ptr %p)    { entry: ret void }',
        'define void @cssc_oled_show(ptr %p)     { entry: ret void }',
        'define void @cssc_oled_fill(ptr %p, i64 %c) { entry: call void @cssc_tft_fill(ptr %p, i64 %c) ret void }',
        'define void @cssc_oled_pixel(ptr %p, i64 %x, i64 %y, i64 %c) { entry: ret void }',
        'define void @cssc_oled_line(ptr %p, i64 %x0, i64 %y0, i64 %x1, i64 %y1, i64 %c) { entry: ret void }',
        'define void @cssc_oled_rect(ptr %p, i64 %x, i64 %y, i64 %w, i64 %h, i64 %c) { entry: ret void }',
        'define void @cssc_oled_fillrect(ptr %p, i64 %x, i64 %y, i64 %w, i64 %h, i64 %c) { entry: ret void }',
        'define void @cssc_oled_circle(ptr %p, i64 %cx, i64 %cy, i64 %r, i64 %c) { entry: ret void }',
        'define void @cssc_oled_text(ptr %p, i64 %x, i64 %y, ptr %s, i64 %c, i64 %sc) { entry: ret void }',
    ]


_TFT_SYMBOLS = frozenset({
    'cssc_tft_new',  'cssc_tft_free',
    'cssc_tft_begin','cssc_tft_close','cssc_tft_show',
    'cssc_tft_fill', 'cssc_tft_pixel','cssc_tft_line',
    'cssc_tft_rect', 'cssc_tft_fillrect','cssc_tft_circle','cssc_tft_text',
    'cssc_oled_new', 'cssc_oled_free',
    'cssc_oled_begin','cssc_oled_close','cssc_oled_show',
    'cssc_oled_fill','cssc_oled_pixel','cssc_oled_line',
    'cssc_oled_rect','cssc_oled_fillrect','cssc_oled_circle','cssc_oled_text',
})


def _host_game_use_external_runtime() -> bool:
    """True when the v6 driver will link `cssc_host_game.c` as a companion
    object. In that mode we emit `declare` lines for the game-facing
    runtime symbols so ld/lld doesn't see two definitions (LLVM-stub
    body + real C body) of the same symbol.

    The env var mirrors the driver-side guard in
    `_host_compile_game_runtime`. Any value in `{off, 0, false, no}`
    opts out and falls back to the stub bodies.
    """
    val = os.environ.get('CSSC_HOST_GAME_RUNTIME', '').strip().lower()
    return val not in ('off', '0', 'false', 'no')


def _emit_cssc_video_matrix_fb_console(use_external_runtime: Optional[bool] = None) -> List[str]:
    """Host stubs for #video / #matrix / #framebuffer / #console.

    When `use_external_runtime=True`, emit `declare` lines only — the
    real bodies come from `cssc_host_game.c` linked as a companion .o.
    The `%cssc_v_*` opaque struct types still appear so any per-target
    LLVM optimisation that peeks at pointer element types has a
    consistent view; LLVM's opaque-pointer mode ignores them at IR
    level anyway.

    When `use_external_runtime=False`, emit no-op `define` bodies so
    scripts that touch the game modules still link on hosts without
    the companion .o (e.g. `CSSC_HOST_GAME_RUNTIME=off` or install
    variants that stripped the .c). The real rendering surface lives
    in the companion .o; these stubs guarantee link succeeds without
    it.

    Passing `None` (the default used by grouped-emitter dispatch)
    consults `_host_game_use_external_runtime()` so callers that
    haven't been threaded with the flag still land on the correct
    mode via the same env-var driver `_host_compile_game_runtime`
    obeys.
    """
    if use_external_runtime is None:
        use_external_runtime = _host_game_use_external_runtime()
    if use_external_runtime:
        return [
            '; --- gipeo: #video / #matrix / #framebuffer / #console '
            '(external runtime — declares only) ---',
            '%cssc_v_video   = type { i64, i64, i64, i64 }',
            '%cssc_v_matrix  = type { i64, i64, i64 }',
            '%cssc_v_fb      = type { i64, i64 }',
            '%cssc_v_console = type { i64, i64 }',
            '',
            'declare ptr  @cssc_video_new(i64, i64, i64)',
            'declare void @cssc_video_free(ptr)',
            'declare void @cssc_video_begin(ptr)',
            'declare void @cssc_video_close(ptr)',
            'declare void @cssc_video_clear(ptr, i64)',
            'declare void @cssc_video_pixel(ptr, i64, i64, i64)',
            'declare i64  @cssc_video_get_pixel(ptr, i64, i64)',
            'declare void @cssc_video_present(ptr)',
            'declare i64  @cssc_video_is_open(ptr)',
            'declare ptr  @cssc_video_hwnd(ptr)',
            '',
            'declare ptr  @cssc_matrix_new(i64, i64, i64)',
            'declare void @cssc_matrix_free(ptr)',
            'declare void @cssc_matrix_fill(ptr, i64)',
            'declare void @cssc_matrix_pixel(ptr, i64, i64, i64)',
            'declare i64  @cssc_matrix_get_pixel(ptr, i64, i64)',
            'declare i64  @cssc_matrix_width(ptr)',
            'declare i64  @cssc_matrix_height(ptr)',
            'declare void @cssc_matrix_show(ptr)',
            '',
            'declare ptr  @cssc_framebuffer_new(i64, i64)',
            'declare void @cssc_framebuffer_free(ptr)',
            'declare void @cssc_framebuffer_fill(ptr, i64)',
            'declare void @cssc_framebuffer_pixel(ptr, i64, i64, i64)',
            'declare i64  @cssc_framebuffer_get_pixel(ptr, i64, i64)',
            'declare i64  @cssc_framebuffer_width(ptr)',
            'declare i64  @cssc_framebuffer_height(ptr)',
            'declare void @cssc_framebuffer_present(ptr, ptr)',
            '',
            'declare ptr  @cssc_console_new(i64, i64)',
            'declare void @cssc_console_free(ptr)',
            'declare void @cssc_console_write(ptr, ptr)',
            'declare void @cssc_console_clear(ptr)',
            'declare void @cssc_console_close(ptr)',
        ]
    return [
        '; --- gipeo: #video / #matrix / #framebuffer / #console (host stubs) ---',
        'declare ptr @malloc(i64)',
        'declare void @free(ptr)',
        '',
        '; --- video ---',
        '%cssc_v_video = type { i64, i64, i64, i64 }   ; w, h, fps, is_open',
        'define ptr @cssc_video_new(i64 %w, i64 %h, i64 %fps) {',
        'entry:',
        '  %p = call ptr @malloc(i64 32)',
        '  store i64 %w, ptr %p, align 8',
        '  %p1 = getelementptr inbounds %cssc_v_video, ptr %p, i64 0, i32 1',
        '  store i64 %h, ptr %p1, align 8',
        '  %p2 = getelementptr inbounds %cssc_v_video, ptr %p, i64 0, i32 2',
        '  store i64 %fps, ptr %p2, align 8',
        '  %p3 = getelementptr inbounds %cssc_v_video, ptr %p, i64 0, i32 3',
        '  store i64 1, ptr %p3, align 8',
        '  ret ptr %p',
        '}',
        'define void @cssc_video_free(ptr %p)    { entry: call void @free(ptr %p) ret void }',
        'define void @cssc_video_begin(ptr %p)   { entry: ret void }',
        'define void @cssc_video_close(ptr %p) {',
        'entry:',
        '  %op = getelementptr inbounds %cssc_v_video, ptr %p, i64 0, i32 3',
        '  store i64 0, ptr %op, align 8',
        '  ret void',
        '}',
        'define void @cssc_video_clear(ptr %p, i64 %c) { entry: ret void }',
        'define void @cssc_video_present(ptr %p)       { entry: ret void }',
        'define i64  @cssc_video_is_open(ptr %p) {',
        'entry:',
        '  %op = getelementptr inbounds %cssc_v_video, ptr %p, i64 0, i32 3',
        '  %v = load i64, ptr %op, align 8',
        '  ret i64 %v',
        '}',
        '',
        '; --- matrix ---',
        '%cssc_v_matrix = type { i64, i64, i64 }   ; w, h, scale',
        'define ptr @cssc_matrix_new(i64 %w, i64 %h, i64 %scale) {',
        'entry:',
        '  %p = call ptr @malloc(i64 24)',
        '  store i64 %w, ptr %p, align 8',
        '  %p1 = getelementptr inbounds %cssc_v_matrix, ptr %p, i64 0, i32 1',
        '  store i64 %h, ptr %p1, align 8',
        '  %p2 = getelementptr inbounds %cssc_v_matrix, ptr %p, i64 0, i32 2',
        '  store i64 %scale, ptr %p2, align 8',
        '  ret ptr %p',
        '}',
        'define void @cssc_matrix_free(ptr %p)  { entry: call void @free(ptr %p) ret void }',
        'define void @cssc_matrix_fill(ptr %p, i64 %c)             { entry: ret void }',
        'define void @cssc_matrix_pixel(ptr %p, i64 %x, i64 %y, i64 %c) { entry: ret void }',
        'define void @cssc_matrix_show(ptr %p)                       { entry: ret void }',
        '',
        '; --- framebuffer ---',
        '%cssc_v_fb = type { i64, i64 }   ; w, h',
        'define ptr @cssc_framebuffer_new(i64 %w, i64 %h) {',
        'entry:',
        '  %p = call ptr @malloc(i64 16)',
        '  store i64 %w, ptr %p, align 8',
        '  %p1 = getelementptr inbounds %cssc_v_fb, ptr %p, i64 0, i32 1',
        '  store i64 %h, ptr %p1, align 8',
        '  ret ptr %p',
        '}',
        'define void @cssc_framebuffer_free(ptr %p)                                { entry: call void @free(ptr %p) ret void }',
        'define void @cssc_framebuffer_fill(ptr %p, i64 %c)                        { entry: ret void }',
        'define void @cssc_framebuffer_pixel(ptr %p, i64 %x, i64 %y, i64 %c)       { entry: ret void }',
        'define void @cssc_framebuffer_present(ptr %p)                             { entry: ret void }',
        '',
        '; --- console ---',
        '%cssc_v_console = type { i64, i64 }',
        'define ptr @cssc_console_new(i64 %w, i64 %h) {',
        'entry:',
        '  %p = call ptr @malloc(i64 16)',
        '  store i64 %w, ptr %p, align 8',
        '  %p1 = getelementptr inbounds %cssc_v_console, ptr %p, i64 0, i32 1',
        '  store i64 %h, ptr %p1, align 8',
        '  ret ptr %p',
        '}',
        'define void @cssc_console_free(ptr %p)  { entry: call void @free(ptr %p) ret void }',
        'define void @cssc_console_write(ptr %p, ptr %s) { entry: ret void }',
        'define void @cssc_console_clear(ptr %p)  { entry: ret void }',
        'define void @cssc_console_close(ptr %p)  { entry: ret void }',
    ]


_VIDEO_FB_CONSOLE_SYMBOLS = frozenset({
    'cssc_video_new', 'cssc_video_free',
    'cssc_video_begin', 'cssc_video_close', 'cssc_video_clear',
    'cssc_video_pixel', 'cssc_video_get_pixel',
    'cssc_video_present', 'cssc_video_is_open',
    'cssc_video_hwnd',
    'cssc_matrix_new', 'cssc_matrix_free',
    'cssc_matrix_fill', 'cssc_matrix_pixel',
    'cssc_matrix_get_pixel',
    'cssc_matrix_width', 'cssc_matrix_height',
    'cssc_matrix_show',
    'cssc_framebuffer_new', 'cssc_framebuffer_free',
    'cssc_framebuffer_fill', 'cssc_framebuffer_pixel',
    'cssc_framebuffer_get_pixel',
    'cssc_framebuffer_width', 'cssc_framebuffer_height',
    'cssc_framebuffer_present',
    'cssc_console_new', 'cssc_console_free',
    'cssc_console_write', 'cssc_console_clear', 'cssc_console_close',
})


# ---------------------------------------------------------------------------
# Game-namespace runtime declares.
#
# Each emitter below produces `declare` lines for its family's symbols;
# the corresponding function bodies live in `cssc_host_game.c`, linked
# as a companion object by v6_driver's host-game path. No local bodies
# — link fails cleanly if `cssc_host_game.o` is missing, which mirrors
# the diagnostic the video/matrix/fb/console emitter uses via
# `_host_game_use_external_runtime`.
# ---------------------------------------------------------------------------
def _emit_cssc_keyboard() -> List[str]:
    return [
        '; --- keyboard: cssc_keyboard_* (external runtime) ---',
        'declare ptr  @cssc_keyboard_new()',
        'declare void @cssc_keyboard_free(ptr)',
        'declare void @cssc_keyboard_update(ptr)',
        'declare i64  @cssc_keyboard_is_pressed(ptr, ptr)',
        'declare i64  @cssc_keyboard_is_down(ptr, ptr)',
        'declare i64  @cssc_keyboard_is_released(ptr, ptr)',
        'declare ptr  @cssc_keyboard_get_key(ptr)',
    ]


_KEYBOARD_SYMBOLS = frozenset({
    'cssc_keyboard_new', 'cssc_keyboard_free',
    'cssc_keyboard_update',
    'cssc_keyboard_is_pressed', 'cssc_keyboard_is_down',
    'cssc_keyboard_is_released', 'cssc_keyboard_get_key',
})


def _emit_cssc_mouse() -> List[str]:
    return [
        '; --- mouse: cssc_mouse_* (external runtime) ---',
        'declare ptr  @cssc_mouse_new(ptr)',
        'declare void @cssc_mouse_free(ptr)',
        'declare void @cssc_mouse_update(ptr)',
        'declare i64  @cssc_mouse_get_x(ptr)',
        'declare i64  @cssc_mouse_get_y(ptr)',
        'declare ptr  @cssc_mouse_get_pos(ptr)',
        'declare i64  @cssc_mouse_is_clicked(ptr, ptr)',
        'declare i64  @cssc_mouse_is_held(ptr, ptr)',
        'declare i64  @cssc_mouse_is_released(ptr, ptr)',
        'declare i64  @cssc_mouse_is_over(ptr, i64, i64, i64, i64)',
    ]


_MOUSE_SYMBOLS = frozenset({
    'cssc_mouse_new', 'cssc_mouse_free',
    'cssc_mouse_update',
    'cssc_mouse_get_x', 'cssc_mouse_get_y', 'cssc_mouse_get_pos',
    'cssc_mouse_is_clicked', 'cssc_mouse_is_held',
    'cssc_mouse_is_released', 'cssc_mouse_is_over',
})


def _emit_cssc_sound() -> List[str]:
    return [
        '; --- sound: cssc_sound_* (external runtime) ---',
        'declare ptr  @cssc_sound_new()',
        'declare void @cssc_sound_free(ptr)',
        'declare ptr  @cssc_sound_load(ptr, ptr)',
        'declare void @cssc_sound_play(ptr, ptr)',
        'declare void @cssc_sound_stop(ptr, ptr)',
        'declare void @cssc_sound_stop_all(ptr)',
        'declare void @cssc_sound_set_volume(ptr, i64)',
        'declare i64  @cssc_sound_is_playing(ptr, ptr)',
    ]


_SOUND_SYMBOLS = frozenset({
    'cssc_sound_new', 'cssc_sound_free', 'cssc_sound_load',
    'cssc_sound_play', 'cssc_sound_stop', 'cssc_sound_stop_all',
    'cssc_sound_set_volume', 'cssc_sound_is_playing',
})


def _emit_cssc_sprite() -> List[str]:
    return [
        '; --- video.sprite: cssc_sprite_* (external runtime) ---',
        'declare ptr  @cssc_sprite_new(i64, i64)',
        'declare void @cssc_sprite_free(ptr)',
        'declare ptr  @cssc_sprite_load(ptr)',
        'declare void @cssc_sprite_set_pixel(ptr, i64, i64, i64)',
        'declare i64  @cssc_sprite_get_pixel(ptr, i64, i64)',
        'declare i64  @cssc_sprite_width(ptr)',
        'declare i64  @cssc_sprite_height(ptr)',
        'declare void @cssc_sprite_draw(ptr, ptr, i64, i64)',
        'declare void @cssc_sprite_draw_scaled(ptr, ptr, i64, i64, i64, i64)',
        'declare void @cssc_sprite_draw_tinted(ptr, ptr, i64, i64, i64)',
        'declare void @cssc_sprite_draw_alpha (ptr, ptr, i64, i64, i64)',
    ]


_SPRITE_SYMBOLS = frozenset({
    'cssc_sprite_new', 'cssc_sprite_free', 'cssc_sprite_load',
    'cssc_sprite_set_pixel', 'cssc_sprite_get_pixel',
    'cssc_sprite_width', 'cssc_sprite_height',
    'cssc_sprite_draw', 'cssc_sprite_draw_scaled',
    'cssc_sprite_draw_tinted', 'cssc_sprite_draw_alpha',
})


def _emit_cssc_tilemap() -> List[str]:
    return [
        '; --- video.tilemap: cssc_tm_* (external runtime) ---',
        'declare ptr  @cssc_tm_new(i64, i64, i64, i64)',
        'declare void @cssc_tm_free(ptr)',
        'declare void @cssc_tm_set_tile(ptr, i64, ptr)',
        'declare void @cssc_tm_set(ptr, i64, i64, i64)',
        'declare i64  @cssc_tm_get(ptr, i64, i64)',
        'declare i64  @cssc_tm_cols(ptr)',
        'declare i64  @cssc_tm_rows(ptr)',
        'declare void @cssc_tm_draw(ptr, ptr, i64, i64)',
    ]


_TILEMAP_SYMBOLS = frozenset({
    'cssc_tm_new', 'cssc_tm_free',
    'cssc_tm_set_tile', 'cssc_tm_set', 'cssc_tm_get',
    'cssc_tm_cols', 'cssc_tm_rows', 'cssc_tm_draw',
})


def _emit_cssc_font() -> List[str]:
    return [
        '; --- video.font: cssc_font_* (external runtime) ---',
        'declare ptr  @cssc_font_new()',
        'declare void @cssc_font_free(ptr)',
        'declare ptr  @cssc_font_load(ptr)',
        'declare ptr  @cssc_font_builtin()',
        'declare i64  @cssc_font_height(ptr)',
        'declare i64  @cssc_font_measure(ptr, ptr)',
        'declare void @cssc_font_draw(ptr, ptr, ptr, i64, i64, i64)',
    ]


_FONT_SYMBOLS = frozenset({
    'cssc_font_new', 'cssc_font_free', 'cssc_font_load',
    'cssc_font_builtin',
    'cssc_font_height', 'cssc_font_measure', 'cssc_font_draw',
})


def _emit_truncdfsf2() -> List[str]:
    """Host stub for the libgcc soft-float `f64 → f32` thunk.

    Windows lld doesn't auto-link compiler-rt's builtins library, so
    user code referencing `__truncdfsf2` (emitted by cir_lower for
    `#stack[float, 32] x = <f64-literal>`) would fail at link time.
    We provide the symbol locally as a hardware `fptrunc` — semantically
    identical to compiler-rt and zero overhead with the optimiser on.
    """
    return [
        '',
        '; --- __truncdfsf2: hardware fptrunc shim (host) ---',
        'define float @__truncdfsf2(double %d) {',
        'entry:',
        '  %r = fptrunc double %d to float',
        '  ret float %r',
        '}',
    ]


def _emit_extendsfdf2() -> List[str]:
    """Host stub for the libgcc soft-float `f32 → f64` thunk."""
    return [
        '',
        '; --- __extendsfdf2: hardware fpext shim (host) ---',
        'define double @__extendsfdf2(float %f) {',
        'entry:',
        '  %r = fpext float %f to double',
        '  ret double %r',
        '}',
    ]


def _emit_fixdfsi() -> List[str]:
    """Host stub for libgcc soft-float `double → i32` thunk.

    cir_lower invokes `__fixdfsi` with `return_type=INT64`, so the
    emitted call site reads `%v = call i64 @__fixdfsi(double …)`. We
    match that signature exactly: fptosi to i32, then sext to i64 so
    callers see the canonical truncation semantics the compiler-rt
    builtin would produce. Embedded Xtensa pulls the real i32-returning
    builtin from libgcc/softfloat — host needs this shim because
    Windows lld-link does not implicitly pull compiler-rt.
    """
    return [
        '',
        '; --- __fixdfsi: hardware fptosi shim (host) ---',
        'define i64 @__fixdfsi(double %d) {',
        'entry:',
        '  %i32 = fptosi double %d to i32',
        '  %i64 = sext i32 %i32 to i64',
        '  ret i64 %i64',
        '}',
    ]


def _emit_floatsidf() -> List[str]:
    """Host stub for libgcc soft-float `i32 → double` thunk.

    cir_lower passes i64 args at the call site (`call double
    @__floatsidf(i64 …)`); we truncate to i32 inside and then sitofp
    to double, matching the canonical compiler-rt builtin's
    promotion semantics for values that fit in i32.
    """
    return [
        '',
        '; --- __floatsidf: hardware sitofp shim (host) ---',
        'define double @__floatsidf(i64 %i) {',
        'entry:',
        '  %i32 = trunc i64 %i to i32',
        '  %r = sitofp i32 %i32 to double',
        '  ret double %r',
        '}',
    ]


_SYMBOL_EMITTERS = {
    'cssc_runtime_init':     _emit_cssc_runtime_init,
    'cssc_runtime_shutdown': _emit_cssc_runtime_shutdown,
    'cssc_exit':             _emit_cssc_exit,
    'cssc_print_int':        _emit_cssc_print_int,
    'cssc_print_newline':    _emit_cssc_print_newline,
    'cssc_print_float':      _emit_cssc_print_float,
    'cssc_print_bool':       _emit_cssc_print_bool,
    'cssc_print_str':        _emit_cssc_print_str,
    'cssc_panic':            _emit_cssc_panic,
    'cssc_out_int':          _emit_cssc_out_int,
    'cssc_out_float':        _emit_cssc_out_float,
    'cssc_out_bool':         _emit_cssc_out_bool,
    'cssc_out_str':          _emit_cssc_out_str,
    'cssc_out_string':       _emit_cssc_out_string,
    '__truncdfsf2':          _emit_truncdfsf2,
    '__extendsfdf2':         _emit_extendsfdf2,
    '__fixdfsi':             _emit_fixdfsi,
    '__floatsidf':           _emit_floatsidf,
}

# Group emitters share state and emit several symbols at once.
# Order matters for `emit_runtime_ll`'s output stability — vector_int comes
# first because its struct (%cssc_vec_int) is the architectural anchor that
# other heap kinds mirror.
_CONTAINER_REPR_SYMBOLS = frozenset({
    'cssc_str_concat_free',
    'cssc_repr_quote',
    'cssc_value_fmt',
    'cssc_value_repr',
    'cssc_value_str',
    'cssc_array_bind_fmt',
    'cssc_array_bind_repr',
    'cssc_array_bind_str',
    'cssc_map_si_fmt',
    'cssc_map_si_repr',
    'cssc_map_si_str',
})


def _emit_cssc_container_repr() -> List[str]:
    """Faithful Python-`repr()` container stringify runtime.

    Reproduces the interpreter's `cssc::to_string(container)` byte-for-byte
    (which is Python `repr()` of the underlying list/dict):
      * array_bind (array<auto>/array<T>/vector<auto> element rows) →
        ``[`` + join(element repr, ``, ``) + ``]``
      * map_si (map<string,int>) → ``{`` + join(``'key': val``, ``, ``) + ``}``
        in INSERTION order (via the per-entry `seq` field).
      * string elements are repr-quoted (single quotes by default; double
        quotes if the value contains ``'`` and not ``"``; ``'`` back-slash
        escaped when both are present; ``\\``, ``\\n``, ``\\r``, ``\\t`` and
        other control bytes escaped exactly like CPython `str.__repr__`).
      * bool → ``True`` / ``False`` (Python casing, inside containers).
      * int → decimal, float → `cssc_float_to_str`.
      * nested containers recurse (`[['a', 'b']]`, `[{'k': 1}]`).

    The functions are mutually recursive (array→value→array/map) and are
    also called from `cssc_bind_entry_as_string` (tag 6/7) so a popped /
    selected nested-container element stringifies faithfully. Strings are
    built with `cssc_string_concat`; every transient is released via the
    `cssc_str_concat_free` helper so there is no leak."""
    CONSTS = {
        'lbrack': '[', 'rbrack': ']', 'lbrace': '{', 'rbrace': '}',
        'comma': ', ', 'colon': ': ', 'empta': '[]', 'emptm': '{}',
        'true': 'True', 'false': 'False', 'sqempty': "''",
    }
    clen = {}
    lines: List[str] = ['', '; --- faithful Python-repr container stringify ---']
    for key, text in CONSTS.items():
        raw = text.encode('utf-8')
        body = ''.join(('\\%02X' % b) if (b in (0x22, 0x5c) or b < 0x20 or b >= 0x7f)
                       else chr(b) for b in raw)
        clen[key] = len(raw)
        lines.append(
            f'@.crq_{key} = private unnamed_addr constant '
            f'[{len(raw) + 1} x i8] c"{body}\\00"')
    lines.append('')

    def lit(var, key):
        n = clen[key]
        return [
            f'  %{var}_p = getelementptr inbounds [{n + 1} x i8], '
            f'ptr @.crq_{key}, i64 0, i64 0',
            f'  %{var} = call ptr @cssc_string_lit(ptr %{var}_p, i64 {n})',
        ]

    # ---- concat helper: concat(a,b), release both inputs, return fresh ----
    lines += [
        'define ptr @cssc_str_concat_free(ptr %a, ptr %b) {',
        'entry:',
        '  %r = call ptr @cssc_string_concat(ptr %a, ptr %b)',
        '  call void @cssc_release(ptr %a)',
        '  call void @cssc_release(ptr %b)',
        '  ret ptr %r',
        '}',
        '',
    ]

    # ---- cssc_repr_quote(s): Python str-repr quoting of a heap string ----
    lines += [
        'define ptr @cssc_repr_quote(ptr %s) {',
        'entry:',
        '  %isn = icmp eq ptr %s, null',
        '  br i1 %isn, label %emptystr, label %scan_init',
        'emptystr:',
    ] + lit('eq', 'sqempty') + [
        '  ret ptr %eq',
        'scan_init:',
        '  %data = call ptr @cssc_string_data(ptr %s)',
        '  %n = call i64 @cssc_string_size(ptr %s)',
        '  br label %scan',
        'scan:',
        '  %si = phi i64 [ 0, %scan_init ], [ %sinext, %scancont ]',
        '  %hasS = phi i1 [ 0, %scan_init ], [ %hasS2, %scancont ]',
        '  %hasD = phi i1 [ 0, %scan_init ], [ %hasD2, %scancont ]',
        '  %sdone = icmp uge i64 %si, %n',
        '  br i1 %sdone, label %pick, label %scanbody',
        'scanbody:',
        '  %scp = getelementptr inbounds i8, ptr %data, i64 %si',
        '  %sc = load i8, ptr %scp',
        '  %isSq = icmp eq i8 %sc, 39',
        '  %isDq = icmp eq i8 %sc, 34',
        '  %hasS2 = or i1 %hasS, %isSq',
        '  %hasD2 = or i1 %hasD, %isDq',
        '  br label %scancont',
        'scancont:',
        '  %sinext = add i64 %si, 1',
        '  br label %scan',
        'pick:',
        '  %notD = xor i1 %hasD, true',
        '  %useD = and i1 %hasS, %notD',
        '  %quote = select i1 %useD, i8 34, i8 39',
        '  %n4 = mul i64 %n, 4',
        '  %bufsz = add i64 %n4, 3',
        '  %buf = call ptr @malloc(i64 %bufsz)',
        '  store i8 %quote, ptr %buf',
        '  br label %eloop',
        'eloop:',
        '  %ei = phi i64 [ 0, %pick ], [ %einext, %econt ]',
        '  %p = phi i64 [ 1, %pick ], [ %pnext, %econt ]',
        '  %edone = icmp uge i64 %ei, %n',
        '  br i1 %edone, label %efin, label %ebody',
        'ebody:',
        '  %ecp = getelementptr inbounds i8, ptr %data, i64 %ei',
        '  %ec = load i8, ptr %ecp',
        '  %isBs = icmp eq i8 %ec, 92',
        '  br i1 %isBs, label %e_bs, label %e_chkq',
        # ---- backslash → \\ ----
        'e_bs:',
        '  %pbsA = getelementptr inbounds i8, ptr %buf, i64 %p',
        '  store i8 92, ptr %pbsA',
        '  %pbs1 = add i64 %p, 1',
        '  %pbsB = getelementptr inbounds i8, ptr %buf, i64 %pbs1',
        '  store i8 92, ptr %pbsB',
        '  %pbs2 = add i64 %p, 2',
        '  br label %econt',
        'e_chkq:',
        '  %isQ = icmp eq i8 %ec, %quote',
        '  br i1 %isQ, label %e_q, label %e_chknl',
        # ---- the active quote char → \<quote> ----
        'e_q:',
        '  %pqA = getelementptr inbounds i8, ptr %buf, i64 %p',
        '  store i8 92, ptr %pqA',
        '  %pq1 = add i64 %p, 1',
        '  %pqB = getelementptr inbounds i8, ptr %buf, i64 %pq1',
        '  store i8 %quote, ptr %pqB',
        '  %pq2 = add i64 %p, 2',
        '  br label %econt',
        'e_chknl:',
        '  %isNl = icmp eq i8 %ec, 10',
        '  br i1 %isNl, label %e_nl, label %e_chkcr',
        'e_nl:',
        '  %pnlA = getelementptr inbounds i8, ptr %buf, i64 %p',
        '  store i8 92, ptr %pnlA',
        '  %pnl1 = add i64 %p, 1',
        '  %pnlB = getelementptr inbounds i8, ptr %buf, i64 %pnl1',
        '  store i8 110, ptr %pnlB',
        '  %pnl2 = add i64 %p, 2',
        '  br label %econt',
        'e_chkcr:',
        '  %isCr = icmp eq i8 %ec, 13',
        '  br i1 %isCr, label %e_cr, label %e_chktab',
        'e_cr:',
        '  %pcrA = getelementptr inbounds i8, ptr %buf, i64 %p',
        '  store i8 92, ptr %pcrA',
        '  %pcr1 = add i64 %p, 1',
        '  %pcrB = getelementptr inbounds i8, ptr %buf, i64 %pcr1',
        '  store i8 114, ptr %pcrB',
        '  %pcr2 = add i64 %p, 2',
        '  br label %econt',
        'e_chktab:',
        '  %isTab = icmp eq i8 %ec, 9',
        '  br i1 %isTab, label %e_tab, label %e_chkctrl',
        'e_tab:',
        '  %ptabA = getelementptr inbounds i8, ptr %buf, i64 %p',
        '  store i8 92, ptr %ptabA',
        '  %ptab1 = add i64 %p, 1',
        '  %ptabB = getelementptr inbounds i8, ptr %buf, i64 %ptab1',
        '  store i8 116, ptr %ptabB',
        '  %ptab2 = add i64 %p, 2',
        '  br label %econt',
        # ---- control byte (<0x20 or ==0x7f) → \xHH (lowercase hex) ----
        'e_chkctrl:',
        '  %ecu = zext i8 %ec to i32',
        '  %lt20 = icmp ult i32 %ecu, 32',
        '  %is7f = icmp eq i32 %ecu, 127',
        '  %isCtrl = or i1 %lt20, %is7f',
        '  br i1 %isCtrl, label %e_ctrl, label %e_raw',
        'e_ctrl:',
        '  %pcA = getelementptr inbounds i8, ptr %buf, i64 %p',
        '  store i8 92, ptr %pcA',
        '  %pc1 = add i64 %p, 1',
        '  %pcB = getelementptr inbounds i8, ptr %buf, i64 %pc1',
        '  store i8 120, ptr %pcB',
        '  %hi = lshr i8 %ec, 4',
        '  %hi4 = and i8 %hi, 15',
        '  %hi_ge = icmp uge i8 %hi4, 10',
        '  %hi_off = select i1 %hi_ge, i8 87, i8 48',
        '  %hi_ch = add i8 %hi4, %hi_off',
        '  %pc2 = add i64 %p, 2',
        '  %pcC = getelementptr inbounds i8, ptr %buf, i64 %pc2',
        '  store i8 %hi_ch, ptr %pcC',
        '  %lo4 = and i8 %ec, 15',
        '  %lo_ge = icmp uge i8 %lo4, 10',
        '  %lo_off = select i1 %lo_ge, i8 87, i8 48',
        '  %lo_ch = add i8 %lo4, %lo_off',
        '  %pc3 = add i64 %p, 3',
        '  %pcD = getelementptr inbounds i8, ptr %buf, i64 %pc3',
        '  store i8 %lo_ch, ptr %pcD',
        '  %pc4 = add i64 %p, 4',
        '  br label %econt',
        # ---- ordinary byte → copy verbatim ----
        'e_raw:',
        '  %prA = getelementptr inbounds i8, ptr %buf, i64 %p',
        '  store i8 %ec, ptr %prA',
        '  %pr1 = add i64 %p, 1',
        '  br label %econt',
        'econt:',
        '  %pnext = phi i64 [ %pbs2, %e_bs ], [ %pq2, %e_q ], '
        '[ %pnl2, %e_nl ], [ %pcr2, %e_cr ], [ %ptab2, %e_tab ], '
        '[ %pc4, %e_ctrl ], [ %pr1, %e_raw ]',
        '  %einext = add i64 %ei, 1',
        '  br label %eloop',
        'efin:',
        '  %pclose = getelementptr inbounds i8, ptr %buf, i64 %p',
        '  store i8 %quote, ptr %pclose',
        '  %finlen = add i64 %p, 1',
        '  %res = call ptr @cssc_string_lit(ptr %buf, i64 %finlen)',
        '  call void @free(ptr %buf)',
        '  ret ptr %res',
        '}',
        '',
    ]

    # ---- cssc_value_fmt(val_bits, tag, mode): one tagged cell → string ----
    # mode 0 = CSSC str form ({…}, raw unquoted strings, true/false bool);
    # mode 1 = Python repr ([…], quoted strings, True/False). The mode is
    # threaded through nested containers so a whole tree renders in one form.
    lines += [
        'define ptr @cssc_value_fmt(i64 %val, i64 %tag, i64 %mode) {',
        'entry:',
        '  switch i64 %tag, label %vint [ i64 2, label %vflt '
        'i64 3, label %vstr i64 4, label %vbool '
        'i64 6, label %varr i64 7, label %vmap ]',
        'vint:',
        '  %is = call ptr @cssc_int_to_str(i64 %val)',
        '  ret ptr %is',
        'vflt:',
        '  %fd = call double @__cssc_bitcast_i64_f64(i64 %val)',
        '  %fs = call ptr @cssc_float_to_str(double %fd)',
        '  ret ptr %fs',
        'vstr:',
        '  %sp = inttoptr i64 %val to ptr',
        '  %isReprS = icmp eq i64 %mode, 1',
        '  br i1 %isReprS, label %vstr_r, label %vstr_s',
        'vstr_r:',
        '  %srq = call ptr @cssc_repr_quote(ptr %sp)',
        '  ret ptr %srq',
        'vstr_s:',
        '  %scp = call ptr @cssc_string_copy(ptr %sp)',
        '  ret ptr %scp',
        'vbool:',
        '  %bnz = icmp ne i64 %val, 0',
        '  %isReprB = icmp eq i64 %mode, 1',
        '  br i1 %isReprB, label %vbool_r, label %vbool_s',
        'vbool_r:',
        '  br i1 %bnz, label %btrue, label %bfalse',
        'btrue:',
    ] + lit('bt', 'true') + [
        '  ret ptr %bt',
        'bfalse:',
    ] + lit('bf', 'false') + [
        '  ret ptr %bf',
        'vbool_s:',
        '  %bs = call ptr @cssc_bool_to_str(i1 %bnz)',
        '  ret ptr %bs',
        'varr:',
        '  %ap = inttoptr i64 %val to ptr',
        '  %ar = call ptr @cssc_array_bind_fmt(ptr %ap, i64 %mode)',
        '  ret ptr %ar',
        'vmap:',
        '  %mp = inttoptr i64 %val to ptr',
        '  %mr = call ptr @cssc_map_si_fmt(ptr %mp, i64 %mode)',
        '  ret ptr %mr',
        '}',
        '',
        'define ptr @cssc_value_repr(i64 %val, i64 %tag) {',
        'entry:',
        '  %r = call ptr @cssc_value_fmt(i64 %val, i64 %tag, i64 1)',
        '  ret ptr %r',
        '}',
        '',
        'define ptr @cssc_value_str(i64 %val, i64 %tag) {',
        'entry:',
        '  %r = call ptr @cssc_value_fmt(i64 %val, i64 %tag, i64 0)',
        '  ret ptr %r',
        '}',
        '',
    ]

    # ---- cssc_array_bind_fmt(a, mode): open + join(cell fmts, ', ') + close.
    #      repr → '[' … ']'; str → '{' … '}'.  ----
    lines += [
        'define ptr @cssc_array_bind_fmt(ptr %a, i64 %mode) {',
        'entry:',
        '  %isRepr = icmp eq i64 %mode, 1',
        '  %isn = icmp eq ptr %a, null',
        '  br i1 %isn, label %empty, label %go',
        'empty:',
        '  %egG = select i1 %isRepr, ptr @.crq_empta, ptr @.crq_emptm',
        '  %e = call ptr @cssc_string_lit(ptr %egG, i64 2)',
        '  ret ptr %e',
        'go:',
        '  %n = call i64 @cssc_array_bind_size(ptr %a)',
        '  %obG = select i1 %isRepr, ptr @.crq_lbrack, ptr @.crq_lbrace',
        '  %acc0 = call ptr @cssc_string_lit(ptr %obG, i64 1)',
        '  br label %loop',
        'loop:',
        '  %i = phi i64 [ 0, %go ], [ %inext, %cont ]',
        '  %acc = phi ptr [ %acc0, %go ], [ %acc3, %cont ]',
        '  %done = icmp uge i64 %i, %n',
        '  br i1 %done, label %fin, label %body',
        'body:',
        '  %needsep = icmp ugt i64 %i, 0',
        '  br i1 %needsep, label %sep, label %nosep',
        'sep:',
    ] + lit('cm', 'comma') + [
        '  %acc1 = call ptr @cssc_str_concat_free(ptr %acc, ptr %cm)',
        '  br label %elem',
        'nosep:',
        '  br label %elem',
        'elem:',
        '  %acc2 = phi ptr [ %acc1, %sep ], [ %acc, %nosep ]',
        '  %ent = call ptr @cssc_array_bind_get_entry(ptr %a, i64 %i)',
        '  %tag = call i64 @cssc_bind_entry_cell_tag(ptr %ent, i64 0)',
        '  %vbits = call i64 @cssc_bind_entry_cell_int(ptr %ent, i64 0)',
        '  %er = call ptr @cssc_value_fmt(i64 %vbits, i64 %tag, i64 %mode)',
        '  %acc3 = call ptr @cssc_str_concat_free(ptr %acc2, ptr %er)',
        '  br label %cont',
        'cont:',
        '  %inext = add i64 %i, 1',
        '  br label %loop',
        'fin:',
        '  %cbG = select i1 %isRepr, ptr @.crq_rbrack, ptr @.crq_rbrace',
        '  %rb = call ptr @cssc_string_lit(ptr %cbG, i64 1)',
        '  %res = call ptr @cssc_str_concat_free(ptr %acc, ptr %rb)',
        '  ret ptr %res',
        '}',
        '',
        'define ptr @cssc_array_bind_repr(ptr %a) {',
        'entry:',
        '  %r = call ptr @cssc_array_bind_fmt(ptr %a, i64 1)',
        '  ret ptr %r',
        '}',
        '',
        'define ptr @cssc_array_bind_str(ptr %a) {',
        'entry:',
        '  %r = call ptr @cssc_array_bind_fmt(ptr %a, i64 0)',
        '  ret ptr %r',
        '}',
        '',
    ]

    # ---- cssc_map_si_fmt(m, mode): "{key: v, ...}" in insertion (seq) order.
    #      repr → keys repr-quoted ('k'); str → keys raw (k). Braces both.  ----
    lines += [
        'define ptr @cssc_map_si_fmt(ptr %m, i64 %mode) {',
        'entry:',
        '  %isn = icmp eq ptr %m, null',
        '  br i1 %isn, label %empty, label %go',
        'empty:',
    ] + lit('e', 'emptm') + [
        '  ret ptr %e',
        'go:',
        '  %size = call i64 @cssc_map_si_size(ptr %m)',
        '  %cap = call i64 @cssc_map_si_cap(ptr %m)',
    ] + lit('acc0', 'lbrace') + [
        '  br label %seqloop',
        'seqloop:',
        '  %seq = phi i64 [ 0, %go ], [ %seqnext, %seqcont ]',
        '  %accS = phi ptr [ %acc0, %go ], [ %accE, %seqcont ]',
        '  %sdone = icmp uge i64 %seq, %size',
        '  br i1 %sdone, label %fin, label %inner',
        'inner:',
        '  %i = phi i64 [ 0, %seqloop ], [ %inext, %innercont ]',
        '  %idone = icmp uge i64 %i, %cap',
        '  br i1 %idone, label %notfound, label %ibody',
        'ibody:',
        '  %st = call i64 @cssc_map_si_bstate(ptr %m, i64 %i)',
        '  %occ = icmp eq i64 %st, 1',
        '  br i1 %occ, label %chkseq, label %innercont',
        'chkseq:',
        '  %bs = call i64 @cssc_map_si_bseq(ptr %m, i64 %i)',
        '  %match = icmp eq i64 %bs, %seq',
        '  br i1 %match, label %emit, label %innercont',
        'innercont:',
        '  %inext = add i64 %i, 1',
        '  br label %inner',
        'emit:',
        '  %needsep = icmp ugt i64 %seq, 0',
        '  br i1 %needsep, label %sepb, label %nosepb',
        'sepb:',
    ] + lit('cm', 'comma') + [
        '  %accSep = call ptr @cssc_str_concat_free(ptr %accS, ptr %cm)',
        '  br label %kv',
        'nosepb:',
        '  br label %kv',
        'kv:',
        '  %acc1 = phi ptr [ %accSep, %sepb ], [ %accS, %nosepb ]',
        '  %kptr = call ptr @cssc_map_si_bkeyptr(ptr %m, i64 %i)',
        '  %klen = call i64 @cssc_map_si_bkeylen(ptr %m, i64 %i)',
        '  %kstr = call ptr @cssc_string_lit(ptr %kptr, i64 %klen)',
        '  %isReprK = icmp eq i64 %mode, 1',
        '  br i1 %isReprK, label %k_repr, label %k_raw',
        'k_repr:',
        '  %kq = call ptr @cssc_repr_quote(ptr %kstr)',
        '  call void @cssc_release(ptr %kstr)',
        '  br label %kdone',
        'k_raw:',
        '  br label %kdone',
        'kdone:',
        '  %keyfinal = phi ptr [ %kq, %k_repr ], [ %kstr, %k_raw ]',
        '  %acc2 = call ptr @cssc_str_concat_free(ptr %acc1, ptr %keyfinal)',
    ] + lit('cl', 'colon') + [
        '  %acc3 = call ptr @cssc_str_concat_free(ptr %acc2, ptr %cl)',
        '  %val = call i64 @cssc_map_si_bval(ptr %m, i64 %i)',
        '  %vstr = call ptr @cssc_int_to_str(i64 %val)',
        '  %acc4 = call ptr @cssc_str_concat_free(ptr %acc3, ptr %vstr)',
        '  br label %seqcont',
        'notfound:',
        '  br label %seqcont',
        'seqcont:',
        '  %accE = phi ptr [ %acc4, %kdone ], [ %accS, %notfound ]',
        '  %seqnext = add i64 %seq, 1',
        '  br label %seqloop',
        'fin:',
    ] + lit('rb', 'rbrace') + [
        '  %res = call ptr @cssc_str_concat_free(ptr %accS, ptr %rb)',
        '  ret ptr %res',
        '}',
        '',
        'define ptr @cssc_map_si_repr(ptr %m) {',
        'entry:',
        '  %r = call ptr @cssc_map_si_fmt(ptr %m, i64 1)',
        '  ret ptr %r',
        '}',
        '',
        'define ptr @cssc_map_si_str(ptr %m) {',
        'entry:',
        '  %r = call ptr @cssc_map_si_fmt(ptr %m, i64 0)',
        '  ret ptr %r',
        '}',
        '',
    ]
    return lines


_GROUP_EMITTERS = {
    'container_repr': (_CONTAINER_REPR_SYMBOLS, _emit_cssc_container_repr),
    'vector_int':   (_VECTOR_INT_SYMBOLS,   _emit_cssc_vector_int),
    'vector_float': (_VECTOR_FLOAT_SYMBOLS, _emit_cssc_vector_float),
    'vector_bool':  (_VECTOR_BOOL_SYMBOLS,  _emit_cssc_vector_bool),
    'vector_string': (_VECTOR_STRING_SYMBOLS, _emit_cssc_vector_string),
    'string':       (_STRING_SYMBOLS,       _emit_cssc_string_full),
    'map_si':       (_MAP_SI_SYMBOLS,       _emit_cssc_map_si),
    'map_ss':       (_MAP_SS_SYMBOLS,       _emit_cssc_map_ss),
    'map_is':       (_MAP_IS_SYMBOLS,       _emit_cssc_map_is),
    'map_ii':       (_MAP_II_SYMBOLS,       _emit_cssc_map_ii),
    'map_sf':       (_MAP_SF_SYMBOLS,       _emit_cssc_map_sf),
    'map_if':       (_MAP_IF_SYMBOLS,       _emit_cssc_map_if),
    'bind_ss':      (_BIND_SS_SYMBOLS,      _emit_cssc_bind_ss),
    'array_bind':   (_ARRAY_BIND_SYMBOLS,   _emit_cssc_array_bind),
    'obj_alloc':    (_OBJ_ALLOC_SYMBOLS,    _emit_cssc_obj_alloc),
    'startup':      (_STARTUP_SYMBOLS,      _emit_startup_globals_and_sysout),
    'startup_sysarg': (_STARTUP_SYSARG_SYMBOLS, _emit_startup_sysarg),
    'sys_argv':     (_SYS_ARGV_SYMBOLS,     _emit_cssc_sys_argv),
    'pin':          (_PIN_SYMBOLS,          _emit_cssc_pin),
    'i2c':          (_I2C_SYMBOLS,          _emit_cssc_i2c),
    'spi':          (_SPI_SYMBOLS,          _emit_cssc_spi),
    'uart':         (_UART_SYMBOLS,         _emit_cssc_uart),
    'adc':          (_ADC_SYMBOLS,          _emit_cssc_adc),
    'pwm':          (_PWM_SYMBOLS,          _emit_cssc_pwm),
    'timer':        (_TIMER_SYMBOLS,        _emit_cssc_timer),
    'tft':          (_TFT_SYMBOLS,          _emit_cssc_tft),
    'video_fb_console': (_VIDEO_FB_CONSOLE_SYMBOLS, _emit_cssc_video_matrix_fb_console),
    # Game-namespace declares — bodies live in cssc_host_game.c.
    'keyboard':     (_KEYBOARD_SYMBOLS,     _emit_cssc_keyboard),
    'mouse':        (_MOUSE_SYMBOLS,        _emit_cssc_mouse),
    'sound':        (_SOUND_SYMBOLS,        _emit_cssc_sound),
    'sprite':       (_SPRITE_SYMBOLS,       _emit_cssc_sprite),
    'tilemap':      (_TILEMAP_SYMBOLS,      _emit_cssc_tilemap),
    'font':         (_FONT_SYMBOLS,         _emit_cssc_font),
    'time':         (_TIME_SYMBOLS,         _emit_cssc_time),
    'math':         (_MATH_SYMBOLS,         _emit_cssc_math),
    'stringify':    (_STRINGIFY_SYMBOLS,    _emit_stringify_helpers),
}


_COMPANION_RUNTIME_SYMBOLS = frozenset({
    'cssc_ma_fade', 'cssc_ma_lerpf', 'cssc_ma_clampf',
    'cssc_ma_smoothstep', 'cssc_ma_smootherstep',
    'cssc_ma_floorf', 'cssc_ma_floori', 'cssc_ma_ceilf',
    'cssc_ma_roundf', 'cssc_ma_absf',
    'cssc_ma_sqrtf', 'cssc_ma_sinf', 'cssc_ma_cosf', 'cssc_ma_tanf',
    'cssc_ma_atan2f', 'cssc_ma_powf', 'cssc_ma_expf', 'cssc_ma_logf',
    'cssc_ma_minf', 'cssc_ma_maxf',
    'cssc_ma_hash2', 'cssc_ma_hash3', 'cssc_ma_hash4',
    'cssc_ma_hashUnit', 'cssc_ma_hashUnit3',
    'cssc_ma_valueNoise2', 'cssc_ma_fbm2',
    'cssc_ma_perlin2', 'cssc_ma_perlinFbm2',
    'cssc_ma_worldgen_tile_at', 'cssc_ma_worldgen_is_solid_at',
    'cssc_ma_available',
    'cssc_ini_read', 'cssc_ini_write',
    'cssc_ini_has_key', 'cssc_ini_delete', 'cssc_ini_exists',
    'cssc_stdio_exists', 'cssc_stdio_read', 'cssc_stdio_write',
    'cssc_stdio_createfile', 'cssc_stdio_removefile', 'cssc_stdio_cwd',
    'cssc_video_fillrect', 'cssc_video_draw_rect',
    'cssc_video_darken', 'cssc_video_draw_text',
    'cssc_video_open_titled', 'cssc_system_run', 'cssc_console_color',
    'cssc_sprite_sheet_load', 'cssc_sprite_sheet_draw_frame',
    'cssc_sprite_sheet_free',
    'cssc_tm_tileset_load', 'cssc_tm_create_from_tileset',
    'cssc_tm_set_at', 'cssc_tm_draw_cam',
    'cssc_camera_new', 'cssc_camera_free',
    'cssc_camera_set_bounds', 'cssc_camera_follow',
    'cssc_camera_x', 'cssc_camera_y',
    'cssc_sound_loop', 'cssc_sound_pause', 'cssc_sound_resume',
    'cssc_sound_default_load', 'cssc_sound_default_play',
    'cssc_sound_default_stop', 'cssc_sound_default_stop_all',
    'cssc_sound_default_set_volume', 'cssc_sound_default_is_playing',
    'cssc_sound_default_loop', 'cssc_sound_default_pause',
    'cssc_sound_default_resume',
    'cssc_devdebug_push', 'cssc_devdebug_stdout',
    'cssc_console_sync', 'cssc_console_desync', 'cssc_console_out',
    'cssc_mouse_default_update',
    'cssc_mouse_bind_default',
    'cssc_mouse_default_get_x', 'cssc_mouse_default_get_y',
    'cssc_mouse_default_get_pos',
    'cssc_mouse_default_is_clicked', 'cssc_mouse_default_is_held',
    'cssc_mouse_default_is_released', 'cssc_mouse_default_is_over',
    'cssc_keyboard_default_update',
    'cssc_keyboard_default_is_pressed',
    'cssc_keyboard_default_is_down',
    'cssc_keyboard_default_is_released',
    'cssc_keyboard_default_get_key',
    'cssc_input',
    # CCOS freestanding intrinsics, host-provided by cssc_host_extras.c so the
    # CSSC-written interpreter (kernel/interp.cssc) can be compiled + unit-tested
    # on the host without booting the bare-metal kernel. Memory/bit ops are real;
    # port-I/O and framebuffer accessors are inert stubs (no MMIO on host).
    'cssc_alloc_raw', 'cssc_free_raw', 'cssc_heap_used',
    'cssc_memcopy', 'cssc_memfill32',
    'cssc_peek8', 'cssc_peek16', 'cssc_peek32', 'cssc_peek64',
    'cssc_poke8', 'cssc_poke16', 'cssc_poke32', 'cssc_poke64',
    'cssc_band', 'cssc_bor', 'cssc_bxor', 'cssc_shl', 'cssc_shr',
    'cssc_fadd', 'cssc_fsub', 'cssc_fmul', 'cssc_fdiv', 'cssc_fmod_',
    'cssc_fneg', 'cssc_fcmp', 'cssc_i2f', 'cssc_f2i', 'cssc_fabs',
    'cssc_fsqrt', 'cssc_ffloor', 'cssc_fceil', 'cssc_ftrunc', 'cssc_fround',
    'cssc_f2str', 'cssc_str2f',
    'cssc_outb', 'cssc_outw', 'cssc_outl',
    'cssc_inb', 'cssc_inw', 'cssc_inl',
    'cssc_fb_addr', 'cssc_fb_width', 'cssc_fb_height',
    'cssc_fb_pitch', 'cssc_fb_bpp',
    'cssc_host_read', 'cssc_host_write',
    # gui:: retro-glass framework — bodies in cssc_host_gui.c (companion .o).
    'cssc_gui_screen_new', 'cssc_gui_screen_clear', 'cssc_gui_screen_present',
    'cssc_gui_screen_isopen', 'cssc_gui_screen_close', 'cssc_gui_screen_update',
    'cssc_gui_screen_render', 'cssc_gui_screen_width', 'cssc_gui_screen_height',
    'cssc_gui_screen_add', 'cssc_gui_screen_mousex', 'cssc_gui_screen_mousey',
    'cssc_gui_screen_mousedown',
    'cssc_gui_screen_pollchar', 'cssc_gui_screen_pollkey', 'cssc_gui_screen_wheel',
    'cssc_gui_screen_fillrect', 'cssc_gui_screen_drawrect', 'cssc_gui_screen_drawtext',
    'cssc_gui_font_new', 'cssc_gui_font_setscale', 'cssc_gui_font_scale',
    'cssc_gui_font_setcolor', 'cssc_gui_font_color', 'cssc_gui_font_measure',
    'cssc_gui_font_height',
    'cssc_gui_text_new', 'cssc_gui_text_settext', 'cssc_gui_text_text',
    'cssc_gui_text_setpos', 'cssc_gui_text_x', 'cssc_gui_text_y',
    'cssc_gui_text_setcolor', 'cssc_gui_text_setscale', 'cssc_gui_text_setfont',
    'cssc_gui_text_measure', 'cssc_gui_text_draw', 'cssc_gui_text_hide',
    'cssc_gui_text_show',
    'cssc_gui_button_new', 'cssc_gui_button_setlabel', 'cssc_gui_button_label',
    'cssc_gui_button_setrect', 'cssc_gui_button_position', 'cssc_gui_button_size',
    'cssc_gui_button_setcolor', 'cssc_gui_button_sethovercolor',
    'cssc_gui_button_settextcolor', 'cssc_gui_button_onclick',
    'cssc_gui_button_update', 'cssc_gui_button_ishovered',
    'cssc_gui_button_ispressed', 'cssc_gui_button_draw', 'cssc_gui_button_hide',
    'cssc_gui_button_show',
    'cssc_gui_toolbar_new', 'cssc_gui_toolbar_add', 'cssc_gui_toolbar_setpos',
    'cssc_gui_toolbar_setsize', 'cssc_gui_toolbar_setorientation',
    'cssc_gui_toolbar_setspacing', 'cssc_gui_toolbar_update',
    'cssc_gui_toolbar_draw',
    'cssc_gui_textbox_new', 'cssc_gui_textbox_setrect', 'cssc_gui_textbox_settext',
    'cssc_gui_textbox_text', 'cssc_gui_textbox_length', 'cssc_gui_textbox_setfocus',
    'cssc_gui_textbox_focused', 'cssc_gui_textbox_setcolor', 'cssc_gui_textbox_setscale',
    'cssc_gui_textbox_update', 'cssc_gui_textbox_draw',
    'cssc_gui_editor_new', 'cssc_gui_editor_setrect', 'cssc_gui_editor_settext',
    'cssc_gui_editor_text', 'cssc_gui_editor_linecount', 'cssc_gui_editor_cursorline',
    'cssc_gui_editor_cursorcol', 'cssc_gui_editor_gotoline', 'cssc_gui_editor_setfocus',
    'cssc_gui_editor_setscale', 'cssc_gui_editor_setcolor', 'cssc_gui_editor_setgutter',
    'cssc_gui_editor_update', 'cssc_gui_editor_draw',
    'cssc_gui_list_new', 'cssc_gui_list_setrect', 'cssc_gui_list_add',
    'cssc_gui_list_addat', 'cssc_gui_list_clear', 'cssc_gui_list_count',
    'cssc_gui_list_selected', 'cssc_gui_list_selectedtext', 'cssc_gui_list_setselected',
    'cssc_gui_list_setfocus', 'cssc_gui_list_setscale', 'cssc_gui_list_setcolor',
    'cssc_gui_list_update', 'cssc_gui_list_draw',
})


def supported_symbols() -> Set[str]:
    """Return the set of runtime symbol names Transembly can emit.

    Extended with `_COMPANION_RUNTIME_SYMBOLS` — externals provided by
    the linked companion .o files (cssc_host_extras.c / cssc_math_accel.c
    / cssc_ini.c). Transembly doesn't emit their bodies (that's the
    companion compile step's job), but it accepts them as valid
    externals so the "unknown symbol" gate doesn't fire.
    """
    all_syms = set(_SYMBOL_EMITTERS.keys())
    for syms, _emit in _GROUP_EMITTERS.values():
        all_syms |= syms
    all_syms |= _COMPANION_RUNTIME_SYMBOLS
    return all_syms


def emit_runtime_ll(symbols: Iterable[str],
                    target_triple: Optional[str] = None,
                    module_id: str = 'cssc_runtime',
                    runtime_profile: str = 'host',
                    *, internal_linkage: bool = False) -> str:
    """Emit the LLVM IR for the requested runtime symbols.

    `symbols` is the set of `cssc_*` names referenced by the user module.
    The init/shutdown pair is always included (the main-shim references
    them unconditionally).

    `runtime_profile` switches the underlying I/O / allocator backing:
      * 'host'    : libc printf + malloc — the default for x86_64 /
                    Linux / macOS / Pi (Pi runs Linux).
      * 'esp8266' : UART-register direct writes for output, static
                    bump allocator for malloc. No libc dependency.
      * 'esp32'   : same shape as esp8266 but for the LX7 UART layout.
      * 'avr'     : Arduino Serial output via AVR USART registers,
                    minimal SRAM bump allocator.

    Symbols outside the supported set raise RuntimeError — no silent
    skip, no TODO. The caller (v6_driver) sees the missing-feature
    explicitly.
    """
    triple = target_triple or default_target_triple()
    if runtime_profile != 'host':
        # Embedded profile: hand off to the bare-metal emitter family.
        # That module mirrors the symbol set but routes output to UART
        # registers and replaces malloc with a static bump allocator.
        return _emit_baremetal_runtime_ll(
            symbols, triple, module_id, runtime_profile,
        )

    requested = set(symbols)
    # init/shutdown are always linked in (main-shim calls them).
    requested.add('cssc_runtime_init')
    requested.add('cssc_runtime_shutdown')
    # Process-startup state is always emitted because the main shim
    # references @cssc_argc / @cssc_argv / @cssc_sysout_value
    # unconditionally — adding 'cssc_sysout' as a marker pulls the whole
    # group via the grouped-emitter pass below.
    requested.add('cssc_sysout')

    # Soft-float / soft-int / soft-mul libgcc helpers (`__divsi3`,
    # `__muldf3`, `__extendsfdf2`, `__truncdfsf2`, `__floatsidf`,
    # `__fixdfsi`, etc.) are normally provided by clang's compiler-rt
    # at link time. On Windows the lld driver does *not* implicitly
    # pull `libclang_rt.builtins-x86_64.lib`, so f32↔f64 conversions
    # would fail to link. The two thunks user code actually triggers
    # (`__truncdfsf2`, `__extendsfdf2`) ship as hardware shims via
    # `_SYMBOL_EMITTERS`; they only get emitted when the user module
    # actually references them. Strip the remaining `__*` libgcc
    # thunks from the missing-set check so the host build never
    # spuriously flags them.
    requested_for_check = {s for s in requested if not s.startswith('__')}
    missing = requested_for_check - supported_symbols()
    if missing:
        raise RuntimeError(
            f"Transembly Phase 1: runtime symbols not implemented yet: "
            f"{sorted(missing)}. They land in Phase 2+ — see "
            f"includecpp/core/cssl/native/CSSC_V6_NATIVE_PLAN.md"
        )

    out: List[str] = []
    out.append(f"; ModuleID = '{module_id}'")
    out.append(f'source_filename = "<transembly-{module_id}>"')
    out.append(f'target triple = "{triple}"')
    out.append('')

    # libc / msvcrt declarations always needed
    out.append('declare i32 @printf(ptr, ...)')
    out.append('')

    # Format-string globals — emit those we actually need.
    if 'cssc_print_int' in requested:
        out.append(_fmt_int())
    if 'cssc_print_float' in requested:
        out.append(_fmt_float())
    if 'cssc_print_bool' in requested:
        out.append(_fmt_true())
        out.append(_fmt_false())
    out.append('')

    # Cross-group runtime dependency: the array_bind group emits
    # `cssc_bind_entry_as_string`, which calls the scalar stringify helpers
    # (cssc_int_to_str / cssc_float_to_str / cssc_bool_to_str) UNCONDITIONALLY
    # as part of its IR body. Those live in the `stringify` group, whose
    # symbols the user module may not reference directly — so pull that group
    # whenever the bind group is emitted, or clang sees undefined values.
    # `cssc_sys_argv` builds an array_bind of string cells from argv, so it
    # needs the array_bind runtime group AND the startup shim (which defines
    # @cssc_argc / @cssc_argv). Pull both whenever it is referenced.
    if requested & _SYS_ARGV_SYMBOLS:
        requested = requested | _ARRAY_BIND_SYMBOLS
        requested = requested | _STARTUP_SYMBOLS | _STARTUP_SYSARG_SYMBOLS
    if requested & _ARRAY_BIND_SYMBOLS:
        requested = requested | _STRINGIFY_SYMBOLS
        # `cssc_bind_entry_free` now recurses into nested-container cells:
        # tag-7 map_si cells are torn down via `cssc_map_si_free`, so the
        # map_si group must be present whenever the array_bind group is (a
        # nested array<auto> map cell would otherwise leave it undefined).
        requested = requested | _MAP_SI_SYMBOLS
        # `cssc_bind_entry_as_string` now recurses into tag-6/7 cells via the
        # faithful Python-repr runtime, so it must always be present too.
        requested = requested | _CONTAINER_REPR_SYMBOLS
    if requested & _CONTAINER_REPR_SYMBOLS:
        # The repr runtime calls the scalar stringify helpers, the string
        # runtime (lit/concat/data/size/release), the array_bind cell
        # accessors and the map_si bucket readers.
        requested = requested | _STRINGIFY_SYMBOLS | _STRING_SYMBOLS
        requested = requested | _ARRAY_BIND_SYMBOLS | _MAP_SI_SYMBOLS

    # Resolve grouped emitters: if any of a group's symbols are requested,
    # emit the entire group once. Removes those from the individual loop.
    pending = set(requested)
    grouped_lines: List[str] = []
    for group_name, (group_syms, group_emit) in _GROUP_EMITTERS.items():
        if pending & group_syms:
            grouped_lines.extend(group_emit())
            grouped_lines.append('')
            pending -= group_syms

    # Strip libgcc / compiler-rt thunks that we DON'T ship a definition
    # for. The two we do define (`__truncdfsf2`, `__extendsfdf2` — host
    # hardware shims that bypass Windows lld's missing-compiler-rt
    # behaviour) are listed in `_SYMBOL_EMITTERS`, so we keep any `__*`
    # symbol that has a registered emitter. Everything else is left to
    # the link-time resolver.
    pending = {s for s in pending
               if not s.startswith('__') or s in _SYMBOL_EMITTERS}

    # Companion-runtime symbols (host_extras / math_accel / ini) live in
    # separately compiled .o files and don't have transembly emitters.
    # They're recognised as valid externals but no body is emitted here —
    # the link step resolves them against the companion .o.
    pending -= _COMPANION_RUNTIME_SYMBOLS

    for sym in sorted(pending):
        out.extend(_SYMBOL_EMITTERS[sym]())
        out.append('')

    # Append grouped emitters last (they declare shared types/externs).
    out.extend(grouped_lines)

    result = _dedupe_declares('\n'.join(out) + '\n')
    result = _apply_runtime_define_attrs(result)
    if internal_linkage:
        result = _apply_internal_linkage(result)
    return result


# Runtime-side mirror of `cir_to_llvm._runtime_declare_attrs`. Keep the
# two tables in sync — the mid-tier optimiser only trusts attributes it
# sees on BOTH the declare (user.ll side) AND the define (runtime.ll
# side); a mismatch keeps LLVM's conservative behaviour on the module
# where the attribute is missing.
_RUNTIME_DEFINE_ATTRS = {
    'cssc_runtime_init':     'nounwind willreturn memory(inaccessiblemem: readwrite)',
    'cssc_runtime_shutdown': 'nounwind willreturn memory(inaccessiblemem: readwrite)',
    'cssc_scope_push':       'nounwind willreturn memory(inaccessiblemem: readwrite)',
    'cssc_scope_pop':        'nounwind willreturn memory(inaccessiblemem: readwrite)',
    'cssc_sqrt':             'readnone nounwind willreturn',
    'cssc_random':           'nounwind willreturn memory(inaccessiblemem: readwrite)',
    'cssc_random_int':       'nounwind willreturn memory(inaccessiblemem: readwrite)',
    'cssc_rng_next':         'nounwind willreturn memory(inaccessiblemem: readwrite)',
    'cssc_uptime':           'nounwind willreturn memory(inaccessiblemem: readwrite)',
    'cssc_tick':             'nounwind willreturn memory(inaccessiblemem: readwrite)',
    'cssc_sleep_ms':         'nounwind willreturn memory(inaccessiblemem: readwrite)',
    'cssc_time_init':        'nounwind willreturn memory(inaccessiblemem: readwrite)',
    'cssc_load_i64_at':      'readonly nounwind willreturn',
    'cssc_string_size':      'readonly nounwind willreturn',
    'cssc_print_int':        'nounwind willreturn memory(argmem: read, inaccessiblemem: readwrite)',
    'cssc_print_float':      'nounwind willreturn memory(argmem: read, inaccessiblemem: readwrite)',
    'cssc_print_bool':       'nounwind willreturn memory(argmem: read, inaccessiblemem: readwrite)',
    'cssc_print_str':        'nounwind willreturn memory(argmem: read, inaccessiblemem: readwrite)',
    'cssc_print_string':     'nounwind willreturn memory(argmem: read, inaccessiblemem: readwrite)',
    'cssc_print_newline':    'nounwind willreturn memory(inaccessiblemem: readwrite)',
    'cssc_out_int':          'nounwind willreturn memory(argmem: read, inaccessiblemem: readwrite)',
    'cssc_out_float':        'nounwind willreturn memory(argmem: read, inaccessiblemem: readwrite)',
    'cssc_out_bool':         'nounwind willreturn memory(argmem: read, inaccessiblemem: readwrite)',
    'cssc_out_str':          'nounwind willreturn memory(argmem: read, inaccessiblemem: readwrite)',
    'cssc_out_string':       'nounwind willreturn memory(argmem: read, inaccessiblemem: readwrite)',
    'cssc_panic':            'noreturn nounwind',
    '__truncdfsf2':          'readnone nounwind willreturn',
    '__extendsfdf2':         'readnone nounwind willreturn',
}


def _apply_runtime_define_attrs(text: str) -> str:
    """Splice LLVM function attributes into each `define <ret> @<sym>(...)`
    header for symbols listed in `_RUNTIME_DEFINE_ATTRS`. Idempotent —
    a header already carrying the attribute string is left untouched.

    Format after splicing (attributes go BETWEEN the parameter list's
    closing paren and the body-opening brace, per LLVM IR grammar):
        define void @cssc_runtime_init() nounwind willreturn {
    Placing them before the return type parses as return-value
    attributes and is rejected by clang / opt. Only touches lines that
    start with `define ` and contain both `(` and `)` — declarations,
    comments, and body lines are pass-through.
    """
    if not _RUNTIME_DEFINE_ATTRS:
        return text
    lines = text.split('\n')
    out_lines: List[str] = []
    for line in lines:
        stripped = line.lstrip()
        if not stripped.startswith('define '):
            out_lines.append(line)
            continue
        sym = _extract_define_symbol(stripped)
        if sym is None:
            out_lines.append(line)
            continue
        attrs = _RUNTIME_DEFINE_ATTRS.get(sym)
        if not attrs:
            out_lines.append(line)
            continue
        # Find the parameter list's closing paren. LLVM permits nested
        # parens in the sig only inside type expressions we don't emit
        # from these helpers, so a simple rfind on the first `{` guard
        # works.
        brace_idx = line.find('{')
        if brace_idx < 0:
            # `define ...` line without body-brace (should not happen
            # in our emitters, but bail defensively).
            out_lines.append(line)
            continue
        # Walk left from the brace to the matching `)` that closes the
        # parameter list.
        close_paren = line.rfind(')', 0, brace_idx)
        if close_paren < 0:
            out_lines.append(line)
            continue
        # Skip idempotent: attrs already present between paren and brace.
        between = line[close_paren + 1:brace_idx]
        first_attr_token = attrs.split()[0]
        if first_attr_token in between:
            out_lines.append(line)
            continue
        line = (line[:close_paren + 1]
                + ' ' + attrs
                + line[close_paren + 1:])
        out_lines.append(line)
    return '\n'.join(out_lines)


_KEEP_EXTERNAL_RUNTIME = frozenset({
    'cssc_runtime_init',
    'cssc_runtime_shutdown',
    'cssc_argc',
    'cssc_argv',
    'cssc_sysout_value',
})


def _apply_internal_linkage(text: str) -> str:
    """Prefix every non-main-referenced `define` with `internal `.

    Skips the small set of symbols that the main-shim references
    directly (`cssc_runtime_init`, `cssc_runtime_shutdown`) plus the
    three globals bound at process start. Everything else in the
    runtime module gets internal linkage — when user.o and runtime.o
    are linked in one clang invocation, this lets `--gc-sections`
    strip anything the user code doesn't reach without ambiguity.

    Idempotent: a `define internal ...` line is left untouched.
    """
    lines = text.split('\n')
    out: List[str] = []
    for line in lines:
        stripped = line.lstrip()
        if stripped.startswith('define ') and ' internal ' not in stripped:
            sym = _extract_define_symbol(stripped)
            if sym is not None and sym not in _KEEP_EXTERNAL_RUNTIME:
                idx = line.index('define ') + len('define ')
                line = line[:idx] + 'internal ' + line[idx:]
        elif stripped.startswith('@') and '=' in stripped and 'global ' in stripped:
            head = stripped.split('=', 1)[0].strip()
            if head.startswith('@'):
                gsym = head[1:].strip()
                if (gsym not in _KEEP_EXTERNAL_RUNTIME
                        and ' internal ' not in stripped
                        and ' private ' not in stripped
                        and ' external ' not in stripped):
                    line = line.replace('= global ', '= internal global ')
        out.append(line)
    return '\n'.join(out)


def _extract_define_symbol(define_line: str) -> Optional[str]:
    idx = define_line.find('@')
    if idx < 0:
        return None
    end = idx + 1
    while end < len(define_line) and (define_line[end].isalnum()
                                        or define_line[end] in '_.'):
        end += 1
    return define_line[idx + 1:end] if end > idx + 1 else None


# Dedupe declarations (functions, globals, named struct types). LLVM rejects
# duplicate `declare @foo` / `%T = type ...` / `@g = external global ...` lines
# even when signatures match. We key each by the named symbol and replace
# subsequent occurrences with an elision comment to keep the IR valid.
def _dedupe_declares(text: str) -> str:
    seen: set = set()
    out_lines: List[str] = []
    for line in text.split('\n'):
        stripped = line.strip()
        key = _decl_key(stripped)
        if key is not None:
            if key in seen:
                out_lines.append(f'; dup-declare elided: {key}')
                continue
            seen.add(key)
        out_lines.append(line)
    return '\n'.join(out_lines)


def _decl_key(stripped: str):
    """Return a hashable key for a module-level declaration line, or None
    if `stripped` is not a declaration."""
    if not stripped or stripped.startswith(';'):
        return None
    if stripped.startswith('declare '):
        # Key is the function name token between `@` and `(`.
        at = stripped.find('@')
        if at < 0:
            return None
        end = stripped.find('(', at)
        return ('declare', stripped[at:end] if end > 0 else stripped[at:])
    if stripped.startswith('@'):
        eq = stripped.find('=')
        if eq < 0:
            return None
        return ('global', stripped[:eq].strip())
    if stripped.startswith('%') and ' = type ' in stripped:
        eq = stripped.find('=')
        return ('type', stripped[:eq].strip())
    return None


# ---------------------------------------------------------------------------
# Phase 5: bare-metal runtime profile.
# ---------------------------------------------------------------------------
# Embedded targets (ESP8266 / ESP32 / Arduino) don't have libc — no printf,
# no malloc. The runtime functions still keep their signatures, but their
# bodies write directly to UART hardware and allocate from a static
# bump-allocator pool inside .bss.
#
# Per-target UART register addresses + bump-pool sizes are picked from
# `_BAREMETAL_PROFILES`. The IR is freestanding: no libc declarations,
# no platform-specific stdio shims. The user's compiled module links
# only against these runtime symbols.
# ---------------------------------------------------------------------------
_BAREMETAL_PROFILES = {
    # ESP8266 NodeMCU / Wemos D1: UART0 TX FIFO at 0x60000000, status
    # register at 0x6000001C; 64 KB heap pool is a safe default that
    # leaves room for the WiFi MAC fixed-cost on production boards.
    'esp8266': {
        'uart_tx_addr':   0x60000000,
        'uart_stat_addr': 0x6000001C,
        'uart_stat_mask': 0x00FF0000,    # TX FIFO count bits
        'uart_stat_full': 0x00080000,    # 128-byte FIFO threshold
        'heap_pool_size': 65536,
    },
    'esp32': {
        # ESP32-S3 UART0 TX FIFO @ 0x60000000 (same as legacy ESP8266
        # base — the Espressif memory map keeps UART0 at a stable
        # address across ESP8266 / ESP32 / ESP32-S2 / ESP32-S3).
        'uart_tx_addr':   0x60000000,
        'uart_stat_addr': 0x6000001C,
        'uart_stat_mask': 0x00FF0000,
        'uart_stat_full': 0x00080000,
        'heap_pool_size': 262144,
    },
    'avr': {
        # ATmega328P UDR0 at 0xC6, UCSR0A at 0xC0 (status, bit 5 = UDRE0).
        # The runtime emits writes through these — but AVR uses a 16-bit
        # address space with `inout` instructions in real asm; LLVM IR
        # represents them as memory loads/stores to the I/O addresses.
        'uart_tx_addr':   0xC6,
        'uart_stat_addr': 0xC0,
        'uart_stat_mask': 0x20,            # UDRE0 bit
        'uart_stat_full': 0x20,
        'heap_pool_size': 1536,            # 2 KB SRAM - stack reservation
    },
}


def _emit_baremetal_runtime_ll(symbols: Iterable[str], triple: str,
                               module_id: str,
                               profile_name: str) -> str:
    """Emit a freestanding LLVM IR runtime module for embedded targets.

    The set of supported symbols mirrors the host runtime — same names,
    same signatures — so user code compiled with `runtime_profile='host'`
    and `runtime_profile='esp8266'` is identical. Only the bodies differ.

    Supported on bare-metal in Phase 5a:
      cssc_runtime_init        — no-op (UART is assumed pre-configured by
                                  the boot stub that the linker provides)
      cssc_runtime_shutdown    — spin-loop hlt-equivalent
      cssc_print_int(i64)      — writes ASCII decimal to UART TX FIFO
      cssc_print_bool(i1)      — writes "true"/"false"
      cssc_obj_alloc(i64)      — bump-allocator out of the static pool
      cssc_obj_free(ptr)       — no-op (no per-block free; the pool is
                                  reset on `cssc_runtime_shutdown` in
                                  long-running embedded loops)

    Unsupported on bare-metal (would need additional work — typically a
    full malloc/free, file I/O, libc strings, etc.):
      cssc_print_float, cssc_print_string, cssc_print_str, cssc_panic,
      cssc_vector_*, cssc_map_si_*, cssc_bind_ss_*, cssc_string_*.
    """
    if profile_name not in _BAREMETAL_PROFILES:
        raise RuntimeError(
            f"Transembly: bare-metal profile {profile_name!r} not registered. "
            f"Available: {sorted(_BAREMETAL_PROFILES.keys())}"
        )
    profile = _BAREMETAL_PROFILES[profile_name]

    requested = set(symbols)
    requested.add('cssc_runtime_init')
    requested.add('cssc_runtime_shutdown')

    # Delegate to the dedicated bare-metal emitter — it owns the full
    # symbol surface (string ops, time, stringify, peripherals, …) and
    # the per-target tweaks (UART TX FIFO addresses, arena sizes).
    from .embedded import (
        emit_runtime_ll as _bm_emit,
        supported_baremetal_symbols as _bm_supported,
    )
    supported = _bm_supported()
    missing = requested - supported
    if missing:
        raise RuntimeError(
            f"Transembly bare-metal ({profile_name}): runtime symbol(s) "
            f"{sorted(missing)} need a bare-metal port. The dedicated "
            f"bare-metal emitter ({len(supported)} symbols) covers the "
            f"common surface — file an issue for the missing one."
        )
    return _bm_emit(symbols, triple, module_id, profile_name)

    pool_size = profile['heap_pool_size']
    tx_addr   = profile['uart_tx_addr']
    out: List[str] = []
    out.append(f"; ModuleID = '{module_id}-{profile_name}'")
    out.append(f'source_filename = "<transembly-bare-{profile_name}>"')
    out.append(f'target triple = "{triple}"')
    out.append('')
    out.append(f'; --- Bare-metal runtime for {profile_name} (Phase 5) ---')
    out.append(f'; UART TX FIFO @ {hex(tx_addr)}, heap pool: {pool_size} bytes.')
    out.append('')
    # Static bump-allocator pool. Placed in .bss so the boot stub zero-
    # initialises it; no special section attribute — let lld place it.
    out.append(f'@cssc_heap_pool = internal global [{pool_size} x i8] zeroinitializer, align 8')
    out.append(f'@cssc_heap_offset = internal global i64 0, align 8')
    out.append('')

    # cssc_runtime_init: no-op. The boot stub is expected to configure
    # the UART + zero .bss before calling main().
    out += [
        'define void @cssc_runtime_init() {',
        'entry:',
        '  ret void',
        '}',
        '',
    ]

    # cssc_runtime_shutdown: spin forever — there is no OS to exit to.
    out += [
        'define void @cssc_runtime_shutdown() {',
        'entry:',
        '  br label %spin',
        'spin:',
        '  br label %spin',
        '}',
        '',
    ]

    if 'cssc_print_int' in requested:
        out += _baremetal_print_int(tx_addr)
    if 'cssc_print_bool' in requested:
        out += _baremetal_print_bool(tx_addr)
    if 'cssc_obj_alloc' in requested:
        out += _baremetal_obj_alloc(pool_size)
    if 'cssc_obj_free' in requested:
        out += [
            'define void @cssc_obj_free(ptr %p) {',
            'entry:',
            '  ; bump allocator — per-block free is a no-op in Phase 5a.',
            '  ret void',
            '}',
            '',
        ]

    return _dedupe_declares('\n'.join(out) + '\n')


def _baremetal_uart_write_byte(tx_addr: int) -> List[str]:
    """Helper: a `cssc_uart_putc(i8)` function that writes one byte to
    the UART TX FIFO. Called from print_int / print_bool / future
    print_str."""
    return [
        'define void @cssc_uart_putc(i8 %c) {',
        'entry:',
       f'  store volatile i8 %c, ptr inttoptr (i64 {tx_addr} to ptr), align 1',
        '  ret void',
        '}',
        '',
    ]


def _baremetal_print_int(tx_addr: int) -> List[str]:
    """Print a signed i64 as ASCII decimal followed by '\\n' to UART.

    Buffer-on-stack approach: convert the integer into a 24-byte stack
    buffer right-to-left, then emit each digit through cssc_uart_putc.
    For negative numbers we emit '-' first and negate.
    """
    return _baremetal_uart_write_byte(tx_addr) + [
        'define void @cssc_print_int(i64 %n) {',
        'entry:',
        '  %buf = alloca [24 x i8], align 1',
        '  %neg = icmp slt i64 %n, 0',
        '  br i1 %neg, label %do.neg, label %abs',
        'do.neg:',
        '  call void @cssc_uart_putc(i8 45)',     # '-'
        '  %nabs = sub i64 0, %n',
        '  br label %abs',
        'abs:',
        '  %v0 = phi i64 [ %n, %entry ], [ %nabs, %do.neg ]',
        '  br label %loop',
        'loop:',
        '  %i  = phi i64 [ 0,    %abs ], [ %i.next, %loop_body ]',
        '  %v  = phi i64 [ %v0,  %abs ], [ %v.next, %loop_body ]',
        '  %done = icmp eq i64 %v, 0',
        '  %first = icmp eq i64 %i, 0',
        '  %stop = and i1 %done, %first',
        '  br i1 %stop, label %zero, label %loop_step',
        'loop_step:',
        '  %any_done = icmp eq i64 %v, 0',
        '  br i1 %any_done, label %emit, label %loop_body',
        'loop_body:',
        '  %d = urem i64 %v, 10',
        '  %v.next = udiv i64 %v, 10',
        '  %d8 = trunc i64 %d to i8',
        '  %digit = add i8 %d8, 48',                    # '0' + d
        '  %slot = getelementptr inbounds [24 x i8], ptr %buf, i64 0, i64 %i',
        '  store i8 %digit, ptr %slot, align 1',
        '  %i.next = add i64 %i, 1',
        '  br label %loop',
        'zero:',
        '  call void @cssc_uart_putc(i8 48)',     # '0'
        '  br label %newline',
        'emit:',
        '  br label %emit_loop',
        'emit_loop:',
        '  %j = phi i64 [ %i, %emit ], [ %j.next, %emit_step ]',
        '  %j_done = icmp eq i64 %j, 0',
        '  br i1 %j_done, label %newline, label %emit_step',
        'emit_step:',
        '  %j.next = sub i64 %j, 1',
        '  %eslot = getelementptr inbounds [24 x i8], ptr %buf, i64 0, i64 %j.next',
        '  %ec = load i8, ptr %eslot, align 1',
        '  call void @cssc_uart_putc(i8 %ec)',
        '  br label %emit_loop',
        'newline:',
        '  call void @cssc_uart_putc(i8 10)',    # '\n'
        '  ret void',
        '}',
        '',
    ]


def _baremetal_print_bool(tx_addr: int) -> List[str]:
    """Print 'true' or 'false' followed by '\\n' to UART."""
    return [
        '@.cssc_bare_true  = private unnamed_addr constant [5 x i8] c"true\\0A"',
        '@.cssc_bare_false = private unnamed_addr constant [6 x i8] c"false\\0A"',
        '',
        'define void @cssc_print_bool(i1 %b) {',
        'entry:',
        '  br i1 %b, label %yes, label %no',
        'yes:',
        '  %tp = getelementptr inbounds [5 x i8], ptr @.cssc_bare_true, i64 0, i64 0',
        '  call void @cssc_bare_print(ptr %tp, i64 5)',
        '  ret void',
        'no:',
        '  %fp = getelementptr inbounds [6 x i8], ptr @.cssc_bare_false, i64 0, i64 0',
        '  call void @cssc_bare_print(ptr %fp, i64 6)',
        '  ret void',
        '}',
        '',
        'define internal void @cssc_bare_print(ptr %s, i64 %len) {',
        'entry:',
        '  br label %loop',
        'loop:',
        '  %i = phi i64 [ 0, %entry ], [ %i.next, %step ]',
        '  %done = icmp uge i64 %i, %len',
        '  br i1 %done, label %end, label %step',
        'step:',
        '  %p = getelementptr inbounds i8, ptr %s, i64 %i',
        '  %c = load i8, ptr %p, align 1',
        '  call void @cssc_uart_putc(i8 %c)',
        '  %i.next = add i64 %i, 1',
        '  br label %loop',
        'end:',
        '  ret void',
        '}',
        '',
    ]


def _baremetal_obj_alloc(pool_size: int) -> List[str]:
    """Bump allocator out of @cssc_heap_pool, size capped by pool_size."""
    return [
        'define ptr @cssc_obj_alloc(i64 %size) {',
        'entry:',
        '  ; align size up to 8 bytes',
        '  %add = add i64 %size, 7',
        '  %asz = and i64 %add, -8',
        '  %off = load i64, ptr @cssc_heap_offset, align 8',
        '  %new = add i64 %off, %asz',
       f'  %oom = icmp ugt i64 %new, {pool_size}',
        '  br i1 %oom, label %fail, label %ok',
        'fail:',
        '  ret ptr null',                # caller checks; Phase 5b adds panic
        'ok:',
        '  store i64 %new, ptr @cssc_heap_offset, align 8',
        '  %base = getelementptr inbounds i8, ptr @cssc_heap_pool, i64 %off',
        '  ret ptr %base',
        '}',
        '',
    ]


__all__ = ['emit_runtime_ll', 'supported_symbols', 'default_target_triple']
