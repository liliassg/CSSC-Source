"""Freestanding x86-64 Transembly runtime — CCOS bare-metal target.

The `ccos` target's CSSC runtime and Limine boot glue live in two freestanding
C companion objects compiled and linked by the v6 driver
(`cssc_ccos_rt.c` — serial console, bump arena, strings, printers, and the
port-I/O / MMIO / privileged-instruction intrinsics; `cssc_ccos_boot.c` — the
`kmain` ELF entry, the Limine request structs, and the framebuffer / HHDM /
memmap accessors). This mirrors the `cssc_softfloat.c` (AVR) and
`cssc_host_game.c` (host) companion-object pattern: clang compiles the inline
assembly correctly and the `cssc_str` ABI is expressed once in C, matching the
host emitter's `{ i32 refcount, i32 size, [0 x i8] data }` layout.

This module therefore emits only a minimal runtime IR module (the driver's
`user.ll` / `runtime.ll` codegen flow always expects a runtime module) and
exposes the companion-source and linker-script paths that `_link_ccos`
consumes.
"""
from __future__ import annotations

from pathlib import Path
from typing import Iterable

_HERE = Path(__file__).resolve().parent
    

def runtime_c_source() -> Path:
    """Freestanding CSSC runtime (serial, strings, printers, intrinsics)."""
    return _HERE / 'cssc_ccos_rt.c'


def mem_c_source() -> Path:
    """Memory management (frame allocator + kernel heap, Phase 2)."""
    return _HERE / 'cssc_ccos_mem.c'


def companion_c_sources() -> list:
    """All freestanding C companion sources, in link order."""
    return [boot_c_source(), runtime_c_source(), mem_c_source()]


def boot_c_source() -> Path:
    """Limine boot companion (kmain entry, requests, hand-off accessors)."""
    return _HERE / 'cssc_ccos_boot.c'


def linker_script() -> Path:
    """Higher-half kernel linker script."""
    return _HERE / 'ccos.ld'


def emit_runtime_ll(symbols: Iterable[str],
                    target_triple: str,
                    module_id: str = 'cssc_runtime_ccos') -> str:
    """Return the freestanding runtime IR module.

    The real runtime is compiled from `cssc_ccos_rt.c` and linked as a
    companion object, so this IR module is intentionally empty bar the
    header — the driver's `runtime.ll` -> `runtime.o` step yields a valid,
    symbol-free object that contributes nothing to the link.
    """
    # `symbols` is accepted for signature parity with the host / embedded
    # emitters; the C companion provides every runtime symbol.
    _ = list(symbols)
    return (
        f"; ModuleID = '{module_id}'\n"
        f'source_filename = "<transembly-freestanding-ccos>"\n'
        f'target triple = "{target_triple}"\n'
    )


__all__ = [
    'emit_runtime_ll',
    'runtime_c_source',
    'boot_c_source',
    'linker_script',
]
