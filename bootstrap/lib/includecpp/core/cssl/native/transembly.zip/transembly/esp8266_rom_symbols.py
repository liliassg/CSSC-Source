"""ESP8266 ROM symbol table — addresses → function/data names.

When the chip crashes at an `epc1` (program counter) value somewhere in
the boot ROM region (0x40000000..0x40010000), there is no debug info in
our `.elf` for it — those bytes live on the chip itself, not in our
build artefact. Without a symbol table, the diagnostics tool can only
say "epc1 is somewhere in ROM"; with one, it can say "epc1 is inside
`boot_from_flash` at offset +0x4F8, two bytes after a `l8ui` near a
known data-load loop".

The data here is **transcribed verbatim** from Espressif's official
[`eagle.rom.addr.v6.ld`](https://github.com/espressif/ESP8266_NONOS_SDK/blob/master/ld/eagle.rom.addr.v6.ld)
linker script (also shipped in PlatformIO's
`framework-arduinoespressif8266/tools/sdk/ld/`). The ESP8266 ROM has
been frozen since the chip's 2013 tape-out — these addresses don't
change between SDK releases.

Two tables:
  * `_CODE_SYMS` — 339 function entry points in the IROM range
    0x40000080..0x4000e388.
  * `_DATA_SYMS` — 9 well-known data tables in the DRAM range
    0x3fffc000..0x3fffde10 (`UartDev`, `flashchip`, exception handler
    tables, etc.).

Both are sorted by address for O(log n) binary-search lookup.

Helpers exposed:
  * `resolve_rom_addr(addr)` — given any address in the ROM code or
    data range, returns `(symbol_name, offset_into_symbol)` or None.
  * `is_rom_addr(addr)` — bool, useful for routing PC values to either
    addr2line (user `.elf`) or this map.

Example:
    >>> from .esp8266_rom_symbols import resolve_rom_addr
    >>> resolve_rom_addr(0x40001800)
    ('boot_from_flash', 0x4F8)
    >>> resolve_rom_addr(0x40004678)
    ('Cache_Read_Enable', 0)
    >>> resolve_rom_addr(0x40000000)  # below first symbol → None
    None
"""
from __future__ import annotations

import bisect
from typing import Optional, Tuple


# Address ranges where the ROM symbols live. Use these to decide whether
# an address belongs to the ROM (look it up here) or to the user image
# (look it up via addr2line against the linked `.elf`).
ROM_CODE_LO: int = 0x40000000
ROM_CODE_HI: int = 0x40010000     # exclusive — IROM ends here, IRAM starts at 0x40100000
ROM_DATA_LO: int = 0x3fffc000
ROM_DATA_HI: int = 0x3fffe000     # exclusive — covers the documented data tables


def is_rom_addr(addr: int) -> bool:
    """True if `addr` falls in the ESP8266 ROM code or data range.

    The user-program lives in IRAM/IROM from 0x40100000 upwards on
    ESP8266; the ROM ends at 0x40010000. Addresses between
    0x40010000..0x401fffff are unmapped on a standard ESP8266 image
    and would themselves indicate a wild jump.
    """
    return (ROM_CODE_LO <= addr < ROM_CODE_HI
            or ROM_DATA_LO <= addr < ROM_DATA_HI)


def resolve_rom_addr(addr: int) -> Optional[Tuple[str, int]]:
    """Return `(symbol, offset)` for any address inside a known ROM
    function/data block.

    Lookup strategy: binary-search the sorted table for the largest
    symbol address ≤ `addr`. Return that symbol + the byte distance
    from its start. If `addr` falls below the first symbol's address
    (e.g. the exception vectors at 0x40000000..0x4000007f, which are
    not documented as named symbols in the SDK), return None — the
    caller should fall back to a generic "in ROM" message.

    Both `_CODE_SYMS` and `_DATA_SYMS` use the same lookup; we just
    pick the right table based on which range `addr` falls in.
    """
    if ROM_CODE_LO <= addr < ROM_CODE_HI:
        table = _CODE_SYMS
        addrs = _CODE_ADDRS
    elif ROM_DATA_LO <= addr < ROM_DATA_HI:
        table = _DATA_SYMS
        addrs = _DATA_ADDRS
    else:
        return None
    idx = bisect.bisect_right(addrs, addr) - 1
    if idx < 0:
        return None
    sym_addr, sym_name = table[idx]
    return sym_name, addr - sym_addr


# The raw `(address, name)` tables. Sourced from `eagle.rom.addr.v6.ld`.
# Sorted by address — both lookup helpers depend on this.
#
# Edit warning: don't reorder, don't deduplicate, don't reformat. Any
# new entries must keep the sort order. If you regenerate from a newer
# SDK, re-emit with `sorted([(a, n) for ...])` then paste back.

_CODE_SYMS: Tuple[Tuple[int, str], ...] = (
    (0x40000080, '_ResetVector'),
    (0x400000a4, '_ResetHandler'),
    (0x4000042c, '_start'),
    (0x40000454, '_xtos_set_exception_handler'),
    (0x4000048c, '_xtos_l1int_handler'),
    (0x4000056c, '_xtos_restore_intlevel'),
    (0x40000574, '_xtos_set_vpri'),
    (0x40000590, '_xtos_cause3_handler'),
    (0x40000598, '_xtos_c_wrapper_handler'),
    (0x400005f0, 'srand'),
    (0x40000600, 'rand'),
    (0x40000650, '__muldi3'),
    (0x40000688, 'xthal_bcopy'),
    (0x400006c4, 'xthal_memcpy'),
    (0x4000074c, 'xthal_copy123'),
    (0x40000814, 'cmd_parse'),
    (0x4000091c, 'get_first_seg'),
    (0x40000a04, 'remove_head_space'),
    (0x40000a60, 'convert_para_str'),
    (0x40000b24, 'conv_str_decimal'),
    (0x40000cb8, 'conv_str_hex'),
    (0x40000dc0, 'ets_set_idle_cb'),
    (0x40000dd0, 'ets_task'),
    (0x40000e04, 'ets_run'),
    (0x40000e24, 'ets_post_rom'),
    (0x40000f74, 'ets_intr_lock'),
    (0x40000f80, 'ets_intr_unlock'),
    (0x40000f88, 'ets_isr_attach'),
    (0x40000f98, 'ets_isr_mask'),
    (0x40000fa8, 'ets_isr_unmask'),
    (0x40000fbc, 'ets_set_user_start'),
    (0x40000fec, 'main'),
    (0x40001308, 'boot_from_flash'),
    (0x400018a4, 'ets_memset'),
    (0x400018b4, 'ets_memcpy'),
    (0x400018c4, 'ets_memmove'),
    (0x400018d4, 'ets_memcmp'),
    (0x40001998, 'mem_init'),
    (0x400019e0, 'mem_free'),
    (0x40001a14, 'mem_trim'),
    (0x40001b40, 'mem_malloc'),
    (0x40001c2c, 'mem_calloc'),
    (0x40001c58, 'mem_zalloc'),
    (0x40001c6c, 'mem_realloc'),
    (0x40001cb8, 'eprintf_init_buf'),
    (0x40001d14, 'eprintf'),
    (0x40001d48, 'eprintf_to_host'),
    (0x40001da0, 'ets_write_char'),
    (0x40001dcc, 'ets_uart_putc1'),
    (0x40001f00, 'ets_vprintf'),
    (0x4000242c, 'ets_install_putc1'),
    (0x40002438, 'ets_install_uart_printf'),
    (0x40002450, 'ets_install_external_printf'),
    (0x4000248c, 'ets_install_putc2'),
    (0x40002494, 'est_get_printf_buf_remain_len'),
    (0x4000249c, 'est_reset_printf_buf_len'),
    (0x400024cc, 'ets_printf'),
    (0x40002544, 'ets_uart_printf'),
    (0x40002578, 'ets_external_printf'),
    (0x400025e0, 'rtc_get_reset_reason'),
    (0x4000264c, 'software_reset'),
    (0x40002668, 'rtc_set_sleep_mode'),
    (0x4000269c, 'dtm_params_init'),
    (0x400026c8, 'dtm_set_intr_mask'),
    (0x400026d0, 'dtm_get_intr_mask'),
    (0x400026dc, 'dtm_set_params'),
    (0x400027a4, 'save_rxbcn_mactime'),
    (0x400027ac, 'save_tsf_us'),
    (0x400027b8, 'ets_enter_sleep'),
    (0x40002870, 'rtc_enter_sleep'),
    (0x400029ec, 'rtc_intr_handler'),
    (0x40002a40, 'ets_rtc_int_register'),
    (0x40002a88, 'ets_strcpy'),
    (0x40002a98, 'ets_strncpy'),
    (0x40002aa8, 'ets_strcmp'),
    (0x40002ab8, 'ets_strncmp'),
    (0x40002ac8, 'ets_strlen'),
    (0x40002ad8, 'ets_strstr'),
    (0x40002ae8, 'ets_bzero'),
    (0x40002af8, 'ets_str2macaddr'),
    (0x40002b74, 'ets_char2xdigit'),
    (0x40002bcc, 'ets_getc'),
    (0x40002be8, 'ets_putc'),
    (0x40002c48, 'ets_timer_setfn'),
    (0x40002c64, 'timer_insert'),
    (0x40002cc4, 'ets_timer_arm'),
    (0x40002d40, 'ets_timer_disarm'),
    (0x40002d80, 'ets_timer_done'),
    (0x40002da8, 'ets_timer_handler_isr'),
    (0x40002e68, 'ets_timer_init'),
    (0x40002ecc, 'ets_delay_us'),
    (0x40002f04, 'ets_update_cpu_frequency'),
    (0x40002f0c, 'ets_get_cpu_frequency'),
    (0x40002f34, 'ets_wdt_get_mode'),
    (0x40002fa0, 'ets_wdt_enable'),
    (0x400030f0, 'ets_wdt_disable'),
    (0x40003158, 'ets_wdt_restore'),
    (0x40003170, 'ets_wdt_init'),
    (0x400031b4, 'roundup2'),
    (0x400031c0, 'multofup'),
    (0x40003230, 'UartConnCheck'),
    (0x40003368, 'UartDwnLdProc'),
    (0x40003538, 'FlashDwnLdStartMsgProc'),
    (0x400035a0, 'FilePacketSendReqMsgProc'),
    (0x40003658, 'FlashDwnLdStopReqMsgProc'),
    (0x4000368c, 'FlashDwnLdParamCfgMsgProc'),
    (0x400036c4, 'MemDwnLdStartMsgProc'),
    (0x400036f0, 'MemPacketSendReqMsgProc'),
    (0x4000377c, 'MemDwnLdStopReqMsgProc'),
    (0x400037a0, 'UartConnectProc'),
    (0x400037ac, 'UartRegWriteProc'),
    (0x4000381c, 'UartRegReadProc'),
    (0x4000383c, 'uartAttach'),
    (0x400038a4, 'uart_buff_switch'),
    (0x40003924, 'uart_baudrate_detect'),
    (0x400039d8, 'rom_uart_div_modify'),
    (0x40003a14, 'Uart_Init'),
    (0x40003b30, 'uart_tx_one_char'),
    (0x40003b64, 'uart_rx_one_char_block'),
    (0x40003b8c, 'uart_rx_one_char'),
    (0x40003bbc, 'uart_rx_intr_handler'),
    (0x40003c30, 'UartRxString'),
    (0x40003c80, 'send_packet'),
    (0x40003cf4, 'SendMsg'),
    (0x40003d08, 'recv_packet'),
    (0x40003eac, 'RcvMsg'),
    (0x40003ec8, 'uart_rx_readbuff'),
    (0x40003ef4, 'UartGetCmdLn'),
    (0x40003f4c, 'GetUartDevice'),
    (0x40003f58, 'SelectSpiFunction'),
    (0x400043c8, 'SPI_read_status'),
    (0x40004400, 'SPI_write_status'),
    (0x4000443c, 'SPI_write_enable'),
    (0x4000448c, 'Wait_SPI_Idle'),
    (0x400044c0, 'Enable_QMode'),
    (0x40004644, 'spi_flash_attach'),
    (0x40004678, 'Cache_Read_Enable'),
    (0x400047f0, 'Cache_Read_Disable'),
    (0x40004878, 'SPIUnlock'),
    (0x400048a8, 'SPILock'),
    (0x400048ec, 'SPIReadModeCnfig'),
    (0x40004984, 'SPIEraseChip'),
    (0x400049b4, 'SPIEraseBlock'),
    (0x40004a00, 'SPIEraseSector'),
    (0x40004a4c, 'SPIWrite'),
    (0x40004b1c, 'SPIRead'),
    (0x40004b44, 'SPIEraseArea'),
    (0x40004c2c, 'SPIParamCfg'),
    (0x40004c50, 'gpio_init'),
    (0x40004cd0, 'gpio_output_set'),
    (0x40004cf0, 'gpio_input_get'),
    (0x40004d04, 'gpio_register_set'),
    (0x40004d5c, 'gpio_register_get'),
    (0x40004d88, 'gpio_intr_pending'),
    (0x40004d90, 'gpio_pin_intr_state_set'),
    (0x40004dcc, 'gpio_intr_ack'),
    (0x40004e28, 'gpio_intr_handler_register'),
    (0x40004e90, 'gpio_pin_wakeup_enable'),
    (0x40004ed4, 'gpio_pin_wakeup_disable'),
    (0x40004efc, 'gpio_intr_test'),
    (0x40004f40, 'lldesc_build_chain'),
    (0x40005050, 'lldesc_num2link'),
    (0x4000507c, 'lldesc_set_owner'),
    (0x400050fc, 'sip_post'),
    (0x40005180, 'sip_alloc_to_host_evt'),
    (0x40005234, 'sip_to_host_evt_send_done'),
    (0x400052c0, 'sip_reclaim_tx_data_pkt'),
    (0x4000534c, 'sip_reclaim_from_host_cmd'),
    (0x4000544c, 'sip_install_rx_ctrl_cb'),
    (0x4000545c, 'sip_install_rx_data_cb'),
    (0x40005668, 'sip_get_state'),
    (0x4000567c, 'sip_init_attach'),
    (0x400056c4, 'sip_post_init'),
    (0x40005808, 'sip_send'),
    (0x40005864, 'sip_to_host_chain_append'),
    (0x400058a8, 'sip_get_ptr'),
    (0x40005c1c, 'slc_reattach'),
    (0x40005c50, 'slc_init_attach'),
    (0x40005d90, 'slc_enable'),
    (0x40005db8, 'slc_select_tohost_gpio_mode'),
    (0x40005dc0, 'slc_select_tohost_gpio'),
    (0x40005de4, 'slc_send_to_host_chain'),
    (0x40005e94, 'slc_from_host_chain_recycle'),
    (0x40005f10, 'slc_to_host_chain_recycle'),
    (0x40005f24, 'slc_from_host_chain_fetch'),
    (0x40006014, 'slc_pause_from_host'),
    (0x4000603c, 'slc_resume_from_host'),
    (0x40006068, 'slc_set_host_io_max_window'),
    (0x4000608c, 'slc_init_credit'),
    (0x400060ac, 'slc_add_credits'),
    (0x400060c0, 'rom_abs_temp'),
    (0x400060d0, 'rom_chip_v5_disable_cca'),
    (0x400060ec, 'rom_chip_v5_enable_cca'),
    (0x4000610c, 'rom_chip_v5_sense_backoff'),
    (0x4000615c, 'rom_dc_iq_est'),
    (0x400061b8, 'rom_en_pwdet'),
    (0x40006238, 'rom_get_bb_atten'),
    (0x40006260, 'rom_get_corr_power'),
    (0x400062dc, 'rom_get_fm_sar_dout'),
    (0x40006394, 'rom_get_noisefloor'),
    (0x400063b0, 'rom_get_power_db'),
    (0x40006400, 'rom_iq_est_disable'),
    (0x40006430, 'rom_iq_est_enable'),
    (0x40006484, 'rom_linear_to_db'),
    (0x4000650c, 'rom_set_txclk_en'),
    (0x40006550, 'rom_set_rxclk_en'),
    (0x400065a4, 'rom_mhz2ieee'),
    (0x40006628, 'rom_rxiq_get_mis'),
    (0x40006738, 'rom_sar_init'),
    (0x4000678c, 'rom_set_ana_inf_tx_scale'),
    (0x400067c8, 'rom_set_loopback_gain'),
    (0x40006830, 'rom_set_noise_floor'),
    (0x40006874, 'rom_start_noisefloor'),
    (0x400068b4, 'rom_start_tx_tone'),
    (0x4000698c, 'rom_stop_tx_tone'),
    (0x40006a1c, 'rom_txtone_linear_pwr'),
    (0x40006a98, 'rom_tx_mac_disable'),
    (0x40006ad4, 'rom_tx_mac_enable'),
    (0x40006b08, 'phy_get_romfuncs'),
    (0x40006b10, 'rom_ana_inf_gating_en'),
    (0x40006c50, 'rom_set_channel_freq'),
    (0x40006f84, 'rom_chip_50_set_channel'),
    (0x4000711c, 'rom_chip_v5_rx_init'),
    (0x4000718c, 'rom_chip_v5_tx_init'),
    (0x40007268, 'rom_i2c_readReg'),
    (0x4000729c, 'rom_i2c_readReg_Mask'),
    (0x400072d8, 'rom_i2c_writeReg'),
    (0x4000730c, 'rom_i2c_writeReg_Mask'),
    (0x4000737c, 'rom_pbus_debugmode'),
    (0x40007410, 'rom_pbus_enter_debugmode'),
    (0x40007448, 'rom_pbus_exit_debugmode'),
    (0x4000747c, 'rom_pbus_force_test'),
    (0x400074d8, 'rom_pbus_rd'),
    (0x4000754c, 'rom_pbus_set_rxgain'),
    (0x40007610, 'rom_pbus_set_txgain'),
    (0x40007648, 'rom_pbus_workmode'),
    (0x40007688, 'rom_pbus_xpd_rx_off'),
    (0x400076cc, 'rom_pbus_xpd_rx_on'),
    (0x400076fc, 'rom_pbus_xpd_tx_off'),
    (0x40007740, 'rom_pbus_xpd_tx_on'),
    (0x400077a0, 'rom_pbus_xpd_tx_on__low_gain'),
    (0x40007804, 'rom_phy_reset_req'),
    (0x4000781c, 'rom_restart_cal'),
    (0x40007868, 'rom_rfpll_reset'),
    (0x400078dc, 'rom_write_rfpll_sdm'),
    (0x40007968, 'rom_rfpll_set_freq'),
    (0x40007a28, 'rom_cal_tos_v50'),
    (0x40007bf0, 'rom_pbus_dco___SA2'),
    (0x40007eb4, 'rom_rfcal_pwrctrl'),
    (0x4000804c, 'rom_rfcal_rxiq'),
    (0x40008264, 'rom_rfcal_rxiq_set_reg'),
    (0x40008388, 'rom_rfcal_txcap'),
    (0x40008610, 'rom_rfcal_txiq'),
    (0x400088b8, 'rom_rfcal_txiq_cover'),
    (0x40008a70, 'rom_rfcal_txiq_set_reg'),
    (0x40008b6c, 'rom_rxiq_cover_mg_mp'),
    (0x40008c6c, 'rom_set_txbb_atten'),
    (0x40008d34, 'rom_set_txiq_cal'),
    (0x40008dd0, 'rijndaelKeySetupDec'),
    (0x40008ea4, 'aes_decrypt_init'),
    (0x400092d4, 'aes_decrypt'),
    (0x400092e4, 'aes_decrypt_deinit'),
    (0x40009300, 'rijndaelKeySetupEnc'),
    (0x40009410, 'aes_unwrap'),
    (0x400094fc, 'base64_encode'),
    (0x40009648, 'base64_decode'),
    (0x400097ac, 'md5_vector'),
    (0x40009818, 'MD5Init'),
    (0x40009834, 'MD5Update'),
    (0x40009900, 'MD5Final'),
    (0x4000a160, 'hmac_md5_vector'),
    (0x4000a2cc, 'hmac_md5'),
    (0x4000a2ec, 'sha1_vector'),
    (0x4000a364, 'SHA1Transform'),
    (0x4000b584, 'SHA1Init'),
    (0x4000b5a8, 'SHA1Update'),
    (0x4000b648, 'SHA1Final'),
    (0x4000b840, 'pbkdf2_sha1'),
    (0x4000b8b4, 'hmac_sha1_vector'),
    (0x4000ba28, 'hmac_sha1'),
    (0x4000ba48, 'sha1_prf'),
    (0x4000bb3c, 'wepkey_64'),
    (0x4000bc40, 'wepkey_128'),
    (0x4000bd28, '_xtos_set_interrupt_handler_arg'),
    (0x4000bd70, '_xtos_set_interrupt_handler'),
    (0x4000bd84, '_xtos_ints_on'),
    (0x4000bda4, '_xtos_ints_off'),
    (0x4000bdc8, 'strcmp'),
    (0x4000bec8, 'strcpy'),
    (0x4000bf4c, 'strlen'),
    (0x4000bfa8, 'strncmp'),
    (0x4000c0a0, 'strncpy'),
    (0x4000c180, '__addsf3'),
    (0x4000c268, '__subsf3'),
    (0x4000c3dc, '__mulsf3'),
    (0x4000c4c4, '__fixunssfsi'),
    (0x4000c538, '__adddf3'),
    (0x4000c688, '__subdf3'),
    (0x4000c8f0, '__muldf3'),
    (0x4000cb94, '__divdf3'),
    (0x4000ccb8, '__fixdfsi'),
    (0x4000cd00, '__fixunsdfsi'),
    (0x4000cd5c, '__truncdfsf2'),
    (0x4000cdfc, '__extendsfdf2'),
    (0x4000ce60, '__divdi3'),
    (0x4000d310, '__udivdi3'),
    (0x4000d770, '__umoddi3'),
    (0x4000dbe0, '_xtos_alloca_handler'),
    (0x4000dbe4, '_xtos_syscall_handler'),
    (0x4000dbf8, '_xtos_p_none'),
    (0x4000dbfc, '_xtos_set_intlevel'),
    (0x4000dc18, '_xtos_set_min_intlevel'),
    (0x4000dc3c, '_xtos_unhandled_interrupt'),
    (0x4000dc44, '_xtos_unhandled_exception'),
    (0x4000dc54, '_xtos_return_from_exc'),
    (0x4000dc88, '__divsi3'),
    (0x4000dcf0, '__umulsidi3'),
    (0x4000dd38, 'xthal_get_ccount'),
    (0x4000dd40, 'xthal_set_ccompare'),
    (0x4000dd4c, 'xthal_get_ccompare'),
    (0x4000dd58, 'xthal_get_intread'),
    (0x4000dd60, 'xthal_set_intclear'),
    (0x4000dd68, 'rc4_skip'),
    (0x4000de84, 'bzero'),
    (0x4000dea8, 'memcmp'),
    (0x4000df48, 'memcpy'),
    (0x4000e04c, 'memmove'),
    (0x4000e190, 'memset'),
    (0x4000e1e0, 'strstr'),
    (0x4000e21c, '__udivsi3'),
    (0x4000e268, '__umodsi3'),
    (0x4000e2a4, '__floatunsisf'),
    (0x4000e2ac, '__floatsisf'),
    (0x4000e2e8, '__floatunsidf'),
    (0x4000e2f0, '__floatsidf'),
    (0x4000e320, 'xthal_window_spill_nw'),
    (0x4000e324, 'xthal_window_spill'),
    (0x4000e328, '_rom_store_table'),
    (0x4000e388, '_rom_store'),
)

_DATA_SYMS: Tuple[Tuple[int, str], ...] = (
    (0x3fffc000, '_xtos_exc_handler_table'),
    (0x3fffc100, '_xtos_c_handler_table'),
    (0x3fffc714, 'flashchip'),
    (0x3fffccf0, 'Te0'),
    (0x3fffd0f0, 'rcons'),
    (0x3fffd100, 'Td0'),
    (0x3fffd500, 'Td4s'),
    (0x3fffdcd0, 'user_start_fptr'),
    (0x3fffde10, 'UartDev'),
)

# Pre-extracted address vectors for `bisect`. Both tables are sorted-
# ascending, so we can extract the first column once and bisect-right
# on it. This is just `tuple(a for a, _ in _XXX_SYMS)` lifted to
# module-init time.
_CODE_ADDRS: Tuple[int, ...] = tuple(a for a, _ in _CODE_SYMS)
_DATA_ADDRS: Tuple[int, ...] = tuple(a for a, _ in _DATA_SYMS)


__all__ = [
    'ROM_CODE_LO', 'ROM_CODE_HI', 'ROM_DATA_LO', 'ROM_DATA_HI',
    'is_rom_addr', 'resolve_rom_addr',
]
