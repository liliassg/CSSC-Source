"""ABI / codegen issue scanner for Xtensa LX106 / LX7 assembly.

`cssc native trace script.cssc` builds the script to .s (asm) and
walks the resulting Xtensa assembly for the classes of bug that
caused the videodriver chip to hang during this session's bring-up:

  * a0-clobber               — `call0 X` inside a function that never
                              saved a0; after the inner call returns,
                              the outer function's `ret.n` jumps to a
                              corrupt address (the bug we saw in the
                              original cssc_tft_pixel).
  * callee-save-clobber      — function writes to one of a12..a15
                              without saving it; under the CALL0 ABI
                              every callee must preserve a12..a15.
                              This is the bug that crashed every
                              object method until the prologue
                              learned to save the used-CS set.
  * sp-displacement-spill    — function does `addi a1, a1, -N` and
                              then reads from `a1, +M` where M was a
                              spill offset valid for the ORIGINAL SP.
                              Manifests as off-by-N argument loads
                              when a caller passes stack args.
  * misaligned-call0-target  — call0 to a label whose preceding
                              instruction isn't .align 4; Xtensa
                              CALL0 requires 4-byte-aligned targets.
  * iram-byte-load           — l8ui/s8i to addresses the layout
                              suggests live in IRAM (cause 3 on
                              ESP8266; IRAM only supports word
                              loads/stores).
  * recursive-leaf           — function calls itself or its callee
                              without saving a0 (subset of a0-
                              clobber, but flagged separately so the
                              user sees the recursive depth issue).

The scanner is purely textual — it doesn't run llc, doesn't load
the ELF; it just reads the .s file. That keeps the trace pass fast
(<100 ms for a 5000-line user.s) and means it can run as a default
post-build step without slowing the iteration loop.

CLI surface (wired in `includecpp/cli/commands.py`):

    cssc native trace script.cssc                 # all checks
    cssc native trace script.cssc --mode a0       # just a0-clobber
    cssc native trace script.cssc --mode cs,sp    # CS + SP-displacement
    cssc native trace script.cssc --json          # machine-readable
"""

from __future__ import annotations

import dataclasses
import json
import re
import sys
from typing import Callable, Dict, List, Optional, Set, Tuple


# ---------------------------------------------------------------------------
# Diagnostic record.
# ---------------------------------------------------------------------------
@dataclasses.dataclass
class Diag:
    kind:      str         # short id, e.g. 'a0-clobber'
    severity:  str         # 'error' | 'warning' | 'info'
    function:  str         # asm function name where the issue lives
    line:      int         # 1-based line in the .s file
    text:      str         # short title shown in the summary
    detail:    str         # multi-line explanation
    fix_hint:  str         # one-paragraph remediation suggestion

    def render_pretty(self, file_path: str) -> str:
        # Colorless plain text; the CLI command wraps it in click.secho
        # for terminal colors.
        head = (
            f'[{self.severity.upper():7}] {self.kind:24}  '
            f'{self.function}  ({file_path}:{self.line})'
        )
        body = '\n'.join('    ' + ln for ln in self.detail.splitlines())
        hint = '    hint: ' + self.fix_hint.replace('\n', '\n          ')
        return f'{head}\n    {self.text}\n{body}\n{hint}'

    def to_json(self) -> Dict:
        return dataclasses.asdict(self)


# ---------------------------------------------------------------------------
# Function-block parser. Splits the .s text into function blocks.
# ---------------------------------------------------------------------------
@dataclasses.dataclass
class FuncBlock:
    name:    str
    body:    List[str]     # lines INCLUDING the leading `<name>:` line
    start:   int           # 1-based source line of the leading label
    end:     int           # 1-based source line of the `.size ...` directive


# Regex for a function-label start. Functions are conventionally
# declared as `name:` on a single line. Local labels start with `.L`
# (or `.`) and are block / branch targets INSIDE a function — we
# skip those so they don't fragment the body.
_LABEL_RE = re.compile(r'^([a-zA-Z_$][\w.$]*):\s*$')
_SIZE_RE  = re.compile(r'^\s*\.size\s+([a-zA-Z_.$][\w.$]*)\s*,')


def parse_functions(source: str) -> List[FuncBlock]:
    """Split `source` into a list of function blocks.

    A real function is one that the assembler is supposed to treat as
    a callable symbol — emitter-produced functions always declare
    themselves via `.type NAME, @function` AND end with
    `.size NAME, .-NAME`. Hand-written runtime helpers do the same.
    Anywhere else, a bare `name:` line is a local branch target
    (a `p1`, `sl2`, `delay_loop`, etc.) and must NOT fragment the
    enclosing function's body — otherwise the per-function checks
    see a junk function whose prologue is "nothing" and report
    spurious clobber errors.

    Pre-pass: walk the source once to collect the names declared as
    `.type NAME, @function` (or referenced by `.size NAME, .-NAME`).
    The main pass then treats only those labels as block starts.
    """
    lines = source.splitlines()
    declared: Set[str] = set()
    for raw in lines:
        m = re.match(r'^\s*\.type\s+(\.?[a-zA-Z_][\w.$]*)\s*,\s*@function',
                     raw)
        if m:
            declared.add(m.group(1))
        sm = _SIZE_RE.match(raw)
        if sm:
            declared.add(sm.group(1))
    blocks: List[FuncBlock] = []
    cur:   Optional[FuncBlock] = None
    # Also accept labels that match `^([a-zA-Z_]\w*):` AND appear in
    # `declared`. Allow `.L`-prefixed real symbols too if explicitly
    # declared as @function (rare but possible).
    label_pattern = re.compile(r'^(\.?[a-zA-Z_$][\w.$]*):\s*$')
    for i, raw in enumerate(lines):
        m = label_pattern.match(raw)
        if m:
            name = m.group(1)
            if name in declared:
                if cur is not None and cur.end == 0:
                    cur.end = i
                    blocks.append(cur)
                cur = FuncBlock(name=name, body=[raw], start=i + 1, end=0)
                continue
            # Not declared — treat as a branch target inside cur.
        if cur is not None:
            cur.body.append(raw)
            sm = _SIZE_RE.match(raw)
            if sm and sm.group(1) == cur.name:
                cur.end = i + 1
                blocks.append(cur)
                cur = None
    if cur is not None and cur.end == 0:
        cur.end = len(lines)
        blocks.append(cur)
    return blocks


# ---------------------------------------------------------------------------
# Per-check helpers — each returns a list of Diag.
# ---------------------------------------------------------------------------
_CALL0_RE   = re.compile(r'^\s*call0\s+([a-zA-Z_.$][\w.$]*)')
_RET_RE     = re.compile(r'^\s*ret(\.n)?\s*$')
_SAVE_RE    = re.compile(r'^\s*s32i(\.n)?\s+(a\d+),\s*a1,\s*(\d+)')
_SP_DEC_RE  = re.compile(r'^\s*addi\s+a1,\s*a1,\s*(-\d+)')
_SP_INC_RE  = re.compile(r'^\s*addi\s+a1,\s*a1,\s*(\d+)')
_LITERAL_RE = re.compile(r'^\s*\.literal\b')


def _writes_to(line: str) -> Optional[str]:
    """If the line writes a value to a register, return the
    destination register name (e.g. 'a12'). Else None.

    Recognises the common write opcodes used by hand-written
    runtime asm + emitter output.

    NOTE: We deliberately exclude `ssl` and `ssr` — those write the
    Shift Amount Register (SAR), NOT the named GPR. (`ssl a14` reads
    a14 and stores its low 5 bits in SAR for a subsequent sll/srl;
    a14 itself is unchanged.) Including them produced false positives
    in cssc_i2c_drive's bit-bang loop.
    """
    # Strip a trailing comment so it doesn't confuse the regex.
    body = line.split(';', 1)[0].split('#', 1)[0].strip()
    if not body:
        return None
    m = re.match(
        r'(mov(?:\.n)?|movi(?:\.n)?|l32i(?:\.n)?|l32r|l8ui|l16ui|l16si|'
        r'addi(?:\.n)?|addmi|add(?:\.n)?|sub|and|or|xor|not|'
        r'srli|srai|sll|srl|sra|extui|sext|neg|abs|'
        r'mull|muluh|mulsh|'
        r'rsr\.\w+|callx0)\s+'
        r'(a\d+)\b', body)
    if not m:
        return None
    return m.group(2)


def _restores(line: str) -> Optional[Tuple[str, int]]:
    """If line is `l32i / l32i.n  aN, a1, +OFF`, return (reg, off)."""
    m = re.match(r'^\s*l32i(\.n)?\s+(a\d+),\s*a1,\s*(\d+)', line)
    if not m:
        return None
    return m.group(2), int(m.group(3))


def _is_emitter_function(fb: FuncBlock) -> bool:
    """Heuristic: an emitter-produced function name follows the
    pattern `cssc_user_main`, `cssc_obj_<Name>_<method>`, `cssc_main_<n>`,
    or other CIR-derived names. Runtime asm functions use shorter
    suffixes (`cssc_int_to_str`, `cssc_string_lit`, `cssc_tft_text`).
    The scanner's per-check helpers apply slightly different rules
    (e.g. emitter prologues already track callee-save use; runtime
    has to declare it by hand). We return True when this is a
    user-emitted function.
    """
    # Emitter-produced names always include cssc_user_main or
    # cssc_obj_.*_.* etc. Quick heuristic.
    if fb.name == 'cssc_user_main':
        return True
    if fb.name.startswith('cssc_obj_') and '_' in fb.name[len('cssc_obj_'):]:
        return True
    if fb.name.startswith('_cssc_user_entry') or fb.name.startswith('_cssc_'):
        return True
    return False


def check_a0_clobber(fb: FuncBlock) -> List[Diag]:
    """Flag any function that calls call0 but never s32i'd a0 to the frame.

    A non-leaf function MUST preserve its return address (a0) across
    every call0 it issues, because call0 itself stores the return
    address INTO a0. If a0 isn't on the stack when the inner call
    happens, the outer function's eventual `ret.n` jumps to garbage.
    """
    diags: List[Diag] = []
    saves_a0 = False
    first_call0_line = -1
    first_call0_target = None
    for off, line in enumerate(fb.body):
        if _SAVE_RE.match(line) and ' a0' in line.replace(',', ' '):
            saves_a0 = True
        cm = _CALL0_RE.match(line)
        if cm and not saves_a0 and first_call0_line == -1:
            first_call0_line = off
            first_call0_target = cm.group(1)
    if first_call0_line >= 0 and not saves_a0:
        diags.append(Diag(
            kind='a0-clobber',
            severity='error',
            function=fb.name,
            line=fb.start + first_call0_line,
            text=(f'{fb.name} calls {first_call0_target} without saving '
                  f'a0 in its prologue.'),
            detail=(
                'CALL0 ABI on Xtensa LX106/LX7: every `call0 X`\n'
                'instruction overwrites a0 with the return address\n'
                'of the inner call. If the calling function does\n'
                'not save its own a0 to the stack BEFORE the inner\n'
                'call0, its eventual `ret.n` jumps to whatever a0\n'
                'contains — typically a wild address in the inner\n'
                'callee, which traps as a load-prohibited fault\n'
                '(cause 28) or jumps to the ROM panic handler\n'
                '(PC=0x40001800 on ESP8266).'
            ),
            fix_hint=(
                'Add a frame in the prologue: `addi a1, a1, -16; '
                's32i.n a0, a1, 12`. Restore + pop in the epilogue: '
                '`l32i.n a0, a1, 12; addi a1, a1, 16; ret.n`. '
                'Reuse the same frame to spill any other caller-save '
                'values you need to preserve across the inner call.'
            ),
        ))
    return diags


def check_callee_save_clobber(fb: FuncBlock) -> List[Diag]:
    """Flag any function that writes to a12..a15 without saving the
    register first.

    Emitter-produced functions go through `XtensaEmitter.emit_function`
    which always saves the used callee-save set; for hand-written
    runtime asm the author has to do it by hand. This check catches
    the latter.
    """
    diags: List[Diag] = []
    saved: Set[str] = set()
    first_clobber: Dict[str, int] = {}
    for off, line in enumerate(fb.body):
        sm = _SAVE_RE.match(line)
        if sm:
            saved.add(sm.group(2))
            continue
        wr = _writes_to(line)
        if wr is None:
            continue
        if wr in ('a12', 'a13', 'a14', 'a15') and wr not in saved:
            first_clobber.setdefault(wr, off)
    for reg, off in sorted(first_clobber.items()):
        diags.append(Diag(
            kind='callee-save-clobber',
            severity='error',
            function=fb.name,
            line=fb.start + off,
            text=(f'{fb.name} writes to {reg} without saving it.'),
            detail=(
                'Under CALL0 the registers a12..a15 are callee-save:\n'
                'every callee that clobbers one MUST preserve and\n'
                'restore the original value. Without the save, the\n'
                "caller's live data in that register is destroyed\n"
                'when this function returns — manifesting as null\n'
                'pointer dereferences, corrupt object handles, or\n'
                'silent wrong-result bugs depending on what the\n'
                'caller had stored there.'
            ),
            fix_hint=(
                f'Add `s32i.n {reg}, a1, OFF` to the prologue and '
                f'`l32i.n {reg}, a1, OFF` to the epilogue. Use an '
                f'offset that does not overlap any other frame slot.'
            ),
        ))
    return diags


def check_sp_displacement(fb: FuncBlock) -> List[Diag]:
    """Flag a `addi a1, a1, -N` followed by `a1, M` accesses that
    are likely meant to address slots from the ORIGINAL SP.

    This is the bug that cost us videodriver's first attempt — the
    emitter would lower an outgoing stack-arg call as

        addi   a1, a1,  -32       ; reserve outgoing args
        l32i.n a4, a1, 336        ; read spill[336] BUT a1 has moved

    where `336` was a frame offset valid only for the original SP.
    Without compensating by +32 every load reads the wrong word.
    """
    diags: List[Diag] = []
    in_displaced = 0
    displace_line = -1
    for off, line in enumerate(fb.body):
        dec = _SP_DEC_RE.match(line)
        inc = _SP_INC_RE.match(line)
        if dec:
            in_displaced = -int(dec.group(1))   # positive amount
            displace_line = off
            continue
        if inc:
            in_displaced = 0
            continue
        # Within a displaced region, any l32i/s32i from a1 with
        # offset >= displace_amount is suspicious — it's accessing
        # what looks like a frame slot from the old SP without
        # compensating.
        if in_displaced > 0:
            m = re.match(
                r'^\s*(l32i(?:\.n)?|s32i(?:\.n)?)\s+a\d+,\s*a1,\s*(\d+)',
                line)
            if m:
                off_n = int(m.group(2))
                # Heuristic: outgoing-args region is [0..displace).
                # Anything past that is either a slot that's been
                # already compensated for (and we can't tell from
                # text alone) or a missed compensation. We flag any
                # access with offset >= 2*displace as definitely
                # suspicious — the well-behaved compensated form
                # would already include the displace in its offset.
                if off_n >= 2 * in_displaced:
                    diags.append(Diag(
                        kind='sp-displacement-spill',
                        severity='warning',
                        function=fb.name,
                        line=fb.start + off,
                        text=(
                            f'Inside SP-displaced region (-{in_displaced} '
                            f'bytes), accessing [a1, +{off_n}] looks like '
                            f'it should be [a1, +{off_n + in_displaced}].'
                        ),
                        detail=(
                            'A previous `addi a1, a1, -N` moved the stack '
                            f'pointer down by {in_displaced} bytes (line '
                            f'{fb.start + displace_line}). All loads/stores '
                            'via a1 inside this region MUST add the '
                            "displacement amount to the original frame "
                            "offset, otherwise they hit the wrong slot."
                        ),
                        fix_hint=(
                            'Either pop SP before reading source spill '
                            'slots, or write `[a1, +{n_plus_displ}]` where '
                            'n_plus_displ = original_offset + displacement. '
                            "If you're generating this code from the "
                            'emitter, make sure _sp_displacement is '
                            'consulted in _load_ssa_to / _load_ssa_to_pair.'
                        ),
                    ))
    return diags


def check_misaligned_call0(fb: FuncBlock, source_lines: List[str]) -> List[Diag]:
    """Flag a call0 to a target whose preceding line isn't .align 4."""
    diags: List[Diag] = []
    # Look up every label location across the FULL source so we can
    # check the call0's target alignment.
    label_lines: Dict[str, int] = {}
    for i, raw in enumerate(source_lines):
        m = _LABEL_RE.match(raw)
        if m:
            label_lines[m.group(1)] = i
    for off, line in enumerate(fb.body):
        cm = _CALL0_RE.match(line)
        if not cm:
            continue
        target = cm.group(1)
        loc = label_lines.get(target)
        if loc is None:
            continue          # external symbol — alignment handled by linker
        # Walk backward to skip blank lines + comments. If the
        # immediately preceding non-blank, non-comment line is a
        # .align 4 or .align of >=2, we accept.
        ok = False
        j = loc - 1
        while j >= 0:
            prev = source_lines[j].strip()
            if not prev or prev.startswith('#') or prev.startswith(';'):
                j -= 1; continue
            if prev.startswith('.align'):
                # `.align 4`, `.align 8`, etc.
                m = re.match(r'\.align\s+(\d+)', prev)
                if m and int(m.group(1)) >= 2:
                    ok = True
            break
        if not ok:
            diags.append(Diag(
                kind='misaligned-call0-target',
                severity='warning',
                function=fb.name,
                line=fb.start + off,
                text=(
                    f'call0 target {target} lacks a `.align 4` before its '
                    f'label.'),
                detail=(
                    'Xtensa CALL0 requires the call target to be 4-byte '
                    'aligned. If the linker happens to place the label '
                    'on a 4-byte boundary, the chip runs fine; if not, '
                    'the call traps with cause 0 (IllegalInstruction).'
                ),
                fix_hint=(
                    f'Insert `.align 4` immediately before `{target}:`. '
                    'The emitter does this automatically for emitted '
                    'functions via the post-pass; runtime asm should '
                    'follow the same convention.'
                ),
            ))
    return diags


def check_iram_byte_load(fb: FuncBlock) -> List[Diag]:
    """Flag any l8ui/s8i whose pointer-source label is in .iram*.

    On ESP8266 the IRAM bank doesn't support byte-granular loads
    (cause 3, LoadStoreErrorCause). This is the bug that started
    appearing once strings + tables ended up co-located with .text;
    moving them to .section .rodata (which lands in DRAM) is the
    standard fix.
    """
    diags: List[Diag] = []
    # We can't know the actual section a symbol ends up in from the
    # .s alone — that's a linker decision. Flag l8ui/s8i with the
    # immediate-comment hint of "iram" or  to a label starting with
    # `.iram_` etc. as a soft warning.
    for off, line in enumerate(fb.body):
        m = re.match(r'^\s*(l8ui|s8i)\s+a\d+,\s*(a\d+),\s*\d+', line)
        if not m:
            continue
        rest = line.lower()
        if 'iram' in rest or '0x40100' in rest:
            diags.append(Diag(
                kind='iram-byte-load',
                severity='warning',
                function=fb.name,
                line=fb.start + off,
                text=(
                    'Byte load/store via a pointer that appears to '
                    'address IRAM. ESP8266 IRAM is word-only.'),
                detail=(
                    'l8ui / s8i on IRAM raises LoadStoreErrorCause '
                    '(cause 3) on ESP8266. Place byte-addressed '
                    'tables (.asciz, font, lookup) in .rodata so '
                    'they map to DRAM (or flash via the linker).'
                ),
                fix_hint=(
                    'Wrap the table in `.section .rodata` and emit '
                    'it before the `.text` resumption. The linker '
                    'will place .rodata in DRAM by default.'
                ),
            ))
    return diags


def check_recursive_leaf(fb: FuncBlock) -> List[Diag]:
    """Flag a function that calls itself but doesn't save a0.

    Direct recursion without a saved return address is a guaranteed
    infinite loop on the first invocation (the inner call overwrites
    a0, the outer never returns).
    """
    diags: List[Diag] = []
    saves_a0 = any(
        _SAVE_RE.match(ln) and ' a0' in ln.replace(',', ' ')
        for ln in fb.body
    )
    if saves_a0:
        return diags
    for off, line in enumerate(fb.body):
        cm = _CALL0_RE.match(line)
        if cm and cm.group(1) == fb.name:
            diags.append(Diag(
                kind='recursive-leaf',
                severity='error',
                function=fb.name,
                line=fb.start + off,
                text=(
                    f'{fb.name} calls itself without saving a0.'),
                detail=(
                    "Direct recursion needs a save/restore of the\n"
                    "return address. Without it, the second call's\n"
                    "call0 overwrites the first call's saved a0\n"
                    "(which is still in the register), and the\n"
                    "recursion never unwinds."
                ),
                fix_hint=(
                    'Add `addi a1, a1, -16; s32i.n a0, a1, 12` to '
                    'the prologue and the matching restore to the '
                    'epilogue.'
                ),
            ))
            break
    return diags


# ---------------------------------------------------------------------------
# Driver — runs the selected modes against a .s file.
# ---------------------------------------------------------------------------
ALL_MODES = ('a0', 'cs', 'align', 'iram', 'recursive')
# `sp` (sp-displacement-spill) is intentionally excluded from the
# default mode set. After the emitter learned to consult
# `_sp_displacement` when reading/writing spill slots inside an
# outgoing-stack-arg block, every COMPENSATED load now produces an
# offset >= the displacement amount — which is exactly what the
# original heuristic flagged as suspicious. The check is still
# useful for hand-written runtime-asm authors verifying their own
# offset bookkeeping, so we keep it accessible via `--mode sp` but
# no longer flood the default report with what are now legitimate
# accesses.
OPT_IN_MODES = ('sp',)

_MODE_TO_CHECK: Dict[str, Callable] = {
    'a0':         check_a0_clobber,
    'cs':         check_callee_save_clobber,
    'sp':         check_sp_displacement,
    'recursive':  check_recursive_leaf,
    'iram':       check_iram_byte_load,
    # 'align' uses a different signature (needs full source) — driver
    # dispatches it specially below.
}


def trace_asm(source: str,
              modes: Tuple[str, ...] = ALL_MODES) -> List[Diag]:
    """Run the requested checks against a .s blob; return the diag list."""
    blocks = parse_functions(source)
    lines = source.splitlines()
    all_diags: List[Diag] = []
    for fb in blocks:
        for mode in modes:
            if mode == 'align':
                all_diags.extend(check_misaligned_call0(fb, lines))
                continue
            check = _MODE_TO_CHECK.get(mode)
            if check is None:
                continue
            all_diags.extend(check(fb))
    return all_diags


def render(diags: List[Diag], file_path: str) -> str:
    """Render the diag list as human-readable text."""
    if not diags:
        return f'[OK] no issues found in {file_path}.'
    out = [f'{len(diags)} issue(s) in {file_path}:', '']
    for d in diags:
        out.append(d.render_pretty(file_path))
        out.append('')
    return '\n'.join(out)


# ---------------------------------------------------------------------------
# Public surface: parse, then drive the CLI command.
# ---------------------------------------------------------------------------
def trace_file(asm_path: str,
               modes: Tuple[str, ...] = ALL_MODES) -> Tuple[List[Diag], str]:
    """Read a .s file and run the requested checks. Returns
    `(diags, rendered_text)` for the CLI to print + decide exit-code."""
    with open(asm_path, 'r', encoding='utf-8', errors='replace') as fp:
        source = fp.read()
    diags = trace_asm(source, modes)
    return diags, render(diags, asm_path)
