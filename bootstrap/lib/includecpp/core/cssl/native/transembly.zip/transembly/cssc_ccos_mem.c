/* CSSC v6 native — CCOS memory management (Phase 2, x86-64 freestanding).
 *
 * Provides:
 *   * a physical page-frame allocator (bitmap) built from the Limine memory
 *     map — the foundation for paging / drivers in later phases;
 *   * the real kernel heap behind `cssc_obj_alloc` / `cssc_obj_free`, a
 *     first-fit implicit free-list with coalescing over the largest usable
 *     RAM region (accessed through Limine's higher-half direct map). This
 *     replaces the bump arena: explicit `#delete` now genuinely frees.
 *   * memory-stat accessors read by CSSC via `cssc::memUsable` / `heapUsed`
 *     / `framesFree` / `framesTotal`.
 *
 * `cssc_mem_init()` runs once from the boot entry (kmain) after the serial
 * console and before `cssc_user_main`, so the heap is live before the first
 * CSSC string allocation.
 */

typedef unsigned char       u8;
typedef unsigned int        u32;
typedef unsigned long long  u64;
typedef signed   long long  i64;

#define PAGE            4096ull
#define MAX_FRAMES      (1ull << 20)       /* covers 4 GiB of RAM      */
/* Object-heap cap. 64 MiB was too tight once the kernel loads the WHOLE CCFS
 * into RAM at boot (sources + wallpapers + the 8 MiB ccos.img) AND the on-metal
 * Transembly compiler asks for its ~38 MiB of tables -- alloc then returned 0
 * and CSSC promptly wrote to address 0 (a #PF with CR2=0). Real machines have
 * GiBs; take 512 MiB so `build <file>` has comfortable headroom. Still capped
 * (not "all of RAM") so the frame allocator keeps pages for everything else --
 * the bitmap only tracks the first 4 GiB anyway (MAX_FRAMES). */
#define HEAP_CAP        (512ull * 1024 * 1024) /* cap the object heap   */
#define HDR             16u                /* heap block header bytes  */
#define BLK_MAGIC       0xCC05B10Cu

#define LIMINE_MEMMAP_USABLE 0

/* Accessors implemented in cssc_ccos_boot.c (read the Limine responses). */
extern u64 cssc_memmap_count(void);
extern u64 cssc_memmap_base(u64 i);
extern u64 cssc_memmap_length(u64 i);
extern u64 cssc_memmap_type(u64 i);
extern u64 cssc_hhdm_offset(void);

/* ------------------------------------------------------------------ */
/* Physical frame allocator — one bit per 4 KiB frame (1 = used).      */
/* ------------------------------------------------------------------ */
static u8  frame_bitmap[MAX_FRAMES / 8];
static u64 total_frames = 0;
static u64 free_frames  = 0;
static u64 usable_bytes = 0;

static void bm_set(u64 f)   { frame_bitmap[f >> 3] |= (u8)(1u << (f & 7u)); }
static void bm_clear(u64 f) { frame_bitmap[f >> 3] &= (u8)~(1u << (f & 7u)); }
static int  bm_test(u64 f)  { return (frame_bitmap[f >> 3] >> (f & 7u)) & 1u; }

/* ------------------------------------------------------------------ */
/* Kernel object heap — implicit first-fit free list over one region.  */
/* ------------------------------------------------------------------ */
typedef struct { u64 size; u32 free; u32 magic; } hdr_t;  /* exactly 16 B */

static u64 heap_base = 0;   /* virtual (HHDM) start of the heap arena */
static u64 heap_end  = 0;
static u64 heap_used = 0;

/* Static fallback arena — used only if the Limine memmap / HHDM are
 * unavailable, so allocation never faults during early bring-up. */
static u8  fallback_arena[8ull * 1024 * 1024] __attribute__((aligned(16)));

static u64 align16(u64 x) { return (x + 15u) & ~15ull; }

static void heap_init(u64 base_virt, u64 len) {
    heap_base = base_virt;
    heap_end  = base_virt + len;
    heap_used = 0;
    hdr_t *h = (hdr_t *)base_virt;
    h->size  = len - HDR;
    h->free  = 1;
    h->magic = BLK_MAGIC;
}

void cssc_mem_init(void) {
    /* 1. Build the frame bitmap: everything used, then free the USABLE
     *    regions. Also track the largest usable region for the heap. */
    for (u64 i = 0; i < sizeof(frame_bitmap); i++) frame_bitmap[i] = 0xFF;

    u64 best_base = 0, best_len = 0;
    u64 n = cssc_memmap_count();
    for (u64 i = 0; i < n; i++) {
        if (cssc_memmap_type(i) != LIMINE_MEMMAP_USABLE) continue;
        u64 base = cssc_memmap_base(i);
        u64 len  = cssc_memmap_length(i);
        usable_bytes += len;
        u64 first = (base + PAGE - 1) / PAGE;
        u64 last  = (base + len) / PAGE;
        for (u64 f = first; f < last && f < MAX_FRAMES; f++) {
            bm_clear(f);
            free_frames++;
            if (f + 1 > total_frames) total_frames = f + 1;
        }
        if (len > best_len) { best_len = len; best_base = base; }
    }

    /* 2. Carve the heap arena from the largest usable region (capped),
     *    and reserve its frames so the frame allocator won't reuse it. */
    u64 hhdm = cssc_hhdm_offset();
    if (best_len >= (1ull << 20) && hhdm != 0) {
        /* Take at most HALF the largest usable region, capped at HEAP_CAP.
         * Taking min(region, CAP) starved the frame allocator on small-RAM
         * machines: a 256 MiB QEMU handed the WHOLE region to the heap and left
         * 118 free frames for page tables / MMIO maps. Half keeps the frame
         * allocator healthy everywhere, and on a real multi-GiB machine the
         * 512 MiB cap still binds first. */
        u64 hlen = best_len / 2;
        if (hlen > HEAP_CAP) hlen = HEAP_CAP;
        hlen &= ~(PAGE - 1);
        u64 hbase_phys = (best_base + PAGE - 1) & ~(PAGE - 1);
        u64 first = hbase_phys / PAGE;
        u64 last  = (hbase_phys + hlen) / PAGE;
        for (u64 f = first; f < last && f < MAX_FRAMES; f++) {
            if (!bm_test(f)) { bm_set(f); if (free_frames) free_frames--; }
        }
        heap_init(hhdm + hbase_phys, hlen);
    } else {
        /* No usable region / HHDM — fall back to the static arena. */
        heap_init((u64)fallback_arena, sizeof(fallback_arena));
    }
}

void *cssc_obj_alloc(i64 size) {
    if (heap_base == 0) heap_init((u64)fallback_arena, sizeof(fallback_arena));
    u64 need = align16((u64)size);
    if (need == 0) need = 16;
    u64 cur = heap_base;
    while (cur + HDR <= heap_end) {
        hdr_t *h = (hdr_t *)cur;
        if (h->free && h->size >= need) {
            if (h->size >= need + HDR + 16u) {          /* split */
                u64 nxt = cur + HDR + need;
                hdr_t *nh = (hdr_t *)nxt;
                nh->size  = h->size - need - HDR;
                nh->free  = 1;
                nh->magic = BLK_MAGIC;
                h->size   = need;
            }
            h->free = 0;
            heap_used += h->size + HDR;
            return (void *)(cur + HDR);
        }
        cur = cur + HDR + h->size;
    }
    return (void *)0;                                    /* OOM */
}

void cssc_obj_free(void *p) {
    if (!p) return;
    hdr_t *h = (hdr_t *)((u64)p - HDR);
    if (h->magic != BLK_MAGIC || h->free) return;
    h->free = 1;
    heap_used -= h->size + HDR;
    /* Coalesce all adjacent free blocks (single linear pass). */
    u64 cur = heap_base;
    while (cur + HDR <= heap_end) {
        hdr_t *c = (hdr_t *)cur;
        u64 nxt = cur + HDR + c->size;
        if (c->free && nxt + HDR <= heap_end) {
            hdr_t *nb = (hdr_t *)nxt;
            if (nb->free && nb->magic == BLK_MAGIC) {
                c->size += HDR + nb->size;
                continue;
            }
        }
        cur = nxt;
    }
}

/* ------------------------------------------------------------------ */
/* Stats accessors — CSSC-reachable via cssc:: intrinsics.             */
/* ------------------------------------------------------------------ */
u64 cssc_mem_usable(void)   { return usable_bytes; }
u64 cssc_heap_used(void)    { return heap_used; }
u64 cssc_frames_free(void)  { return free_frames; }
u64 cssc_frames_total(void) { return total_frames; }

/* ------------------------------------------------------------------ */
/* MMIO mapping — map a physical device BAR into the virtual address    */
/* space so CSSC drivers can peek/poke it. Limine's HHDM covers RAM,    */
/* NOT the PCI MMIO holes (e.g. an SDHCI BAR at 0xFEBC0000), so a raw    */
/* `hhdm + bar` access page-faults. We walk (and, where absent, build)  */
/* the active 4-level page tables and install 4 KiB, cache-disabled     */
/* mappings in a dedicated higher-half MMIO window.                     */
/* ------------------------------------------------------------------ */
#define MMIO_WINDOW_BASE  0xFFFFC00000000000ull  /* unused higher-half slot */
#define PTE_P             0x001ull   /* present            */
#define PTE_RW            0x002ull   /* writable           */
#define PTE_PWT           0x008ull   /* write-through      */
#define PTE_PCD           0x010ull   /* cache-disable      */
#define PTE_PS            0x080ull   /* huge page (PDPT/PD) */
#define PTE_ADDR_MASK     0x000FFFFFFFFFF000ull

/* Allocate one zeroed 4 KiB frame for a page table; returns phys addr (0 = OOM).
 * Starts at frame 1: physical frame 0 (address 0x0) is deliberately never handed
 * out because callers use 0 as the "allocation failed" sentinel. Under UEFI the
 * frame allocator would otherwise return frame 0 first (low RAM is usable there,
 * unlike legacy BIOS where it's reserved), and pt_next's `if (!tbl)` would then
 * mistake a valid page-table frame for OOM -> cssc_map_mmio fails -> every device
 * with a high 64-bit BAR (xHCI!) never maps. Reserving the zero page fixes it. */
static u64 pt_alloc_frame(void) {
    for (u64 f = 1; f < total_frames; f++) {
        if (!bm_test(f)) {
            bm_set(f);
            if (free_frames) free_frames--;
            u64 phys = f * PAGE;
            u64 *v = (u64 *)(cssc_hhdm_offset() + phys);
            for (int i = 0; i < 512; i++) v[i] = 0;
            return phys;
        }
    }
    return 0;
}

/* Ensure the child table below `entry` exists; return its phys base (0 = fail).
 * Refuses to descend into a huge-page mapping (our fresh window never has one). */
static u64 pt_next(u64 *entry) {
    if (*entry & PTE_P) {
        if (*entry & PTE_PS) return 0;               /* huge page — cannot split */
        return *entry & PTE_ADDR_MASK;
    }
    u64 tbl = pt_alloc_frame();
    if (!tbl) return 0;
    *entry = tbl | PTE_P | PTE_RW;
    return tbl;
}

/* Running virtual cursor into the MMIO window. Every mapping is placed here and
 * the cursor bumps forward, so the virtual address is DECOUPLED from the physical
 * BAR. The old scheme (vaddr = MMIO_WINDOW_BASE + phys) broke for 64-bit BARs at
 * very high physical addresses (e.g. a UEFI-assigned xHCI BAR at 0xC000000000 =
 * 768 GiB): MMIO_WINDOW_BASE + phys landed in a higher-half PML4 slot the firmware
 * had ALREADY populated (under UEFI, Limine inherits huge-page mappings there),
 * and pt_next refuses to split a huge page -> cssc_map_mmio returned 0 and the
 * controller never came up. 0 = "not chosen yet"; chosen lazily on first use. */
static u64 mmio_vcursor = 0;

/* Pick a completely FREE higher-half PML4 slot (entry not present => the whole
 * 512 GiB under it is unmapped, so our fresh table walk can never collide with a
 * firmware huge page). Returns the canonical base vaddr of that slot, or the old
 * fixed window as a last resort. Scans 384..510 first (well clear of the HHDM at
 * 256 and the kernel at 511), then 256..510. */
static u64 mmio_pick_window(u64 hhdm, u64 pml4_phys) {
    u64 *t4 = (u64 *)(hhdm + pml4_phys);
    for (u64 s = 384; s <= 510; s++) {
        if (!(t4[s] & PTE_P))
            return 0xFFFF000000000000ull | (s << 39);
    }
    for (u64 s = 256; s < 384; s++) {
        if (!(t4[s] & PTE_P))
            return 0xFFFF000000000000ull | (s << 39);
    }
    return MMIO_WINDOW_BASE;
}

/* Map [phys, phys+size) and return the virtual address of `phys` (0 = fail). */
u64 cssc_map_mmio(u64 phys, u64 size) {
    u64 hhdm = cssc_hhdm_offset();
    if (hhdm == 0 || size == 0) return 0;
    u64 cr3;
    __asm__ volatile ("mov %%cr3, %0" : "=r"(cr3));
    u64 pml4_phys = cr3 & PTE_ADDR_MASK;

    if (mmio_vcursor == 0)
        mmio_vcursor = mmio_pick_window(hhdm, pml4_phys);

    u64 base  = phys & ~(PAGE - 1);
    u64 pages = (size + (phys - base) + PAGE - 1) / PAGE;
    u64 vbase = mmio_vcursor;
    mmio_vcursor += pages * PAGE;

    for (u64 p = 0; p < pages; p++) {
        u64 v  = vbase + p * PAGE;
        u64 ph = base  + p * PAGE;
        u64 i4 = (v >> 39) & 0x1FF, i3 = (v >> 30) & 0x1FF;
        u64 i2 = (v >> 21) & 0x1FF, i1 = (v >> 12) & 0x1FF;

        u64 *t4 = (u64 *)(hhdm + pml4_phys);
        u64 pdpt = pt_next(&t4[i4]);            if (!pdpt) return 0;
        u64 *t3 = (u64 *)(hhdm + pdpt);
        u64 pd   = pt_next(&t3[i3]);            if (!pd)   return 0;
        u64 *t2 = (u64 *)(hhdm + pd);
        u64 pt   = pt_next(&t2[i2]);            if (!pt)   return 0;
        u64 *t1 = (u64 *)(hhdm + pt);
        t1[i1] = ph | PTE_P | PTE_RW | PTE_PWT | PTE_PCD;   /* uncached MMIO */
    }
    /* flush the TLB (reload CR3) so the new mappings take effect */
    __asm__ volatile ("mov %0, %%cr3" :: "r"(cr3) : "memory");
    return vbase + (phys - base);
}

/* ---- self-hosting execution primitive (Transembly) --------------------------
 * Make [addr, addr+size) EXECUTABLE: clear the NX bit (63) and set RW on the
 * page-table entries covering it. `addr` is a live HHDM heap virtual address
 * (from cssc::alloc), so the entries already exist -- we only relax them. The
 * HHDM is frequently mapped with 2 MiB / 1 GiB HUGE pages; we cannot split them
 * (pt_next refuses), so we clear NX on the huge entry itself -- coarser (the
 * whole huge region becomes executable) but correct for running emitted code.
 * If EFER.NXE is off, bit 63 is already 0 and this is a harmless no-op; a final
 * CR3 reload flushes the TLB. */
#define NX_BIT (1ull << 63)
void cssc_make_exec(u64 addr, u64 size) {
    u64 hhdm = cssc_hhdm_offset();
    if (hhdm == 0 || size == 0) return;
    u64 cr3;
    __asm__ volatile ("mov %%cr3, %0" : "=r"(cr3));
    u64 pml4_phys = cr3 & PTE_ADDR_MASK;
    u64 base  = addr & ~(PAGE - 1);
    u64 pages = (size + (addr - base) + PAGE - 1) / PAGE;
    for (u64 p = 0; p < pages; p++) {
        u64 v  = base + p * PAGE;
        u64 i4 = (v >> 39) & 0x1FF, i3 = (v >> 30) & 0x1FF;
        u64 i2 = (v >> 21) & 0x1FF, i1 = (v >> 12) & 0x1FF;
        u64 *t4 = (u64 *)(hhdm + pml4_phys);
        if (!(t4[i4] & PTE_P)) continue;
        u64 *t3 = (u64 *)(hhdm + (t4[i4] & PTE_ADDR_MASK));
        if (!(t3[i3] & PTE_P)) continue;
        if (t3[i3] & PTE_PS) { t3[i3] = (t3[i3] & ~NX_BIT) | PTE_RW; continue; } /* 1 GiB */
        u64 *t2 = (u64 *)(hhdm + (t3[i3] & PTE_ADDR_MASK));
        if (!(t2[i2] & PTE_P)) continue;
        if (t2[i2] & PTE_PS) { t2[i2] = (t2[i2] & ~NX_BIT) | PTE_RW; continue; } /* 2 MiB */
        u64 *t1 = (u64 *)(hhdm + (t2[i2] & PTE_ADDR_MASK));
        if (!(t1[i1] & PTE_P)) continue;
        t1[i1] = (t1[i1] & ~NX_BIT) | PTE_RW;                                    /* 4 KiB */
    }
    __asm__ volatile ("mov %0, %%cr3" :: "r"(cr3) : "memory");   /* TLB flush */
}
