"""Xtensa LX106 CIR → assembly emitter.

This is the v6 native backend for ESP8266 (Tensilica Xtensa LX106 core).
It bypasses the LLVM Xtensa upstream-experimental backend entirely —
stock LLVM ships without it — and emits Xtensa-LX106 assembly text
directly from our CIR. The assembly is then fed to the `xtensa-lx106-elf-as`
assembler (which ships with the GCC-based toolchain PlatformIO installs)
and linked with `ld.lld` (or `xtensa-lx106-elf-ld`) using the linker
script in [esp_link.py].

## Design principles

1. **No silent gaps.** Every CIR op has an explicit dispatch entry. Ops
   that aren't yet implemented raise `NotImplementedError` with a phase
   tag so it's obvious in the build output what's pending. We never
   emit `nop` or skip an op silently.
2. **Phased rollout.** Phases A–I in the project TODO map directly to
   sections of this module. Each phase fills in a slice of the
   dispatch table + corresponding runtime stubs.
3. **Hand-written, optimal.** This backend exists specifically to beat
   what a generic LLVM compile would produce for our value layout. Hot
   paths (`cssc_release_internal`, `cssc_retain`, string ops) get
   hand-tuned ASM. Cold paths use the same templated lowering as a
   compiler would.

## Xtensa LX106 — ISA quick-reference

The LX106 is a 32-bit dual-issue VLIW-flavoured RISC. ESP8266's
specific variant (also called L106 / Tensilica L106) supports:

* **24-bit instruction encoding** is the default; many ops have a
  16-bit narrow form (Code Density option).
* **No FPU.** All f64 work is software-emulated. We use `__adddf3` /
  `__subdf3` / `__muldf3` / `__divdf3` from the GCC runtime (libgcc.a,
  shipped with xtensa-lx106-elf-gcc) — the user already has these.
* **No MUL/DIV in some L106 builds.** Integer multiply lands via
  `__mulsi3`; signed divide via `__divsi3`. Both are tiny libgcc
  thunks; we declare them external.
* **Register windows** are *disabled* on ESP8266 (CALL0 ABI). We use
  the flat 16-register model. No `CALL8`/`CALL12` window rotation —
  every call uses `CALL0` and we save/restore registers explicitly.

### Register file (CALL0 ABI — what ESP8266 uses)

| Name   | Role                                    | Volatile? |
|--------|-----------------------------------------|-----------|
| a0     | Return address (stored by `CALL0`)      | volatile  |
| a1     | Stack pointer (SP)                      | preserved |
| a2..a7 | Argument / return registers (a2 = ret)  | volatile  |
| a8..a11| Scratch / temp                          | volatile  |
| a12..a15| Callee-saved registers                 | preserved |

* Function calls pass first 6 args in `a2..a7`. Further args spill to
  stack at `[a1, +0]..[a1, +N]`.
* Return value (32-bit) lives in `a2`. For 64-bit returns: low in `a2`,
  high in `a3` (LSB-first because Xtensa is little-endian).
* Float return: not applicable on LX106 (no FPU), so `f64` returns go
  via the integer pair `a2:a3` just like `i64`.

### Stack frame layout

Standard prologue (no register windows):

```
addi   a1, a1, -<frame_size>
s32i   a0, a1, <frame_size> - 4    ; save return PC
s32i   a12, a1, ...                ; save callee-saved if used
s32i   a13, a1, ...
...
<function body>
l32i   a0,  a1, <frame_size> - 4   ; restore return PC
l32i   a12, a1, ...
addi   a1, a1, <frame_size>
ret.n                              ; (narrow form of `ret`)
```

`frame_size` must be a multiple of 16 (Xtensa ABI alignment).

### Branch encoding limits

* `BEQI`, `BLTI`, etc. — conditional branches range ±256 bytes.
* `J <label>` (jump) — 18-bit signed offset, ±128 KB range.
* Crossing the range needs a trampoline. We never need it for our
  function-sized blocks; if we did, the assembler would relax to a
  jump-over-jump pattern automatically.

### Memory map (ESP8266)

| Region    | Start      | Use                            |
|-----------|------------|--------------------------------|
| IRAM      | 0x40100000 | Code that must run from RAM    |
| IROM      | 0x40200000 | Code that can run from flash   |
| DRAM      | 0x3FFE8000 | Static + heap (96 KB total)    |
| UART0 TX  | 0x60000000 | One-byte FIFO write            |

The boot stub in [esp_link.py] places `_start` at the beginning of
IRAM. Our `_cssc_user_main` lands there; data + bump heap go in DRAM.

### Narrow / wide instruction selection

The Code Density option (which the L106 has) provides a 16-bit narrow
form of many common instructions:

* `mov.n`, `add.n`, `addi.n`, `ret.n`, `nop.n`, `s32i.n`, `l32i.n`,
  `bnez.n`, `beqz.n`, `movi.n`, `or.n`

We use the narrow forms whenever the operand ranges fit. The assembler
sometimes can pick narrow forms automatically (`.opt`) but we'll be
explicit so the assembly reads predictably and tooling diffs cleanly.

### CSSC value layout (matches host)

`CsscVal = { i64 tag, i64 data }` — 16 bytes. On a 32-bit chip the i64
is two i32 words (lo, hi). The TAG_INT / TAG_FLOAT / … constants from
[../cir/types.py] are stable across hosts.

### CALL0 calling convention encoding

For each call site we:
1. Compute arg values into a8..a13 (scratch).
2. `mov` them into a2..a7 just before the call (so the call doesn't
   clobber computed values).
3. Emit `call0 <symbol>`.
4. The callee's prologue saves `a0` to the stack; we don't.
5. After return, `a2` (and `a3` for 64-bit) holds the result.

## Module surface

```python
emit_program(module, runtime_symbols, profile) -> str
    Returns one self-contained .s assembly text.

emit_runtime_min(profile) -> str
    Hand-written runtime stubs in Xtensa assembly. Phase A8 includes
    cssc_runtime_init, cssc_runtime_shutdown, cssc_uart_putc,
    cssc_print_int. Later phases extend this set.

supported_ops() -> set[str]
    Names of the CIR ops this backend currently handles. The dispatch
    table raises `NotImplementedError` for everything else with a
    clear "Phase X" tag so users can see the gap.
```

## Phase status (synced with TODO)

| Phase | Scope                                            | Status        |
|-------|--------------------------------------------------|---------------|
| A1    | ISA docs (this header)                           | done          |
| A2    | Register allocator                               | done (linear) |
| A3    | Dispatch shell (NotImplementedError per op)      | done          |
| A4    | ConstInt + SlotAlloc/Store/Load (int)            | done          |
| A5    | Ret + Call (POD args)                            | done          |
| A6    | BinOp/CmpOp int                                  | done          |
| A7    | Br/BrCond + block labels                         | done          |
| A8    | Minimal runtime (UART, print_int)                | done          |
| A9    | v6_driver routing                                | done          |
| A10   | Smoke test                                       | pending       |
| B*    | f64 / strings / heap / time / bool               | pending       |
| C*    | containers / sectors / objects                   | pending       |
| D*    | GPIO / I2C / SPI / UART / ADC / PWM / Timer MMIO | pending       |
| E*    | TFT / OLED / video / matrix / framebuffer / cons | pending       |
| F*    | ESP32 LX7 / AVR variants                         | pending       |
| G*    | Direct ELF emission                              | pending       |
| H*    | esptool .bin wrap                                | partial       |
| I*    | Flash protocol                                   | pending       |

Any CIR op outside this set lands with a `NotImplementedError` that
carries the phase tag. Look at `_OP_HANDLERS` to see the full table.
"""
from __future__ import annotations

import os

from typing import Any, Dict, List, Optional, Set, Tuple

from ..cir.ops import (
    Op, Block, Function, Module,
    ConstInt, ConstFloat, ConstBool, ConstStr,
    WrapInt, WrapFloat, WrapBool,
    SlotAlloc, SlotStore, SlotLoad, SlotRelease, SlotRetain,
    ScopePush, ScopePop, ScopeBind,
    Call, CsscOutln,
    BinOp, CmpOp,
    GlobalAddr, MemberAddr,
    Br, BrCond, Ret, Unreachable,
)
from ..cir.types import (
    INT64, INT32, INT8, FLOAT64, BOOL, PTR, STRING_PTR, CSSCVAL, VOID,
)


# ---------------------------------------------------------------------------
# A2 — Register allocator
#
# Linear-scan allocation over the 14 useful GPRs (a2..a15; a0=RA, a1=SP).
# Each SSA id maps to a (register | spill-slot). Live-ranges are tracked
# by first/last use index within a block; allocation runs per-block.
#
# Strategy:
#   * Scratch values prefer a8..a11 (volatile across calls).
#   * Long-lived values prefer a12..a15 (callee-saved — survive calls).
#   * Arg-passing values move into a2..a7 right before each call.
#   * Spills go to slots in the frame's locals area at `a1 + spill_off`.
#
# The CIR is SSA — every value has exactly one definition, so liveness
# is straightforward. Multi-block lifetimes (phi-resolution) currently
# spill across block boundaries; an enhanced pass can hoist short-lived
# cross-block values into preserved regs.
# ---------------------------------------------------------------------------
## Register class partition.
#
# Hardware reality on the L106 (CALL0 ABI):
#   a0/a1  reserved (return PC / stack pointer)
#   a2..a7 call-clobbered argument/return slots
#   a8..a15 general-purpose; a12..a15 callee-saved by convention
#
# Codegen partition (this backend):
#   `HANDLER_SCRATCH`  — registers individual op handlers freely use
#                        for staging values mid-expression. The
#                        allocator NEVER hands these out to SSA values
#                        so a handler can always grab them without
#                        spilling a live SSA value first.
#   `ALLOC_REGS`       — the pool the allocator draws from for SSA
#                        values. Callee-saved, so they survive `call0`
#                        instructions without explicit save/restore at
#                        the call site (the callee's prologue saves
#                        them if it clobbers them). With more than 3
#                        live SSA values the spill path takes over.
#   `WIDE_OFFSET_SCRATCH` (a15) — reserved as the dedicated scratch
#                        register for `s32i`/`l32i` widening when a
#                        frame slot's offset exceeds the wide encoding
#                        limit (1020 bytes). Held back from the
#                        allocator AND from `HANDLER_SCRATCH` so the
#                        post-process widener can rewrite an
#                        out-of-range `s32i.n REG, a1, OFF` to
#                        `addmi a15, a1, OFF_HIGH; s32i REG, a15, OFF_LOW`
#                        WITHOUT any liveness analysis — a15 is
#                        guaranteed dead at every program point because
#                        no other code path is allowed to write it.
#                        This unblocks multi-KB stack frames cleanly;
#                        the cost is one fewer callee-saved register
#                        available to the linear-scan allocator (more
#                        spills on register-pressured functions).
#   `ARG_REGS`         — arg/return passing for `call0`. Materialised
#                        just before each call by a handler; volatile
#                        across the call.
#
# The strict partition keeps the codegen correct without live-range
# analysis: handler scratch and SSA-allocated regs never share, the
# wide-offset scratch never moves, so nothing live in one can be
# clobbered by the other.
HANDLER_SCRATCH      = ['a8', 'a9', 'a10', 'a11']
ALLOC_REGS           = ['a12', 'a13', 'a14', 'a15']
WIDE_OFFSET_SCRATCH  = 'a15'
# Legacy aliases retained so existing call sites keep working — both
# names now refer to the new partition.
SCRATCH_REGS    = ALLOC_REGS   # historical name — was: "scratch for SSA"
PRESERVED_REGS  = ALLOC_REGS
ARG_REGS        = ['a2', 'a3', 'a4', 'a5', 'a6', 'a7']


class _RegAlloc:
    """Per-function register allocator with native i64/f64 pair support.

    Each SSA value has a *width* (32 or 64). 32-bit values take one
    GPR; 64-bit values take a pair (lo, hi) with consecutive register
    numbers preferred but not required. Spills land in the per-frame
    spill area at a 4-byte (32-bit value) or 8-byte (64-bit pair)
    aligned offset.

    Why no register-window machinery? ESP8266 boot the LX106 with the
    CALL0 ABI — register windows disabled. We have a flat 16-register
    file (a0..a15) of which a0/a1 are reserved (RA/SP), a2..a7 are
    call-clobbered argument registers, a8..a11 are call-clobbered
    scratch, and a12..a15 are callee-saved. We track which of the
    callee-saved set we touched so the prologue saves only what's
    needed (no blanket-save penalty).

    Why pairs are tracked separately from singles? An i64 value
    needs simultaneous access to BOTH halves for any arithmetic op
    that propagates carry — adding the halves separately requires
    that the low-add result is still reachable when the high-add
    runs. The simplest correct way is to keep both halves alive
    together until the SSA value dies. The allocator therefore
    treats a pair as an atomic unit; it never spills just one half.
    """

    def __init__(self) -> None:
        # 32-bit single-reg map: SSA id → register name (a8/a9/.../a15).
        self.id_to_reg:    Dict[int, str] = {}
        # 64-bit paired-reg map: SSA id → (lo_reg, hi_reg).
        self.id_to_pair:   Dict[int, Tuple[str, str]] = {}
        # Spill slot map: SSA id → byte offset from a1.
        # For 64-bit values the offset addresses the LO word; HI is at +4.
        self.id_to_spill:  Dict[int, int] = {}
        self.id_spill_64:  Set[int] = set()      # which spills are i64
        self.next_spill:   int = 0               # bytes; multiple of 4
        # Free-pool. Each register can be in at most one free list.
        # Both pools are the same (a12..a15) — the historical scratch/
        # preserved split disappeared once we partitioned handler-scratch
        # off into its own register class. We keep two list-views so
        # the `long_lived` hint still influences allocation order
        # (long-lived prefers a15 → a12, short-lived a12 → a15) which
        # in practice gives slightly better register reuse.
        self.free_scratch:   List[str] = list(ALLOC_REGS)
        self.free_preserved: List[str] = list(reversed(ALLOC_REGS))
        self.used_preserved: Set[str] = set()    # for prologue/epilogue
        # Track set membership so a single register can't appear in both
        # lists after a release.
        self._free_set: Set[str] = set(ALLOC_REGS)

    # ----- 32-bit allocation -------------------------------------------
    def take_32(self, ssa_id: int, *, long_lived: bool = False) -> str:
        """Allocate a 32-bit register (or spill slot) for `ssa_id`."""
        if ssa_id in self.id_to_reg:
            return self.id_to_reg[ssa_id]
        if ssa_id in self.id_to_pair:
            # The value was already paired — return the low half.
            return self.id_to_pair[ssa_id][0]
        r = self._take_one(long_lived=long_lived)
        if r is None:
            off = self._reserve_spill(8 if False else 4)
            self.id_to_spill[ssa_id] = off
            return f'[spill+{off}]'
        self.id_to_reg[ssa_id] = r
        return r

    # ----- 64-bit (paired) allocation ----------------------------------
    def take_64(self, ssa_id: int, *, long_lived: bool = False) -> Tuple[str, str]:
        """Allocate a pair of 32-bit registers for an i64/f64 value.

        Prefers consecutive registers (a8+a9, a10+a11, …) so future
        passes can fold them into a single LDM-style hardware load if
        we ever add one — but works with any two available regs.
        """
        if ssa_id in self.id_to_pair:
            return self.id_to_pair[ssa_id]
        if ssa_id in self.id_to_reg:
            # Promote a previously-32 SSA id to 64: keep the lo register,
            # grab a fresh one for hi.
            lo = self.id_to_reg.pop(ssa_id)
            hi = self._take_one(long_lived=long_lived)
            if hi is None:
                # No more regs — spill the whole pair.
                self._return_reg(lo)
                off = self._reserve_spill(8)
                self.id_to_spill[ssa_id] = off
                self.id_spill_64.add(ssa_id)
                return (f'[spill+{off}]', f'[spill+{off + 4}]')
            self.id_to_pair[ssa_id] = (lo, hi)
            return (lo, hi)
        lo = self._take_one(long_lived=long_lived)
        if lo is None:
            off = self._reserve_spill(8)
            self.id_to_spill[ssa_id] = off
            self.id_spill_64.add(ssa_id)
            return (f'[spill+{off}]', f'[spill+{off + 4}]')
        hi = self._take_one(long_lived=long_lived)
        if hi is None:
            # Partial spill — return lo, spill hi. Edge case: we'd
            # rather have BOTH in registers, but if no register
            # remains for hi we keep lo (warm cache) and spill hi.
            self._return_reg(lo)
            off = self._reserve_spill(8)
            self.id_to_spill[ssa_id] = off
            self.id_spill_64.add(ssa_id)
            return (f'[spill+{off}]', f'[spill+{off + 4}]')
        self.id_to_pair[ssa_id] = (lo, hi)
        return (lo, hi)

    def release(self, ssa_id: int) -> None:
        """Return registers/spill to the pool when the SSA value is dead.
        SSA dataflow is single-assignment so once an op's last user has
        consumed the value it's safe to reclaim."""
        if ssa_id in self.id_to_reg:
            self._return_reg(self.id_to_reg.pop(ssa_id))
        if ssa_id in self.id_to_pair:
            lo, hi = self.id_to_pair.pop(ssa_id)
            self._return_reg(lo)
            self._return_reg(hi)
        # Note: we deliberately don't reclaim spill slots in this
        # pass — frame slots are scarce relative to register pressure,
        # but a smarter pass could coalesce.

    # ----- Internals --------------------------------------------------
    def _take_one(self, *, long_lived: bool = False) -> Optional[str]:
        """Allocate one register from the shared a12..a15 pool.

        `long_lived` flips the allocation order so long-lived values
        prefer a15 (less likely to collide with short-lived spills
        in our predictable use patterns). Either way the register
        comes from the same pool and is callee-saved.
        """
        # Both lists share the same underlying register set tracked by
        # `_free_set`; we pop from whichever the caller's preference
        # suggests and remove from the set.
        if long_lived:
            for r in self.free_scratch[:]:
                if r in self._free_set:
                    self._free_set.discard(r)
                    self.free_scratch.remove(r)
                    if r in self.free_preserved:
                        self.free_preserved.remove(r)
                    self.used_preserved.add(r)
                    return r
        else:
            for r in self.free_preserved[:]:
                if r in self._free_set:
                    self._free_set.discard(r)
                    self.free_preserved.remove(r)
                    if r in self.free_scratch:
                        self.free_scratch.remove(r)
                    self.used_preserved.add(r)
                    return r
        return None

    def _return_reg(self, r: str) -> None:
        if r.startswith('[') or r in self._free_set:
            return
        self._free_set.add(r)
        # Restore in stable order so test output is deterministic.
        idx = ALLOC_REGS.index(r)
        # Both lists view the same pool; reinsert.
        if r not in self.free_scratch:
            self.free_scratch.insert(idx, r)
        if r not in self.free_preserved:
            self.free_preserved.insert(len(ALLOC_REGS) - 1 - idx, r)

    def _reserve_spill(self, bytes_: int) -> int:
        # 8-byte values need 8-byte alignment so SlotLoad of the i64
        # pair sees consecutive words on a 32-bit-aligned chip.
        if bytes_ == 8 and (self.next_spill & 7):
            self.next_spill += 4   # pad up to 8-byte alignment
        off = self.next_spill
        self.next_spill += bytes_
        # Bounds-check: if `emit_function` set a `spill_limit`,
        # honor it so an under-sized spill area produces an emitter
        # error instead of silent stack corruption.
        limit = getattr(self, 'spill_limit', None)
        if limit is not None and self.next_spill > limit:
            raise RuntimeError(
                f'Xtensa spill area exhausted: requested {bytes_}B at '
                f'offset 0x{off:x}, limit 0x{limit:x}. Increase the '
                f'spill_estimate pre-flight in emit_function.'
            )
        return off


# ---------------------------------------------------------------------------
# A3 — CIR-op dispatch shell. One handler per CIR op type. Anything
# unmapped raises with a phase tag so the build output tells the user
# exactly which CIR op needs porting.
# ---------------------------------------------------------------------------
class XtensaEmitter:
    """Per-program emitter. Holds the assembly text + per-function state."""

    def __init__(self) -> None:
        self.lines: List[str] = []
        self.regs: _RegAlloc = _RegAlloc()
        self.slot_offsets: Dict[int, int] = {}   # SSA-id of SlotAlloc → frame offset
        self.frame_size: int = 0
        self.string_pool: Dict[str, str] = {}    # label → text
        # `literal_pool` accumulates `.literal LABEL, <value>` lines
        # that the L32R-materialiser needs. Each entry can be:
        #   * an int (numeric constant → `.literal label, <int>`)
        #   * a str (symbol name → `.literal label, <sym>` — linker resolves)
        # Emitted at the end of each function so PC-relative L32R can
        # find them in range (32 KB).
        self.literal_pool: List[Tuple[str, Any]] = []
        self.next_str_idx: int = 0
        # The active Module — set by `emit_program` before each function
        # is emitted. Handlers like `_h_member_addr` read it for the
        # struct-types map; setting it as an attribute (rather than
        # threading it through every signature) keeps the handler
        # signatures uniform `(em, op, fn)`.
        self._current_module: Optional[Module] = None
        # Active chip profile. emit_program() sets these so per-op
        # handlers can pick chip-specific codegen paths (e.g. FPU
        # instructions on ESP32 LX7 vs libgcc soft-float thunks on
        # ESP8266 LX106). emit_program() always overrides; the
        # placeholders here keep type-checkers happy.
        self.profile_name: str = 'esp8266'
        self.profile: Dict[str, Any] = {}
        # Tracks any extra SP-offset added (e.g. while `_h_call` has
        # adjusted a1 down to make room for outgoing stack args). All
        # spill-relative loads/stores add this to their frame offset
        # so they still hit the original slot.
        self._sp_displacement: int = 0
        # Whether the current function manages its own arena scope.
        # Set per-function by `emit_function`; consulted by `_h_ret`.
        self._use_scope: bool = False
        # Trace mode: when True, every emitter-produced user function
        # (cssc_user_*, cssc_obj_*, cssc_sec_*) gets a `> fnname\n`
        # printf injected at the prologue's end and `< fnname\n` at
        # the epilogue's start. The chip's UART then transmits a
        # call-stack trace as a side channel; on a crash the LAST
        # unmatched `>` tells you exactly which function held control
        # when the chip lost it. Hand-written runtime symbols
        # (cssc_string_*, cssc_obj_alloc, …) are NOT instrumented —
        # they're hot helpers and their trace volume would dominate.
        self.trace_mode: bool = False
        # `--diag-mem` runtime instrumentation. When True, every
        # user / object / sector function entry gets a `call0
        # cssc_diag_mem_check(fn_id)` injection. The chip emits
        # `[cssc-mem] fn=<id> arena=<off> sp=<sp>` per call; the
        # host-side post-processor watches for growth across
        # calls of the same fn to pinpoint scope-leak / stack-leak
        # bugs that static audits can't see (e.g. the videodriver
        # uptime=2.619 crash). Cost: ~30 UART putcs per check.
        # Default OFF to keep production firmware tight.
        self.diag_mem: bool = False
        # Per-function id assignment for diag-mem. fn_id 1..N — 0
        # reserved for "not instrumented".
        self._diag_mem_fn_ids: Dict[str, int] = {}
        self._diag_mem_next_id: int = 1
        # `--diag-mem-trace` per-CIR-op runtime trace. When True (and
        # diag_mem is also True), every potentially-faulting CIR op
        # gets a `[cssc-trace] op=<id>` marker emitted BEFORE the op
        # itself. The chip's last logged op_id pinpoints the exact
        # source line that crashed — closes the gap between per-fn
        # `[cssc-mem]` (function granularity) and the addr2line
        # roundtrip (instruction granularity but needs the .elf).
        # Cost: ~25 UART putcs per op. UART floods at 74880 baud, so
        # default OFF. Implies `diag_mem` (the sidecar map subsets).
        self.diag_mem_trace: bool = False
        # Per-op id assignment for diag-mem-trace. op_id 1..N — used
        # to resolve "last logged op before crash" → source line via
        # the sidecar `.diag-trace-map.txt`. The op map is emitted as
        # `; DIAG-TRACE-MAP op=<N> fn=<sym> src=L<line> kind=<op-kind>`
        # comments at the end of the user.s; the host build extracts
        # those lines into the sidecar file (see v6_driver.py).
        self._trace_op_next_id: int = 1
        self._trace_op_map: List[Tuple[int, str, int, str]] = []
        # Counter for generating unique trace-string labels per
        # function. Each instrumented function emits one .Lstr_trace_<n>
        # symbol pointing at its `> name\n` rodata payload.
        self._trace_str_counter: int = 0
        # Accumulator for trace-name string literals — emitted to
        # .rodata at the end of emit_program (so a single section
        # transition handles all of them).
        self._trace_strings: List[Tuple[str, str]] = []

    def emit(self, line: str) -> None:
        self.lines.append(line)

    def _emit_trace_enter(self, fn_name: str) -> None:
        """Emit the `> fn_name\\n` UART print at function-entry.

        Uses a per-function string-literal label stashed in
        `self._trace_strings`, materialised into `.rodata` after the
        last function emits. The injection assumes:
          * a0 has just been saved to the frame by the surrounding
            prologue (we don't reload it).
          * a2/a3 are caller-save and free to clobber.
          * `cssc_print_str(ptr, i64-len)` expects a2=ptr, a4=len_lo
            (per CSSC-Xtensa CALL0 ABI: ptr+i64 → a2, a4:a5).
        """
        payload = f'> {fn_name}'
        idx = self._trace_str_counter
        self._trace_str_counter += 1
        label = f'.Lstr_trace_{idx}'
        lit_label = f'.Ltrace_{idx}'
        # Stash for later .rodata emission. The trailing newline keeps
        # each event on its own line in the host's listener output.
        self._trace_strings.append((label, payload + '\n'))
        self.literal_pool.append((lit_label, label))
        # cssc_print_str's signature is `(ptr, i64 len)` — under the
        # pair-align CALL0 ABI used by every CIR-emitted call site,
        # that lays out as `a2 = ptr, a4 = len_lo, a5 = len_hi`
        # (a3 is the pair-align skip). The hand-written runtime
        # `cssc_print_str` reads len from a4 to match. The trace-
        # call here uses the same convention so all callers (CIR-
        # emitted user code AND runtime-internal trace) agree.
        # Pre-fix this site put len in a3, which silently went
        # nowhere because the function actually reads a4 — strings
        # printed nothing.
        self.emit(f'  l32r    a2, {lit_label}'
                  f'    # trace enter: "{payload}"')
        self.emit(f'  movi    a4, {len(payload) + 1}'
                  f'    # len.lo (pair-align skips a3)')
        self.emit(f'  movi    a5, 0'
                  f'                # len.hi = 0 (always)')
        self.emit(f'  call0   cssc_print_str')

    def _emit_diag_mem_enter(self, fn_name: str) -> None:
        """`--diag-mem` per-function-entry mem-check call.

        Assigns the function a stable small integer id (so the chip
        emits compact lines instead of full function names), then
        emits:
          movi  a2, <fn_id>
          call0 cssc_diag_mem_check

        The runtime helper (cssc_diag_mem_check in xtensa runtime
        asm) reads the arena cursor + caller's SP and prints a
        single `[cssc-mem] fn=<id> arena=<off> sp=<sp>` line.

        Host-side post-processor pairs `fn=<id>` back to the
        function symbol via the id table dumped at end of asm.
        """
        if fn_name not in self._diag_mem_fn_ids:
            self._diag_mem_fn_ids[fn_name] = self._diag_mem_next_id
            self._diag_mem_next_id += 1
        fid = self._diag_mem_fn_ids[fn_name]
        self.emit(f'  movi    a2, {fid}'
                  f'             # diag-mem fn_id for "{fn_name}"')
        self.emit(f'  call0   cssc_diag_mem_check')

    def _emit_diag_trace_op(self, op_kind: str, fn_name: str,
                             src_line: int) -> None:
        """`--diag-mem-trace` per-op marker emission.

        Emitted BEFORE the underlying op handler runs. Skipped when:
          * the flag is off,
          * the op_kind is not in the traceable allow-list,
          * a stack-arg displacement is currently live (a1 is shifted
            for outgoing args) — emitting a `call0` mid-shift would
            corrupt the in-flight call.

        Assigns each marker a stable id (`op_id`) and records the
        (op_id, fn_name, src_line, op_kind) mapping for the sidecar
        `.diag-trace-map.txt`.
        """
        if not self.diag_mem_trace:
            return
        if op_kind not in _TRACEABLE_OP_KINDS:
            return
        # Refuse to emit while an outgoing-stack-args region is live —
        # the `call0 cssc_diag_trace_op` itself would corrupt the
        # in-flight call's stack args (which sit at a1+0..stack_bytes
        # in the displaced frame). The trace point migrates upward to
        # the next safe insertion site automatically (we just skip
        # here; the next dispatched op without displacement will get a
        # marker).
        if self._sp_displacement != 0:
            return
        op_id = self._trace_op_next_id
        self._trace_op_next_id += 1
        self._trace_op_map.append((op_id, fn_name, src_line, op_kind))
        self.emit(f'  movi    a2, {op_id}'
                  f'    # diag-trace {op_kind}@L{src_line}')
        self.emit(f'  call0   cssc_diag_trace_op')

    @staticmethod
    def _function_is_traceable(name: str) -> bool:
        """True if this function should get trace-instrumentation in
        `--trace` mode.

        Whitelist: every emitter-produced user function — `cssc_user_*`
        (#define bodies + `cssc_user_main`), `cssc_obj_*` (object ctors
        and label methods), `cssc_sec_*` (sector functions). Hand-
        written runtime symbols (cssc_string_lit, cssc_obj_alloc,
        cssc_array_bind_*, cssc_i2c_*, cssc_tft_*, etc.) are excluded:
        they're high-frequency hot helpers and their trace volume would
        drown the UART even at 921 kbaud, plus we can't safely inject
        a function-call into hand-written CALL0 assembly without
        knowing the exact a-register liveness.

        Internal helpers (cssc_scope_push, cssc_retain, cssc_release,
        ABI thunks) are also excluded — they're called inside the
        instrumented function's own prologue/epilogue and would
        recurse into the tracer.
        """
        if name in ('cssc_user_main',):
            return True
        if name.startswith('cssc_obj_') and not name.endswith('_release_members'):
            return True
        if name.startswith('cssc_user_'):
            return True
        if name.startswith('cssc_sec_'):
            return True
        return False

    @staticmethod
    def _function_owns_scope(name: str) -> bool:
        """Should this function bracket its body with scope_push/pop?

        Object constructors (`cssc_obj_<Type>_ctor`) NEVER push a scope
        — they allocate persistent object-member values whose pointers
        the caller stashes in the object struct. Everything else
        emitter-produced (the entry function `cssc_user_main`, every
        object label method `cssc_obj_<Type>_<label>` for label != ctor,
        every `#define` body `cssc_user_<name>`, every sector function
        `cssc_sec_<Sector>_<name>`) DOES push. Runtime helpers
        (cssc_string_lit / cssc_string_concat / cssc_float_to_str /
        cssc_obj_alloc / etc.) live in the runtime-asm template and
        don't go through `emit_function`, so they automatically allocate
        in the caller's scope — which is the contract we want for them.

        A.2.3: `cssc_user_*` and `cssc_sec_*` added so transient heap
        temps inside a #define or sector body don't leak into the
        caller's scope across hot-loop invocations.
        """
        if name == 'cssc_user_main':
            return True
        if name.startswith('cssc_obj_'):
            return not name.endswith('_ctor')
        if name.startswith('cssc_user_'):
            return True
        if name.startswith('cssc_sec_'):
            return True
        return False

    def emit_function(self, fn: Function) -> None:
        # Fresh per-function alloc state.
        self.regs = _RegAlloc()
        self.slot_offsets = {}

        # ---- Plan: walk ops twice. First pass tallies frame size
        # (sum of every SlotAlloc + register-spill slots reserved by
        # the allocator). Second pass emits the actual assembly.
        # The two-pass approach lets the prologue declare the final
        # frame size up front. -----------------------------------
        frame_locals = 0
        for blk in fn.blocks:
            for op in blk.ops:
                if isinstance(op, SlotAlloc):
                    self.slot_offsets[op.id] = frame_locals
                    frame_locals += _slot_bytes(op)
        # Round locals up to 8-byte alignment (i64 spills need 8-aligned
        # offsets). The spill area lives ABOVE the locals so the two
        # allocators never share a byte — stack-allocated CIR slots
        # are referenced by pointer (each SlotAlloc returns a ptr
        # into the frame), so overlapping with spill writes would
        # silently corrupt the slot contents.
        locals_aligned = (frame_locals + 7) & ~7

        # Pre-flight the spill allocator over the entire function so
        # we know the final spill-area size before emitting any code.
        # Conservatively assume every SSA result that lacks a free
        # register ends up spilled — we count i64/f64/csscval as 8
        # bytes (with 8-byte alignment padding) and everything else
        # as 4. The result is an upper bound on what
        # `_RegAlloc._reserve_spill` will demand, plus generous
        # headroom so out-going-stack-arg areas allocated by
        # `_h_call` never extend past the saved-PC slot.
        spill_estimate = 0
        max_stack_call = 0
        # Incoming function parameters are SSA ids 0..N-1 and each one
        # gets a spill slot during the param-binding pass (i64/f64 take
        # 8-byte-aligned 8B slots, scalar / ptr take 4B). The estimator
        # MUST account for these or wide-signature functions
        # (`addframe<int, string, int>` etc.) hit the spill cap before
        # the body's own slots are even allocated.
        for _pname, ptype in fn.params:
            if _is_pair_kind(ptype.kind):
                if spill_estimate % 8 != 0:
                    spill_estimate += 4
                spill_estimate += 8
            else:
                spill_estimate += 4
        for blk in fn.blocks:
            for op in blk.ops:
                rt = getattr(op, 'result_type', None)
                if rt is not None and not rt.is_void():
                    if _is_pair_kind(rt.kind):
                        # Pad to 8-byte and consume 8.
                        if spill_estimate % 8 != 0:
                            spill_estimate += 4
                        spill_estimate += 8
                    elif rt.kind not in ('void', 'ptr', 'string_ptr',
                                          'i1', 'i8'):
                        spill_estimate += 4
                    else:
                        spill_estimate += 4
                # Track outgoing stack-arg block for any call site.
                if isinstance(op, Call):
                    _, n_stack = _arg_reg_layout(op.arg_types or [])
                    max_stack_call = max(max_stack_call, n_stack * 4)
        # Round outgoing-stack-arg block to 16 bytes — `_h_call`
        # always allocates a multiple of 16 to keep ABI alignment.
        max_stack_call = (max_stack_call + 15) & ~15
        spill_area = max(64, (spill_estimate + 15) & ~15)
        saved_pc = 4
        # CALL0 ABI: a12..a15 are callee-save. Any callee that clobbers
        # one must save/restore it. We reserve 16 bytes of fixed save
        # area for a12..a15 between the spill area and the saved-PC
        # slot; the prologue emits stores only for those that the body
        # actually used, the epilogue emits matching loads.
        saved_callee = 16
        # +16 ABI safety margin sits between spill area and the
        # callee-save area so very late spills don't tread on it.
        raw = (locals_aligned + spill_area + saved_callee
               + saved_pc + 16 + max_stack_call)
        self.frame_size = (raw + 15) & ~15
        # Anchor spill offsets at the start of the spill area so they
        # never overlap stack-allocated slots.
        self.regs.next_spill = locals_aligned
        # Hard upper-bound the spill allocator at the saved-PC slot —
        # any further spill request triggers an allocator-bug error
        # at emit time rather than a silent stack-corruption crash
        # on real hardware.
        self.regs.spill_limit = locals_aligned + spill_area
        self._spill_area_end = self.regs.spill_limit
        # Fixed offsets for callee-save preservation.
        # Layout (highest offset = top of frame):
        #   [frame_size - 4]  : saved a0 (RA)
        #   [frame_size - 8]  : saved a15
        #   [frame_size - 12] : saved a14
        #   [frame_size - 16] : saved a13
        #   [frame_size - 20] : saved a12
        # These four slots live just below the saved-PC slot, inside
        # the 16-byte saved_callee area we just reserved.
        self._cs_offsets = {
            'a15': self.frame_size - 8,
            'a14': self.frame_size - 12,
            'a13': self.frame_size - 16,
            'a12': self.frame_size - 20,
        }

        # Three-pass body emission: capture param-binding (the moves
        # that pull args out of a2..a7 into their assigned SSA regs)
        # SEPARATELY from the rest of the body. We need that separation
        # because the optional trace-mode injection (`> name\n` print)
        # clobbers a2/a3 via `cssc_print_str` — if the trace fires
        # BEFORE param-binding has saved the incoming args, the body
        # ends up using `cssc_print_str`'s return value as `self`,
        # which is small-positive and faults at offset+8.
        #
        # Emission layout:
        #   1. Prologue (frame setup + callee-save spill + scope_push)
        #   2. param_binding_buf — drained args from a2..a7 to SSA regs
        #   3. trace-enter (if --trace) — now safe to clobber a2..a7
        #   4. body_buf — all CIR ops
        saved_lines = self.lines
        body_buf: List[str] = []
        param_binding_buf: List[str] = []
        self.lines = body_buf

        # CRITICAL: set `_use_scope` BEFORE the body walk. `_h_ret`
        # reads this flag to decide whether to emit `cssc_scope_pop`,
        # and the body walk is where every Ret op is materialised.
        # Setting it AFTER the walk meant the body inherited the
        # PREVIOUS function's value — so when `cssc_user_main` (which
        # owns a scope) was emitted before `cssc_obj_T_ctor` (which
        # MUST NOT pop a scope it never pushed), the ctor's epilogue
        # ended up calling `cssc_scope_pop` with sp=0 underflowing
        # the stack, then writing junk back into `cssc_arena_off`.
        # The next allocator call returned a wildly wrong pointer
        # and every downstream framebuffer write smashed adjacent
        # memory.
        self._use_scope = self._function_owns_scope(fn.name)

        # Param-binding: function args arrive in a2..a7. We move them
        # into the SSA-id register the allocator picks. For now we
        # eagerly spill all args to their assigned slots/regs — a
        # later pass can elide moves when the param's first use is
        # already in the right register.
        #
        # CRITICAL: the layout MUST match `_arg_reg_layout` (used by
        # `_h_call` for call-site arg materialisation). That layout is
        # **pair-aligned**: i64/f64 args must start on an even-numbered
        # arg slot so they form a natural register pair (a2:a3, a4:a5,
        # a6:a7). When an odd slot is unfilled before a wide arg, that
        # slot stays empty rather than being claimed by the wide value.
        #
        # An earlier version of this prologue advanced a naive cursor
        # by `slots_needed`, ignoring the pair-alignment skip. For a
        # function with signature `(self: ptr, y: i64, txt: ptr)` the
        # caller puts {self in a2, y in a4:a5, txt in a6} while the
        # naive callee read {self in a2, y in a3:a4, txt in a5}, so
        # the callee saw self correctly but treated `a3` as y_lo
        # (garbage), `a4` as y_hi (actually y_lo), and `a5` as txt
        # (actually y_hi = 0). The OLED rendering then crashed on a
        # null string ptr. This affected every label method with an
        # explicit numeric param (e.g. `addframe<int: y, string: txt>`)
        # and every `#cdefine`-generated user function whose signature
        # mixed scalar and ptr args.
        # Route param-binding moves into their own buffer so the
        # trace-injection later can sit between them and the body
        # (see "Three-pass body emission" comment above).
        self.lines = param_binding_buf
        arg_reg_cursor = 0
        # Stack-arg byte offset, RELATIVE to the caller's stack-arg block
        # (which sits at our `a1 + frame_size`). Mirrors the layout the
        # call-site emitter (`_h_call`) produces: i64/f64 stack args are
        # 8-byte-aligned, ptr/scalar stack args are 4-byte tight.
        stack_arg_off = 0
        for i in range(len(fn.params)):
            ptype = fn.params[i][1]
            wide = _is_pair_kind(ptype.kind)
            slots_needed = 2 if wide else 1
            # Pair-align: if a wide arg's slot would land on an odd
            # register (a3, a5, …), skip one to align to (a4, a6, …).
            if wide and arg_reg_cursor % 2 != 0:
                arg_reg_cursor += 1
            if arg_reg_cursor + slots_needed <= len(ARG_REGS):
                # Fits in argument registers — emit register-to-SSA moves
                # via the existing helpers.
                src_lo = ARG_REGS[arg_reg_cursor]
                if wide:
                    src_hi = ARG_REGS[arg_reg_cursor + 1]
                    self._store_from_pair_to_ssa(i, src_lo, src_hi)
                else:
                    self._store_from_reg_to_ssa(i, src_lo)
                arg_reg_cursor += slots_needed
            else:
                # Overflow — stack-passed. Caller wrote the value into
                # its outgoing stack-arg block at [caller_sp + off]; from
                # our prologue we see that at [a1 + frame_size + off].
                # i64 args are 8-byte aligned (mirrors _h_call's stride);
                # ptr/scalar args are 4-byte tight.
                if wide and stack_arg_off % 8 != 0:
                    stack_arg_off += 4
                base_off = self.frame_size + stack_arg_off
                if wide:
                    # Load lo/hi from [a1 + base_off]/[a1 + base_off + 4]
                    # via a8/a9 scratch then forward to the SSA pair.
                    self.emit(f'  l32i.n  a8, a1, {base_off}'
                              f'    ; stack-arg #{i} lo')
                    self.emit(f'  l32i.n  a9, a1, {base_off + 4}'
                              f'    ; stack-arg #{i} hi')
                    self._store_from_pair_to_ssa(i, 'a8', 'a9')
                    stack_arg_off += 8
                else:
                    self.emit(f'  l32i.n  a8, a1, {base_off}'
                              f'    ; stack-arg #{i}')
                    self._store_from_reg_to_ssa(i, 'a8')
                    stack_arg_off += 4
                # Once we've spilled past a7, all subsequent args also
                # go on the stack — clamp the register cursor so the
                # next iteration takes the stack path immediately.
                arg_reg_cursor = len(ARG_REGS)

        # Switch back to body_buf for the actual CIR-op emission.
        self.lines = body_buf

        # ---- Body ----
        for blk in fn.blocks:
            self.emit(f'.L{fn.name}__{blk.label}:')
            for op in blk.ops:
                self._emit_op(op, fn)

        # ---- Switch back to the top-level line buffer. ----
        self.lines = saved_lines

        # Determine which callee-save regs the function touched.
        # Stable order (a12 → a15) so the layout is deterministic.
        used_cs = [r for r in ('a12', 'a13', 'a14', 'a15')
                   if r in self.regs.used_preserved]
        self._cs_used = used_cs

        # (self._use_scope was set BEFORE the body walk; see the comment
        # at the top of this function.)

        # ---- Prologue ----
        self.emit(f'  .text')
        self.emit(f'  .global {fn.name}')
        self.emit(f'  .type   {fn.name}, @function')
        self.emit(f'{fn.name}:')
        self.emit(f'  addi    a1, a1, -{self.frame_size}')
        # Phase: Xtensa large-frame fix. Both `s32i.n` (0..60) and
        # `s32i` (0..1020) cap their offset. For frames > 1020 bytes,
        # the saved-callee + saved-RA slots live above the wide
        # form's reach. We materialise a scratch base near the top
        # of the frame and use SMALL offsets off that base. a8 is
        # caller-save (clobbered by every `call0`) but is unused in
        # the prologue itself, so it's safe scratch here.
        _save_at = _emit_frame_store_helper(self)
        _save_at('a0', self.frame_size - 4)
        # Save the callee-save regs that the body uses.
        for r in used_cs:
            _save_at(r, self._cs_offsets[r],
                      tail=f'    # save callee-save {r}')
        if self._use_scope:
            self.emit(f'  call0   cssc_scope_push'
                      f'    # arena scope for transient allocations')

        # Drain param-binding moves first — these pull args out of
        # a2..a7 into their assigned SSA registers (callee-save a12..a15
        # for long-lived values, spill slots otherwise). After this
        # the incoming args are safely stashed and the trace call can
        # freely clobber a2..a7.
        self.lines.extend(param_binding_buf)

        # Trace-mode instrumentation. When the build was invoked with
        # `--trace`, every instrumented function prints `> name\n` to
        # UART before running its body. On a crash, the LAST unmatched
        # `> <fnname>` in the chip-log identifies the function that
        # held control — invaluable for pinpointing codegen-interaction
        # bugs where the crash PC has been overwritten by the nested
        # exception handler.
        #
        # The injected sequence is:
        #   l32r  a2, .Ltrace_<n>          ; ptr to "> name\n" cstr
        #   movi  a3, <strlen>             ; length
        #   call0 cssc_print_str           ; write to UART0
        # Total: ~8 instructions, ~24 bytes per function. The trace
        # MUST emit AFTER param_binding_buf — otherwise the
        # cssc_print_str call clobbers a2/a3 before the body can read
        # the incoming function args from them, and every later
        # `self`-ptr access faults.
        if self.trace_mode and self._function_is_traceable(fn.name):
            self._emit_trace_enter(fn.name)

        # `--diag-mem` instrumentation: emit a `cssc_diag_mem_check
        # (fn_id)` call at function entry so the chip dumps arena + SP
        # per call. The host listener watches for monotonic growth.
        # Same gate as trace_mode (user-emitted functions only — never
        # the hand-written runtime symbols, they'd recurse and drown
        # the UART).
        if self.diag_mem and self._function_is_traceable(fn.name):
            self._emit_diag_mem_enter(fn.name)

        # Dump the captured body.
        self.lines.extend(body_buf)

        # ---- Epilogue is emitted by the Ret handler (it emits the
        # matching l32i.n restores for self._cs_used before popping
        # the frame and returning).

        # Flush any literal-pool entries this function accumulated. L32R
        # is PC-relative ±32 KB, and emitting the pool right at the
        # function's end guarantees in-range without complicating
        # branch-target layout.
        if self.literal_pool:
            self.emit(f'  .literal_position')
            for label, val in self.literal_pool:
                if isinstance(val, int):
                    # Numeric constant — emit signed-decimal.
                    self.emit(f'  .literal {label}, {val}')
                else:
                    # Symbol reference — the linker resolves it.
                    self.emit(f'  .literal {label}, {val}')
            self.literal_pool.clear()
        self.emit(f'  .size   {fn.name}, .-{fn.name}')
        self.emit('')
        # A.2.5: clear `_use_scope` after the function is fully emitted.
        # The flag is set at the top of `emit_function` for the next
        # function, so this is robustness-only — but it prevents any
        # future tail-of-function helper that might be added from
        # inheriting the previous function's value.
        self._use_scope = False

    # -----------------------------------------------------------------
    # Op dispatch.
    # -----------------------------------------------------------------
    def _emit_op(self, op: Op, fn: Function) -> None:
        handler = _OP_HANDLERS.get(type(op))
        if handler is None:
            raise NotImplementedError(
                f'Xtensa LX106: CIR op {type(op).__name__} has no '
                f'handler yet. See `xtensa_lx106.py` phase table.'
            )
        # `--diag-mem-trace` injection: emit a `[cssc-trace] op=<id>`
        # UART marker BEFORE the op runs (only for traceable kinds, and
        # only when no outgoing-stack-args region is currently live —
        # see `_emit_diag_trace_op` for the safety gates).
        if self.diag_mem_trace:
            op_kind = type(op).__name__
            src_line = (op.loc[1] if op.loc and len(op.loc) >= 2 else 0)
            self._emit_diag_trace_op(op_kind, fn.name, src_line)
        handler(self, op, fn)

    # -----------------------------------------------------------------
    # Helpers — register or spill access.
    # -----------------------------------------------------------------
    def _load_ssa_to(self, ssa_id: int, dst_reg: str) -> None:
        """Load the low 32 bits of `ssa_id` into `dst_reg`. Use this
        only for values you know are 32-bit-wide (ptr, i32, i1). For
        i64/f64 use `_load_ssa_to_pair`."""
        if ssa_id in self.regs.id_to_reg:
            src = self.regs.id_to_reg[ssa_id]
            if src != dst_reg:
                self.emit(f'  mov.n   {dst_reg}, {src}')
            return
        if ssa_id in self.regs.id_to_pair:
            lo, _ = self.regs.id_to_pair[ssa_id]
            if lo.startswith('['):
                off = self.regs.id_to_spill[ssa_id] + self._sp_displacement
                self.emit(f'  l32i.n  {dst_reg}, a1, {off}')
            else:
                if lo != dst_reg:
                    self.emit(f'  mov.n   {dst_reg}, {lo}')
            return
        if ssa_id in self.regs.id_to_spill:
            off = self.regs.id_to_spill[ssa_id] + self._sp_displacement
            self.emit(f'  l32i.n  {dst_reg}, a1, {off}')
            return
        raise RuntimeError(
            f'Xtensa LX106: SSA id {ssa_id} has neither register nor '
            f'spill slot — was it never defined?'
        )

    def _load_ssa_to_pair(self, ssa_id: int, dst_lo: str, dst_hi: str) -> None:
        """Load the full 64-bit value of `ssa_id` into `(dst_lo, dst_hi)`.

        Handles all four allocator states:
          * paired in registers — `mov` each half.
          * paired in spill — load both halves from `[a1, +off]`/`+off+4`.
          * sole register (used as 32-bit) — zero-extend: lo = reg, hi = 0.
          * sole spill (32-bit) — load lo, zero hi.

        When SP has been displaced (e.g. while writing outgoing stack
        args inside `_h_call`), the spill-relative offset is shifted
        by `self._sp_displacement` so the read still hits the original
        slot.
        """
        if ssa_id in self.regs.id_to_pair:
            src_lo, src_hi = self.regs.id_to_pair[ssa_id]
            if src_lo.startswith('['):
                # Paired spill — both halves in consecutive words.
                off = self.regs.id_to_spill[ssa_id] + self._sp_displacement
                self.emit(f'  l32i.n  {dst_lo}, a1, {off}')
                self.emit(f'  l32i.n  {dst_hi}, a1, {off + 4}')
                return
            if src_lo != dst_lo:
                self.emit(f'  mov.n   {dst_lo}, {src_lo}')
            if src_hi != dst_hi:
                self.emit(f'  mov.n   {dst_hi}, {src_hi}')
            return
        if ssa_id in self.regs.id_to_reg:
            src = self.regs.id_to_reg[ssa_id]
            if src != dst_lo:
                self.emit(f'  mov.n   {dst_lo}, {src}')
            self.emit(f'  movi.n  {dst_hi}, 0')
            return
        if ssa_id in self.regs.id_to_spill:
            off = self.regs.id_to_spill[ssa_id] + self._sp_displacement
            self.emit(f'  l32i.n  {dst_lo}, a1, {off}')
            if ssa_id in self.regs.id_spill_64:
                self.emit(f'  l32i.n  {dst_hi}, a1, {off + 4}')
            else:
                self.emit(f'  movi.n  {dst_hi}, 0')
            return
        raise RuntimeError(
            f'Xtensa LX106: SSA id {ssa_id} has no defined storage — '
            f'lowering produced a use before def?'
        )

    def _store_from_pair_to_ssa(self, ssa_id: int, src_lo: str, src_hi: str) -> None:
        """Place the i64 (src_lo, src_hi) into wherever `ssa_id` lives.
        Allocates a paired slot for the SSA id if it doesn't have one yet.
        """
        if ssa_id not in self.regs.id_to_pair and ssa_id not in self.regs.id_to_spill:
            self.regs.take_64(ssa_id)
        if ssa_id in self.regs.id_to_pair:
            dst_lo, dst_hi = self.regs.id_to_pair[ssa_id]
            if dst_lo.startswith('['):
                off = self.regs.id_to_spill[ssa_id] + self._sp_displacement
                self.emit(f'  s32i.n  {src_lo}, a1, {off}')
                self.emit(f'  s32i.n  {src_hi}, a1, {off + 4}')
            else:
                if src_lo != dst_lo:
                    self.emit(f'  mov.n   {dst_lo}, {src_lo}')
                if src_hi != dst_hi:
                    self.emit(f'  mov.n   {dst_hi}, {src_hi}')
            return
        # Spilled — write both halves to the frame.
        off = self.regs.id_to_spill[ssa_id] + self._sp_displacement
        self.emit(f'  s32i.n  {src_lo}, a1, {off}')
        self.emit(f'  s32i.n  {src_hi}, a1, {off + 4}')

    def _store_from_reg_to_ssa(self, ssa_id: int, src_reg: str) -> None:
        """Place a 32-bit value into wherever `ssa_id` lives."""
        if ssa_id not in self.regs.id_to_reg and ssa_id not in self.regs.id_to_spill:
            self.regs.take_32(ssa_id)
        if ssa_id in self.regs.id_to_reg:
            dst = self.regs.id_to_reg[ssa_id]
            if src_reg != dst:
                self.emit(f'  mov.n   {dst}, {src_reg}')
            return
        off = self.regs.id_to_spill[ssa_id] + self._sp_displacement
        self.emit(f'  s32i.n  {src_reg}, a1, {off}')

    def _alloc_str_label(self, text: str) -> str:
        label = f'.LC{self.next_str_idx}'
        self.next_str_idx += 1
        self.string_pool[label] = text
        return label

    def _new_label(self, hint: str = 'L') -> str:
        """Unique local label for branch targets etc."""
        lab = f'.L{hint}{self.next_str_idx}'
        self.next_str_idx += 1
        return lab


def _slot_bytes_for_release(op) -> int:
    """Byte width of the slot a SlotRelease op points at.

    Mirrors `_slot_bytes` (the SlotAlloc-time sizing) but takes a
    SlotRelease (which carries `op.elem_kind` + `op.bits`). Used by
    `_h_slot_release` to zero EXACTLY the slot's storage — never
    more, never less. The "never more" half is critical: overflowing
    a 4-byte heap-ptr slot stomps the adjacent spill slot and was
    the root cause of the videodriver tick crash.

    Kept as a separate helper instead of inlining so a future regression
    can be caught by static audit (any divergence between the alloc-time
    and release-time width is a bug — both must consult one source of
    truth).
    """
    kind = getattr(op, 'elem_kind', None)
    bits = getattr(op, 'bits', 0)
    if kind == 'bool':
        return 4
    if kind == 'int':
        return 8
    if kind == 'float':
        return 4 if bits == 32 else 8
    if kind in ('string', 'vector_int', 'vector_float', 'array_int',
                'array_float', 'array_string',
                'vector_bool',     # Phase A.1
                'vector_string',   # Phase A.2
                'array_bool',      # Phase A.3
                'map_si', 'bind_ss',
                'map_ss', 'map_is', 'map_ii',
                'map_sf', 'map_if',
                'bind_entry', 'array_bind',
                'object_handle',
                'object', 'pin', 'i2c', 'spi', 'uart', 'adc', 'pwm',
                'timer', 'tft', 'oled', 'st7735', 'video', 'matrix',
                'framebuffer', 'console'):
        return 4   # heap pointer (LX106 is 32-bit)
    # Unknown kind — conservative 4 bytes (smaller is safer; refuses to
    # overflow into adjacent slots even if the kind ever grows). The
    # audit (F.3.j SLOT_RELEASE_OVERFLOW) catches divergence between
    # this table and `_slot_bytes` at dev-audit time.
    return 4


def _slot_bytes(op: SlotAlloc) -> int:
    """Bytes a SlotAlloc consumes in the local frame.

    Mirrors `_SLOT_STORAGE` in [cir_to_llvm.py]. POD kinds get 4
    bytes (LX106 is 32-bit; an i64 slot occupies 8 bytes because
    our value layout assumes 64-bit ints — we keep that for ABI
    compatibility with the host runtime).
    """
    kind = op.elem_kind
    if kind in ('bool',):
        return 4
    if kind in ('int',):
        return 8     # i64 lives in two regs / 8 stack bytes
    if kind in ('float',):
        # `#stack[float, 32]` opts into 32-bit storage so we honor the
        # declared bits. The default `#stack[float]` and explicit
        # `#stack[float, 64]` keep the 8-byte slot needed for the f64
        # software-emulation path through libgcc thunks.
        return 4 if op.bits == 32 else 8
    if kind in ('string', 'vector_int', 'vector_float', 'array_int',
                'array_float', 'array_string',
                'vector_bool',     # Phase A.1
                'vector_string',   # Phase A.2
                'array_bool',      # Phase A.3
                'map_si', 'bind_ss',
                'map_ss', 'map_is', 'map_ii',
                'map_sf', 'map_if',
                'bind_entry', 'array_bind',
                'object_handle',
                'object', 'pin', 'i2c', 'spi', 'uart', 'adc', 'pwm',
                'timer', 'tft', 'oled', 'st7735', 'video', 'matrix',
                'framebuffer', 'console'):
        return 4     # heap pointer (LX106 is 32-bit)
    raise NotImplementedError(
        f'Xtensa LX106 Phase B: slot kind {kind!r} not yet sized'
    )


# ---------------------------------------------------------------------------
# Large-frame addressing helpers. Both `s32i.n` (offset 0..60) and the
# wide `s32i` (offset 0..1020) hit a hard limit Xtensa LX106 can't
# encode past. Functions whose frame exceeds 1020 bytes (the
# audit_corpus test, programs with many slot declarations) need an
# intermediate base register. These helpers return closures the
# prologue/epilogue emitters call per save/restore site — they pick
# narrow / wide / addi-base automatically.
#
# Scratch register: a8. Caller-save under CALL0, NEVER used during
# the prologue or epilogue (no calls fire between frame-alloc and
# body-start, nor between body-end and frame-restore), so clobbering
# it is safe. The body itself is allowed to use a8 — by the time it
# runs the prologue has finished and we don't rely on a8's prologue
# value.
# ---------------------------------------------------------------------------
def _emit_frame_store_helper(em: 'XtensaEmitter'):
    """Return a closure `save(reg, off, tail='')` that emits the right
    s32i variant for the given offset. Once a function's prologue
    crosses 1020, the closure materialises an `a1 + OFF_HIGH` base in
    the dedicated `WIDE_OFFSET_SCRATCH` register (a15) and reuses it
    for every subsequent large-offset save.

    a15 is reserved framework-wide as the wide-offset scratch — it is
    held back from `ALLOC_REGS`, `HANDLER_SCRATCH`, and the callee-save
    set, so no other code path can hold a live value in it. Writing to
    a15 here is therefore safe with zero preservation logic. Same
    register reused by `_xtensa_widen_narrow_mem_ops` for the body,
    so prologue and body share one consistent base reservation.
    """
    state = {'base_set': False, 'base_off': 0}
    scratch = WIDE_OFFSET_SCRATCH

    def _save(reg: str, off: int, tail: str = '') -> None:
        if 0 <= off <= 60:
            em.emit(f'  s32i.n  {reg}, a1, {off}{tail}')
            return
        if 0 <= off <= 1020:
            em.emit(f'  s32i    {reg}, a1, {off}{tail}')
            return
        # Large-offset path: set up the WIDE_OFFSET_SCRATCH base near
        # the top of the frame the first time we hit one, then re-use
        # it for every subsequent large-offset save.
        if not state['base_set']:
            base_off = (off // 1020) * 1020
            if 0 <= base_off <= 2047:
                em.emit(f'  movi    {scratch}, {base_off}')
                em.emit(f'  add     {scratch}, a1, {scratch}')
            else:
                em.emit(f'  l32r    {scratch}, .L_framebase_{em.next_str_idx}')
                em.literal_pool.append(
                    (f'.L_framebase_{em.next_str_idx}', base_off))
                em.next_str_idx += 1
                em.emit(f'  add     {scratch}, a1, {scratch}')
            state['base_set'] = True
            state['base_off'] = base_off
        adj = off - state['base_off']
        if 0 <= adj <= 60:
            em.emit(f'  s32i.n  {reg}, {scratch}, {adj}{tail}')
        else:
            em.emit(f'  s32i    {reg}, {scratch}, {adj}{tail}')
    return _save


def _emit_frame_load_helper(em: 'XtensaEmitter'):
    """Mirror of `_emit_frame_store_helper` for the epilogue. Uses the
    same dedicated `WIDE_OFFSET_SCRATCH` register (a15) for the
    large-offset base.
    """
    state = {'base_set': False, 'base_off': 0}
    scratch = WIDE_OFFSET_SCRATCH

    def _load(reg: str, off: int, tail: str = '') -> None:
        if 0 <= off <= 60:
            em.emit(f'  l32i.n  {reg}, a1, {off}{tail}')
            return
        if 0 <= off <= 1020:
            em.emit(f'  l32i    {reg}, a1, {off}{tail}')
            return
        if not state['base_set']:
            base_off = (off // 1020) * 1020
            if 0 <= base_off <= 2047:
                em.emit(f'  movi    {scratch}, {base_off}')
                em.emit(f'  add     {scratch}, a1, {scratch}')
            else:
                em.emit(f'  l32r    {scratch}, .L_framebase_{em.next_str_idx}')
                em.literal_pool.append(
                    (f'.L_framebase_{em.next_str_idx}', base_off))
                em.next_str_idx += 1
                em.emit(f'  add     {scratch}, a1, {scratch}')
            state['base_set'] = True
            state['base_off'] = base_off
        adj = off - state['base_off']
        if 0 <= adj <= 60:
            em.emit(f'  l32i.n  {reg}, {scratch}, {adj}{tail}')
        else:
            em.emit(f'  l32i    {reg}, {scratch}, {adj}{tail}')
    return _load


# ---------------------------------------------------------------------------
# Width inference — many CIR ops carry their result_type, so we can pick
# 32 vs 64-bit codegen directly from the op without needing a separate
# annotation pass.
# ---------------------------------------------------------------------------
def _is_pair_kind(kind: str) -> bool:
    """True for value kinds that occupy two 32-bit registers."""
    return kind in ('i64', 'f64', 'csscval')


def _materialise_imm32(em: 'XtensaEmitter', dst: str, val: int) -> None:
    """Load a 32-bit immediate into `dst` using the smallest possible
    instruction. Xtensa `MOVI.N` is 6-bit; wide `MOVI` is 12-bit
    signed; anything larger goes through the literal pool via L32R.
    """
    val_s = val if val < 0x80000000 else val - 0x100000000
    if 0 <= val_s <= 31:                  # narrow form: 6-bit unsigned
        em.emit(f'  movi.n  {dst}, {val_s}')
    elif -2048 <= val_s <= 2047:          # wide MOVI: 12-bit signed
        em.emit(f'  movi    {dst}, {val_s}')
    else:
        # Literal-pool path — `l32r` loads a PC-relative 32-bit word.
        # Each unique value gets its own labeled `.literal` line.
        lab = f'.LIT{em.next_str_idx}'
        em.next_str_idx += 1
        em.literal_pool.append((lab, val_s))
        em.emit(f'  l32r    {dst}, {lab}')


# Attach the imm32 helper to XtensaEmitter so handlers can call it as a method.
XtensaEmitter._materialise_imm32 = _materialise_imm32   # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# A4 + A12 — ConstInt with full i64 materialisation, ConstBool, SlotAlloc,
# SlotStore (32+64), SlotLoad (32+64), SlotRelease.
#
# ConstInt produces an i64 value living in two 32-bit registers (lo, hi).
# We materialise BOTH halves so downstream BinOp/CmpOp see the full
# 64-bit range — silently truncating to 32 bits would corrupt any
# script that uses uptime() (ms can exceed 2^31 after ~25 days),
# random_int / clamp / large index math etc.
# ---------------------------------------------------------------------------
def _h_const_int(em: XtensaEmitter, op: ConstInt, fn: Function) -> None:
    lo = op.value & 0xFFFFFFFF
    # Sign-extend negative values into the high half so downstream
    # arithmetic operates on the true 64-bit signed value.
    if op.value < 0:
        hi = 0xFFFFFFFF
    else:
        hi = (op.value >> 32) & 0xFFFFFFFF
    lo_reg, hi_reg = em.regs.take_64(op.id)
    # If the pair landed in registers, materialise into them directly.
    # If spilled, materialise into scratch (a8/a9) then store.
    if lo_reg.startswith('['):
        off = em.regs.id_to_spill[op.id]
        em._materialise_imm32('a8', lo)
        em._materialise_imm32('a9', hi)
        em.emit(f'  s32i.n  a8, a1, {off}')
        em.emit(f'  s32i.n  a9, a1, {off + 4}')
    else:
        em._materialise_imm32(lo_reg, lo)
        em._materialise_imm32(hi_reg, hi)


def _h_const_bool(em: XtensaEmitter, op: ConstBool, fn: Function) -> None:
    """`%id = i1 <true|false>` — single-bit value as 32-bit 0 or 1."""
    reg = em.regs.take_32(op.id)
    val = 1 if op.value else 0
    if reg.startswith('['):
        em._materialise_imm32('a8', val)
        em.emit(f'  s32i.n  a8, a1, {em.regs.id_to_spill[op.id]}')
    else:
        em.emit(f'  movi.n  {reg}, {val}')


# ---------------------------------------------------------------------------
# B1 (partial) — ConstFloat materialisation. The L106 has no FPU; an
# f64 lives in two 32-bit registers identical to the i64 pair layout.
# We pull the IEEE-754 bit pattern out of the Python float and stamp it
# into the literal pool as two consecutive i32 words.
# ---------------------------------------------------------------------------
def _h_const_float(em: XtensaEmitter, op: ConstFloat, fn: Function) -> None:
    """Materialise a float constant as raw IEEE-754 bits.

    f32 occupies one register; f64 spans a pair. We avoid the libgcc
    int↔float conversion thunks entirely by precomputing the bits in
    Python and dropping them straight into the literal pool. That's
    one `l32r` (or two `movi`s if the constant fits 12-bit signed)
    per half — independent of the chip's FPU support.
    """
    import struct
    if op.result_type.kind == 'f32':
        bits32 = struct.unpack('<I', struct.pack('<f', op.value))[0]
        reg = em.regs.take_32(op.id)
        if reg.startswith('['):
            off = em.regs.id_to_spill[op.id]
            em._materialise_imm32('a8', bits32)
            em.emit(f'  s32i.n  a8, a1, {off}    ; f32 const')
        else:
            em._materialise_imm32(reg, bits32)
        return
    bits = struct.unpack('<Q', struct.pack('<d', op.value))[0]
    lo = bits & 0xFFFFFFFF
    hi = (bits >> 32) & 0xFFFFFFFF
    lo_reg, hi_reg = em.regs.take_64(op.id)
    if lo_reg.startswith('['):
        off = em.regs.id_to_spill[op.id]
        em._materialise_imm32('a8', lo)
        em._materialise_imm32('a9', hi)
        em.emit(f'  s32i.n  a8, a1, {off}')
        em.emit(f'  s32i.n  a9, a1, {off + 4}')
    else:
        em._materialise_imm32(lo_reg, lo)
        em._materialise_imm32(hi_reg, hi)


# ---------------------------------------------------------------------------
# B2 (partial) — ConstStr materialisation. Raw string literals live in
# `.rodata` (placed via the IROM section by the linker so flash holds
# the bytes). The CIR's `ConstStr.name` is already a unique label;
# we accumulate the (label, text) pairs on the emitter and dump
# `<label>: .asciz "..."` at the end of the program. The op itself
# just materialises the label's address into a register.
#
# Length pairs propagate via the existing `_str_len_table` side
# channel in cir_to_llvm — that's an LLVM-side concept though. On
# Xtensa we hand the raw `ptr` to runtime helpers (e.g.
# `cssc_string_lit(ptr ascii_z)`) which compute the length on the
# fly via a strlen loop. That keeps the CIR backend-agnostic.
# ---------------------------------------------------------------------------
def _h_const_str(em: XtensaEmitter, op: ConstStr, fn: Function) -> None:
    em.string_pool[op.name] = op.text
    # Side-table: per-SSA-id → byte length, so `_h_csscoutln`
    # (ptr-kind) and any other downstream consumer can pass the
    # length to `cssc_print_str(ptr, i64 len)` without having to
    # walk back to the ConstStr op. Initialised on first ConstStr.
    if not hasattr(em, '_const_str_len'):
        em._const_str_len = {}
    em._const_str_len[op.id] = op.length
    reg = em.regs.take_32(op.id)
    if reg.startswith('['):
        # Spill — load via scratch.
        em.literal_pool.append((f'.LITS{em.next_str_idx}', op.name))
        em.emit(f'  l32r    a8, .LITS{em.next_str_idx}')
        em.emit(f'  s32i.n  a8, a1, {em.regs.id_to_spill[op.id]}')
        em.next_str_idx += 1
    else:
        em.literal_pool.append((f'.LITS{em.next_str_idx}', op.name))
        em.emit(f'  l32r    {reg}, .LITS{em.next_str_idx}')
        em.next_str_idx += 1


# ---------------------------------------------------------------------------
# B6 — Wrap{Int,Float,Bool}: stamp a primitive into the 16-byte CsscVal
# layout `{ i64 tag, i64 data }`.
#
# A CsscVal occupies four 32-bit words on the chip: tag_lo, tag_hi,
# data_lo, data_hi. We materialise it into the SSA's spill slot
# (a CsscVal is too wide for the pair-register form). The dest is
# always a frame slot; the SSA value tracks the pointer to that slot.
#
# Tag constants come from KIND_TO_TAG / TAG_* in cir/types.py.
# ---------------------------------------------------------------------------
from ..cir.types import TAG_INT, TAG_FLOAT, TAG_BOOL


def _emit_csscval_stamp(em: XtensaEmitter,
                        slot_off: int,
                        tag: int,
                        src_lo: str, src_hi: str) -> None:
    """Write a 16-byte CsscVal at `[a1, slot_off]`:
       tag_lo = tag, tag_hi = 0, data_lo = src_lo, data_hi = src_hi.
    """
    em._materialise_imm32('a8', tag)
    em.emit(f'  s32i.n  a8, a1, {slot_off}      ; CsscVal.tag.lo')
    em.emit(f'  movi.n  a8, 0')
    em.emit(f'  s32i.n  a8, a1, {slot_off + 4}  ; CsscVal.tag.hi')
    em.emit(f'  s32i.n  {src_lo}, a1, {slot_off + 8}   ; CsscVal.data.lo')
    em.emit(f'  s32i.n  {src_hi}, a1, {slot_off + 12}  ; CsscVal.data.hi')


def _take_csscval_slot(em: XtensaEmitter, ssa_id: int) -> int:
    """Reserve 16 bytes in the frame for a CsscVal and bind the SSA
    id's pointer to that slot's address."""
    # Allocate 16 bytes aligned to 4 in the spill region.
    if em.regs.next_spill & 3:
        em.regs.next_spill = (em.regs.next_spill + 3) & ~3
    off = em.regs.next_spill
    em.regs.next_spill += 16
    # Materialise the slot's address into the SSA's register.
    reg = em.regs.take_32(ssa_id)
    if reg.startswith('['):
        em.emit(f'  addi    a10, a1, {off}')
        em.emit(f'  s32i.n  a10, a1, {em.regs.id_to_spill[ssa_id]}')
    else:
        em.emit(f'  addi    {reg}, a1, {off}')
    return off


def _h_wrap_int(em: XtensaEmitter, op: WrapInt, fn: Function) -> None:
    em._load_ssa_to_pair(op.src, 'a8', 'a9')
    off = _take_csscval_slot(em, op.id)
    _emit_csscval_stamp(em, off, TAG_INT, 'a8', 'a9')


def _h_wrap_float(em: XtensaEmitter, op: WrapFloat, fn: Function) -> None:
    em._load_ssa_to_pair(op.src, 'a8', 'a9')
    off = _take_csscval_slot(em, op.id)
    _emit_csscval_stamp(em, off, TAG_FLOAT, 'a8', 'a9')


def _h_wrap_bool(em: XtensaEmitter, op: WrapBool, fn: Function) -> None:
    em._load_ssa_to(op.src, 'a8')
    em.emit(f'  movi.n  a9, 0    ; bool: zero-extended high word')
    off = _take_csscval_slot(em, op.id)
    _emit_csscval_stamp(em, off, TAG_BOOL, 'a8', 'a9')


# ---------------------------------------------------------------------------
# C3 — GlobalAddr: load a module global's address via PC-relative L32R.
# The linker resolves the symbol at link time, so the value
# materialises from the literal pool transparently.
# ---------------------------------------------------------------------------
def _h_global_addr(em: XtensaEmitter, op: GlobalAddr, fn: Function) -> None:
    reg = em.regs.take_32(op.id)
    lab = f'.LITG{em.next_str_idx}'
    em.next_str_idx += 1
    # Use a literal_pool entry with the symbol name; the assembler
    # generates the relocation entry that the linker resolves.
    em.literal_pool.append((lab, op.llvm_sym))
    if reg.startswith('['):
        em.emit(f'  l32r    a8, {lab}')
        em.emit(f'  s32i.n  a8, a1, {em.regs.id_to_spill[op.id]}')
    else:
        em.emit(f'  l32r    {reg}, {lab}')


# ---------------------------------------------------------------------------
# C4 — MemberAddr: address-of a struct field at compile-known offset.
#
# CIR's MemberAddr is GEP-style: base pointer + struct type + field
# index. The field offset comes from the registered struct layout:
# every field is currently 4 or 8 bytes; we use the struct-types map
# the CIR builder populated to compute the byte offset.
#
# For Xtensa we materialise `base + offset` via ADDI (immediate range
# -128..127) or a literal-pool ADD for larger offsets.
# ---------------------------------------------------------------------------
_FIELD_TY_BYTES = {
    'i64':    8,
    'i32':    4,
    'i1':     1,    # but stored in a 4-byte slot for alignment
    'double': 8,
    'ptr':    4,
    'i8':     1,
}


def _h_member_addr(em: XtensaEmitter, op: MemberAddr, fn: Function) -> None:
    # Look up the struct's field layout from the Module's struct_types.
    # The builder stored it as List[str] of LLVM type-name strings.
    fn_module = em._current_module
    struct_def = fn_module.struct_types.get(op.struct_ty)
    if struct_def is None:
        raise RuntimeError(
            f'Xtensa LX106: MemberAddr on unknown struct {op.struct_ty!r}'
        )
    # Compute the byte offset of the requested field index.
    offset = 0
    for i, fty in enumerate(struct_def):
        if i == op.field_idx:
            break
        sz = _FIELD_TY_BYTES.get(fty, 4)
        # Each field is laid out at its natural alignment (we round up
        # to that field's size since LX106 only requires 4-byte aligned
        # word access). For mixed i64/i32 structs this matches what
        # the LLVM emitter does for the host build.
        align = 8 if sz == 8 else 4
        offset = (offset + align - 1) & ~(align - 1)
        offset += sz
    em._load_ssa_to(op.base, 'a8')
    reg = em.regs.take_32(op.id)
    target = 'a9' if reg.startswith('[') else reg
    if -128 <= offset <= 127:
        em.emit(f'  addi    {target}, a8, {offset}    ; {op.struct_ty}.field[{op.field_idx}]')
    else:
        em._materialise_imm32('a10', offset)
        em.emit(f'  add     {target}, a8, a10')
    if reg.startswith('['):
        em.emit(f'  s32i.n  {target}, a1, {em.regs.id_to_spill[op.id]}')


def _h_slot_alloc(em: XtensaEmitter, op: SlotAlloc, fn: Function) -> None:
    """A `SlotAlloc` reserves frame space (the prologue's first pass
    counted bytes for it). The SSA value of the op is a *pointer* to
    that frame slot. We materialise `a1 + frame_offset` into a 32-bit
    register (pointers are 32-bit on LX106).
    """
    reg = em.regs.take_32(op.id)
    off = em.slot_offsets[op.id]
    if reg.startswith('['):
        em.emit(f'  addi    a8, a1, {off}    ; {op.elem_kind} slot[{op.id}]')
        em.emit(f'  s32i.n  a8, a1, {em.regs.id_to_spill[op.id]}')
    else:
        em.emit(f'  addi    {reg}, a1, {off}    ; {op.elem_kind} slot[{op.id}]')


def _h_slot_store(em: XtensaEmitter, op: SlotStore, fn: Function) -> None:
    """Write a value into a slot. Width comes from `value_type`."""
    em._load_ssa_to(op.slot, 'a8')   # slot ptr → a8
    if _is_pair_kind(op.value_type.kind):
        em._load_ssa_to_pair(op.value, 'a9', 'a10')
        em.emit(f'  s32i.n  a9,  a8, 0    ; lo')
        em.emit(f'  s32i.n  a10, a8, 4    ; hi')
    elif op.value_type.kind == 'f32':
        # Single-precision float — one 32-bit register, written as
        # raw IEEE-754 bits. Same instruction as ptr/i32 store, but
        # we tag the comment so it's obvious in `--emit asm` output.
        em._load_ssa_to(op.value, 'a9')
        em.emit(f'  s32i.n  a9, a8, 0    ; f32')
    elif op.value_type.kind == 'i1':
        # Bool stored as a single byte at the slot's start; the
        # interpreter and host runtime treat the rest of the i64-slot
        # as padding, so we leave it untouched.
        em._load_ssa_to(op.value, 'a9')
        em.emit(f'  s8i     a9, a8, 0    ; bool')
    else:
        # 32-bit ptr / i32 — single word write.
        em._load_ssa_to(op.value, 'a9')
        em.emit(f'  s32i.n  a9, a8, 0')


def _h_slot_load(em: XtensaEmitter, op: SlotLoad, fn: Function) -> None:
    """Read a slot. The result type (set by the CIR builder using
    the slot's declared bit width) decides 32 vs 64-bit load: f32
    slots produce a single-word load even though `elem_kind` is
    still the abstract 'float'."""
    em._load_ssa_to(op.slot, 'a8')
    kind = op.elem_kind
    is_f32 = op.result_type.kind == 'f32'
    if kind == 'int' or (kind == 'float' and not is_f32):
        lo, hi = em.regs.take_64(op.id)
        if lo.startswith('['):
            off = em.regs.id_to_spill[op.id]
            em.emit(f'  l32i.n  a9,  a8, 0')
            em.emit(f'  l32i.n  a10, a8, 4')
            em.emit(f'  s32i.n  a9,  a1, {off}')
            em.emit(f'  s32i.n  a10, a1, {off + 4}')
        else:
            em.emit(f'  l32i.n  {lo}, a8, 0')
            em.emit(f'  l32i.n  {hi}, a8, 4')
    elif kind == 'float' and is_f32:
        # Single-precision: one 32-bit load, materialised in a single
        # SSA register. The downstream BinOp/Call dispatch is what
        # picks the FPU vs libgcc path based on profile.
        reg = em.regs.take_32(op.id)
        if reg.startswith('['):
            off = em.regs.id_to_spill[op.id]
            em.emit(f'  l32i.n  a9, a8, 0    ; f32')
            em.emit(f'  s32i.n  a9, a1, {off}')
        else:
            em.emit(f'  l32i.n  {reg}, a8, 0    ; f32')
    elif kind == 'bool':
        # Load a single byte; zero-extend into the result register.
        reg = em.regs.take_32(op.id)
        if reg.startswith('['):
            em.emit(f'  l8ui    a9, a8, 0')
            em.emit(f'  s32i.n  a9, a1, {em.regs.id_to_spill[op.id]}')
        else:
            em.emit(f'  l8ui    {reg}, a8, 0')
    else:
        # ptr / string / vector / map / object_handle / peripherals —
        # all 32-bit handles.
        reg = em.regs.take_32(op.id)
        if reg.startswith('['):
            em.emit(f'  l32i.n  a9, a8, 0')
            em.emit(f'  s32i.n  a9, a1, {em.regs.id_to_spill[op.id]}')
        else:
            em.emit(f'  l32i.n  {reg}, a8, 0')


def _h_slot_release(em: XtensaEmitter, op: SlotRelease, fn: Function) -> None:
    """Per-kind release. POD is a no-op for the cleanup side; heap
    kinds call the matching runtime symbol. Strings route through
    the unified `cssc_release` (A.3.4 refcount cascade — decrements
    refcount, frees on zero); everything else still routes to its
    per-kind `cssc_<kind>_free` until those kinds also adopt
    refcounts.

    Slot ZEROING after release is critical for the v6 mirror live-ref
    semantic — `_emit_mirror_epilogue_ret` (cir_lower.py) records the
    slot's address at mirror time and re-fetches via
    `cssc_load_i64_at` at function exit. A slot deleted during the
    post-mirror cleanup MUST return 0 on re-fetch (matches
    interpreter invalidation rules).

    CRITICAL — bit-exact storage identity: we zero EXACTLY the slot's
    width, never more. A 4-byte heap-ptr slot (string/vector/oled/…)
    gets 4 zero bytes; an 8-byte i64/f64 slot gets 8. The prior
    "always zero 8 bytes" pattern stomped the next adjacent spill
    slot when the released slot was 4 bytes wide — that was the
    root cause of the videodriver `frame += 1` LoadProhibited
    crash (the zero overflow corrupted the field[3] addr spill slot
    that the next CIR op tried to dereference).

    The runtime symbols are declared `.extern` so the assembler
    resolves them at link time.
    """
    if op.elem_kind in ('int', 'bool', 'float'):
        # POD slot — no heap to release. Still zero the storage so
        # a later live-ref re-fetch (via cssc_load_i64_at) sees 0.
        # POD slot widths (mirrored from `_slot_bytes`):
        #   int     → 8 bytes (i64)
        #   bool    → 4 bytes (i1 in 4-byte slot)
        #   float   → 4 if bits==32 else 8
        slot_bytes = _slot_bytes_for_release(op)
        em.emit(f'  # slot_release({op.elem_kind}) — zero {slot_bytes} bytes')
        em._load_ssa_to(op.slot, 'a8')
        em.emit(f'  movi.n  a9, 0')
        em.emit(f'  s32i.n  a9, a8, 0')
        if slot_bytes >= 8:
            em.emit(f'  s32i.n  a9, a8, 4')
        return
    # Heap kinds: load the ptr from the slot, pass it to the dispatch.
    sym_map = {
        # A.3.4: string release goes through the refcount cascade.
        'string':       'cssc_release',
        'vector_int':   'cssc_vector_free_int',
        'vector_float': 'cssc_vector_free_float',
        # Phase A.1 / A.3: bool vectors / arrays — arena allocator, no-op
        # at release time but the symbol still needs to exist so the
        # emitted call links.
        'vector_bool':  'cssc_vector_free_bool',
        'array_bool':   'cssc_vector_free_bool',
        # Phase A.2: parallel to array_string with refcount cascade.
        'vector_string':'cssc_vector_free_string',
        'array_int':    'cssc_vector_free_int',
        'array_string': 'cssc_array_string_free',
        'array_float':  'cssc_vector_free_float',
        'map_si':       'cssc_map_si_free',
        'map_ss':       'cssc_map_ss_free',
        'map_is':       'cssc_map_is_free',
        'map_ii':       'cssc_map_ii_free',
        'map_sf':       'cssc_map_sf_free',
        'map_if':       'cssc_map_if_free',
        'bind_ss':      'cssc_bind_ss_free',
        'bind_entry':   'cssc_bind_entry_free',
        'array_bind':   'cssc_array_bind_release',
        'pin':          'cssc_pin_free',
        'i2c':          'cssc_i2c_free',
        'spi':          'cssc_spi_free',
        'uart':         'cssc_uart_free',
        'adc':          'cssc_adc_free',
        'pwm':          'cssc_pwm_free',
        'timer':        'cssc_timer_free',
        'tft':          'cssc_tft_free',
        'oled':         'cssc_tft_free',
        'video':        'cssc_video_free',
        'matrix':       'cssc_matrix_free',
        'framebuffer':  'cssc_framebuffer_free',
        'console':      'cssc_console_free',
        'object_handle':'cssc_obj_free',
    }
    sym = sym_map.get(op.elem_kind)
    if sym is None:
        raise NotImplementedError(
            f'Xtensa LX106 Phase B: slot_release({op.elem_kind!r}) not wired'
        )
    em._load_ssa_to(op.slot, 'a8')
    em.emit(f'  l32i.n  a2, a8, 0     # arg0: heap ptr')
    # CALL0 ABI: a2..a11 are caller-save. cssc_release (and every
    # cssc_*_free dispatch listed in sym_map) immediately reuses
    # a8 as a refcount/scratch register, so the slot ptr we just
    # parked in a8 is GONE after the call. Spill a8 to a 16-byte
    # aligned tmp frame BEFORE the call and reload AFTER. Failing
    # to do this manifested on chip as Exception 29 (StoreProhibited,
    # excvaddr=0x0) at the post-call `s32i.n a9, a8, 0` — the dead
    # a8 happened to hold a freshly-decremented refcount of 0.
    em.emit(f'  addi    a1, a1, -16    # save slot ptr across release')
    em.emit(f'  s32i.n  a8, a1, 0')
    em.emit(f'  call0   {sym}')
    em.emit(f'  l32i.n  a8, a1, 0      # reload slot ptr (a8 is caller-save)')
    em.emit(f'  addi    a1, a1, 16')
    # Zero the slot's storage AFTER reloading slot ptr. We zero
    # EXACTLY the slot's width — never more. Heap-ptr slots are 4
    # bytes on Xtensa (LX106 is a 32-bit ISA); writing the trailing
    # `s32i.n a9, a8, 4` stomped the adjacent 4-byte spill slot,
    # which on tick was the field[3] addr cache. Frame had:
    #   [a1+4..7] = flabel string-ptr slot     (4 bytes)
    #   [a1+8..11] = field[3] addr spill slot  (4 bytes)
    # `_h_slot_release(flabel)` zeroed [a1+4..11] = 8 bytes, leaving
    # field[3] addr = NULL — the next `frame += 1` SlotLoad then
    # crashed dereferencing NULL. Now we zero only `slot_bytes`.
    #
    # Mirror live-ref re-fetch reads via `cssc_load_i64_at` (8 bytes).
    # For 4-byte slots that overflow into the adjacent spill IS
    # currently a known semantic gap — separate from this fix — and
    # only bites mirrored heap slots. videodriver mirrors `frame`
    # (i64), not a string, so this gap doesn't surface for it. The
    # gap is tracked for follow-up: either widen the mirror re-fetch
    # to know the slot's payload width, or expose
    # `cssc_load_ptr_at(addr)` and dispatch by slot kind.
    slot_bytes = _slot_bytes_for_release(op)
    em.emit(f'  movi.n  a9, 0')
    em.emit(f'  s32i.n  a9, a8, 0     # zero slot lo (mirror invalidate)')
    if slot_bytes >= 8:
        em.emit(f'  s32i.n  a9, a8, 4     # zero slot hi')


def _h_slot_retain(em: 'XtensaEmitter', op, fn: Function) -> None:
    """A.3.4 retain: bump the refcount of a heap value held in a slot.

    POD kinds are skipped (no refcount to bump). Strings (and any future
    refcount-managed kinds) load the ptr from the slot and call
    `cssc_retain(ptr)`. NULL-safe via cssc_retain's own check.
    """
    if op.elem_kind not in ('string',):
        em.emit(f'  # slot_retain({op.elem_kind}) — no-op for this kind')
        return
    em._load_ssa_to(op.slot, 'a8')
    em.emit(f'  l32i.n  a2, a8, 0     # arg0: heap ptr')
    em.emit(f'  call0   cssc_retain')


def _h_unreachable(em: 'XtensaEmitter', op, fn: Function) -> None:
    """A.3.12 unreachable terminator. Emit a self-loop so the CPU
    bottles here if the no-return-call upstream somehow returned (it
    shouldn't — `cssc_panic` halts the CPU with `waiti 0` — but the
    label guarantees the function bytes are well-formed)."""
    em.emit(f'1:')
    em.emit(f'  j       1b              # unreachable')


# ---------------------------------------------------------------------------
# A5 + A12 — Call / Ret with full i64/f64 pair-passing semantics.
#
# CALL0 ABI on LX106 (no register windows): args in a2..a7, return in
# a2 (32-bit) or a2:a3 (64-bit, lo:hi). Each i64/f64 arg consumes TWO
# consecutive arg regs. Args 7+ spill to stack at [a1, +0..].
#
# We pre-allocate arg-reg slots first so a wide value never lands
# straddling the 6-reg boundary (e.g. lo=a7, hi=a8) — the C ABI
# requires both halves of a wide arg to be in the SAME class
# (both arg-reg or both on stack).
# ---------------------------------------------------------------------------
def _arg_reg_layout(arg_types: List[Any]) -> Tuple[List[Tuple[int, int]], int]:
    """Map each CIR arg index to its (start_arg_reg_idx, width_in_regs).

    Returns ``([(reg_idx, width), …], n_stack_words)``. The layout
    follows the **pair-aligned** Xtensa CALL0 ABI variant that
    xtensa-lx106-elf-gcc uses: 64-bit args are forced to start on an
    even-numbered ARG_REG so they form a natural register pair
    (a2:a3, a4:a5, a6:a7). When an odd slot is unfilled before a
    64-bit arg, that slot stays empty rather than being claimed by
    the wide value — matching the hand-written runtime's
    `a2=handle, a4=x_lo, a6=y_lo` assumption.

    n_stack_words accounts for the same 8-byte alignment on the
    stack-arg side: a 4-byte ptr followed by an i64 leaves a 4-byte
    hole before the pair. Returning the padded word count keeps the
    caller's `addi a1, a1, -stack_bytes` reservation in sync with
    the actual offsets `_h_call` uses to write the args.
    """
    layout: List[Tuple[int, int]] = []
    used = 0
    stack_off_bytes = 0
    for ty in arg_types:
        width = 2 if _is_pair_kind(ty.kind) else 1
        if width == 2 and used % 2 != 0:
            # Pair-align the i64 pair in arg regs (skip odd slot).
            used += 1
        if used + width <= len(ARG_REGS):
            layout.append((used, width))
            used += width
        else:
            if width == 2 and stack_off_bytes % 8 != 0:
                stack_off_bytes += 4   # 8-byte align before i64
            layout.append((-1, width))
            stack_off_bytes += width * 4
            used = len(ARG_REGS)
    return layout, (stack_off_bytes + 3) // 4


def _h_call(em: XtensaEmitter, op: Call, fn: Function) -> None:
    """`%id = call <ret> @<callee>(<args>)`.

    Two-stage arg materialisation:
      1. Spill any callee-volatile (a8..a11) live-across-call values
         into their assigned frame spill slots. (Skipped for now —
         our naive allocator marks long-lived values as a12..a15
         which survive calls.)
      2. Materialise each arg into its matching `a2..a7` slot. Wide
         args fill two consecutive regs (lo first).
    """
    arg_types = op.arg_types or []
    if len(arg_types) != len(op.args):
        raise RuntimeError(
            f'Xtensa: Call to {op.callee!r}: '
            f'{len(op.args)} args vs {len(arg_types)} arg_types'
        )
    layout, n_stack = _arg_reg_layout(arg_types)
    # Reserve sp space for stack-passed args if any. We pop it back
    # after the call (saves needing the callee to know its caller's
    # frame size). Stack args sit at [a1, 0..n_stack*4-1] in
    # declaration order; wide args occupy two consecutive words.
    stack_bytes = n_stack * 4
    if stack_bytes:
        # Align to 16 bytes to keep the Xtensa ABI requirement.
        stack_bytes = (stack_bytes + 15) & ~15
        em.emit(f'  addi    a1, a1, -{stack_bytes}    ; outgoing stack args')
        # Every subsequent spill-relative load/store inside the
        # arg-materialisation block must add `stack_bytes` to its
        # offset so it still finds the original slot. The helpers
        # consult `em._sp_displacement` for that.
        em._sp_displacement = stack_bytes

    # Materialise args in reverse so we don't overwrite an earlier
    # arg's source register before its last use. Reverse order means
    # the deepest registers (a7, a6) fill first; by the time we touch
    # a2, no earlier arg-reg still holds an unconsumed source. Stack
    # args go to specific offsets which can be filled in any order
    # since their destinations are independent memory slots.
    # First pass: register args (reverse order).
    for i in range(len(op.args) - 1, -1, -1):
        a_id = op.args[i]
        reg_idx, width = layout[i]
        if reg_idx == -1:
            continue   # stack-passed; handled below
        if width == 2:
            em._load_ssa_to_pair(a_id, ARG_REGS[reg_idx], ARG_REGS[reg_idx + 1])
        else:
            em._load_ssa_to(a_id, ARG_REGS[reg_idx])
    # Second pass: stack args, written to [a1, +off]. INT64/f64
    # args take 8-byte aligned slots (matching the pair-aligned
    # register ABI), so a 4-byte ptr that precedes an i64 leaves a
    # 4-byte hole before it. The hand-written runtime functions in
    # cssc_tft_text / cssc_oled_show / etc. expect this layout.
    stack_off = 0
    for i, (reg_idx, width) in enumerate(layout):
        if reg_idx != -1:
            continue
        a_id = op.args[i]
        if width == 2:
            # Align to 8 for the i64 pair.
            if stack_off % 8 != 0:
                stack_off += 4
            em._load_ssa_to_pair(a_id, 'a8', 'a9')
            em.emit(f'  s32i.n  a8, a1, {stack_off}')
            em.emit(f'  s32i.n  a9, a1, {stack_off + 4}')
            stack_off += 8
        else:
            em._load_ssa_to(a_id, 'a8')
            em.emit(f'  s32i.n  a8, a1, {stack_off}')
            stack_off += 4
    em.emit(f'  call0   {op.callee}')
    if stack_bytes:
        em.emit(f'  addi    a1, a1, {stack_bytes}     ; pop stack args')
        em._sp_displacement = 0
    if op.result_type.is_void():
        return
    # Capture the return value into the SSA's assigned storage.
    if _is_pair_kind(op.result_type.kind):
        em._store_from_pair_to_ssa(op.id, 'a2', 'a3')
    else:
        em._store_from_reg_to_ssa(op.id, 'a2')


def _h_ret(em: XtensaEmitter, op: Ret, fn: Function) -> None:
    """Function epilogue + return.

    For value returns we load the value into a2 (32-bit) or a2:a3
    (i64/f64) so the caller's `_h_call` finds it in the right place.
    Then we pop the arena scope (if this function owns one — see
    `_function_owns_scope`), restore the callee-save registers the
    prologue saved (CALL0 ABI: a12..a15 must be preserved across
    calls), restore a0 (RA), pop the frame, and return.
    """
    if op.value is not None:
        if _is_pair_kind(op.value_type.kind):
            em._load_ssa_to_pair(op.value, 'a2', 'a3')
        else:
            em._load_ssa_to(op.value, 'a2')
    # Bulk-free this function's transient arena allocations. The push
    # was emitted by `emit_function`'s prologue iff `_use_scope` is
    # set; we mirror that here. The pop helper uses only a8..a11 as
    # scratch, so the return value sitting in a2:a3 survives.
    if getattr(em, '_use_scope', False):
        em.emit(f'  call0   cssc_scope_pop'
                f'    # bulk-free transient arena allocations')
    # Restore the same callee-save regs the prologue saved, in
    # reverse order purely for cosmetic symmetry — load order
    # doesn't matter because all four slots are independent.
    # Large-frame: route through the same auto-widening helper the
    # prologue uses, so saves and restores stay byte-for-byte
    # symmetric regardless of frame size.
    cs_used = getattr(em, '_cs_used', None) or []
    cs_offsets = getattr(em, '_cs_offsets', None) or {}
    _load_at = _emit_frame_load_helper(em)
    for r in reversed(cs_used):
        _load_at(r, cs_offsets[r],
                  tail=f'    # restore callee-save {r}')
    _load_at('a0', em.frame_size - 4)
    em.emit(f'  addi    a1, a1, {em.frame_size}')
    em.emit(f'  ret.n')


# ---------------------------------------------------------------------------
# A6 + A12 — Int arithmetic + comparison, full 64-bit.
#
# Xtensa LX106 lacks a 64-bit ALU. We synthesise i64 ops via:
#   * ADD/SUB low-half + carry/borrow propagation into high-half.
#   * MUL/DIV/MOD via libgcc's `__muldi3 / __divdi3 / __moddi3` thunks
#     (they live in libgcc.a, which xtensa-lx106-elf-gcc ships).
# ---------------------------------------------------------------------------
def _emit_add64(em: XtensaEmitter,
                d_lo: str, d_hi: str,
                a_lo: str, a_hi: str,
                b_lo: str, b_hi: str) -> None:
    """64-bit addition: (d_lo, d_hi) = (a_lo, a_hi) + (b_lo, b_hi).

    Sequence:
      add  d_lo, a_lo, b_lo
      bgeu d_lo, a_lo, .no_carry          ; unsigned-no-overflow → no carry
      addi t,    a_hi, 1                  ; carry detected
      j    .add_hi
    .no_carry:
      mov  t,    a_hi
    .add_hi:
      add  d_hi, t, b_hi

    The branch is a 4-cycle hit if taken; for the typical hot
    add-counter pattern (lo never overflows in any single iteration)
    the no-branch path is one ADD + one mov.
    """
    no_carry = em._new_label('addnc')
    end_lab  = em._new_label('addhi')
    em.emit(f'  add     {d_lo}, {a_lo}, {b_lo}')
    em.emit(f'  bgeu    {d_lo}, {a_lo}, {no_carry}')
    em.emit(f'  addi    a8, {a_hi}, 1     ; carry-in to hi')
    em.emit(f'  j       {end_lab}')
    em.emit(f'{no_carry}:')
    em.emit(f'  mov.n   a8, {a_hi}')
    em.emit(f'{end_lab}:')
    em.emit(f'  add     {d_hi}, a8, {b_hi}')


def _emit_sub64(em: XtensaEmitter,
                d_lo: str, d_hi: str,
                a_lo: str, a_hi: str,
                b_lo: str, b_hi: str) -> None:
    """64-bit subtraction with borrow:
      sub  d_lo, a_lo, b_lo
      bgeu a_lo, b_lo, .no_borrow         ; no unsigned underflow
      addi t,    a_hi, -1                 ; borrow out of hi
      j    .sub_hi
    .no_borrow:
      mov  t,    a_hi
    .sub_hi:
      sub  d_hi, t, b_hi
    """
    no_borrow = em._new_label('subnb')
    end_lab   = em._new_label('subhi')
    em.emit(f'  sub     {d_lo}, {a_lo}, {b_lo}')
    em.emit(f'  bgeu    {a_lo}, {b_lo}, {no_borrow}')
    em.emit(f'  addi    a8, {a_hi}, -1    ; borrow-out of hi')
    em.emit(f'  j       {end_lab}')
    em.emit(f'{no_borrow}:')
    em.emit(f'  mov.n   a8, {a_hi}')
    em.emit(f'{end_lab}:')
    em.emit(f'  sub     {d_hi}, a8, {b_hi}')


_INT64_THUNK = {
    '*':  '__muldi3',
    '/':  '__divdi3',
    '%':  '__moddi3',
}


def _h_binop(em: XtensaEmitter, op: BinOp, fn: Function) -> None:
    """Lower a CIR `BinOp`. Handles int (i64) and bool (i1) ops; float
    lands in Phase B1.
    """
    if op.operand_type.kind == 'i64':
        # Load both operands into scratch pairs.
        em._load_ssa_to_pair(op.lhs, 'a8',  'a9')
        em._load_ssa_to_pair(op.rhs, 'a10', 'a11')
        # Take an SSA destination pair.
        d_lo, d_hi = em.regs.take_64(op.id)
        # If the destination is spilled, use caller-save scratch
        # (a2/a3) so we don't trample on callee-save SSAs (a12-a15)
        # that the register allocator may have already assigned to
        # *other* persistent values. a2-a7 are arg regs and are
        # caller-save under CALL0; outside of an arg-marshalling
        # block they're free to use as scratch.
        if d_lo.startswith('['):
            res_lo, res_hi = 'a2', 'a3'
        else:
            res_lo, res_hi = d_lo, d_hi
        if op.op == '+':
            _emit_add64(em, res_lo, res_hi, 'a8', 'a9', 'a10', 'a11')
        elif op.op == '-':
            _emit_sub64(em, res_lo, res_hi, 'a8', 'a9', 'a10', 'a11')
        elif op.op == '&':
            # Bitwise AND per 32-bit half. Single-cycle on Xtensa.
            em.emit(f'  and     {res_lo}, a8, a10')
            em.emit(f'  and     {res_hi}, a9, a11')
        elif op.op == '|':
            em.emit(f'  or      {res_lo}, a8, a10')
            em.emit(f'  or      {res_hi}, a9, a11')
        elif op.op == '^':
            em.emit(f'  xor     {res_lo}, a8, a10')
            em.emit(f'  xor     {res_hi}, a9, a11')
        elif op.op == 'lshr':
            # Logical right shift on i64 by RHS (low 7 bits matter).
            # Xtensa has only 32-bit shifts; build i64 lshr by hand.
            # Used by the v6 scanp bit-pack: shift count is a small
            # compile-time constant (32 + pos), so the runtime path
            # below is fine. Implementation: extract the shift amount
            # (low 6 bits, max 63), then either shift the upper half
            # into the lower half (shift >= 32) or do the cross-word
            # blend (shift < 32).
            em.emit(f'  ; ── i64 lshr ──')
            # a10 = shift amount (low 6 bits)
            em.emit(f'  extui   a10, a10, 0, 6')
            # If shift >= 32: result_lo = (hi >> (shift-32)); result_hi = 0
            # Else:           result_lo = (lo >> shift) | (hi << (32-shift))
            #                 result_hi = hi >> shift
            em.emit(f'  movi.n  a11, 32')
            big_lab = em._new_label('lshr.big')
            done_lab = em._new_label('lshr.done')
            em.emit(f'  bge     a10, a11, {big_lab}')
            # shift < 32 path
            em.emit(f'  ssr     a10')                     # SAR = shift
            em.emit(f'  src     {res_lo}, a9, a8')         # lo = (hi:lo) >> shift
            em.emit(f'  srl     {res_hi}, a9')             # hi = hi >> shift
            em.emit(f'  j       {done_lab}')
            em.emit(f'{big_lab}:')
            em.emit(f'  addi    a10, a10, -32')
            em.emit(f'  ssr     a10')
            em.emit(f'  srl     {res_lo}, a9')             # lo = hi >> (shift-32)
            em.emit(f'  movi.n  {res_hi}, 0')
            em.emit(f'{done_lab}:')
        elif op.op == '>>':
            # Arithmetic right shift (sign-preserving) — not needed by
            # the bit-pack but added for completeness so any future
            # signed shift in user code works on Xtensa.
            em.emit(f'  ; ── i64 ashr ──')
            em.emit(f'  extui   a10, a10, 0, 6')
            em.emit(f'  movi.n  a11, 32')
            big_lab = em._new_label('ashr.big')
            done_lab = em._new_label('ashr.done')
            em.emit(f'  bge     a10, a11, {big_lab}')
            em.emit(f'  ssr     a10')
            em.emit(f'  src     {res_lo}, a9, a8')
            em.emit(f'  sra     {res_hi}, a9')              # arith shift hi
            em.emit(f'  j       {done_lab}')
            em.emit(f'{big_lab}:')
            em.emit(f'  addi    a10, a10, -32')
            em.emit(f'  ssr     a10')
            em.emit(f'  sra     {res_lo}, a9')
            # Sign-extend result_hi: hi >> 31
            em.emit(f'  srai    {res_hi}, a9, 31')
            em.emit(f'{done_lab}:')
        elif op.op == '<<':
            em.emit(f'  ; ── i64 shl ──')
            em.emit(f'  extui   a10, a10, 0, 6')
            em.emit(f'  movi.n  a11, 32')
            big_lab = em._new_label('shl.big')
            done_lab = em._new_label('shl.done')
            em.emit(f'  bge     a10, a11, {big_lab}')
            em.emit(f'  ssl     a10')
            em.emit(f'  src     {res_hi}, a9, a8')         # hi = (hi:lo) << shift (high words)
            em.emit(f'  sll     {res_lo}, a8')              # lo = lo << shift
            em.emit(f'  j       {done_lab}')
            em.emit(f'{big_lab}:')
            em.emit(f'  addi    a10, a10, -32')
            em.emit(f'  ssl     a10')
            em.emit(f'  sll     {res_hi}, a8')              # hi = lo << (shift-32)
            em.emit(f'  movi.n  {res_lo}, 0')
            em.emit(f'{done_lab}:')
        elif op.op in _INT64_THUNK:
            # libgcc thunk: takes a2:a3 (LHS), a4:a5 (RHS); returns a2:a3.
            em.emit(f'  mov.n   a2, a8')
            em.emit(f'  mov.n   a3, a9')
            em.emit(f'  mov.n   a4, a10')
            em.emit(f'  mov.n   a5, a11')
            em.emit(f'  call0   {_INT64_THUNK[op.op]}')
            em.emit(f'  mov.n   {res_lo}, a2')
            em.emit(f'  mov.n   {res_hi}, a3')
        else:
            raise NotImplementedError(
                f'Xtensa LX106: int64 BinOp {op.op!r} not wired'
            )
        if d_lo.startswith('['):
            off = em.regs.id_to_spill[op.id]
            em.emit(f'  s32i.n  {res_lo}, a1, {off}')
            em.emit(f'  s32i.n  {res_hi}, a1, {off + 4}')
        return
    if op.operand_type.kind == 'i1':
        # Bool arithmetic: only && / || appear here (logical_not goes
        # through a different op). The CIR layer expands && / || into
        # CmpOp+BrCond so we typically don't see i1 BinOp — assert
        # explicitly so a silent miscompile can't sneak in.
        raise NotImplementedError(
            'Xtensa LX106: BinOp on i1 should have been expanded to '
            'short-circuit branches by the CIR layer'
        )
    if op.operand_type.kind == 'f64':
        # Soft-float via libgcc thunks. ABI: args in (a2:a3) (a4:a5);
        # return in a2:a3. The thunk does the IEEE arithmetic, we
        # marshal results into the SSA's storage.
        thunk = {
            '+': '__adddf3',
            '-': '__subdf3',
            '*': '__muldf3',
            '/': '__divdf3',
        }.get(op.op)
        if thunk is None:
            raise NotImplementedError(
                f'Xtensa LX106: f64 BinOp {op.op!r} not in the libgcc set'
            )
        em._load_ssa_to_pair(op.lhs, 'a2', 'a3')
        em._load_ssa_to_pair(op.rhs, 'a4', 'a5')
        em.emit(f'  call0   {thunk}')
        em._store_from_pair_to_ssa(op.id, 'a2', 'a3')
        return
    if op.operand_type.kind == 'f32':
        # Single-precision: profile decides between hardware FPU
        # (ESP32 LX7) and libgcc soft-float thunks (ESP8266 LX106).
        #
        # The FPU path is the entire reason `#stack[float, 32]` is
        # worth opting into on ESP32: WFR/RFR move bits between
        # integer regs (a8/a9) and FPU regs (f0/f1) for one cycle
        # each, while ADD.S / SUB.S / MUL.S / DIV.S each take ~6
        # cycles. The libgcc thunk equivalent (__addsf3 etc.) is
        # ~70-100 cycles for a single call.
        if em.profile.get('fpu') == 'single':
            fpu_insn = {
                '+': 'add.s',
                '-': 'sub.s',
                '*': 'mul.s',
                '/': 'div.s',
            }.get(op.op)
            if fpu_insn is None:
                raise NotImplementedError(
                    f"Xtensa LX7 FPU: f32 BinOp {op.op!r} not wired"
                )
            em._load_ssa_to(op.lhs, 'a8')
            em._load_ssa_to(op.rhs, 'a9')
            em.emit(f'  wfr     f0, a8')
            em.emit(f'  wfr     f1, a9')
            em.emit(f'  {fpu_insn:7s} f2, f0, f1')
            em.emit(f'  rfr     a8, f2')
            em._store_from_reg_to_ssa(op.id, 'a8')
            return
        # ESP8266 LX106 has no FPU — fall through to libgcc f32
        # thunks. ABI: single args in a2 / a3; return in a2.
        thunk = {
            '+': '__addsf3',
            '-': '__subsf3',
            '*': '__mulsf3',
            '/': '__divsf3',
        }.get(op.op)
        if thunk is None:
            raise NotImplementedError(
                f'Xtensa LX106: f32 BinOp {op.op!r} not in the libgcc set'
            )
        em._load_ssa_to(op.lhs, 'a2')
        em._load_ssa_to(op.rhs, 'a3')
        em.emit(f'  call0   {thunk}')
        em._store_from_reg_to_ssa(op.id, 'a2')
        return
    raise NotImplementedError(
        f'Xtensa LX106: BinOp on {op.operand_type.kind!r} not yet wired'
    )


def _h_cmpop(em: XtensaEmitter, op: CmpOp, fn: Function) -> None:
    """Integer (i64) comparison → i1 result {0, 1}.

    Two-stage compare for the full 64-bit range:
      1. Compare hi halves. If they differ, the hi result decides
         (signed-aware for `<`/`>`/`<=`/`>=`; equality stops early).
      2. Else compare lo halves unsigned.

    For pure equality we can short-circuit: equal iff hi==hi && lo==lo.
    """
    if op.operand_type.kind == 'f64':
        # libgcc f64 comparisons return a tri-state i32:
        #   __eqdf2 / __nedf2     →  0 if equal else 1
        #   __ltdf2 / __ledf2     →  -1 if less, 0 if equal, +1 if greater
        #   __gtdf2 / __gedf2     →  same shape (per our softfloat impl)
        # We map each CSSC op to the thunk + the SINGLE branch
        # instruction that selects the "true" path. The old code did
        # `if want_zero: beqz; if want_gt: bnez` which double-fires
        # for `>=` (every result branches true) and never produces
        # the right shape for `>` (bnez catches BOTH signs). Now we
        # emit exactly one branch matching the operation's semantics:
        #   ==  → beqz       (a2 == 0)
        #   !=  → bnez       (a2 != 0)
        #   <   → bltz       (a2 <  0)
        #   <=  → bgei a2,1,SKIP+inverted (any of < or ==)
        #   >   → bgei a2,1  (a2 >  0; bnez would also catch a2 < 0)
        #   >=  → bgez       (a2 >= 0)
        thunk = {
            '==': '__eqdf2', '!=': '__nedf2', '<':  '__ltdf2',
            '<=': '__ledf2', '>':  '__gtdf2', '>=': '__gedf2',
        }[op.op]
        em._load_ssa_to_pair(op.lhs, 'a2', 'a3')
        em._load_ssa_to_pair(op.rhs, 'a4', 'a5')
        em.emit(f'  call0   {thunk}')
        true_lab = em._new_label('fcmpT')
        end_lab  = em._new_label('fcmpE')
        dst_reg = em.regs.take_32(op.id)
        res = 'a10' if dst_reg.startswith('[') else dst_reg
        em.emit(f'  movi.n  {res}, 0')
        if op.op == '==':
            em.emit(f'  beqz    a2, {true_lab}')
        elif op.op == '!=':
            em.emit(f'  bnez    a2, {true_lab}')
        elif op.op == '<':
            em.emit(f'  bltz    a2, {true_lab}')
        elif op.op == '<=':
            # a2 <= 0 ⟺ NOT (a2 > 0). Bias the skip-when-positive form.
            skip_lab = em._new_label('fcmpS')
            em.emit(f'  bgei    a2, 1, {skip_lab}     ; skip (a2 > 0 → false)')
            em.emit(f'  j       {true_lab}')
            em.emit(f'{skip_lab}:')
        elif op.op == '>':
            em.emit(f'  bgei    a2, 1, {true_lab}     ; a2 > 0 → true')
        elif op.op == '>=':
            em.emit(f'  bgez    a2, {true_lab}        ; a2 >= 0 → true')
        em.emit(f'  j       {end_lab}')
        em.emit(f'{true_lab}:')
        em.emit(f'  movi.n  {res}, 1')
        em.emit(f'{end_lab}:')
        if dst_reg.startswith('['):
            em.emit(f'  s32i.n  {res}, a1, {em.regs.id_to_spill[op.id]}')
        return
    if op.operand_type.kind == 'f32':
        # Single-precision comparison: on ESP32 LX7 we use the FPU
        # ordered-compare instructions and read the result via
        # the boolean register that XOR/CONJ tests; on ESP8266 we
        # route through libgcc soft-float thunks. The thunk return
        # convention matches `__eqdf2` etc. — i32 with the same
        # tri-state semantics.
        if em.profile.get('fpu') == 'single':
            # FPU path: OEQ.S / OLT.S / OLE.S into a boolean register
            # (Xtensa "br" — bit-vector b0..b15). For ESP32 LX7 the
            # only direct compares are OEQ, OLT, OLE; we synthesize
            # the rest via inversion or operand swap.
            #
            #   ==      → OEQ.S  → b0 = 1 if equal
            #   !=      → !OEQ.S
            #   <       → OLT.S  → b0 = 1 if lhs < rhs
            #   <=      → OLE.S
            #   >       → OLT.S with operands swapped
            #   >=      → OLE.S with operands swapped
            em._load_ssa_to(op.lhs, 'a8')
            em._load_ssa_to(op.rhs, 'a9')
            em.emit(f'  wfr     f0, a8')
            em.emit(f'  wfr     f1, a9')
            invert = False
            if op.op == '==':
                em.emit(f'  oeq.s   b0, f0, f1')
            elif op.op == '!=':
                em.emit(f'  oeq.s   b0, f0, f1')
                invert = True
            elif op.op == '<':
                em.emit(f'  olt.s   b0, f0, f1')
            elif op.op == '<=':
                em.emit(f'  ole.s   b0, f0, f1')
            elif op.op == '>':
                em.emit(f'  olt.s   b0, f1, f0')   # swapped
            elif op.op == '>=':
                em.emit(f'  ole.s   b0, f1, f0')
            else:
                raise NotImplementedError(
                    f"Xtensa LX7 FPU: CmpOp {op.op!r} not wired"
                )
            dst_reg = em.regs.take_32(op.id)
            res = 'a10' if dst_reg.startswith('[') else dst_reg
            true_lab = em._new_label('fcmpT')
            end_lab  = em._new_label('fcmpE')
            em.emit(f'  movi.n  {res}, 0')
            if invert:
                em.emit(f'  bf      b0, {true_lab}')   # branch if false → true
            else:
                em.emit(f'  bt      b0, {true_lab}')
            em.emit(f'  j       {end_lab}')
            em.emit(f'{true_lab}:')
            em.emit(f'  movi.n  {res}, 1')
            em.emit(f'{end_lab}:')
            if dst_reg.startswith('['):
                em.emit(f'  s32i.n  {res}, a1, {em.regs.id_to_spill[op.id]}')
            return
        # ESP8266 LX106 — libgcc soft-float thunks. Same tri-state
        # convention as the f64 path. Single-branch lowering: every
        # CSSC compare op has exactly ONE branch instruction that
        # selects the "true" path from the thunk's sign. The earlier
        # multi-branch form (beqz+bnez for `>=`) double-fired and
        # made every comparison evaluate true.
        thunk = {
            '==': '__eqsf2', '!=': '__nesf2', '<':  '__ltsf2',
            '<=': '__lesf2', '>':  '__gtsf2', '>=': '__gesf2',
        }[op.op]
        em._load_ssa_to(op.lhs, 'a2')
        em._load_ssa_to(op.rhs, 'a3')
        em.emit(f'  call0   {thunk}')
        true_lab = em._new_label('fcmpT')
        end_lab  = em._new_label('fcmpE')
        dst_reg = em.regs.take_32(op.id)
        res = 'a10' if dst_reg.startswith('[') else dst_reg
        em.emit(f'  movi.n  {res}, 0')
        if op.op == '==':
            em.emit(f'  beqz    a2, {true_lab}')
        elif op.op == '!=':
            em.emit(f'  bnez    a2, {true_lab}')
        elif op.op == '<':
            em.emit(f'  bltz    a2, {true_lab}')
        elif op.op == '<=':
            skip_lab = em._new_label('fcmpS')
            em.emit(f'  bgei    a2, 1, {skip_lab}     ; skip (a2 > 0 → false)')
            em.emit(f'  j       {true_lab}')
            em.emit(f'{skip_lab}:')
        elif op.op == '>':
            em.emit(f'  bgei    a2, 1, {true_lab}     ; a2 > 0 → true')
        elif op.op == '>=':
            em.emit(f'  bgez    a2, {true_lab}        ; a2 >= 0 → true')
        em.emit(f'  j       {end_lab}')
        em.emit(f'{true_lab}:')
        em.emit(f'  movi.n  {res}, 1')
        em.emit(f'{end_lab}:')
        if dst_reg.startswith('['):
            em.emit(f'  s32i.n  {res}, a1, {em.regs.id_to_spill[op.id]}')
        return
    if op.operand_type.kind != 'i64':
        raise NotImplementedError(
            f'Xtensa LX106: CmpOp on {op.operand_type.kind!r} not yet wired'
        )
    em._load_ssa_to_pair(op.lhs, 'a8',  'a9')
    em._load_ssa_to_pair(op.rhs, 'a10', 'a11')
    dst_reg = em.regs.take_32(op.id)
    # Spilled cmp results use a caller-save scratch (a2) so we don't
    # trample on persistent SSAs that the allocator may have parked
    # in a12-a15. Same reasoning as the i64 BinOp handler above.
    res = 'a2' if dst_reg.startswith('[') else dst_reg

    true_lab = em._new_label('cmpT')
    end_lab  = em._new_label('cmpE')

    # We pre-set 0; the branches jump to true_lab to overwrite with 1.
    em.emit(f'  movi.n  {res}, 0')

    if op.op == '==':
        # Both halves must match. Test hi first (cheap branch out).
        diff = em._new_label('cmpD')
        em.emit(f'  bne     a9,  a11, {diff}     ; hi differs → not equal')
        em.emit(f'  beq     a8,  a10, {true_lab} ; lo equal     → equal')
        em.emit(f'{diff}:')
    elif op.op == '!=':
        em.emit(f'  bne     a9,  a11, {true_lab} ; hi differs → not equal')
        em.emit(f'  bne     a8,  a10, {true_lab} ; lo differs → not equal')
    elif op.op in ('<', '<=', '>', '>='):
        # Signed compare. Use `blt`/`bge` on the hi half; if hi halves
        # are equal, fall through to an unsigned compare on the lo.
        # For `<=` and `>=` we flip operands to reuse blt/bge.
        a_lo, a_hi, b_lo, b_hi = 'a8', 'a9', 'a10', 'a11'
        if op.op in ('>', '<='):
            # Swap: `a > b` is `b < a`, `a <= b` is `b >= a`.
            a_lo, a_hi, b_lo, b_hi = b_lo, b_hi, a_lo, a_hi
        strict = op.op in ('<', '>')
        # First: hi a < hi b → result TRUE.
        em.emit(f'  blt     {a_hi}, {b_hi}, {true_lab}     ; hi signed-less')
        # Second: hi a > hi b → result FALSE (skip).
        em.emit(f'  blt     {b_hi}, {a_hi}, {end_lab}      ; hi signed-greater')
        # Third: hi equal — compare lo unsigned.
        if strict:
            em.emit(f'  bltu    {a_lo}, {b_lo}, {true_lab} ; lo unsigned-less')
        else:
            # `<=` (after swap → `>=`): true if (a >= b), which here
            # means a_lo >= b_lo since hi is equal.
            em.emit(f'  bgeu    {a_lo}, {b_lo}, {true_lab} ; lo unsigned-geq')
    else:
        raise NotImplementedError(
            f'Xtensa LX106: CmpOp {op.op!r} not in the supported set'
        )
    em.emit(f'  j       {end_lab}')
    em.emit(f'{true_lab}:')
    em.emit(f'  movi.n  {res}, 1')
    em.emit(f'{end_lab}:')

    if dst_reg.startswith('['):
        em.emit(f'  s32i.n  {res}, a1, {em.regs.id_to_spill[op.id]}')


# ---------------------------------------------------------------------------
# A7 — Control flow: Br / BrCond + block labels
# ---------------------------------------------------------------------------
def _h_br(em: XtensaEmitter, op: Br, fn: Function) -> None:
    em.emit(f'  j       .L{fn.name}__{op.target}')


def _h_br_cond(em: XtensaEmitter, op: BrCond, fn: Function) -> None:
    """`br i1 %cond, label %t, label %f`. The condition is 32-bit
    {0,1}; we use BNEZ (branch if not zero) for the "true" target,
    then an unconditional jump for the "false" target.
    """
    em._load_ssa_to(op.cond, 'a8')
    em.emit(f'  bnez    a8, .L{fn.name}__{op.if_true}')
    em.emit(f'  j       .L{fn.name}__{op.if_false}')


# ---------------------------------------------------------------------------
# A8-ish — CsscOutln: route to cssc_print_<kind> based on value_type.
# ---------------------------------------------------------------------------
def _h_csscoutln(em: XtensaEmitter, op: CsscOutln, fn: Function) -> None:
    """`cssc::outln(val)` — pick the matching runtime symbol + width.

    For `ptr` kind (string literal materialised by `ConstStr`), the
    runtime symbol is `cssc_print_str(ptr, i64 len)` — we MUST pass
    the length too, otherwise the function reads garbage in place
    of `len` and silently prints zero bytes (the bug that made
    `cssc::outln("foo")` produce no chip output even though the
    higher-level emitters were correct).

    Per CSSC-Xtensa CALL0 ABI with pair-align (spec §16.5):
      `(ptr, i64)` → a2 = ptr, a4 = len.lo, a5 = len.hi
      (a3 is the pair-align skip).

    The length comes from the per-SSA-id side-table populated by
    `_h_const_str` at ConstStr emit time.
    """
    kind = op.value_type.kind
    sym = {
        'i64':        'cssc_print_int',
        'i1':         'cssc_print_bool',
        'f64':        'cssc_print_float',
        'string_ptr': 'cssc_print_string',
        'ptr':        'cssc_print_str',
    }.get(kind, 'cssc_print_val')
    if kind == 'ptr':
        # ptr + length, pair-aligned. ptr goes in a2; pair-align
        # skips a3; the i64 length fills a4:a5.
        em._load_ssa_to(op.value, 'a2')
        length = getattr(em, '_const_str_len', {}).get(op.value, 0)
        # `length` is the byte count (excluding any trailing NUL).
        # Materialise as a 32-bit immediate into a4; a5 holds the
        # high half of the i64 (always 0 for our string sizes).
        em._materialise_imm32('a4', length & 0xFFFFFFFF)
        em._materialise_imm32('a5', 0)
        em.emit(f'  call0   {sym}')
        # `cssc_print_str` is the cssc::out helper — its runtime
        # comment explicitly states "No trailing newline (cssc::out
        # semantics); the outln-side prints its own '\n' via a
        # separate call." We're the outln-side; emit that '\n' now.
        # Without it, consecutive `cssc::outln("foo"); cssc::outln(
        # "bar");` calls printed "foobar" on one chip-log line — the
        # other kind paths (`cssc_print_int` / `_bool` / `_float` /
        # `_string`) all emit '\n' internally, so this is the only
        # outlier that needed an external newline emit.
        em.emit(f'  movi.n  a2, 10')
        em.emit(f'  call0   cssc_uart_putc')
        return
    if _is_pair_kind(kind):
        em._load_ssa_to_pair(op.value, 'a2', 'a3')
    else:
        em._load_ssa_to(op.value, 'a2')
    em.emit(f'  call0   {sym}')


# ---------------------------------------------------------------------------
# Op dispatch table.
# Anything NOT in this table will raise `NotImplementedError` from
# `XtensaEmitter._emit_op`. That's intentional — we want phase gaps
# to be loud, not silent.
# ---------------------------------------------------------------------------
# `--diag-mem-trace` allow-list. Trace markers are emitted BEFORE each
# of these op kinds; everything else (ConstInt, SlotAlloc, GlobalAddr,
# pure ALU like WrapInt) is skipped to keep UART volume bounded. The
# allow-list deliberately covers the ops most likely to expose the bug
# class chased here:
#   * Call           — every call0 is a potential clobber site
#   * MemberAddr     — `obj->field` ptrs are the classic "stale after
#                      call" pattern (videodriver tick crash candidate)
#   * Ret            — captures the moment before return; if scope_pop
#                      or the saved-reg restore corrupts state we see
#                      the LAST op marker here
#   * SlotStore      — wild stores ARE the symptom of the videodriver
#                      crash (StoreProhibited); trace before each
#                      lets us narrow to the offending CIR site
#   * BrCond         — selects a branch; useful when crash happens in
#                      one branch of an `if` but not the other
_TRACEABLE_OP_KINDS = frozenset({'Call', 'MemberAddr', 'Ret',
                                  'SlotStore', 'BrCond'})


_OP_HANDLERS = {
    ConstInt:    _h_const_int,
    ConstBool:   _h_const_bool,
    ConstFloat:  _h_const_float,
    ConstStr:    _h_const_str,
    SlotAlloc:   _h_slot_alloc,
    SlotStore:   _h_slot_store,
    SlotLoad:    _h_slot_load,
    SlotRelease: _h_slot_release,
    SlotRetain:  _h_slot_retain,
    WrapInt:     _h_wrap_int,
    WrapFloat:   _h_wrap_float,
    WrapBool:    _h_wrap_bool,
    GlobalAddr:  _h_global_addr,
    MemberAddr:  _h_member_addr,
    Call:        _h_call,
    Ret:         _h_ret,
    Unreachable: _h_unreachable,
    BinOp:       _h_binop,
    CmpOp:       _h_cmpop,
    Br:          _h_br,
    BrCond:      _h_br_cond,
    CsscOutln:   _h_csscoutln,
    # Scope ops. The function-level scope_push/pop is driven by the
    # prologue/epilogue (`_function_owns_scope`) — that's the only
    # auto-emitted scope boundary CSSC offers. Body-level
    # ScopePush/ScopePop CIR ops are elided here because cir_lower
    # currently emits none for the Xtensa target (loop bodies are
    # bare per the language contract — "you allocated, you delete").
    # If a future feature needs body-level scopes, swap the lambdas
    # for real `call0 cssc_scope_push/pop` emits. ScopeBind is a
    # builder bookkeeping op with no machine-code effect.
    ScopePush:   lambda em, op, fn: None,
    ScopePop:    lambda em, op, fn: None,
    ScopeBind:   lambda em, op, fn: None,
}


# v6 ptrtoint / inttoptr — Xtensa is a 32-bit ISA so ptr fits in
# i32. The CIR carries 8-byte i64 values for uniformity with the
# x86_64 ABI; on Xtensa we store the ptr in the low half and zero
# the high half. Used by:
#   * `_lower_arg_for_call` (ref args pass slot ADDRESS as i64)
#   * `_lower_scanp` (callee casts back to ptr for binding)
#   * `_lower_mirror` (live-ref slot stores ptr-as-i64)
def _h_ptr_to_int(em: 'XtensaEmitter', op, fn) -> None:
    # Load the src ptr (32-bit register) into the i64 pair: low=ptr, hi=0.
    em._load_ssa_to(op.src, 'a8')                # a8 = src ptr
    d_lo, d_hi = em.regs.take_64(op.id)
    if d_lo.startswith('['):
        res_lo, res_hi = 'a2', 'a3'
    else:
        res_lo, res_hi = d_lo, d_hi
    em.emit(f'  mov.n   {res_lo}, a8')
    em.emit(f'  movi.n  {res_hi}, 0')
    if d_lo.startswith('['):
        off = em.regs.id_to_spill[op.id]
        em.emit(f'  s32i.n  {res_lo}, a1, {off}')
        em.emit(f'  s32i.n  {res_hi}, a1, {off + 4}')


def _h_int_to_ptr(em: 'XtensaEmitter', op, fn) -> None:
    # Inverse of ptr_to_int: take the low 32 bits of the i64 as the ptr.
    em._load_ssa_to_pair(op.src, 'a8', 'a9')     # a8:a9 = src i64
    d = em.regs.take_32(op.id)
    if d.startswith('['):
        em.emit(f'  s32i.n  a8, a1, {em.regs.id_to_spill[op.id]}')
    else:
        em.emit(f'  mov.n   {d}, a8')


# Late-binding registration: import the op classes lazily (the import
# at module-top is the canonical place but PtrToInt/IntToPtr were
# added later and may be missing on older snapshots).
try:
    from ..cir.ops import PtrToInt as _PtrToInt
    _OP_HANDLERS[_PtrToInt] = _h_ptr_to_int
except ImportError:
    pass
try:
    from ..cir.ops import IntToPtr as _IntToPtr
    _OP_HANDLERS[_IntToPtr] = _h_int_to_ptr
except ImportError:
    pass


def supported_ops() -> Set[type]:
    """Public introspection — what CIR ops the Xtensa backend handles."""
    return {k for k, v in _OP_HANDLERS.items()
            if not (hasattr(v, '__name__') and v.__name__ == '<lambda>'
                    and 'NotImplementedError' in (v.__code__.co_consts
                                                  if hasattr(v, '__code__') else ()))}


# ---------------------------------------------------------------------------
# A8 — Minimal runtime in Xtensa assembly.
#
# These are hand-written because the LLVM IR runtime in [embedded.py]
# requires the clang Xtensa backend which stock LLVM lacks. By writing
# the runtime in raw assembly we keep the build self-contained.
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# Per-chip MMIO + memory-map profiles. Each Xtensa target (LX106 on
# ESP8266, LX7 on ESP32, LX7 on ESP32-S2/S3 etc.) shares the
# instruction encoding but has its own peripheral-register layout,
# IRAM/DRAM split, and feature set (FPU availability, register-window
# vs CALL0 ABI, hardware I2C vs bit-bang).
#
# The profile table drives the runtime emission via string
# substitution: each `__PROFILE_<KEY>__` placeholder in the runtime
# assembly is replaced with the active profile's value at emit time.
# That keeps the same hand-written assembly template across chips
# while letting each target plug in its correct addresses.
#
# Adding a new chip family = add an entry here + verify any
# chip-specific instructions in the dispatch table. The CIR-side
# codegen stays unchanged.
# ---------------------------------------------------------------------------
_PROFILES: Dict[str, Dict[str, Any]] = {
    # ESP8266 (Tensilica L106 / Xtensa LX106). The original CSSC
    # bare-metal target. Documented in TRM v2.5 §3.
    'esp8266': {
        'triple':            'xtensa-none-elf',
        'cpu_feature':       'density',
        'fpu':               False,            # software emulation only
        'cycles_per_ms':     80_000,           # 80 MHz default
        'apb_clk_hz':        80_000_000,       # APB always 80 MHz
        'uart_clk_hz':       80_000_000,       # UART clock = APB
        'arena_size_bytes':  65536,            # 64 KB DRAM bump
        # MMIO addresses (in hex strings for literal-pool emission).
        'uart0_tx':          '0x60000000',
        'uart1_tx':          '0x60000F00',
        'uart1_clkdiv':      '0x60000F14',
        'gpio_out':          '0x60000300',
        'gpio_out_w1ts':     '0x60000304',
        'gpio_out_w1tc':     '0x60000308',
        'gpio_enable_w1ts':  '0x60000310',
        'gpio_enable_w1tc':  '0x60000314',
        'gpio_in':           '0x60000318',
        'iomux_table_base':  '0x60000804',     # PERIPHS_IO_MUX
        'spi_cmd':           '0x60000200',
        'spi_clock':         '0x60000218',
        'spi_user':          '0x60000234',
        'spi_user1':         '0x60000238',
        'spi_w0':            '0x60000240',
        'adc_rom_thunk':     '0x40006A14',
        'frc1_load':         '0x60000600',
        'frc1_count':        '0x60000604',
        'frc1_ctrl':         '0x60000608',
        'iram_base':         '0x40100000',     # for the boot stub
        'dram_base':         '0x3FFE8000',
        # Per-GPIO IOMUX register address (PERIPHS_IO_MUX + per-pin offset).
        # Indexed by physical GPIO number 0..15. Values are taken from
        # the ESP8266 TRM v2.5 §4.1 (IO MUX register layout). Bit 7 of
        # each register is the pullup-enable bit our `cssc_pin_pullup`
        # toggles.
        'iomux_table': [
            '0x60000834',  # GPIO 0  — MTDI / U0RXD
            '0x60000818',  # GPIO 1
            '0x60000838',  # GPIO 2
            '0x60000814',  # GPIO 3
            '0x6000083C',  # GPIO 4
            '0x60000840',  # GPIO 5
            '0x6000081C',  # GPIO 6
            '0x60000820',  # GPIO 7
            '0x60000824',  # GPIO 8
            '0x60000828',  # GPIO 9
            '0x6000082C',  # GPIO 10
            '0x60000830',  # GPIO 11
            '0x60000804',  # GPIO 12
            '0x60000808',  # GPIO 13
            '0x6000080C',  # GPIO 14
            '0x60000810',  # GPIO 15
        ],
    },
    # ESP32 (Tensilica L7 / Xtensa LX7). Documented in ESP32 TRM v4.6.
    # Notes:
    #   * Different MMIO base — peripherals are at 0x3FF4xxxx.
    #   * Hardware FPU is available (single-precision); double-precision
    #     still goes through libgcc thunks because the LX7 FPU doesn't
    #     cover f64. Single-precision F1b adds direct ADD.S / SUB.S /
    #     MUL.S / DIV.S instructions for `float` slots when the user
    #     compiles with `#stack[float, 32]` — half the cost of a
    #     libgcc thunk call.
    #   * Hardware I2C peripherals (I2C0 at 0x3FF53000, I2C1 at
    #     0x3FF67000); the bit-bang code from D2 still works as a
    #     fallback when the user picks unmapped GPIO pins. F1c adds
    #     the hardware-I2C-aware fast path.
    #   * Dual-core: PRO_CPU and APP_CPU. CSSC user code currently
    #     pins to PRO_CPU; the second core stays idle. F1d wires
    #     `cssc::on_core(1) { ... }` for explicit cross-core dispatch.
    'esp32': {
        'triple':            'xtensa-esp32-elf',
        'cpu_feature':       'density',
        'fpu':               'single',         # LX7 has single-precision FPU
        'cycles_per_ms':     240_000,          # 240 MHz default
        'apb_clk_hz':        80_000_000,       # APB still 80 MHz on ESP32
        'uart_clk_hz':       80_000_000,       # UART clock = APB
        'arena_size_bytes':  131072,           # 128 KB DRAM bump
        'uart0_tx':          '0x3FF40000',
        'uart1_tx':          '0x3FF50000',
        'uart1_clkdiv':      '0x3FF50014',
        'gpio_out':          '0x3FF44004',
        'gpio_out_w1ts':     '0x3FF44008',
        'gpio_out_w1tc':     '0x3FF4400C',
        'gpio_enable_w1ts':  '0x3FF44024',
        'gpio_enable_w1tc':  '0x3FF44028',
        'gpio_in':           '0x3FF4403C',
        'iomux_table_base':  '0x3FF49000',     # IO_MUX
        'spi_cmd':           '0x3FF65000',     # SPI2 (HSPI on ESP32)
        'spi_clock':         '0x3FF65018',
        'spi_user':          '0x3FF65034',
        'spi_user1':         '0x3FF65038',
        'spi_w0':            '0x3FF65080',
        # ADC: ESP32 has no callable ROM thunk for ADC1 — we program
        # SENS_SAR_MEAS_START1_REG directly. The substitution points
        # `cssc_adc_read` at a hand-written 12-bit SAR sequencer that
        # configures the channel bitmap, kicks off a measurement, and
        # polls SAR_MEAS1_DONE. See `cssc_adc_esp32_read` below.
        'adc_rom_thunk':     'cssc_adc_esp32_read',
        'frc1_load':         '0x3FF5F004',     # TIMG0 T0_LOAD
        'frc1_count':        '0x3FF5F00C',
        'frc1_ctrl':         '0x3FF5F000',
        'iram_base':         '0x40080000',
        'dram_base':         '0x3FFB0000',
        # Per-GPIO IOMUX register address per ESP32 TRM v4.6 §4.11
        # (IO_MUX_GPIOn_REG). 40 entries — GPIO28-31 are reserved/inputs
        # only on ESP32 but we keep slots to preserve `pin_no * 4`
        # indexing. The reserved entries point at the IO_MUX base which
        # has no pullup bit; pin_pullup on those pins is effectively a
        # no-op.
        'iomux_table': [
            '0x3FF49044',  # GPIO 0
            '0x3FF49088',  # GPIO 1  (U0TXD)
            '0x3FF49040',  # GPIO 2
            '0x3FF49084',  # GPIO 3  (U0RXD)
            '0x3FF49048',  # GPIO 4
            '0x3FF4906C',  # GPIO 5
            '0x3FF49060',  # GPIO 6
            '0x3FF49064',  # GPIO 7
            '0x3FF49068',  # GPIO 8
            '0x3FF49054',  # GPIO 9
            '0x3FF49058',  # GPIO 10
            '0x3FF4905C',  # GPIO 11
            '0x3FF49034',  # GPIO 12
            '0x3FF49038',  # GPIO 13
            '0x3FF49030',  # GPIO 14
            '0x3FF4903C',  # GPIO 15
            '0x3FF4904C',  # GPIO 16
            '0x3FF49050',  # GPIO 17
            '0x3FF49070',  # GPIO 18
            '0x3FF49074',  # GPIO 19
            '0x3FF49078',  # GPIO 20
            '0x3FF4907C',  # GPIO 21
            '0x3FF49080',  # GPIO 22
            '0x3FF4908C',  # GPIO 23
            '0x3FF49090',  # GPIO 24
            '0x3FF49024',  # GPIO 25
            '0x3FF49028',  # GPIO 26
            '0x3FF4902C',  # GPIO 27
            '0x3FF49000',  # GPIO 28 — reserved on ESP32 (base sentinel)
            '0x3FF49000',  # GPIO 29 — reserved
            '0x3FF49000',  # GPIO 30 — reserved
            '0x3FF49000',  # GPIO 31 — reserved
            '0x3FF4901C',  # GPIO 32
            '0x3FF49020',  # GPIO 33
            '0x3FF49014',  # GPIO 34 — input-only (RTC)
            '0x3FF49018',  # GPIO 35 — input-only
            '0x3FF49004',  # GPIO 36 — input-only
            '0x3FF49008',  # GPIO 37 — input-only
            '0x3FF4900C',  # GPIO 38 — input-only
            '0x3FF49010',  # GPIO 39 — input-only
        ],
    },
}


def get_profile(name: str) -> Dict[str, Any]:
    """Look up a chip profile. Raises a clear error for unknown names."""
    if name not in _PROFILES:
        raise ValueError(
            f"unknown Xtensa profile {name!r}; "
            f"known: {sorted(_PROFILES.keys())}"
        )
    return _PROFILES[name]


def _profile_iomux_table_asm(profile: Dict[str, Any]) -> str:
    """Render the profile's per-GPIO IOMUX register table as `.word`
    directives. One entry per physical pin, indexed by pin_no.

    The pin_pullup helper indexes this table as `table_base + pin*4`,
    so the entries must stay in numerical order with no gaps.
    """
    out: List[str] = []
    for i, addr in enumerate(profile['iomux_table']):
        out.append(f'  .word {addr}   ; GPIO {i}')
    return '\n'.join(out)


def _profile_substitution_map(profile: Dict[str, Any]) -> Dict[str, str]:
    """Build the placeholder → value mapping consumed by the runtime
    template. Every `__PROFILE_<KEY>__` token in the template must
    have a corresponding entry here, otherwise the substitution leaves
    it raw and the assembler will emit a `bad expression` error.
    """
    return {
        '__PROFILE_UART0_TX__':        profile['uart0_tx'],
        '__PROFILE_UART1_TX__':        profile['uart1_tx'],
        '__PROFILE_UART1_CLKDIV__':    profile['uart1_clkdiv'],
        '__PROFILE_GPIO_OUT__':        profile['gpio_out'],
        '__PROFILE_GPIO_OUT_W1TS__':   profile['gpio_out_w1ts'],
        '__PROFILE_GPIO_OUT_W1TC__':   profile['gpio_out_w1tc'],
        '__PROFILE_GPIO_EN_W1TS__':    profile['gpio_enable_w1ts'],
        '__PROFILE_GPIO_EN_W1TC__':    profile['gpio_enable_w1tc'],
        '__PROFILE_GPIO_IN__':         profile['gpio_in'],
        '__PROFILE_IOMUX_BASE__':      profile['iomux_table_base'],
        '__PROFILE_SPI_CMD__':         profile['spi_cmd'],
        '__PROFILE_SPI_CLOCK__':       profile['spi_clock'],
        '__PROFILE_SPI_USER__':        profile['spi_user'],
        '__PROFILE_SPI_USER1__':       profile['spi_user1'],
        '__PROFILE_SPI_W0__':          profile['spi_w0'],
        '__PROFILE_FRC1_LOAD__':       profile['frc1_load'],
        '__PROFILE_FRC1_COUNT__':      profile['frc1_count'],
        '__PROFILE_FRC1_CTRL__':       profile['frc1_ctrl'],
        '__PROFILE_ADC_READ_TARGET__': profile['adc_rom_thunk'],
        '__PROFILE_CYCLES_PER_MS__':   str(profile['cycles_per_ms']),
        '__PROFILE_APB_HALF_HZ__':     str(profile['apb_clk_hz'] // 2),
        '__PROFILE_UART_CLK_HZ__':     str(profile['uart_clk_hz']),
        '__PROFILE_IOMUX_TABLE_WORDS__': _profile_iomux_table_asm(profile),
    }


def _apply_profile_substitutions(asm_text: str,
                                 profile: Dict[str, Any]) -> str:
    """Replace every `__PROFILE_<KEY>__` token with the profile value.

    After the substitution pass we sanity-check that no placeholder
    leaked through (which would point at a typo in the template). The
    diagnostic is intentionally loud — getting an MMIO address wrong
    on bare metal lands as a hardware lockup, not a Python exception,
    so we fail fast at emit time.
    """
    import re
    subs = _profile_substitution_map(profile)
    for key, value in subs.items():
        asm_text = asm_text.replace(key, value)
    leaked = re.findall(r'__PROFILE_[A-Z0-9_]+__', asm_text)
    if leaked:
        raise RuntimeError(
            f"xtensa runtime substitution: unsubstituted placeholders "
            f"remain: {sorted(set(leaked))} — extend "
            f"`_profile_substitution_map`"
        )
    return asm_text


def _load_font5x7() -> List[Tuple[int, int, int, int, int]]:
    """Parse the project's font5x7 table out of `cssc_tft.c`.

    Single source of truth: the host runtime and the Xtensa runtime
    use the same 96 × 5-byte glyph block, so we read the existing C
    declaration rather than maintaining a duplicate (and risking
    drift). The parse is text-only — we grep the brace-pair lines and
    pull out the five hex bytes per glyph.

    Returns a list of 96 (b0, b1, b2, b3, b4) tuples in ASCII order
    starting at 0x20. If the source file or the table can't be
    located, falls back to a blank-glyph block so the build doesn't
    fail catastrophically — but the OLED text will render empty.
    """
    import re
    from pathlib import Path
    # cssc_tft.c lives in the same `native/` dir as this module.
    src = Path(__file__).parent.parent / 'cssc_tft.c'
    if not src.is_file():
        return [(0, 0, 0, 0, 0)] * 96
    try:
        text = src.read_text(encoding='utf-8', errors='replace')
    except OSError:
        return [(0, 0, 0, 0, 0)] * 96
    # Match `{0xNN,0xNN,0xNN,0xNN,0xNN}` — five hex bytes per glyph,
    # ignore whitespace + commas + trailing-comma noise.
    rows = re.findall(
        r'\{\s*0x([0-9A-Fa-f]{2})\s*,\s*'
        r'0x([0-9A-Fa-f]{2})\s*,\s*'
        r'0x([0-9A-Fa-f]{2})\s*,\s*'
        r'0x([0-9A-Fa-f]{2})\s*,\s*'
        r'0x([0-9A-Fa-f]{2})\s*\}',
        text,
    )
    glyphs = [tuple(int(b, 16) for b in row) for row in rows[:96]]
    # Pad if the source had fewer than 96 entries.
    while len(glyphs) < 96:
        glyphs.append((0, 0, 0, 0, 0))
    return glyphs   # type: ignore[return-value]


def _font5x7_asm() -> str:
    """Render the font5x7 table as Xtensa `.byte` directives. Output
    is one row of 5 bytes per ASCII codepoint 0x20..0x7F."""
    rows = _load_font5x7()
    out: List[str] = []
    for i, glyph in enumerate(rows):
        c = i + 0x20
        ascii_hint = chr(c) if 32 <= c < 127 else '?'
        bytes_s = ', '.join(f'0x{b:02X}' for b in glyph)
        out.append(f'  .byte {bytes_s}    ; 0x{c:02X} {ascii_hint!r}')
    return '\n'.join(out)


def emit_runtime_min(profile: str,
                     requested_symbols: Optional[Set[str]] = None) -> str:
    """Return the hand-written Xtensa runtime as assembly text.

    Full runtime surface for Phases A8 + B2b + B3 + B4 + B7. Every
    function is hand-written Xtensa LX106 assembly; nothing depends
    on libc. The libgcc thunks (`__mulsi3`/`__divsi3`/`__adddf3`/…)
    come from `libgcc.a` which ships with `xtensa-lx106-elf-gcc` and
    the linker pulls them in automatically when our code references
    them.

    | Phase  | Symbol                       | Status |
    |--------|------------------------------|--------|
    | A8     | cssc_runtime_init            | done   |
    | A8     | cssc_runtime_shutdown        | done   |
    | A8     | cssc_uart_putc               | done   |
    | A8     | cssc_print_int               | done   |
    | A8     | cssc_print_bool              | done   |
    | A8     | cssc_print_str               | done   |
    | B2b    | cssc_print_string            | done   |
    | B7     | cssc_sleep_ms                | done   |
    | B7     | cssc_uptime                  | done   |
    | B7     | cssc_tick                    | done   |
    | B4     | cssc_obj_alloc / cssc_obj_free | done   |
    | B2b    | cssc_string_lit              | done   |
    | B2b    | cssc_string_free             | done (no-op — arena) |
    | B2b    | cssc_string_size             | done   |
    | B2b    | cssc_string_data             | done   |
    | B2b    | cssc_string_concat           | done   |
    | B2b    | cssc_string_eq               | done   |
    | B3     | cssc_int_to_str              | done   |
    | B3     | cssc_float_to_str            | done   |
    | B3     | cssc_bool_to_str             | done   |
    | A8     | strlen-like internal helper  | done   |
    """
    _runtime_text = r'''
  .text
  ; ===========================================================================
  ; Hand-written Xtensa LX106 runtime — minimal surface (Phase A8).
  ; CALL0 ABI: args in a2..a7, return value in a2.
  ; ===========================================================================

  .global cssc_runtime_init
  .type   cssc_runtime_init, @function
cssc_runtime_init:
  ; Disable the hardware watchdog. On bare metal we don't pet it,
  ; and the ROM bootloader leaves it enabled with a ~3.2 s timeout.
  ; Without this the chip would reset every few seconds mid-program.
  ;   WDT_CTL_REG (0x60000900) bit 0 = WDT_EN. Clear to disable.
  l32r    a8, .Lwdt_ctl_addr
  movi.n  a9, 0
  s32i.n  a9, a8, 0
  memw
  ; Seed `cssc_last_ccount` with the current CCOUNT so `cssc_uptime`'s
  ; delta math starts from zero on the first call. Without this seed,
  ; the first call would treat the whole power-on CCOUNT value as
  ; elapsed time and bump cssc_uptime_ms by ~tens of seconds.
  rsr.ccount a9
  l32r    a8, .Lrt_lastcc_addr
  s32i.n  a9, a8, 0
  ret.n
  .literal_position
  .literal .Lwdt_ctl_addr,    0x60000900
  .literal .Lrt_lastcc_addr,  cssc_last_ccount
  .size cssc_runtime_init, .-cssc_runtime_init

  .global cssc_runtime_shutdown
  .type   cssc_runtime_shutdown, @function
cssc_runtime_shutdown:
  ret.n
  .size cssc_runtime_shutdown, .-cssc_runtime_shutdown

  ; --- UART0 TX FIFO single-byte write -------------------------------------
  ; cssc_uart_putc(i8 b in a2)
  ;
  ; ESP8266 UART0 TX FIFO is at 0x60000000. Writing a byte enqueues it.
  ; We don't check FIFO full status — for ASCII-character cadence at
  ; 74880 baud the FIFO drains faster than we can push.
  .global cssc_uart_putc
  .type   cssc_uart_putc, @function
cssc_uart_putc:
  ; Send one byte to UART0. We MUST wait for FIFO space first —
  ; the ESP8266 UART0 FIFO is 128 bytes and a busy print loop (e.g.
  ; particle_world's per-frame grid render: ~250 chars in <2 ms)
  ; overruns it well within a single tick. Writing past a full
  ; FIFO silently drops the byte, producing garbled output like
  ; `p2 x842` instead of `p2 x=8.400` (the chip got the `8`, `4`,
  ; and `2` but lost the `=`, `.`, and trailing zeros while the
  ; FIFO was draining).
  ;
  ; UART0_STATUS lives at uart0_base + 0x1C. Bits 16..23 = TX FIFO
  ; byte count. Wait until count < 120 (leaves 8 bytes of headroom
  ; so a follow-up `s8i` doesn't race the drainer).
  l32r    a8, .Luart0_tx_addr
.Luart_wait:
  l32i    a9, a8, 0x1C              ; read UART_STATUS (uart_base + 0x1C)
  extui   a9, a9, 16, 8             ; bits 16..23 = TX FIFO count
  movi    a11, 120
  bgeu    a9, a11, .Luart_wait      ; loop while count >= 120
  s8i     a2, a8, 0                 ; FIFO has space — push the byte
  memw                              ; ensure write reaches the MMIO bus
  ret.n
  .literal_position
  .literal .Luart0_tx_addr, __PROFILE_UART0_TX__
  .size cssc_uart_putc, .-cssc_uart_putc

  ; --- cssc_print_int(i64 n in a2:a3) --------------------------------------
  ; Format `n` (low 32 bits) as decimal + trailing '\n', byte-by-byte
  ; through cssc_uart_putc. Uses an on-stack 12-byte scratch buffer.
  .global cssc_print_int
  .type   cssc_print_int, @function
cssc_print_int:
  ; CALL0 ABI: a0-a11 are caller-save (clobbered by every call0).
  ; a12-a15 are callee-save. Values that must live across calls
  ; (n, the scratch-buffer pointer, the digit count) go in a12-a14;
  ; we save them in the prologue and restore in the epilogue.
  addi    a1, a1, -32
  s32i.n  a0,  a1, 28                ; return PC
  s32i.n  a12, a1, 24                ; a12 = n
  s32i.n  a13, a1, 20                ; a13 = scratch ptr
  s32i.n  a14, a1, 16                ; a14 = digit count
  mov.n   a12, a2                    ; a12 = n (low 32 bits)

  ; Handle negative
  movi.n  a8, 0
  bge     a12, a8, 1f
  movi.n  a2, 45                     ; '-'
  call0   cssc_uart_putc
  neg     a12, a12
1:
  ; Special-case 0 → emit single '0'
  movi.n  a8, 0
  bne     a12, a8, 2f
  movi.n  a2, 48                     ; '0'
  call0   cssc_uart_putc
  j       9f
2:
  ; Convert n to ASCII digits in reverse into [a1+0..a1+11].
  ; a13 = ptr cursor (callee-save; starts at a1+11 going down).
  addi    a13, a1, 11
  movi.n  a14, 0                     ; digit count (callee-save)
3:
  ; n_div = n / 10 via __divsi3 (caller-save scratch is clobbered).
  mov.n   a2, a12
  movi.n  a3, 10
  call0   __divsi3
  mov.n   a8, a2                     ; a8 = quotient (transient, used below)
  ; remainder = n - quotient*10
  mov.n   a2, a8
  movi.n  a3, 10
  call0   __mulsi3                   ; a2 = quotient*10
  sub     a9, a12, a2                ; a9 = remainder digit (0..9)
  addi    a9, a9, 48                 ; ASCII digit
  s8i     a9, a13, 0                 ; *(a13) = digit char
  addi    a13, a13, -1
  addi    a14, a14, 1
  ; n = quotient. Recompute since a8 may have been clobbered.
  mov.n   a2, a12
  movi.n  a3, 10
  call0   __divsi3
  mov.n   a12, a2                    ; a12 = next n
  movi.n  a10, 0
  bne     a12, a10, 3b
  ; Emit digits forward.
  addi    a13, a13, 1                ; first valid char
4:
  l8ui    a2, a13, 0
  call0   cssc_uart_putc
  addi    a13, a13, 1
  addi    a14, a14, -1
  movi.n  a10, 0
  bne     a14, a10, 4b
9:
  movi.n  a2, 10                     ; '\n'
  call0   cssc_uart_putc
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .size cssc_print_int, .-cssc_print_int

  ; `cssc_print_int_nonl(i64 n)` — print decimal digits WITHOUT a
  ; trailing newline. Used by `cssc_diag_mem_check` to keep the
  ; `[cssc-mem] fn=N arena=M sp=K` payload on ONE chip-log line so
  ; the host-side parser can match it via a single-line regex.
  ; Implementation: identical to cssc_print_int but skips the
  ; final `movi a2, 10; call0 cssc_uart_putc` step. Sharing the
  ; rest of the body would cost a function call — copy is cheap
  ; (~100 bytes) and avoids the indirection.
  .global cssc_print_int_nonl
  .type   cssc_print_int_nonl, @function
cssc_print_int_nonl:
  addi    a1, a1, -32
  s32i.n  a0,  a1, 28
  s32i.n  a12, a1, 24
  s32i.n  a13, a1, 20
  s32i.n  a14, a1, 16
  mov.n   a12, a2
  movi.n  a8, 0
  bge     a12, a8, 11f
  movi.n  a2, 45                     ; '-'
  call0   cssc_uart_putc
  neg     a12, a12
11:
  movi.n  a8, 0
  bne     a12, a8, 12f
  movi.n  a2, 48                     ; '0'
  call0   cssc_uart_putc
  j       19f
12:
  addi    a13, a1, 11
  movi.n  a14, 0
13:
  mov.n   a2, a12
  movi.n  a3, 10
  call0   __divsi3
  mov.n   a8, a2
  mov.n   a2, a8
  movi.n  a3, 10
  call0   __mulsi3
  sub     a9, a12, a2
  addi    a9, a9, 48
  s8i     a9, a13, 0
  addi    a13, a13, -1
  addi    a14, a14, 1
  mov.n   a2, a12
  movi.n  a3, 10
  call0   __divsi3
  mov.n   a12, a2
  movi.n  a10, 0
  bne     a12, a10, 13b
  addi    a13, a13, 1
14:
  l8ui    a2, a13, 0
  call0   cssc_uart_putc
  addi    a13, a13, 1
  addi    a14, a14, -1
  movi.n  a10, 0
  bne     a14, a10, 14b
19:
  ; NO trailing '\n' — that's the only difference vs cssc_print_int.
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .size cssc_print_int_nonl, .-cssc_print_int_nonl

  ; A.3.17: `cssc::outln()` with no args calls this — emits a single '\n'
  ; via UART. No formatting, no buffer needed.
  .global cssc_print_newline
  .type   cssc_print_newline, @function
cssc_print_newline:
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  movi.n  a2, 10
  call0   cssc_uart_putc
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_print_newline, .-cssc_print_newline

  ; --- cssc_print_bool(i1 b in a2) -----------------------------------------
  .global cssc_print_bool
  .type   cssc_print_bool, @function
cssc_print_bool:
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  movi.n  a8, 0
  beq     a2, a8, 7f
  ; print "true\n"
  movi.n  a2, 116                    ; t
  call0   cssc_uart_putc
  movi.n  a2, 114                    ; r
  call0   cssc_uart_putc
  movi.n  a2, 117                    ; u
  call0   cssc_uart_putc
  movi.n  a2, 101                    ; e
  call0   cssc_uart_putc
  j       8f
7:
  ; print "false\n"
  movi.n  a2, 102                    ; f
  call0   cssc_uart_putc
  movi.n  a2, 97                     ; a
  call0   cssc_uart_putc
  movi.n  a2, 108                    ; l
  call0   cssc_uart_putc
  movi.n  a2, 115                    ; s
  call0   cssc_uart_putc
  movi.n  a2, 101                    ; e
  call0   cssc_uart_putc
8:
  movi.n  a2, 10
  call0   cssc_uart_putc
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_print_bool, .-cssc_print_bool

  ; --- cssc_print_str(ptr s, i64 len) --------------------------------------
  ; Byte-stream a UTF-8 buffer. No trailing newline (cssc::out semantics);
  ; the outln-side prints its own '\n' via a separate call.
  ;
  ; CALL0 ABI with pair-align (spec §16.5): signature `(ptr, int)`
  ; lands as `a2 = ptr, a4:a5 = int (a3 is the pair-align skip)`.
  ; len.lo therefore arrives in a4 (NOT a3 as the prior version
  ; assumed — that bug made every cssc_print_str call read garbage
  ; in place of the length and silently print 0 bytes, which is why
  ; `cssc::outln("foo")` produced no output on chip).
  .global cssc_print_str
  .type   cssc_print_str, @function
cssc_print_str:
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  mov.n   a12, a2                    ; ptr (low half of arg0; LX106
                                     ; pointers are 32-bit so the
                                     ; high half is irrelevant)
  mov.n   a13, a4                    ; len.lo (a4 per pair-align ABI;
                                     ; a5 holds len.hi which never
                                     ; matters since lengths fit i32)
5:
  movi.n  a8, 0
  beq     a13, a8, 6f
  l8ui    a2, a12, 0
  call0   cssc_uart_putc
  addi    a12, a12, 1
  addi    a13, a13, -1
  j       5b
6:
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_print_str, .-cssc_print_str

  ; `cssc_out_str(ptr, i64 len)` — alias for `cssc_print_str` with
  ; identical semantics: byte-stream a buffer to UART, no trailing
  ; newline. Bug 4 fix: this symbol was previously unresolved at
  ; link time for any program using `cssc::out("string_lit")` — the
  ; v6 `cssc_out_string` runtime dispatch lowers raw `ptr` args to
  ; `cssc_out_str(ptr, len)` matching the host x86_64 emission. We
  ; expose it as a `.global` thunk that immediate-jumps to
  ; `cssc_print_str`. Zero per-call overhead (one `j` instruction).
  .global cssc_out_str
  .type   cssc_out_str, @function
cssc_out_str:
  j       cssc_print_str
  .size cssc_out_str, .-cssc_out_str

  ; `cssc_out_int(i64 n)` — print decimal digits without trailing
  ; newline. Used by `cssc::out(int_val)` (the no-newline sibling
  ; of `cssc::outln`). Alias to the pre-existing `cssc_print_int_nonl`
  ; that the --diag-mem helper already uses; zero-cost `j`.
  .global cssc_out_int
  .type   cssc_out_int, @function
cssc_out_int:
  j       cssc_print_int_nonl
  .size cssc_out_int, .-cssc_out_int

  ; `cssc_out_bool(i1 b)` — print "true" / "false" without newline.
  ; Stringify via cssc_bool_to_str then byte-stream via cssc_print_str
  ; (which already lacks a newline). Two call0 hops, ~30 bytes of asm.
  .global cssc_out_bool
  .type   cssc_out_bool, @function
cssc_out_bool:
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  call0   cssc_bool_to_str             ; in: a2 = bool, out: a2 = cssc_str*
  mov.n   a8, a2
  l32i.n  a9,  a8, 4                    ; size at +4 (post-A.3.4 refcount layout)
  l32i.n  a10, a8, 12                   ; data ptr at +12
  mov.n   a2, a10                       ; arg0 = data ptr
  mov.n   a4, a9                        ; arg1 lo = len (CALL0 i64 pair-align)
  movi.n  a5, 0                         ; arg1 hi = 0
  call0   cssc_print_str
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_out_bool, .-cssc_out_bool

  ; `cssc_out_float(f64 v)` — print float without newline.
  ; v is passed in a2:a3 per CALL0 i64/f64 pair-align ABI.
  .global cssc_out_float
  .type   cssc_out_float, @function
cssc_out_float:
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  call0   cssc_float_to_str             ; in: a2:a3 = f64, out: a2 = cssc_str*
  mov.n   a8, a2
  l32i.n  a9,  a8, 4
  l32i.n  a10, a8, 12
  mov.n   a2, a10
  mov.n   a4, a9
  movi.n  a5, 0
  call0   cssc_print_str
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_out_float, .-cssc_out_float

  ; `cssc_out_string(cssc_str* s)` — like cssc_print_string but no
  ; trailing newline. Same null-sentinel guard as cssc_print_string
  ; for spec §5.4 bare-block fallback safety: a2 == 0 → print "0x0".
  .global cssc_out_string
  .type   cssc_out_string, @function
cssc_out_string:
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  bnez    a2, cssc_out_string__nonnull
  movi.n  a2, '0'
  call0   cssc_uart_putc
  movi.n  a2, 'x'
  call0   cssc_uart_putc
  movi.n  a2, '0'
  call0   cssc_uart_putc
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
cssc_out_string__nonnull:
  mov.n   a8, a2
  l32i.n  a9,  a8, 4
  l32i.n  a10, a8, 12
  mov.n   a2, a10
  mov.n   a4, a9
  movi.n  a5, 0
  call0   cssc_print_str
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_out_string, .-cssc_out_string

  ; ===========================================================================
  ; F.3.j — Runtime memory-watchdog helper (`--diag-mem` build flag)
  ; ===========================================================================
  ;
  ; `cssc_diag_mem_check(i32 fn_id)` — emit one `[cssc-mem]` line to
  ; UART carrying the current arena cursor + stack pointer. Wired in
  ; via the `--diag-mem` build flag (see XtensaEmitter.diag_mem) so
  ; every user/object/sector function entry calls it with a small
  ; function-id integer that the host-side listener correlates back
  ; to a function name via the .map.
  ;
  ; Output format (one line per call):
  ;   [cssc-mem] fn=<ID> arena=<OFF> sp=<SP_HEX>\n
  ;
  ; The host-side post-processor (cssl_diagnostics_v2) scans for
  ; `[cssc-mem]` lines and detects:
  ;   * arena monotonic growth across iterations of the same fn
  ;     (suggests a scope-pop leak)
  ;   * SP drift across calls of the same fn (suggests a stack
  ;     leak via unbalanced SP)
  ;   * arena + (stack_top - sp) > total chip RAM (collision risk)
  ;
  ; Cost: ~30 UART putc calls per invocation. Heavy — only enable
  ; via `--diag-mem`. NOT default. Lives in `.iram0.text` like all
  ; cssc runtime so no DRAM overhead when unused.
  ;
  ; Calling convention: a2 = fn_id (i32). Clobbers a2-a11. Preserves
  ; a12-a15.
  .global cssc_diag_mem_check
  .type   cssc_diag_mem_check, @function
cssc_diag_mem_check:
  addi    a1, a1, -32
  s32i.n  a0, a1, 28
  s32i.n  a12, a1, 24                ; preserve callee-saves we use
  s32i.n  a13, a1, 20
  s32i.n  a14, a1, 16
  s32i.n  a15, a1, 12
  mov.n   a12, a2                    ; a12 = fn_id (preserved across calls)
  ; --- print "[cssc-mem] fn=" ---
  l32r    a2, .Ldiag_mem_prefix
  movi    a4, 14                     ; len of "[cssc-mem] fn="
  movi    a5, 0
  call0   cssc_print_str
  ; --- print fn_id as int (NO newline; use _nonl variant) ---
  mov.n   a2, a12
  movi.n  a3, 0
  call0   cssc_print_int_nonl
  ; --- print " arena=" ---
  l32r    a2, .Ldiag_mem_arena
  movi    a4, 7                      ; len of " arena="
  movi    a5, 0
  call0   cssc_print_str
  ; --- print arena_off (no newline) ---
  l32r    a8, .Larena_off_addr_mem
  l32i.n  a2, a8, 0
  movi.n  a3, 0
  call0   cssc_print_int_nonl
  ; --- print " sp=" ---
  l32r    a2, .Ldiag_mem_sp
  movi    a4, 4                      ; len of " sp="
  movi    a5, 0
  call0   cssc_print_str
  ; --- print SP (a1) — caller's SP = current_a1 + 32 ---
  addi    a2, a1, 32
  movi.n  a3, 0
  call0   cssc_print_int_nonl
  ; --- emit ONE trailing newline so the host listener sees the
  ; whole `[cssc-mem] fn=N arena=M sp=K` payload on ONE line and
  ; the regex matches. Without this the line was split across 6
  ; chip-log entries, breaking the parser.
  movi.n  a2, 10
  call0   cssc_uart_putc
  ; --- epilogue ---
  l32i.n  a15, a1, 12
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .literal_position
  .literal .Ldiag_mem_prefix,   .Lstr_diag_mem_prefix
  .literal .Ldiag_mem_arena,    .Lstr_diag_mem_arena
  .literal .Ldiag_mem_sp,       .Lstr_diag_mem_sp
  .literal .Larena_off_addr_mem, cssc_arena_off
  .section .rodata
.Lstr_diag_mem_prefix:  .asciz "[cssc-mem] fn="
.Lstr_diag_mem_arena:   .asciz " arena="
.Lstr_diag_mem_sp:      .asciz " sp="
  .text
  .size cssc_diag_mem_check, .-cssc_diag_mem_check

  ; ===========================================================================
  ; F.3.k — Runtime per-op trace helper (`--diag-mem-trace` build flag)
  ; ===========================================================================
  ;
  ; `cssc_diag_trace_op(i32 op_id)` — emit one `[cssc-trace] op=<id>`
  ; line to UART. Called BEFORE every potentially-faulting CIR op when
  ; the user opts in via `--diag-mem-trace`. The host-side renderer
  ; correlates the LAST logged op_id (before a crash) to a source line
  ; + op kind via the sidecar `.diag-trace-map.txt` written at build
  ; time by `v6_driver.build_native` from the `DIAG-TRACE-MAP` comment
  ; block at the end of user.s (emitted by `emit_program`).
  ;
  ; Output format (one line per op):
  ;   [cssc-trace] op=<ID>\n
  ;
  ; Cost: ~5 UART putc calls per op. UART floods at 74880 baud (each
  ; line ~3 ms wall-time); a 1000-op tick takes 3 s of UART. Default
  ; OFF — only enable to localize a specific crash. NOT for production.
  ;
  ; Calling convention: a2 = op_id (i32). Clobbers a2-a11. Preserves
  ; a12-a15 (none used here, but the prologue saves a0 for the call0
  ; tracer that audit_handler_call_clobber requires).
  .global cssc_diag_trace_op
  .type   cssc_diag_trace_op, @function
cssc_diag_trace_op:
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8                 ; preserve op_id across cssc_print_str
  mov.n   a12, a2                    ; a12 = op_id
  ; --- print "[cssc-trace] op=" ---
  l32r    a2, .Ldiag_trace_prefix
  movi    a4, 16                     ; len of "[cssc-trace] op="
  movi    a5, 0
  call0   cssc_print_str
  ; --- print op_id as int (no trailing newline) ---
  mov.n   a2, a12
  movi.n  a3, 0
  call0   cssc_print_int_nonl
  ; --- single trailing newline so host parser sees the line whole ---
  movi.n  a2, 10
  call0   cssc_uart_putc
  ; --- epilogue ---
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .literal_position
  .literal .Ldiag_trace_prefix, .Lstr_diag_trace_prefix
  .section .rodata
.Lstr_diag_trace_prefix: .asciz "[cssc-trace] op="
  .text
  .size cssc_diag_trace_op, .-cssc_diag_trace_op

  ; ===========================================================================
  ; B4 — DRAM bump allocator
  ; ===========================================================================
  ;
  ; A static .bss arena. The first byte of `cssc_arena` is the bump
  ; cursor anchor; `cssc_arena_top` is the address just past the
  ; arena. cssc_obj_alloc(size) bumps the cursor by `size` (8-byte-
  ; aligned). cssc_obj_free is a no-op — the arena lives forever.
  ;
  ; For a 64 KB arena at the default DRAM start (chosen by the linker
  ; via `.bss.cssc_arena`), the program gets ~64 KB of heap before
  ; OOM. Out-of-memory traps via `cssc_panic`.
  .section .bss
  .global cssc_arena
  .align  8
cssc_arena:
  .space  65536           ; 64 KB
cssc_arena_top:
  .global cssc_arena_off
  .align  4
cssc_arena_off:
  .word   0               ; bump cursor (byte offset into cssc_arena)

  ; Scope-frame stack: a 32-deep ring of saved arena cursors so each
  ; emitted user function / object label can push a fresh sub-arena at
  ; entry and bulk-free its allocations at exit. Without this, every
  ; tick of a render loop accumulates leaked strings (e.g. the result
  ; of `cssc_float_to_str(cssc::uptime())` passed straight to
  ; `display.text` — a transient temp that has no named owner) and
  ; the 64 KB arena fills in ~400 iterations.
  .global cssc_scope_stack
  .align  4
cssc_scope_stack:
  .space  128             ; 32 frames × 4 bytes each
  .global cssc_scope_sp
  .align  4
cssc_scope_sp:
  .word   0               ; depth (next-free slot index)

  .text

  ; cssc_scope_push: save the current arena cursor onto the scope
  ; stack. Called at the start of every emitter-produced label
  ; method (boot, tick, free, custom) so its allocations live in a
  ; dedicated sub-arena. Constructors do NOT call this — their
  ; allocations are object-member values that have to outlive the
  ; ctor call.
  ;
  ; CRITICAL: this is called from a function's PROLOGUE, BEFORE the
  ; function has saved its argument registers (a2..a7) to its
  ; frame. We MUST preserve every arg register verbatim, otherwise
  ; we wipe the caller's `self` pointer and the function ends up
  ; running with NULL — the next `*self` load traps cause-28 at
  ; offset 0x28 (= self+40, the `dir` field).
  ;
  ; Uses only a8..a11 (caller-save scratch from the perspective of
  ; whoever called scope_push, but distinct from a2..a7 which the
  ; emitter's prologue hasn't spilled yet).
  .global cssc_scope_push
  .type   cssc_scope_push, @function
  .align  4
cssc_scope_push:
  ; The bounds-check (A.2.1) calls into cssc_panic on overflow — that's
  ; a `call0` which would clobber a0 with the panic's return PC and
  ; trip the asm_tracer's a0-clobber check. Save a0 in a 16-byte frame
  ; up front so the tracer + any actually-reached panic both behave.
  ; The normal path restores + pops before ret.n; the panic path falls
  ; into an infinite loop so the frame leak is irrelevant.
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  l32r    a8, .Larena_off_addr_sp
  l32i.n  a9, a8, 0                ; cursor
  l32r    a10, .Lscope_sp_addr
  l32i.n  a11, a10, 0               ; sp
  ; A.2.1: bounds-check sp < 32 before we write stack[sp].
  movi.n  a8, 32
  bge     a11, a8, .Lscope_overflow
  l32r    a8, .Lscope_stack_addr    ; a8 = stack_base
  slli    a11, a11, 2               ; a11 = sp*4 (overwrites sp)
  add     a8, a8, a11               ; a8 = &stack[sp]
  s32i.n  a9, a8, 0                 ; stack[sp] = cursor
  ; Reload sp (we trashed it via the shift) and bump it.
  l32i.n  a11, a10, 0
  addi    a11, a11, 1
  s32i.n  a11, a10, 0               ; sp++
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
.Lscope_overflow:
  l32r    a2, .Lscope_overflow_msg
  movi    a3, 26                    ; strlen("cssc: scope stack overflow")
  call0   cssc_panic
1:
  j       1b                        ; cssc_panic is noreturn
  .size cssc_scope_push, .-cssc_scope_push

  ; cssc_scope_pop: restore the most-recently-pushed arena cursor.
  ; This INSTANTLY bulk-frees every allocation made since the
  ; matching push. Must preserve a2:a3 because the caller may have
  ; just computed a return value into those registers.
  .global cssc_scope_pop
  .type   cssc_scope_pop, @function
  .align  4
cssc_scope_pop:
  ; Same a0-save story as cssc_scope_push — the underflow path calls
  ; cssc_panic via call0 and asm_tracer flags any function with a
  ; call0 that lacks an a0-save prologue.
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  l32r    a8,  .Lscope_sp_addr
  l32i.n  a9,  a8, 0              ; sp
  ; A.2.2: bounds-check sp > 0 before decrement.
  beqz    a9, .Lscope_underflow
  addi    a9,  a9, -1
  s32i.n  a9,  a8, 0               ; sp--
  l32r    a10, .Lscope_stack_addr
  slli    a11, a9, 2
  add     a11, a10, a11           ; &stack[sp]
  l32i.n  a8,  a11, 0             ; saved cursor
  l32r    a9,  .Larena_off_addr_sp
  s32i.n  a8,  a9, 0               ; arena_off = saved
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
.Lscope_underflow:
  l32r    a2, .Lscope_underflow_msg
  movi    a3, 27                    ; strlen("cssc: scope stack underflow")
  call0   cssc_panic
1:
  j       1b                        ; cssc_panic is noreturn
  .literal_position
  .literal .Larena_off_addr_sp,   cssc_arena_off
  .literal .Lscope_sp_addr,       cssc_scope_sp
  .literal .Lscope_stack_addr,    cssc_scope_stack
  .literal .Lscope_overflow_msg,  .Lscope_overflow_str
  .literal .Lscope_underflow_msg, .Lscope_underflow_str
  .section .rodata
.Lscope_overflow_str:  .asciz "cssc: scope stack overflow"
.Lscope_underflow_str: .asciz "cssc: scope stack underflow"
  .text
  .size cssc_scope_pop, .-cssc_scope_pop

  ; cssc_load_i64_at: v6 mirror live-ref re-fetch helper.
  ; in:  a2 (lo) + a3 (hi) = i64 slot-address as a raw bit pattern.
  ; out: a2 (lo) + a3 (hi) = the 8 bytes living at that address;
  ;      `0,0` when the input address is 0 (so a mirror with no
  ;      live-ref returns the snapshot path's 0 deterministically).
  ;
  ; Called from `_emit_mirror_epilogue_ret` (cir_lower.py) at the
  ; function epilogue. The slot address was recorded by `mirror x;`
  ; pointing at x's storage cell; if x was `#delete`d during the
  ; post-mirror cleanup, its slot was zeroed by `_h_slot_release`
  ; (this file, slot_release handler) before the heap release. So
  ; re-fetching after a delete reliably returns 0 — matches the
  ; interpreter's live-ref invalidation contract.
  ;
  ; No callee-save reg use → pure leaf, no a0 spill needed.
  .global cssc_load_i64_at
  .type   cssc_load_i64_at, @function
cssc_load_i64_at:
  ; Test (a2:a3) against the zero word pair. The CALL0 ABI
  ; passes the i64 in a2 (lo) + a3 (hi); we only need to verify
  ; both halves are zero to detect a NULL address.
  or      a8, a2, a3              ; a8 = nonzero iff addr != 0
  beqz    a8, .Lload_zero          ; addr == 0 → return 0
  ; Load 8 bytes from the address (a2:a3). The low half holds the
  ; pointer (we already noted in cssc_obj_alloc that ESP8266
  ; allocations stay under 65535 — the upper half is informational
  ; only and isn't dereferenced for the load).
  l32i.n  a8, a2, 0                ; lo word at *(addr+0)
  l32i.n  a9, a2, 4                ; hi word at *(addr+4)
  mov     a2, a8
  mov     a3, a9
  ret.n
.Lload_zero:
  movi.n  a2, 0
  movi.n  a3, 0
  ret.n
  .size cssc_load_i64_at, .-cssc_load_i64_at

  ; ────────────────────────────────────────────────────────────────────
  ; v6 ref-by-default arg-link plumbing (spec §2.5).
  ;
  ; The HOST runtime (cssc_runtime.c) implements these as a real
  ; pending-link queue + alias-entry table in CsscScopeStack. The
  ; ESP8266 Xtensa runtime uses a much simpler scope model (a 32-deep
  ; ring of arena cursors, no entries-table) so the alias mechanism
  ; cannot be implemented here without a much larger runtime rework.
  ;
  ; For now: both helpers are no-op leaf functions that return
  ; immediately. The ref-by-default INTERPRETER + HOST builds get full
  ; semantics; the ESP8266 build silently no-ops, matching the legacy
  ; behaviour. The LSP lint `DELETE_OF_COPY_PARAM_VIA_REF_CALL` still
  ; fires at the call site, so dangerous patterns surface pre-build.
  ;
  ; Full ESP8266 alias support is tracked in the v6 follow-up plan:
  ; the scope frame needs (name, value) entries to support the alias
  ; tag, which requires per-frame hash storage — non-trivial on the
  ; ESP8266 SRAM budget.
  ;
  ; ABI: both helpers take pointer args via CALL0 (a2, a3); pure leaf,
  ; no register saves needed.
  .global cssc_arg_link
  .type   cssc_arg_link, @function
cssc_arg_link:
  ret.n
  .size cssc_arg_link, .-cssc_arg_link

  .global cssc_scope_delete_aliased
  .type   cssc_scope_delete_aliased, @function
cssc_scope_delete_aliased:
  ret.n
  .size cssc_scope_delete_aliased, .-cssc_scope_delete_aliased

  .global cssc_obj_alloc
  .type   cssc_obj_alloc, @function
cssc_obj_alloc:
  ; in: a2 = size (i64 lo). We ignore the hi half because no single
  ;     allocation on ESP8266 can exceed 65535 bytes anyway.
  ; out: a2 = pointer to a fresh `size`-byte buffer; aborts via panic
  ;      if the arena is exhausted.
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  ; Round size up to 8-byte alignment.
  addi    a2, a2, 7
  movi    a8, -8                  ; mask = ~7
  and     a2, a2, a8
  ; cur = cssc_arena_off (load via l32r)
  l32r    a8, .Larena_off_addr
  l32i.n  a9, a8, 0               ; a9 = current offset
  ; new_off = cur + size
  add     a10, a9, a2
  ; arena_max = sizeof(cssc_arena) = 65536. MUST use a caller-save
  ; reg (a11) — a12-a15 are callee-save under CALL0 and clobbering
  ; them here corrupts every caller's persistent state.
  movi    a11, 1
  slli    a11, a11, 16             ; 65536 = arena size
  bge     a10, a11, .Larena_oom    ; new_off >= cap → out of memory
.Larena_ok:
  ; cssc_arena_off = new_off
  s32i.n  a10, a8, 0
  ; return ptr = &cssc_arena + cur
  l32r    a8, .Larena_base_addr
  add     a2, a8, a9
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
.Larena_oom:
  ; Out of memory — panic with a fixed message.
  l32r    a2, .Loom_msg_addr
  movi.n  a3, 17                  ; len of "cssc: arena OOM\n"
  call0   cssc_panic
  ; unreachable; cssc_panic halts the CPU.
1:
  j       1b
  .size cssc_obj_alloc, .-cssc_obj_alloc

  .global cssc_obj_free
  .type   cssc_obj_free, @function
cssc_obj_free:
  ; arena allocator — free is a no-op. ret immediately.
  ret.n
  .size cssc_obj_free, .-cssc_obj_free

  ; Literal pool entries the allocator uses (need to be in range of
  ; an L32R, so they live at the end of the file too).
  .section .rodata
.Loom_msg:    .asciz "cssc: arena OOM"
  .text
  .literal_position
  .literal .Larena_off_addr,  cssc_arena_off
  .literal .Larena_base_addr, cssc_arena
  .literal .Loom_msg_addr,    .Loom_msg

  ; ===========================================================================
  ; cssc_panic(ptr msg, i64 len) — emit message to UART, halt CPU.
  ; ===========================================================================
  .global cssc_panic
  .type   cssc_panic, @function
cssc_panic:
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  mov.n   a12, a2                 ; msg ptr
  mov.n   a13, a3                 ; len
p1:
  movi.n  a8, 0
  beq     a13, a8, p2
  l8ui    a2, a12, 0
  call0   cssc_uart_putc
  addi    a12, a12, 1
  addi    a13, a13, -1
  j       p1
p2:
  movi.n  a2, 10
  call0   cssc_uart_putc
  ; Halt forever — disable interrupts then waiti 0 in a loop. WAITI
  ; puts the CPU into low-power state until next interrupt; the
  ; surrounding loop catches any wakeup.
p3:
  waiti   0
  j       p3
  .size cssc_panic, .-cssc_panic

  ; ===========================================================================
  ; B7 — Time: cssc_sleep_ms, cssc_uptime, cssc_tick.
  ;
  ; Uses Xtensa's special register CCOUNT (cycle counter, 32-bit, wraps
  ; ~53s at 80 MHz). A module-level `cssc_uptime_ms` global is bumped
  ; once per ms inside cssc_sleep_ms. cssc_uptime returns the global
  ; as a double (seconds).
  ; ===========================================================================
  .data
  .global cssc_uptime_ms
  .align  4
cssc_uptime_ms:
  .word   0
  ; Last CCOUNT sampled by `cssc_uptime`. We use it to compute the
  ; cycles elapsed since the previous call (unsigned subtract handles
  ; CCOUNT's 32-bit wrap, which fires every ~53 s at 80 MHz). Seeded
  ; by `cssc_runtime_init` so the first call returns zero, not the
  ; absolute power-on CCOUNT value.
  .global cssc_last_ccount
  .align  4
cssc_last_ccount:
  .word   0
  .text

  .global cssc_sleep_ms
  .type   cssc_sleep_ms, @function
cssc_sleep_ms:
  ; in: a2:a3 = ms (i64). We use only the low 32 bits.
  ; Pure CCOUNT busy-wait — does NOT bump cssc_uptime_ms any more.
  ; `cssc_uptime` derives uptime from CCOUNT delta on demand, so the
  ; clock tracks real wall time (including time spent inside
  ; display.show(), etc.) instead of just integrated sleep duration.
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  mov.n   a12, a2                ; a12 = ms remaining
  l32r    a13, .Lcycles_per_ms_addr
  l32i.n  a13, a13, 0            ; a13 = cycles_per_ms (80000)
s1:
  movi.n  a8, 0
  beq     a12, a8, s_done
  ; Read CCOUNT, busy-wait until cycles_per_ms have passed.
  rsr.ccount a8                  ; a8 = start
s2:
  rsr.ccount a10
  sub     a11, a10, a8           ; unsigned wrap-safe delta
  bltu    a11, a13, s2
  addi    a12, a12, -1
  j       s1
s_done:
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .literal_position
  .literal .Lcycles_per_ms_addr, .Lcycles_per_ms_val
  .section .rodata
  .align  4
.Lcycles_per_ms_val:
  .word   __PROFILE_CYCLES_PER_MS__
  .text
  .size cssc_sleep_ms, .-cssc_sleep_ms

  .global cssc_uptime
  .type   cssc_uptime, @function
cssc_uptime:
  ; Returns f64 seconds in a2:a3.
  ;
  ; Real-time semantics: derive uptime_ms from the difference between
  ; CCOUNT now and CCOUNT at the previous call. That makes time
  ; advance during long-running work like `display.show()`'s bit-bang
  ; I2C transfer, NOT just during `cssc::sleep`. The earlier impl
  ; only bumped uptime_ms inside the sleep loop, so a videodriver
  ; tick of `sleep(20) + show(~100ms)` reported only 20ms of elapsed
  ; time per ~120ms of real time — uptime advanced ~6× slower than
  ; the wall clock.
  ;
  ; CCOUNT is 32-bit unsigned and wraps every ~53 s at 80 MHz. The
  ; unsigned subtract `cur - last` correctly produces the elapsed
  ; cycle count across a single wrap, so as long as cssc_uptime is
  ; called more than once per 53 s (basically always — every render
  ; tick and every comparison against a shutdown threshold drives a
  ; call) we never miss a wrap.
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  rsr.ccount a8                  ; cur_ccount
  l32r    a9, .Lup_lastcc_addr
  l32i.n  a10, a9, 0             ; last_ccount
  sub     a11, a8, a10           ; delta cycles (unsigned wrap-safe)
  l32r    a12, .Lup_cyc_per_ms_addr
  l32i.n  a12, a12, 0            ; cycles_per_ms (80000 @ 80 MHz)
  ; delta_ms = delta_cycles / cycles_per_ms
  mov.n   a2, a11
  mov.n   a3, a12
  call0   __udivsi3
  mov.n   a13, a2                 ; delta_ms (callee-save)
  ; Update last_ccount = cur_ccount - (delta_cycles mod cycles_per_ms)
  ; i.e. last_ccount += delta_ms * cycles_per_ms. Carrying the
  ; remainder forward keeps quantisation error from accumulating.
  mov.n   a2, a13
  mov.n   a3, a12
  call0   __mulsi3                ; a2 = delta_ms * cyc_per_ms
  l32r    a9, .Lup_lastcc_addr
  l32i.n  a10, a9, 0
  add     a8, a10, a2
  s32i.n  a8, a9, 0               ; last_ccount += consumed cycles
  ; uptime_ms += delta_ms
  l32r    a8, .Lup_uptime_ms_addr
  l32i.n  a9, a8, 0
  add     a9, a9, a13
  s32i.n  a9, a8, 0
  ; Convert uptime_ms (now accurate) to f64 seconds.
  mov.n   a2, a9
  call0   __floatsidf            ; a2:a3 = (double)uptime_ms
  l32r    a8, .Lup_thousand_addr
  l32i.n  a4, a8, 0
  l32i.n  a5, a8, 4
  call0   __divdf3               ; a2:a3 = uptime_ms / 1000.0
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .literal_position
  .literal .Lup_uptime_ms_addr, cssc_uptime_ms
  .literal .Lup_lastcc_addr,    cssc_last_ccount
  .literal .Lup_cyc_per_ms_addr, .Lup_cyc_per_ms_val
  .literal .Lup_thousand_addr,  .Lup_thousand_val
  .section .rodata
  .align  4
.Lup_cyc_per_ms_val:
  .word   __PROFILE_CYCLES_PER_MS__
  .align  8
.Lup_thousand_val:
  .word   0x00000000
  .word   0x408F4000             ; IEEE-754 double 1000.0
  .text
  .size cssc_uptime, .-cssc_uptime

  .global cssc_tick
  .type   cssc_tick, @function
cssc_tick:
  ; Returns i64 monotonic milliseconds. We first advance cssc_uptime_ms
  ; from the CCOUNT delta (same logic as cssc_uptime so both APIs see
  ; the same monotonic clock) then return the updated value.
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  rsr.ccount a8
  l32r    a9, .Ltk_lastcc_addr
  l32i.n  a10, a9, 0
  sub     a11, a8, a10           ; delta cycles (unsigned wrap-safe)
  l32r    a12, .Ltk_cyc_per_ms_addr
  l32i.n  a12, a12, 0
  mov.n   a2, a11
  mov.n   a3, a12
  call0   __udivsi3              ; a2 = delta_ms
  mov.n   a13, a2
  mov.n   a2, a13
  mov.n   a3, a12
  call0   __mulsi3                ; a2 = delta_ms * cyc_per_ms
  l32r    a9, .Ltk_lastcc_addr
  l32i.n  a10, a9, 0
  add     a8, a10, a2
  s32i.n  a8, a9, 0
  l32r    a8, .Ltk_uptime_ms_addr
  l32i.n  a9, a8, 0
  add     a9, a9, a13
  s32i.n  a9, a8, 0
  mov.n   a2, a9                  ; return uptime_ms in a2
  movi.n  a3, 0
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .literal_position
  .literal .Ltk_uptime_ms_addr,   cssc_uptime_ms
  .literal .Ltk_lastcc_addr,      cssc_last_ccount
  .literal .Ltk_cyc_per_ms_addr,  .Ltk_cyc_per_ms_val
  .section .rodata
  .align  4
.Ltk_cyc_per_ms_val:
  .word   __PROFILE_CYCLES_PER_MS__
  .text
  .size cssc_tick, .-cssc_tick

  ; ===========================================================================
  ; B2b — String runtime.
  ;
  ; cssc_str layout (matches host runtime — A.3.4 refcount cascade):
  ;   offset  0: i32 refcount
  ;   offset  4: i32 size
  ;   offset  8: i32 cap
  ;   offset 12: ptr data
  ;   offset 16+: byte payload
  ; Header is exactly 16 bytes (8-byte aligned).
  ; ===========================================================================

  .global cssc_string_lit
  .type   cssc_string_lit, @function
cssc_string_lit:
  ; in: a2 = const char* (0-terminated)
  ; out: a2 = ptr to fresh cssc_str header (refcount=1)
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  s32i.n  a14, a1, 0
  mov.n   a12, a2                ; src ptr
  ; Compute length via strlen-loop.
  mov.n   a13, a12
  movi.n  a14, 0                 ; length counter
sl1:
  l8ui    a8, a13, 0
  movi.n  a9, 0
  beq     a8, a9, sl2
  addi    a13, a13, 1
  addi    a14, a14, 1
  j       sl1
sl2:
  ; Allocate header (16 bytes) + (length+1) for data.
  mov.n   a2, a14
  addi    a2, a2, 1              ; len + 1 for NUL
  addi    a2, a2, 16             ; + header
  ; Round to 8-byte alignment
  addi    a2, a2, 7
  movi    a8, -8
  and     a2, a2, a8
  call0   cssc_obj_alloc          ; a2 = base ptr (header+data combined)
  ; Layout: [refcount @ +0][size @ +4][cap @ +8][data @ +12][bytes @ +16..]
  movi.n  a8, 1
  s32i.n  a8, a2, 0              ; refcount = 1
  s32i.n  a14, a2, 4             ; size
  s32i.n  a14, a2, 8             ; cap
  ; data ptr = base + 16
  addi    a8, a2, 16
  s32i.n  a8, a2, 12             ; data
  ; Copy length bytes from src to data.
  mov.n   a9, a12                ; src
  mov.n   a10, a8                ; dst
  mov.n   a11, a14               ; remaining
sl3:
  movi.n  a13, 0
  beq     a11, a13, sl4
  l8ui    a13, a9, 0
  s8i     a13, a10, 0
  addi    a9, a9, 1
  addi    a10, a10, 1
  addi    a11, a11, -1
  j       sl3
sl4:
  ; Write trailing NUL.
  movi.n  a13, 0
  s8i     a13, a10, 0
  l32i.n  a14, a1, 0
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_string_lit, .-cssc_string_lit

  .global cssc_string_free
  .type   cssc_string_free, @function
cssc_string_free:
  ; Arena allocator: actual memory is reclaimed only when the enclosing
  ; scope is popped. cssc_release calls us when refcount hits 0; we
  ; have nothing concrete to do here but the symbol exists so the
  ; refcount machinery can dispatch uniformly across targets.
  ret.n
  .size cssc_string_free, .-cssc_string_free

  ; cssc_retain(ptr s): increment s->refcount. NULL-safe (refcount field
  ; is at offset 0; if s is NULL we'd trap, so callers must pre-check —
  ; the lowering only emits retain on known-non-null heap ptrs).
  .global cssc_retain
  .type   cssc_retain, @function
cssc_retain:
  beqz    a2, .Lretain_null
  l32i.n  a8, a2, 0              ; refcount
  addi    a8, a8, 1
  s32i.n  a8, a2, 0
.Lretain_null:
  ret.n
  .size cssc_retain, .-cssc_retain

  ; cssc_release(ptr s): decrement s->refcount; if it hits 0, call
  ; cssc_string_free (which is a no-op on the arena allocator but
  ; matches the host's malloc-backed runtime). NULL-safe.
  .global cssc_release
  .type   cssc_release, @function
cssc_release:
  beqz    a2, .Lrelease_null
  l32i.n  a8, a2, 0              ; refcount
  addi    a8, a8, -1
  s32i.n  a8, a2, 0
  bnez    a8, .Lrelease_null
  ; refcount reached zero — call cssc_string_free(a2).
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  call0   cssc_string_free
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
.Lrelease_null:
  ret.n
  .size cssc_release, .-cssc_release

  .global cssc_string_size
  .type   cssc_string_size, @function
cssc_string_size:
  l32i.n  a2, a2, 4              ; size at +4 (was +0 before A.3.4)
  movi.n  a3, 0
  ret.n
  .size cssc_string_size, .-cssc_string_size

  .global cssc_string_data
  .type   cssc_string_data, @function
cssc_string_data:
  l32i.n  a2, a2, 12             ; data at +12 (was +8 before A.3.4)
  ret.n
  .size cssc_string_data, .-cssc_string_data

  ; Doc §3.3: cssc_string_set_byte(s, i, c) — write one byte at
  ; offset `i` of the cssc_str's inline data buffer. NULL-safe +
  ; bounds-checked silent-ignore (`s == NULL` or `i >= size` → no-op).
  ; in: a2 = cssc_str*, a4:a5 = i (lo:hi), a6:a7 = c (lo:hi)
  .global cssc_string_set_byte
  .type   cssc_string_set_byte, @function
cssc_string_set_byte:
  beqz    a2, .Lcssb_done
  l32i.n  a8, a2, 4              ; size
  bgeu    a4, a8, .Lcssb_done    ; i >= size → ignore
  l32i.n  a9, a2, 12             ; data ptr
  add     a9, a9, a4             ; &data[i]
  s8i     a6, a9, 0              ; *(data+i) = (i8) c
.Lcssb_done:
  ret.n
  .size cssc_string_set_byte, .-cssc_string_set_byte

  ; cssc_string_get_byte(s, i) → i64
  ; in: a2 = cssc_str*, a4:a5 = i (lo:hi)
  ; out: a2:a3 = byte at offset i, ASCII '0'..'9' decoded to 0..9
  ; (null ptr / OOB returns 0 silently — same defensive policy as set)
  .global cssc_string_get_byte
  .type   cssc_string_get_byte, @function
cssc_string_get_byte:
  movi.n  a3, 0
  beqz    a2, .Lcsgb_zero
  l32i.n  a8, a2, 4              ; size
  bgeu    a4, a8, .Lcsgb_zero
  l32i.n  a9, a2, 12             ; data ptr
  add     a9, a9, a4             ; &data[i]
  l8ui    a2, a9, 0              ; load byte (zero-extended)
  addi    a10, a2, -48           ; ascii - '0'
  movi.n  a11, 10
  bgeu    a10, a11, .Lcsgb_done  ; not an ascii digit, return raw byte
  mov.n   a2, a10
.Lcsgb_done:
  ret.n
.Lcsgb_zero:
  movi.n  a2, 0
  ret.n
  .size cssc_string_get_byte, .-cssc_string_get_byte

  ; cssc_string_copy(s) — fresh heap cssc_str (deep copy, refcount=1).
  ; Reads s's size + data pointer, then calls cssc_string_lit which
  ; allocates a new header + copies the bytes. Used by the `&` copy
  ; operator on string slots: the caller takes the returned ptr and
  ; the source `s` keeps its own refcount intact.
  .global cssc_string_copy
  .type   cssc_string_copy, @function
cssc_string_copy:
  ; in: a2 = cssc_str* s ; out: a2 = fresh heap cssc_str*
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  beqz    a2, .Lstrcopy_null
  mov.n   a12, a2                ; preserve source ptr
  l32i.n  a4, a2, 4              ; size_lo  → a4 (low half of i64 len)
  movi.n  a5, 0                  ; size_hi  → a5 (always 0 on LX106)
  l32i.n  a2, a12, 12            ; src data ptr
  call0   cssc_string_lit
  ; a2 now holds the new heap cssc_str*
  j       .Lstrcopy_done
.Lstrcopy_null:
  movi.n  a2, 0
.Lstrcopy_done:
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_string_copy, .-cssc_string_copy

  .global cssc_string_concat
  .type   cssc_string_concat, @function
cssc_string_concat:
  ; in: a2 = cssc_str* a, a3 = cssc_str* b
  ; out: a2 = fresh cssc_str* with refcount=1 + concatenated bytes
  addi    a1, a1, -32
  s32i.n  a0, a1, 28
  s32i.n  a12, a1, 24
  s32i.n  a13, a1, 20
  s32i.n  a14, a1, 16
  s32i.n  a15, a1, 12
  mov.n   a12, a2                ; a
  mov.n   a13, a3                ; b
  l32i.n  a14, a12, 4            ; size_a (was +0 before A.3.4)
  l32i.n  a15, a13, 4            ; size_b (was +0 before A.3.4)
  ; total = size_a + size_b
  add     a8, a14, a15
  s32i.n  a8, a1, 0              ; total stays at frame[0]
  ; alloc header + total + 1 (NUL).
  addi    a2, a8, 17             ; total + 16 header + 1 NUL
  addi    a2, a2, 7
  movi    a9, -8
  and     a2, a2, a9
  call0   cssc_obj_alloc         ; a2 = base
  l32i.n  a8, a1, 0              ; reload total
  movi.n  a9, 1
  s32i.n  a9, a2, 0              ; refcount = 1
  s32i.n  a8, a2, 4              ; size = total
  s32i.n  a8, a2, 8              ; cap = total
  addi    a9, a2, 16             ; data ptr
  s32i.n  a9, a2, 12
  ; Copy A's bytes.
  l32i.n  a10, a12, 12           ; src_a (was +8 before A.3.4)
  mov.n   a11, a9                ; dst
  mov.n   a8, a14                ; remaining
cc1:
  movi.n  a3, 0
  beq     a8, a3, cc2
  l8ui    a3, a10, 0
  s8i     a3, a11, 0
  addi    a10, a10, 1
  addi    a11, a11, 1
  addi    a8, a8, -1
  j       cc1
cc2:
  ; Copy B's bytes after A's.
  l32i.n  a10, a13, 12           ; src_b (was +8 before A.3.4)
  mov.n   a8, a15                ; remaining
cc3:
  movi.n  a3, 0
  beq     a8, a3, cc4
  l8ui    a3, a10, 0
  s8i     a3, a11, 0
  addi    a10, a10, 1
  addi    a11, a11, 1
  addi    a8, a8, -1
  j       cc3
cc4:
  ; Write trailing NUL.
  movi.n  a3, 0
  s8i     a3, a11, 0
  l32i.n  a15, a1, 12
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .size cssc_string_concat, .-cssc_string_concat

  .global cssc_string_eq
  .type   cssc_string_eq, @function
cssc_string_eq:
  ; in: a2 = cssc_str* a, a3 = cssc_str* b
  ; out: a2 = i1 (1 = equal, 0 = not)
  l32i.n  a8, a2, 4              ; size_a (was +0 before A.3.4)
  l32i.n  a9, a3, 4              ; size_b
  bne     a8, a9, se_neq
  l32i.n  a10, a2, 12            ; data_a (was +8 before A.3.4)
  l32i.n  a11, a3, 12            ; data_b
  mov.n   a4, a8                 ; remaining
se1:
  movi.n  a5, 0
  beq     a4, a5, se_eq
  l8ui    a5, a10, 0
  l8ui    a6, a11, 0
  bne     a5, a6, se_neq
  addi    a10, a10, 1
  addi    a11, a11, 1
  addi    a4, a4, -1
  j       se1
se_eq:
  movi.n  a2, 1
  ret.n
se_neq:
  movi.n  a2, 0
  ret.n
  .size cssc_string_eq, .-cssc_string_eq

  .global cssc_print_string
  .type   cssc_print_string, @function
cssc_print_string:
  ; Print a cssc_str via cssc_print_str (which expects ptr + i64
  ; length under the CALL0 pair-align ABI: a2 = ptr, a4 = len_lo,
  ; a5 = len_hi. a3 is the pair-align skip).
  ; in: a2 = cssc_str*
  ;
  ; Spec §5.4 bare-block fallback emits a null cssc_str* sentinel for
  ; outer-scope reads that weren't imported via #req. Dereferencing
  ; that null at +4/+12 would LoadProhibited at boot — short-circuit
  ; here: when a2 == 0, print the literal "0x0" + newline so the user
  ; sees the sentinel value the compiler warned about, then return.
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  bnez    a2, cssc_print_string__nonnull
  movi.n  a2, '0'
  call0   cssc_uart_putc
  movi.n  a2, 'x'
  call0   cssc_uart_putc
  movi.n  a2, '0'
  call0   cssc_uart_putc
  movi.n  a2, 10
  call0   cssc_uart_putc
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
cssc_print_string__nonnull:
  mov.n   a8, a2
  l32i.n  a9,  a8, 4             ; size (was +0 before A.3.4 refcount)
  l32i.n  a10, a8, 12            ; data ptr (was +8 before A.3.4 refcount)
  mov.n   a2, a10                ; arg0 ptr
  mov.n   a4, a9                 ; arg1 len_lo (pair-align skip a3)
  movi.n  a5, 0                  ; arg1 len_hi (sizes always fit i32)
  call0   cssc_print_str
  movi.n  a2, 10
  call0   cssc_uart_putc         ; trailing newline
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_print_string, .-cssc_print_string

  ; ===========================================================================
  ; B3 — Stringify: int/float/bool → cssc_str*.
  ;
  ; Each helper formats into a stack buffer then calls cssc_string_lit
  ; to allocate the heap-resident cssc_str. Resulting string is owned
  ; by the caller (arena allocator — survives until shutdown).
  ; ===========================================================================

  .global cssc_int_to_str
  .type   cssc_int_to_str, @function
cssc_int_to_str:
  ; in: a2:a3 = i64 value (we use only the low 32 bits for now —
  ;             the full i64 stringify lands when we wire __divdi3
  ;             for the digit-reduce loop)
  ;
  ; CALL0 ABI: a0-a11 are caller-save (clobbered by every call0).
  ; The quotient and the buffer cursor must live across __divsi3
  ; and __mulsi3 calls, so they go in a12-a15 (callee-save) and we
  ; save/restore them via the prologue.
  ;
  ; Frame layout (48 bytes, 16-aligned). The digit buffer sits at
  ; LOW offsets [0..23] (24 bytes — enough for "-9223372036854775808\0"
  ; once we wire 64-bit divides), and the callee-save spill area sits
  ; at HIGH offsets [24..43] (5 × 4 = 20 bytes). They are DISJOINT —
  ; the original 32-byte layout had buffer[0..23] overlapping
  ; spills[12..27], so writing digits from the high end of the buffer
  ; backwards CORRUPTED the saved callee-save bytes; on return the
  ; restored `a13`/`a14`/`a15` carried the digit ASCII bytes instead
  ; of the caller's actual register values. That manifested as a
  ; chip-side LoadProhibited when the caller next dereferenced
  ; (e.g.) a13 (held a sector-member pointer like &particles
  ; 0x3FFE_8010 whose high bytes had been overwritten with '0' '\0',
  ; corrupting to 0x0030_8010 — exactly the failing excvaddr seen
  ; on chip).
  addi    a1, a1, -48
  s32i.n  a0,  a1, 40
  s32i.n  a12, a1, 36            ; a12 = current value (n)
  s32i.n  a13, a1, 32            ; a13 = buffer cursor
  s32i.n  a14, a1, 28            ; a14 = saw-minus flag
  s32i.n  a15, a1, 24            ; a15 = quotient stash across mulsi3
  ; Stack buffer at frame[0..23] (24 bytes). Cursor starts at the
  ; LAST byte (frame[23]) and walks backwards as digits are written.
  addi    a13, a1, 23
  movi.n  a8, 0
  s8i     a8, a13, 0             ; terminating NUL
  addi    a13, a13, -1
  mov.n   a12, a2                ; value
  movi.n  a8, 0
  bge     a12, a8, is1
  neg     a12, a12
  movi.n  a14, 1                 ; saw-minus
  j       is2
is1:
  movi.n  a14, 0
is2:
  movi.n  a8, 0
  bne     a12, a8, is3
  movi.n  a8, 48                 ; '0'
  s8i     a8, a13, 0
  addi    a13, a13, -1
  j       is_emit_sign
is3:
  ; quotient = n / 10
  mov.n   a2, a12
  movi.n  a3, 10
  call0   __divsi3
  mov.n   a15, a2                ; STASH in callee-save before mulsi3
  ; quotient * 10
  mov.n   a2, a15
  movi.n  a3, 10
  call0   __mulsi3
  sub     a9, a12, a2            ; remainder = n - quotient*10
  addi    a9, a9, 48             ; '0' + digit
  s8i     a9, a13, 0
  addi    a13, a13, -1
  mov.n   a12, a15               ; n = quotient (still live in a15)
  movi.n  a9, 0
  bne     a12, a9, is3
is_emit_sign:
  movi.n  a8, 0
  beq     a14, a8, is_done
  movi.n  a8, 45                 ; '-'
  s8i     a8, a13, 0
  addi    a13, a13, -1
is_done:
  addi    a2, a13, 1
  call0   cssc_string_lit
  l32i.n  a15, a1, 24
  l32i.n  a14, a1, 28
  l32i.n  a13, a1, 32
  l32i.n  a12, a1, 36
  l32i.n  a0,  a1, 40
  addi    a1, a1, 48
  ret.n
  .size cssc_int_to_str, .-cssc_int_to_str

  .global cssc_float_to_str
  .type   cssc_float_to_str, @function
cssc_float_to_str:
  ; in:  a2:a3 = f64 value x
  ; out: a2    = cssc_str* with format "[-]INT.FFF" (fixed 3 fractional digits)
  ;
  ; Algorithm (hand-tuned, no temporary string allocations):
  ;   1. extract sign bit, work with |x| from here on.
  ;   2. scaled = (i32) (|x| * 1000.0)     ← __muldf3 + __fixdfsi
  ;   3. int_part = scaled / 1000, frac = scaled % 1000.
  ;   4. format digits right-to-left into the upper half of our
  ;      stack frame (16-byte scratch buffer). Layout:
  ;        [a1+48..63]: scratch (high end holds last char).
  ;      Write: zero-pad frac to exactly 3 digits, then '.',
  ;      then int_part (variable, at least one digit), then
  ;      optional '-'.
  ;   5. allocate ONE cssc_str (16-byte header + len + NUL),
  ;      memcpy the formatted run into the data area.
  ;
  ; Frame layout (96 bytes, 16-aligned). The 16-byte digit buffer
  ; lives at low offsets ([8..23]) and the callee-save spill area
  ; sits at high offsets ([72..91]) so the right-to-left digit
  ; writes can NEVER touch any saved-register word. The earlier
  ; 80-byte layout put the buffer at [48..63] which overlapped the
  ; saved-a14 word at [60..63]; every digit written into bytes
  ; 60/61/62 partially overwrote saved-a14, and the epilogue's
  ; `l32i.n a14, a1, 60` then restored the corrupted word back into
  ; the caller's a14. That's exactly what made a float-concat in a
  ; while loop hang after iteration 1 — the loop's induction value
  ; lived in callee-save a14/a15 and got smashed on every call.
  ;
  ; Offsets:
  ;   [a1, +0..7]   saved input x (f64).
  ;   [a1, +8..23]  16-byte digit buffer. NUL terminator at +23,
  ;                 last digit slot at +22, writes go right-to-left.
  ;   [a1, +24..27] scaled  (i32: |x| * 1000).
  ;   [a1, +28..31] int_part.
  ;   [a1, +32..35] frac.
  ;   [a1, +36..39] sign byte (also in a15).
  ;   [a1, +40..43] temp for __divsi3/__mulsi3 quotients.
  ;   [a1, +44..47] formatted-run start cursor.
  ;   [a1, +48..51] cssc_str* result (post-alloc).
  ;   [a1, +52..71] pad / future use (20 bytes free).
  ;   [a1, +72..75] saved a12.
  ;   [a1, +76..79] saved a13.
  ;   [a1, +80..83] saved a14.
  ;   [a1, +84..87] saved a15.
  ;   [a1, +88..91] saved a0 (return PC).
  ;   [a1, +92..95] pad.
  ;
  ; CALL0 ABI: this function calls __muldf3, __fixdfsi, __divsi3,
  ; __mulsi3, cssc_string_lit — all of which respect callee-save.
  addi    a1, a1, -96
  s32i.n  a0,  a1, 88
  s32i.n  a12, a1, 72
  s32i.n  a13, a1, 76
  s32i.n  a14, a1, 80
  s32i.n  a15, a1, 84
  s32i.n  a2,  a1, 0
  s32i.n  a3,  a1, 4

  ; ---- (1) Extract sign + absolute value ----
  ; ---- (1) Extract sign + absolute value ----
  ; Sign bit lives in bit 31 of x.hi (a3). bgez branches when
  ; the signed value is >= 0; for IEEE-754 the bit pattern is
  ; lexicographically ordered (sign bit at MSB), so bgez detects
  ; "non-negative double" iff the sign bit is clear.
  movi.n  a15, 0                ; sign = 0
  bgez    a3, .Lftos_abs_done
  movi.n  a15, 1                ; sign = 1
  l32r    a8, .Lftos_signmask   ; 0x80000000
  xor     a3, a3, a8            ; clear sign bit → |x|.hi
  s32i.n  a2, a1, 0
  s32i.n  a3, a1, 4
.Lftos_abs_done:

  ; ---- (2) Multiply by 1000.0 and convert to i32 ----
  l32r    a8, .Lftos_thousand_addr
  l32i.n  a4, a8, 0
  l32i.n  a5, a8, 4
  call0   __muldf3              ; a2:a3 = |x| * 1000.0
  call0   __fixdfsi             ; a2    = (i32) result
  s32i.n  a2, a1, 24            ; scaled

  ; ---- (3) int_part = scaled / 1000 ----
  movi    a3, 1000
  call0   __divsi3              ; a2 = scaled / 1000
  s32i.n  a2, a1, 28
  mov.n   a13, a2               ; int_part (callee-save)

  ; frac = scaled - int_part * 1000
  mov.n   a2, a13
  movi    a3, 1000
  call0   __mulsi3              ; a2 = int_part * 1000
  l32i.n  a8, a1, 24            ; scaled
  sub     a14, a8, a2           ; frac (callee-save)
  s32i.n  a14, a1, 32

  ; ---- (4) Format digits right-to-left into [a1+8..a1+22] ----
  ; NUL terminator at +23 (the last byte of the 16-byte buffer).
  ; All saved registers live at offsets >= 72, so the buffer can
  ; never collide with them no matter how many digits we write.
  movi.n  a8, 0
  s8i     a8, a1, 23
  addi    a12, a1, 22           ; cursor = last digit slot

  ; --- 4a. Three fractional digits (zero-padded to exactly three) ---
  mov.n   a2, a14
  movi    a3, 10
  call0   __divsi3              ; a2 = frac / 10
  s32i.n  a2, a1, 40
  mov.n   a8, a2
  mov.n   a2, a8
  movi    a3, 10
  call0   __mulsi3
  sub     a8, a14, a2
  addi    a8, a8, 0x30
  s8i     a8, a12, 0
  addi    a12, a12, -1
  l32i.n  a14, a1, 40
  mov.n   a2, a14
  movi    a3, 10
  call0   __divsi3
  s32i.n  a2, a1, 40
  mov.n   a8, a2
  mov.n   a2, a8
  movi    a3, 10
  call0   __mulsi3
  sub     a8, a14, a2
  addi    a8, a8, 0x30
  s8i     a8, a12, 0
  addi    a12, a12, -1
  l32i.n  a14, a1, 40
  addi    a8, a14, 0x30
  s8i     a8, a12, 0
  addi    a12, a12, -1

  ; --- 4b. Decimal point ---
  movi.n  a8, 0x2E
  s8i     a8, a12, 0
  addi    a12, a12, -1

  ; --- 4c. Integer-part digits (at least one) ---
  movi.n  a8, 0
  bne     a13, a8, .Lftos_int_loop
  movi.n  a8, 0x30
  s8i     a8, a12, 0
  addi    a12, a12, -1
  j       .Lftos_int_done
.Lftos_int_loop:
  mov.n   a2, a13
  movi    a3, 10
  call0   __divsi3
  s32i.n  a2, a1, 40
  mov.n   a8, a2
  mov.n   a2, a8
  movi    a3, 10
  call0   __mulsi3
  sub     a8, a13, a2
  addi    a8, a8, 0x30
  s8i     a8, a12, 0
  addi    a12, a12, -1
  l32i.n  a13, a1, 40
  movi.n  a8, 0
  bne     a13, a8, .Lftos_int_loop
.Lftos_int_done:

  ; --- 4d. Sign prefix ---
  movi.n  a8, 0
  beq     a15, a8, .Lftos_sign_done
  movi    a8, 0x2D
  s8i     a8, a12, 0
  addi    a12, a12, -1
.Lftos_sign_done:

  ; First byte of formatted text is at [a12+1]. cssc_string_lit walks
  ; from there to the NUL we wrote at [a1+23].
  addi    a2, a12, 1
  call0   cssc_string_lit       ; a2 = cssc_str*
  l32i.n  a15, a1, 84
  l32i.n  a14, a1, 80
  l32i.n  a13, a1, 76
  l32i.n  a12, a1, 72
  l32i.n  a0,  a1, 88
  addi    a1, a1, 96
  ret.n

  .literal_position
  .literal .Lftos_signmask,      0x80000000
  .literal .Lftos_thousand_addr, .Lftos_thousand_val
  .section .rodata
  .align  8
.Lftos_thousand_val:
  .word   0x00000000
  .word   0x408F4000             ; 1000.0 (IEEE-754 double)
  .text
  .size cssc_float_to_str, .-cssc_float_to_str

  .global cssc_bool_to_str
  .type   cssc_bool_to_str, @function
cssc_bool_to_str:
  ; in: a2 = bool (0 or 1) → cssc_str* ("true" / "false")
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  movi.n  a8, 0
  beq     a2, a8, bs_false
  l32r    a2, .Ltrue_addr
  call0   cssc_string_lit
  j       bs_done
bs_false:
  l32r    a2, .Lfalse_addr
  call0   cssc_string_lit
bs_done:
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
  .section .rodata
.Ltrue_str:  .asciz "true"
.Lfalse_str: .asciz "false"
  .text
  .literal_position
  .literal .Ltrue_addr,  .Ltrue_str
  .literal .Lfalse_addr, .Lfalse_str
  .size cssc_bool_to_str, .-cssc_bool_to_str

  ; ===========================================================================
  ; cssc_print_float — convert via cssc_float_to_str then print.
  ; ===========================================================================
  .global cssc_print_float
  .type   cssc_print_float, @function
cssc_print_float:
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  call0   cssc_float_to_str       ; a2 = cssc_str*
  call0   cssc_print_string
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_print_float, .-cssc_print_float

  ; ===========================================================================
  ; D1 — GPIO MMIO driver for ESP8266 LX106.
  ;
  ; Register map (Espressif TRM v2.5 §3):
  ;   GPIO_OUT_REG       = 0x60000300  ; rw — current output bitmask
  ;   GPIO_OUT_W1TS_REG  = 0x60000304  ; w  — atomic set bits
  ;   GPIO_OUT_W1TC_REG  = 0x60000308  ; w  — atomic clear bits
  ;   GPIO_ENABLE_REG    = 0x6000030C  ; rw — output enable mask
  ;   GPIO_ENABLE_W1TS   = 0x60000310  ; w  — atomic enable
  ;   GPIO_ENABLE_W1TC   = 0x60000314  ; w  — atomic disable
  ;   GPIO_IN_REG        = 0x60000318  ; r  — current input state
  ;
  ; IOMUX function-select registers at PERIPHS_IO_MUX = 0x60000800.
  ; Each pin (0-15) has a 4-byte slot; we just need GPIO function = 3
  ; (FUNC3) and the optional pullup bit (bit 7).
  ;
  ; Pin handle (8 bytes in arena):
  ;   offset 0: i32 pin_no
  ;   offset 4: i32 mode (0=input, 1=output, 2=input_pullup, 3=input_pulldown)
  ;
  ; GPIO16 needs separate handling via RTC registers; we panic when
  ; the user asks for it until that port lands.
  ; ===========================================================================

  .global cssc_pin_new
  .type   cssc_pin_new, @function
cssc_pin_new:
  ; in: a2 = pin number (i64 lo)
  ; out: a2 = pin handle pointer
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  s32i.n  a12, a1, 8
  mov.n   a12, a2                ; pin_no
  ; Reject pin_no >= 16 (GPIO16 not yet supported).
  movi.n  a8, 16
  bge     a12, a8, gpio_err_pin16
  ; Reject negative pin numbers.
  movi.n  a8, 0
  blt     a12, a8, gpio_err_pin16
  ; Allocate handle (8 bytes).
  movi.n  a2, 8
  call0   cssc_obj_alloc
  s32i.n  a12, a2, 0             ; pin_no
  movi.n  a8, 0
  s32i.n  a8, a2, 4              ; mode = INPUT (default)
  ; IOMUX function-select: set FUNC3 (GPIO) for the pin.
  ; The IOMUX register address layout for pins 0-15:
  ;   pin 0  → 0x60000834
  ;   pin 1  → 0x60000818
  ;   pin 2  → 0x60000838
  ;   pin 3  → 0x60000814
  ;   pin 4  → 0x60000838 (same as pin 2? No — actually pin 4 → 0x6000083C)
  ; The mapping is irregular; we use a lookup table indexed by pin_no.
  l32r    a8, .Liomux_table_addr
  slli    a9, a12, 2             ; index * 4
  add     a8, a8, a9
  l32i.n  a10, a8, 0             ; IOMUX reg addr for this pin
  ; Set FUNC3: bits[5:4]=0, bit[12]=1 means FUNC3 selected.
  ; Per the TRM the encoding is: clear bits[15:12]=0b0000, then set
  ; bit 12 to map to GPIO. Practically `movi 0x10` and write.
  movi.n  a11, 0x10
  s32i.n  a11, a10, 0
  l32i.n  a12, a1, 8
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
gpio_err_pin16:
  ; Panic: GPIO16/negative not supported.
  l32r    a2, .Lgpio_msg_addr
  movi.n  a3, 18                 ; len of "cssc: bad pin no\n"
  call0   cssc_panic
1:
  j       1b
  .section .rodata
.Lgpio_msg: .asciz "cssc: bad pin no"
  .align 4
.Liomux_table:
__PROFILE_IOMUX_TABLE_WORDS__
  .text
  .literal_position
  .literal .Liomux_table_addr, .Liomux_table
  .literal .Lgpio_msg_addr,    .Lgpio_msg
  .size cssc_pin_new, .-cssc_pin_new

  .global cssc_pin_free
  .type   cssc_pin_free, @function
cssc_pin_free:
  ret.n                          ; arena allocator — free is no-op
  .size cssc_pin_free, .-cssc_pin_free

  .global cssc_pin_mode
  .type   cssc_pin_mode, @function
cssc_pin_mode:
  ; in: a2 = handle, a4 = mode (0..3)  [pair-aligned CALL0 ABI:
  ; signature `(ptr, i64)` lands as a2 = ptr, a3 = pair-align skip,
  ; a4:a5 = i64. The low 32 bits of mode are in a4; for 0..3 we
  ; never use a5.]
  ; Modes: 0=INPUT, 1=OUTPUT, 2=INPUT_PULLUP, 3=INPUT_PULLDOWN
  ;
  ; Three steps per pin configuration:
  ;   (1) Persist mode in handle for read-back.
  ;   (2) Set IOMUX function field = 3 (GPIO) for this pin.
  ;       The chip boots with most pins in alternate-function modes
  ;       (UART/SPI/JTAG), so failing to switch IOMUX leaves
  ;       cssc_pin_write writing to a register that no longer
  ;       drives the physical pad. The function bits live in
  ;       bits 4, 5, 12 of the per-pin IOMUX register; clearing
  ;       all three then setting bits 4 + 5 picks function 3.
  ;   (3) Drive GPIO_ENABLE (W1TS for output, W1TC for input).
  ; CALL0 ABI: we clobber a12/a13/a14 as scratch, so we must
  ; save/restore them.
  addi    a1, a1, -16
  s32i.n  a12, a1, 0
  s32i.n  a13, a1, 4
  s32i.n  a14, a1, 8
  s32i.n  a4, a2, 4              ; (1) persist mode (low 32b of i64 in a4)
  l32i.n  a8, a2, 0              ; pin_no
  ; ---- (2) IOMUX function 3 ----
  l32r    a11, .Lpinmode_iomux_addr
  slli    a12, a8, 2
  add     a11, a11, a12          ; iomux_reg = table[pin]
  l32i.n  a11, a11, 0            ; deref to MMIO address
  l32i.n  a12, a11, 0            ; current value
  movi    a13, 0x1030            ; clear bits 4, 5, 12 (FUNC[2:0])
  movi    a14, -1
  xor     a14, a14, a13          ; mask = ~0x1030
  and     a12, a12, a14
  movi    a13, 0x30              ; FUNC[1:0] = 3 (GPIO), FUNC[2] = 0
  or      a12, a12, a13
  s32i.n  a12, a11, 0
  memw                           ; ordering for the next MMIO write
  ; ---- (3) GPIO_ENABLE direction ----
  ; bit = 1 << pin_no
  movi.n  a9, 1
  ssl     a8
  sll     a9, a9
  movi.n  a10, 1
  bne     a4, a10, pin_mode_input
  l32r    a11, .Lpin_en_w1ts_addr
  s32i.n  a9, a11, 0
  j       pin_mode_done
pin_mode_input:
  l32r    a11, .Lpin_en_w1tc_addr
  s32i.n  a9, a11, 0
pin_mode_done:
  l32i.n  a14, a1, 8
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 0
  addi    a1, a1, 16
  ret.n
  .literal_position
  .literal .Lpinmode_iomux_addr, .Liomux_table
  .literal .Lpin_en_w1ts_addr,   __PROFILE_GPIO_EN_W1TS__
  .literal .Lpin_en_w1tc_addr,   __PROFILE_GPIO_EN_W1TC__
  .size cssc_pin_mode, .-cssc_pin_mode

  .global cssc_pin_write
  .type   cssc_pin_write, @function
cssc_pin_write:
  ; in: a2 = handle, a4 = value (truthy=high)  [pair-aligned CALL0
  ; ABI: signature `(ptr, i64)` lands as a2 = ptr, a3 = pair-align
  ; skip, a4:a5 = i64. The low 32 bits of value are in a4; OR with
  ; a5 in case the caller passed a 64-bit non-zero with zero low.]
  l32i.n  a8, a2, 0              ; pin_no
  movi.n  a9, 1
  ssl     a8
  sll     a9, a9                 ; a9 = bitmask
  ; if value (combined a4|a5) != 0: W1TS, else W1TC
  or      a10, a4, a5            ; full i64 truthiness
  movi.n  a11, 0
  beq     a10, a11, pin_w_clear
  l32r    a11, .Lpin_out_w1ts_addr
  s32i.n  a9, a11, 0
  ret.n
pin_w_clear:
  l32r    a11, .Lpin_out_w1tc_addr
  s32i.n  a9, a11, 0
  ret.n
  .literal_position
  .literal .Lpin_out_w1ts_addr, __PROFILE_GPIO_OUT_W1TS__
  .literal .Lpin_out_w1tc_addr, __PROFILE_GPIO_OUT_W1TC__
  .size cssc_pin_write, .-cssc_pin_write

  .global cssc_pin_read
  .type   cssc_pin_read, @function
cssc_pin_read:
  ; in: a2 = handle
  ; out: a2:a3 = i64 {0 or 1}
  l32i.n  a8, a2, 0              ; pin_no
  l32r    a9, .Lpin_in_reg_addr
  l32i.n  a10, a9, 0             ; GPIO_IN_REG
  ; bit = (GPIO_IN >> pin_no) & 1
  ssr     a8
  srl     a10, a10
  movi.n  a8, 1
  and     a2, a10, a8
  movi.n  a3, 0
  ret.n
  .literal_position
  .literal .Lpin_in_reg_addr, __PROFILE_GPIO_IN__
  .size cssc_pin_read, .-cssc_pin_read

  .global cssc_pin_toggle
  .type   cssc_pin_toggle, @function
cssc_pin_toggle:
  ; in: a2 = handle
  l32i.n  a8, a2, 0              ; pin_no
  movi.n  a9, 1
  ssl     a8
  sll     a9, a9                 ; bitmask
  ; Read current GPIO_OUT, XOR with bitmask, write back.
  ; (Not atomic, but acceptable for the typical "blink an LED" pattern.)
  l32r    a10, .Lpin_out_reg_addr
  l32i.n  a11, a10, 0
  xor     a11, a11, a9
  s32i.n  a11, a10, 0
  ret.n
  .literal_position
  .literal .Lpin_out_reg_addr, __PROFILE_GPIO_OUT__
  .size cssc_pin_toggle, .-cssc_pin_toggle

  ; ===========================================================================
  ; D2 — I2C bit-bang. ESP8266 has no I2C peripheral, so we drive SDA/SCL
  ; as GPIO with manual timing. Default 100 kHz (10 µs / bit) — works for
  ; SSD1306, SH1106, BMP280, MPU6050, etc.
  ;
  ; I2C handle (16 bytes in arena):
  ;   off 0:  i32 bus_id (informational; ignored)
  ;   off 4:  i32 sda_pin
  ;   off 8:  i32 scl_pin
  ;   off 12: i32 half_bit_cycles (cycles for half a bit period — 400 = 100kHz)
  ;
  ; Timing primitive `.cssc_i2c_delay` busy-loops `half_bit_cycles`
  ; using CCOUNT (1 cycle = 12.5 ns at 80 MHz).
  ; ===========================================================================

  .global cssc_i2c_new
  .type   cssc_i2c_new, @function
cssc_i2c_new:
  ; in: a2 = bus_id (i64 lo), a4 = sda_pin (i64 lo), a6 = scl_pin (i64 lo)
  ; Note: With the wide-arg packing, args are (bus_lo, bus_hi, sda_lo, sda_hi,
  ; scl_lo, scl_hi). We only care about the lo halves.
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  s32i.n  a14, a1, 0
  mov.n   a12, a2                  ; bus_id
  mov.n   a13, a4                  ; sda_pin
  mov.n   a14, a6                  ; scl_pin
  ; Allocate 16 bytes handle
  movi.n  a2, 16
  call0   cssc_obj_alloc
  s32i.n  a12, a2, 0
  s32i.n  a13, a2, 4
  s32i.n  a14, a2, 8
  ; Default half-bit period: 400 cycles = ~5 µs @ 80 MHz → 100 kHz I2C.
  movi    a8, 400
  s32i.n  a8, a2, 12
  l32i.n  a14, a1, 0
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_i2c_new, .-cssc_i2c_new

  .global cssc_i2c_free
  .type   cssc_i2c_free, @function
cssc_i2c_free:
  ret.n
  .size cssc_i2c_free, .-cssc_i2c_free

  .global cssc_i2c_begin
  .type   cssc_i2c_begin, @function
cssc_i2c_begin:
  ; in: a2 = handle, a4 = freq_hz (i64 lo). freq_hz==0 means default.
  ;
  ; Configure both SDA + SCL pins for open-drain GPIO operation:
  ;   1. IOMUX function = 3 (GPIO) so the pad is no longer in its
  ;      reset-default alternate function (UART/SPI/JTAG).
  ;   2. IOMUX pullup bit (7) set so the line floats high when
  ;      released — needed because cssc_i2c_drive uses output-
  ;      enable as the bit-bang knob, not output-level.
  ;   3. (cssc_i2c_drive handles direction at runtime — no
  ;      ENABLE setup needed at begin time.)
  ; Then compute half-bit cycles from freq for the timing delay.
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  mov.n   a12, a2                  ; handle
  ; ---- Configure SDA pin IOMUX ----
  l32i.n  a8, a12, 4               ; sda pin
  call0   .cssc_pin_iomux_gpio_pu
  ; ---- Configure SCL pin IOMUX ----
  l32i.n  a8, a12, 8               ; scl pin
  call0   .cssc_pin_iomux_gpio_pu
  ; ---- Compute half-bit cycles if freq_hz != 0 ----
  movi.n  a9, 0
  beq     a4, a9, i2c_begin_done
  l32r    a10, .Li2c_40m_addr
  l32i.n  a10, a10, 0              ; APB/2 Hz
  mov.n   a2, a10
  mov.n   a3, a4
  call0   __divsi3                 ; a2 = half-bit cycles
  s32i.n  a2, a12, 12              ; persist
i2c_begin_done:
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .literal_position
  .literal .Li2c_40m_addr, .Li2c_40m_val
  .section .rodata
  .align 4
.Li2c_40m_val:
  .word __PROFILE_APB_HALF_HZ__
  .text
  .size cssc_i2c_begin, .-cssc_i2c_begin

  ; --- Internal helper: switch a pin's IOMUX to function 3 (GPIO)
  ;     and enable its internal pullup. Caller passes pin_no in a8.
  ;     Clobbers a8..a11. ---
.global .cssc_pin_iomux_gpio_pu
.type .cssc_pin_iomux_gpio_pu, @function
.cssc_pin_iomux_gpio_pu:
  l32r    a9, .Lpinhlp_table_addr
  slli    a10, a8, 2
  add     a9, a9, a10              ; addr of table entry
  l32i.n  a9, a9, 0                ; iomux MMIO address
  l32i.n  a10, a9, 0               ; current value
  ; Clear FUNC[2:0] (bits 4, 5, 12)
  movi    a11, -1
  movi    a8, 0x1030
  xor     a11, a11, a8
  and     a10, a10, a11
  ; Set FUNC = 3 (bits 4, 5) and PULLUP (bit 7)
  movi    a8, 0xB0                 ; 0x30 | 0x80
  or      a10, a10, a8
  s32i.n  a10, a9, 0
  memw
  ret.n
  .literal_position
  .literal .Lpinhlp_table_addr, .Liomux_table
  .size .cssc_pin_iomux_gpio_pu, .-.cssc_pin_iomux_gpio_pu

  ; Internal helper: half-bit delay using CCOUNT busy-loop.
  ; in: a13 = cycles to wait.
.global .cssc_i2c_delay
.type .cssc_i2c_delay, @function
.cssc_i2c_delay:
  rsr.ccount a8
  add     a9, a8, a13
delay_loop:
  rsr.ccount a10
  sub     a11, a10, a8
  bltu    a11, a13, delay_loop
  ret.n
  .size .cssc_i2c_delay, .-.cssc_i2c_delay

  ; Internal helper: drive a pin (set as input → released, output → low).
  ; Open-drain bit-bang: we toggle GPIO_ENABLE rather than GPIO_OUT.
  ;   in: a14 = pin_no, a15 = drive_state (0 = release/HIGH, 1 = pull/LOW)
.global .cssc_i2c_drive
.type .cssc_i2c_drive, @function
.cssc_i2c_drive:
  movi.n  a8, 1
  ssl     a14
  sll     a8, a8                   ; bitmask
  ; Pre-clear the output bit so the pin sinks to 0 when enabled.
  l32r    a9, .Li2c_out_w1tc
  s32i.n  a8, a9, 0
  ; Choose ENABLE_W1TS or ENABLE_W1TC based on drive_state.
  movi.n  a9, 0
  beq     a15, a9, i2c_drv_release
  l32r    a9, .Li2c_en_w1ts
  s32i.n  a8, a9, 0
  ret.n
i2c_drv_release:
  l32r    a9, .Li2c_en_w1tc
  s32i.n  a8, a9, 0
  ret.n
  .literal_position
  .literal .Li2c_out_w1tc, __PROFILE_GPIO_OUT_W1TC__
  .literal .Li2c_en_w1ts,  __PROFILE_GPIO_EN_W1TS__
  .literal .Li2c_en_w1tc,  __PROFILE_GPIO_EN_W1TC__
  .size .cssc_i2c_drive, .-.cssc_i2c_drive

  ; Internal helper: read SDA pin → a2 (0 or 1).
  ;   in: a14 = sda_pin
.global .cssc_i2c_read_sda
.type .cssc_i2c_read_sda, @function
.cssc_i2c_read_sda:
  l32r    a8, .Li2c_in_reg
  l32i.n  a9, a8, 0
  ssr     a14
  srl     a9, a9
  movi.n  a10, 1
  and     a2, a9, a10
  ret.n
  .literal_position
  .literal .Li2c_in_reg, __PROFILE_GPIO_IN__
  .size .cssc_i2c_read_sda, .-.cssc_i2c_read_sda

  ; cssc_i2c_write(handle, addr, byte) → ack_received (1=ACK, 0=NACK)
  .global cssc_i2c_write
  .type   cssc_i2c_write, @function
cssc_i2c_write:
  ; ABI (i64 args packed): a2:a3=handle (but it's a ptr — only lo used),
  ; a4:a5=addr (lo only), a6:a7=byte (lo only).
  ; Frame stores: handle@0, addr@4, byte@8, sda_pin@12, scl_pin@16,
  ; half_cycles@20.
  addi    a1, a1, -48
  s32i.n  a0, a1, 44
  s32i.n  a12, a1, 40
  s32i.n  a13, a1, 36
  s32i.n  a14, a1, 32
  s32i.n  a15, a1, 28
  s32i.n  a2, a1, 0                ; handle
  s32i.n  a4, a1, 4                ; addr
  s32i.n  a6, a1, 8                ; byte
  l32i.n  a8, a2, 4
  s32i.n  a8, a1, 12               ; sda_pin
  l32i.n  a8, a2, 8
  s32i.n  a8, a1, 16               ; scl_pin
  l32i.n  a8, a2, 12
  s32i.n  a8, a1, 20               ; half_cycles
  ; --- START condition ---
  ; SDA high (release), SCL high, delay; SDA low; delay.
  l32i.n  a14, a1, 12              ; sda_pin
  movi.n  a15, 0                   ; release
  call0   .cssc_i2c_drive
  l32i.n  a14, a1, 16              ; scl_pin
  movi.n  a15, 0
  call0   .cssc_i2c_drive
  l32i.n  a13, a1, 20
  call0   .cssc_i2c_delay
  l32i.n  a14, a1, 12              ; sda_pin
  movi.n  a15, 1                   ; pull low
  call0   .cssc_i2c_drive
  l32i.n  a13, a1, 20
  call0   .cssc_i2c_delay
  ; --- Send address byte (addr << 1 + W=0) ---
  l32i.n  a12, a1, 4               ; addr
  slli    a12, a12, 1              ; shift in W bit (0)
  mov.n   a2, a12
  call0   ._cssc_i2c_send_byte
  ; --- Send data byte ---
  l32i.n  a12, a1, 8
  mov.n   a2, a12
  call0   ._cssc_i2c_send_byte
  mov.n   a12, a2                  ; preserve ACK status
  ; --- STOP condition ---
  ; SCL low, SDA low, SCL high (delay), SDA high (delay).
  l32i.n  a14, a1, 16
  movi.n  a15, 1
  call0   .cssc_i2c_drive
  l32i.n  a14, a1, 12
  movi.n  a15, 1
  call0   .cssc_i2c_drive
  l32i.n  a13, a1, 20
  call0   .cssc_i2c_delay
  l32i.n  a14, a1, 16
  movi.n  a15, 0
  call0   .cssc_i2c_drive
  l32i.n  a13, a1, 20
  call0   .cssc_i2c_delay
  l32i.n  a14, a1, 12
  movi.n  a15, 0
  call0   .cssc_i2c_drive
  ; Return last ACK status as i64.
  mov.n   a2, a12
  movi.n  a3, 0
  l32i.n  a15, a1, 28
  l32i.n  a14, a1, 32
  l32i.n  a13, a1, 36
  l32i.n  a12, a1, 40
  l32i.n  a0,  a1, 44
  addi    a1, a1, 48
  ret.n
  .size cssc_i2c_write, .-cssc_i2c_write

  ; Internal: send one byte MSB-first, read ACK bit, return ACK in a2.
  ;   in: a2 = byte to send
  ;   out: a2 = ACK status (1=ACK received)
  ;   uses sda_pin from frame[+12], scl_pin from frame[+16], half@+20
  ;   ASSUMES caller frame is the i2c_write frame layout (relative
  ;   offsets stable across all i2c entry points).
.global ._cssc_i2c_send_byte
.type ._cssc_i2c_send_byte, @function
._cssc_i2c_send_byte:
  ; CALL0 ABI: this helper clobbers a13/a14/a15 (delay-counter, pin-no,
  ; drive-state) as scratch across calls to .cssc_i2c_drive. All three
  ; are callee-save — they MUST be preserved. The prior 16-byte frame
  ; only saved a12, leaking a13..a15 corruption back to every caller
  ; (cssc_i2c_write, _pair, _burst). On hardware this manifested as
  ; subtle timing/protocol failures in long transactions because the
  ; outer functions sometimes refilled these registers from spill
  ; before noticing.
  addi    a1, a1, -32
  s32i.n  a0,  a1, 28
  s32i.n  a12, a1, 24
  s32i.n  a13, a1, 20
  s32i.n  a14, a1, 16
  s32i.n  a15, a1, 12
  mov.n   a12, a2                  ; byte
  movi.n  a4, 8                    ; bits remaining
sb_loop:
  movi.n  a5, 0
  beq     a4, a5, sb_done
  ; SCL low. Parent-frame offsets shift by our prologue size (32):
  ; sda=12 → 44, scl=16 → 48, half=20 → 52.
  l32i.n  a14, a1, 48              ; scl_pin (parent +16)
  movi.n  a15, 1
  call0   .cssc_i2c_drive
  ; SDA = MSB of byte. drive_state semantics: 1=pull-low, 0=release-high.
  ; bit==1 → release (a15=0); bit==0 → pull-low (a15=1).
  movi.n  a8, 0x80
  and     a9, a12, a8
  movi.n  a15, 0
  beq     a9, a8, sb_set_lo
  movi.n  a15, 1
sb_set_lo:
  l32i.n  a14, a1, 44              ; sda_pin (parent +12)
  call0   .cssc_i2c_drive
  l32i.n  a13, a1, 52              ; half_cycles (parent +20)
  call0   .cssc_i2c_delay
  ; SCL high
  l32i.n  a14, a1, 48
  movi.n  a15, 0
  call0   .cssc_i2c_drive
  l32i.n  a13, a1, 52
  call0   .cssc_i2c_delay
  ; next bit
  slli    a12, a12, 1
  addi    a4, a4, -1
  j       sb_loop
sb_done:
  ; --- ACK bit: SCL low, release SDA, SCL high, read SDA, SCL low ---
  l32i.n  a14, a1, 48
  movi.n  a15, 1
  call0   .cssc_i2c_drive
  l32i.n  a14, a1, 44
  movi.n  a15, 0                   ; release
  call0   .cssc_i2c_drive
  l32i.n  a13, a1, 52
  call0   .cssc_i2c_delay
  l32i.n  a14, a1, 48
  movi.n  a15, 0
  call0   .cssc_i2c_drive
  l32i.n  a13, a1, 52
  call0   .cssc_i2c_delay
  l32i.n  a14, a1, 44
  call0   .cssc_i2c_read_sda
  ; a2 = SDA value; ACK = (SDA == 0).
  movi.n  a3, 0
  beq     a2, a3, sb_ack
  movi.n  a2, 0
  j       sb_ret
sb_ack:
  movi.n  a2, 1
sb_ret:
  l32i.n  a15, a1, 12
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .size ._cssc_i2c_send_byte, .-._cssc_i2c_send_byte

  ; cssc_i2c_write_pair(handle, addr, b1, b2)
  ;   Sends `addr+W, b1, b2` in ONE I2C transaction (START..STOP), no
  ;   STOP between b1 and b2. Used by the SSD1306 init sequence
  ;   (b1=0x00 control byte, b2=cmd byte) and by per-byte show
  ;   (b1=0x40 data control, b2=pixel byte). Without this, every
  ;   command/data byte was being sent as its own transaction, which
  ;   the SSD1306 interprets as the control byte alone — no init
  ;   happens, OLED stays dark.
  .global cssc_i2c_write_pair
  .type   cssc_i2c_write_pair, @function
cssc_i2c_write_pair:
  ; Frame mirrors cssc_i2c_write so _cssc_i2c_send_byte can index the
  ; parent frame at +12/+16/+20 for sda/scl/half_cycles. We also
  ; preserve a12..a15 because we use them as scratch + the caller
  ; needs them intact under CALL0 ABI.
  ; In: a2:a3=handle (ptr lo only), a4:a5=addr (lo only),
  ;     a6:a7=b1 (lo only), stack[+0..7]=b2 (i64 lo only).
  ; Out: a2 = ACK status of b2.
  addi    a1, a1, -48
  s32i.n  a0, a1, 44
  s32i.n  a12, a1, 40
  s32i.n  a13, a1, 36
  s32i.n  a14, a1, 32
  s32i.n  a15, a1, 28
  s32i.n  a2, a1, 0                ; handle
  s32i.n  a4, a1, 4                ; addr
  s32i.n  a6, a1, 8                ; b1
  ; b2 came in via the caller's outgoing stack-arg block at [caller_sp + 0].
  ; After our prologue subtracted 48, that's [a1 + 48].
  l32i.n  a8, a1, 48               ; b2 (lo of stack-arg pair)
  s32i.n  a8, a1, 24               ; persist b2 in a free slot
  l32i.n  a8, a2, 4
  s32i.n  a8, a1, 12               ; sda_pin
  l32i.n  a8, a2, 8
  s32i.n  a8, a1, 16               ; scl_pin
  l32i.n  a8, a2, 12
  s32i.n  a8, a1, 20               ; half_cycles
  ; --- START ---
  l32i.n  a14, a1, 12
  movi.n  a15, 0
  call0   .cssc_i2c_drive
  l32i.n  a14, a1, 16
  movi.n  a15, 0
  call0   .cssc_i2c_drive
  l32i.n  a13, a1, 20
  call0   .cssc_i2c_delay
  l32i.n  a14, a1, 12
  movi.n  a15, 1
  call0   .cssc_i2c_drive
  l32i.n  a13, a1, 20
  call0   .cssc_i2c_delay
  ; --- Address byte (W=0) ---
  l32i.n  a12, a1, 4
  slli    a12, a12, 1
  mov.n   a2, a12
  call0   ._cssc_i2c_send_byte
  ; --- b1 ---
  l32i.n  a2, a1, 8
  call0   ._cssc_i2c_send_byte
  ; --- b2 ---
  l32i.n  a2, a1, 24
  call0   ._cssc_i2c_send_byte
  mov.n   a12, a2                  ; preserve final ACK
  ; --- STOP ---
  l32i.n  a14, a1, 16
  movi.n  a15, 1
  call0   .cssc_i2c_drive
  l32i.n  a14, a1, 12
  movi.n  a15, 1
  call0   .cssc_i2c_drive
  l32i.n  a13, a1, 20
  call0   .cssc_i2c_delay
  l32i.n  a14, a1, 16
  movi.n  a15, 0
  call0   .cssc_i2c_drive
  l32i.n  a13, a1, 20
  call0   .cssc_i2c_delay
  l32i.n  a14, a1, 12
  movi.n  a15, 0
  call0   .cssc_i2c_drive
  mov.n   a2, a12
  movi.n  a3, 0
  l32i.n  a15, a1, 28
  l32i.n  a14, a1, 32
  l32i.n  a13, a1, 36
  l32i.n  a12, a1, 40
  l32i.n  a0, a1, 44
  addi    a1, a1, 48
  ret.n
  .size cssc_i2c_write_pair, .-cssc_i2c_write_pair

  ; cssc_i2c_write_burst(handle, addr, ctl, ptr, len)
  ;   Sends `addr+W, ctl, *(ptr), *(ptr+1), ..., *(ptr+len-1)` in
  ;   ONE I2C transaction. Used by cssc_tft_show to push the full
  ;   framebuffer in a single START..STOP envelope instead of
  ;   ~1024 micro-transactions.
  ; In: a2=handle, a4=addr, a6=ctl, stack[0..7]=ptr (lo), stack[8..15]=len.
  ; Out: a2 = ACK status of last byte.
  .global cssc_i2c_write_burst
  .type   cssc_i2c_write_burst, @function
cssc_i2c_write_burst:
  ; Frame: 64 bytes so the per-call ptr-cursor and remaining-len slots
  ; don't collide with the callee-save save slots.
  ;  [+0]  handle
  ;  [+4]  addr
  ;  [+8]  ctl
  ;  [+12] sda_pin
  ;  [+16] scl_pin
  ;  [+20] half_cycles
  ;  [+24] ptr cursor (advances each byte)
  ;  [+28] len remaining (decrements each byte)
  ;  [+44] saved a15
  ;  [+48] saved a14
  ;  [+52] saved a13
  ;  [+56] saved a12
  ;  [+60] saved a0
  ; Caller stack-args land at [+64] (ptr lo), [+72] (len lo).
  addi    a1, a1, -64
  s32i.n  a0,  a1, 60
  s32i.n  a12, a1, 56
  s32i.n  a13, a1, 52
  s32i.n  a14, a1, 48
  s32i.n  a15, a1, 44
  s32i.n  a2, a1, 0                ; handle
  s32i.n  a4, a1, 4                ; addr
  s32i.n  a6, a1, 8                ; ctl
  l32i.n  a8, a1, 64               ; ptr lo (stack arg)
  s32i.n  a8, a1, 24               ; persist ptr cursor
  l32i.n  a8, a1, 72               ; len lo (stack arg)
  s32i.n  a8, a1, 28               ; persist len
  l32i.n  a8, a2, 4
  s32i.n  a8, a1, 12               ; sda_pin
  l32i.n  a8, a2, 8
  s32i.n  a8, a1, 16               ; scl_pin
  l32i.n  a8, a2, 12
  s32i.n  a8, a1, 20               ; half_cycles
  ; --- START ---
  l32i.n  a14, a1, 12
  movi.n  a15, 0
  call0   .cssc_i2c_drive
  l32i.n  a14, a1, 16
  movi.n  a15, 0
  call0   .cssc_i2c_drive
  l32i.n  a13, a1, 20
  call0   .cssc_i2c_delay
  l32i.n  a14, a1, 12
  movi.n  a15, 1
  call0   .cssc_i2c_drive
  l32i.n  a13, a1, 20
  call0   .cssc_i2c_delay
  ; --- Address byte ---
  l32i.n  a12, a1, 4
  slli    a12, a12, 1
  mov.n   a2, a12
  call0   ._cssc_i2c_send_byte
  ; --- Control byte ---
  l32i.n  a2, a1, 8
  call0   ._cssc_i2c_send_byte
  ; --- Data bytes loop ---
wb_loop:
  l32i.n  a8, a1, 28               ; len
  movi.n  a9, 0
  beq     a8, a9, wb_done
  l32i.n  a8, a1, 24               ; ptr cursor
  l8ui    a2, a8, 0
  call0   ._cssc_i2c_send_byte
  l32i.n  a8, a1, 24
  addi    a8, a8, 1
  s32i.n  a8, a1, 24               ; advance cursor
  l32i.n  a8, a1, 28
  addi    a8, a8, -1
  s32i.n  a8, a1, 28               ; decrement remaining
  j       wb_loop
wb_done:
  mov.n   a12, a2                  ; preserve final ACK
  ; --- STOP ---
  l32i.n  a14, a1, 16
  movi.n  a15, 1
  call0   .cssc_i2c_drive
  l32i.n  a14, a1, 12
  movi.n  a15, 1
  call0   .cssc_i2c_drive
  l32i.n  a13, a1, 20
  call0   .cssc_i2c_delay
  l32i.n  a14, a1, 16
  movi.n  a15, 0
  call0   .cssc_i2c_drive
  l32i.n  a13, a1, 20
  call0   .cssc_i2c_delay
  l32i.n  a14, a1, 12
  movi.n  a15, 0
  call0   .cssc_i2c_drive
  mov.n   a2, a12
  movi.n  a3, 0
  l32i.n  a15, a1, 44
  l32i.n  a14, a1, 48
  l32i.n  a13, a1, 52
  l32i.n  a12, a1, 56
  l32i.n  a0,  a1, 60
  addi    a1, a1, 64
  ret.n
  .size cssc_i2c_write_burst, .-cssc_i2c_write_burst

  .global cssc_i2c_read
  .type   cssc_i2c_read, @function
cssc_i2c_read:
  ; in: a2 = handle, a4 = addr → out: a2 = byte read
  ; (Phase D2 minimum: START, send addr|R, read 8 bits + NACK, STOP.)
  ; For brevity we delegate the start/stop machinery to cssc_i2c_write's
  ; helpers but reorder the bit loop to RECEIVE. A self-contained
  ; implementation lives below.
  addi    a1, a1, -48
  s32i.n  a0, a1, 44
  s32i.n  a12, a1, 40
  s32i.n  a13, a1, 36
  s32i.n  a14, a1, 32
  s32i.n  a15, a1, 28
  s32i.n  a2, a1, 0                ; handle
  s32i.n  a4, a1, 4                ; addr
  l32i.n  a8, a2, 4
  s32i.n  a8, a1, 12
  l32i.n  a8, a2, 8
  s32i.n  a8, a1, 16
  l32i.n  a8, a2, 12
  s32i.n  a8, a1, 20
  ; START
  l32i.n  a14, a1, 12
  movi.n  a15, 0
  call0   .cssc_i2c_drive
  l32i.n  a14, a1, 16
  movi.n  a15, 0
  call0   .cssc_i2c_drive
  l32i.n  a13, a1, 20
  call0   .cssc_i2c_delay
  l32i.n  a14, a1, 12
  movi.n  a15, 1
  call0   .cssc_i2c_drive
  l32i.n  a13, a1, 20
  call0   .cssc_i2c_delay
  ; Send (addr << 1) | 1.
  l32i.n  a12, a1, 4
  slli    a12, a12, 1
  movi.n  a8, 1
  or      a12, a12, a8
  mov.n   a2, a12
  call0   ._cssc_i2c_send_byte
  ; Read 8 bits MSB-first.
  movi.n  a12, 0                   ; accumulator
  movi.n  a4, 8
ir_loop:
  movi.n  a5, 0
  beq     a4, a5, ir_done
  l32i.n  a14, a1, 16              ; SCL
  movi.n  a15, 1                   ; low
  call0   .cssc_i2c_drive
  l32i.n  a14, a1, 12              ; SDA
  movi.n  a15, 0                   ; release (will read)
  call0   .cssc_i2c_drive
  l32i.n  a13, a1, 20
  call0   .cssc_i2c_delay
  l32i.n  a14, a1, 16              ; SCL
  movi.n  a15, 0                   ; high
  call0   .cssc_i2c_drive
  l32i.n  a13, a1, 20
  call0   .cssc_i2c_delay
  l32i.n  a14, a1, 12              ; read SDA
  call0   .cssc_i2c_read_sda
  ; shift accumulator left, OR in the bit.
  slli    a12, a12, 1
  or      a12, a12, a2
  addi    a4, a4, -1
  j       ir_loop
ir_done:
  ; Send NACK after the byte (master tells slave "no more bytes").
  l32i.n  a14, a1, 16
  movi.n  a15, 1
  call0   .cssc_i2c_drive
  l32i.n  a14, a1, 12
  movi.n  a15, 0                   ; release SDA (HIGH = NACK)
  call0   .cssc_i2c_drive
  l32i.n  a13, a1, 20
  call0   .cssc_i2c_delay
  l32i.n  a14, a1, 16
  movi.n  a15, 0                   ; SCL high
  call0   .cssc_i2c_drive
  l32i.n  a13, a1, 20
  call0   .cssc_i2c_delay
  ; STOP
  l32i.n  a14, a1, 16
  movi.n  a15, 1
  call0   .cssc_i2c_drive
  l32i.n  a14, a1, 12
  movi.n  a15, 1
  call0   .cssc_i2c_drive
  l32i.n  a13, a1, 20
  call0   .cssc_i2c_delay
  l32i.n  a14, a1, 16
  movi.n  a15, 0
  call0   .cssc_i2c_drive
  l32i.n  a13, a1, 20
  call0   .cssc_i2c_delay
  l32i.n  a14, a1, 12
  movi.n  a15, 0
  call0   .cssc_i2c_drive
  ; Return accumulator as i64.
  mov.n   a2, a12
  movi.n  a3, 0
  l32i.n  a15, a1, 28
  l32i.n  a14, a1, 32
  l32i.n  a13, a1, 36
  l32i.n  a12, a1, 40
  l32i.n  a0,  a1, 44
  addi    a1, a1, 48
  ret.n
  .size cssc_i2c_read, .-cssc_i2c_read

  ; ===========================================================================
  ; D3 — SPI (HSPI hardware block at 0x60000200). Single-byte transfer.
  ;
  ; Register layout (TRM §7):
  ;   SPI_CMD_REG    = 0x60000200  bit 18 = SPI_USR (start transfer)
  ;   SPI_CLOCK_REG  = 0x60000218
  ;   SPI_USER_REG   = 0x60000234
  ;   SPI_USER1_REG  = 0x60000238
  ;   SPI_W0_REG     = 0x60000240
  ;
  ; Handle (16 bytes):
  ;   off 0: i32 bus_id (1=HSPI)
  ;   off 4: i32 sck_pin, off 8: i32 miso_pin, off 12: i32 mosi_pin
  ; ===========================================================================

  .global cssc_spi_new
  .type   cssc_spi_new, @function
cssc_spi_new:
  ; in: a2 = bus_id (i64 lo), a4 = sck (i64 lo), a6 = miso (i64 lo),
  ;     [a1, frame_size+0] = mosi (i64 lo, stack-passed because the
  ;     4th i64 arg overflows the 6-register CALL0 ABI).
  ; out: a2 = handle ptr
  addi    a1, a1, -32
  s32i.n  a0,  a1, 28
  s32i.n  a12, a1, 24
  s32i.n  a13, a1, 20
  s32i.n  a14, a1, 16
  s32i.n  a15, a1, 12
  mov.n   a12, a2                  ; bus
  mov.n   a13, a4                  ; sck
  mov.n   a14, a6                  ; miso
  ; mosi is the stack-passed 4th i64 arg; its lo half lives at
  ; [caller-SP, 0..3] which after our 32-byte prologue is at
  ; [a1, 32..35]. The hi half at [a1, 36..39] is discarded —
  ; pin numbers fit in i32 trivially.
  l32i.n  a15, a1, 32              ; mosi
  movi.n  a2, 16
  call0   cssc_obj_alloc
  s32i.n  a12, a2, 0
  s32i.n  a13, a2, 4
  s32i.n  a14, a2, 8
  s32i.n  a15, a2, 12
  l32i.n  a15, a1, 12
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .size cssc_spi_new, .-cssc_spi_new

  .global cssc_spi_free
  .type   cssc_spi_free, @function
cssc_spi_free:
  ret.n
  .size cssc_spi_free, .-cssc_spi_free

  .global cssc_spi_begin
  .type   cssc_spi_begin, @function
cssc_spi_begin:
  ; Configure HSPI for 8-bit full-duplex transfer at ~1 MHz (Phase D3b).
  ; SPI_USER_REG bits we care about:
  ;   bit 0  = SPI_DOUTDIN   (full-duplex MOSI+MISO on same clocks)
  ;   bit 27 = SPI_USR_MOSI  (we send data)
  ;   bit 28 = SPI_USR_MISO  (we read the slave's response)
  ; SPI_USER1_REG:
  ;   bits 23:17 = SPI_USR_MOSI_BITLEN-1 (8 bits → 7)
  ;   bits 16:8  = SPI_USR_MISO_BITLEN-1 (8 bits → 7)
  ; SPI_CLOCK_REG: clkdiv_pre + clkcnt_n,h,l. The 0x00027001 pattern
  ; divides the 80 MHz APB clock down to ~1 MHz.
  l32r    a8, .Lspi_user_addr
  l32r    a9, .Lspi_user_val
  l32i.n  a9, a9, 0
  s32i.n  a9, a8, 0
  l32r    a8, .Lspi_user1_addr
  l32r    a9, .Lspi_user1_val
  l32i.n  a9, a9, 0
  s32i.n  a9, a8, 0
  l32r    a8, .Lspi_clock_addr
  l32r    a9, .Lspi_clock_val
  l32i.n  a9, a9, 0
  s32i.n  a9, a8, 0
  ret.n
  .literal_position
  .literal .Lspi_user_addr,   __PROFILE_SPI_USER__
  .literal .Lspi_user_val,    .Lspi_user_val_data
  .literal .Lspi_user1_addr,  __PROFILE_SPI_USER1__
  .literal .Lspi_user1_val,   .Lspi_user1_val_data
  .literal .Lspi_clock_addr,  __PROFILE_SPI_CLOCK__
  .literal .Lspi_clock_val,   .Lspi_clock_val_data
  .section .rodata
  .align 4
.Lspi_user_val_data:
  ; SPI_DOUTDIN (bit 0) | SPI_USR_MOSI (bit 27) | SPI_USR_MISO (bit 28)
  ; = 0x18000001. Full-duplex: every clock cycle both MOSI and MISO
  ; bits move in step, exactly the shape `cssc_spi_transfer` expects.
  .word 0x18000001
.Lspi_user1_val_data:
  ; MOSI_BITLEN = 7 (bits 23:17) | MISO_BITLEN = 7 (bits 16:8)
  ;   = 0x00E0_0E00. Eight bits each direction, matching CSSC's
  ; per-byte transfer abstraction.
  .word 0x00E00E00
.Lspi_clock_val_data:
  .word 0x00027001                 ; divider for ~1 MHz
  .text
  .size cssc_spi_begin, .-cssc_spi_begin

  .global cssc_spi_transfer
  .type   cssc_spi_transfer, @function
cssc_spi_transfer:
  ; Phase D3b — full-duplex single-byte transfer.
  ;   in:  a2 = handle (ignored; HSPI is a singleton), a4 = byte (i64 lo)
  ;   out: a2:a3 = i64 sample received on MISO during the same 8 clocks
  ;
  ; The peripheral shifts `a4`'s low 8 bits out on MOSI while
  ; latching MISO into the low 8 bits of SPI_W0. SPI_DOUTDIN was set
  ; in cssc_spi_begin so the two FIFOs share the same clock edges.
  ; After SPI_USR clears we read W0 back, mask to 8 bits, and return.
  l32r    a8, .Lspi_w0_addr
  s32i.n  a4, a8, 0
  l32r    a8, .Lspi_cmd_addr
  movi    a9, 0x40000              ; bit 18 = SPI_USR (start transaction)
  s32i.n  a9, a8, 0
spi_xf_wait:
  l32i.n  a10, a8, 0
  bnez    a10, spi_xf_wait
  ; Read MISO byte from W0[7:0].
  l32r    a8, .Lspi_w0_addr
  l32i.n  a9, a8, 0
  movi    a10, 0xFF
  and     a2, a9, a10
  movi.n  a3, 0
  ret.n
  .literal_position
  .literal .Lspi_w0_addr,  __PROFILE_SPI_W0__
  .literal .Lspi_cmd_addr, __PROFILE_SPI_CMD__
  .size cssc_spi_transfer, .-cssc_spi_transfer

  ; --- Phase D3b multi-byte burst transfer ---------------------------------
  ; cssc_spi_transfer_burst(handle, ptr buf_in_out, i64 length)
  ;
  ; Sends `length` bytes from `buf_in_out` over MOSI, simultaneously
  ; replaces them in-place with the bytes received on MISO. The
  ; chunked engine fits up to 64 bytes per transaction because the
  ; HSPI buffer is W0..W15 = 16 registers × 32 bits = 64 bytes.
  ;
  ;   in:  a2 = handle (ignored), a4 = buf_in_out ptr, a6 = length (i64 lo)
  ;   out: a2 = bytes actually transferred (== length on success)
  ;
  ; The implementation iterates 64-byte chunks. For each chunk:
  ;   1. Configure USER1 with the chunk's bit-length (length*8 - 1).
  ;   2. Copy 0..15 source words from `buf` into W0..W15.
  ;   3. Trigger SPI_USR; poll until clear.
  ;   4. Read W0..W15 back into `buf` (in-place full-duplex semantics).
  ;
  ; This is the hot path for SSD1306 framebuffer pushes, BMP280
  ; pressure reads, and SD-card sector transfers.
  .global cssc_spi_transfer_burst
  .type   cssc_spi_transfer_burst, @function
cssc_spi_transfer_burst:
  addi    a1, a1, -32
  s32i.n  a0, a1, 28
  s32i.n  a12, a1, 24                ; buf cursor
  s32i.n  a13, a1, 20                ; bytes remaining
  s32i.n  a14, a1, 16                ; HSPI base reg cache
  s32i.n  a15, a1, 12                ; chunk size in bytes
  mov.n   a12, a4                    ; a12 = buf cursor
  mov.n   a13, a6                    ; a13 = bytes remaining (i64 lo only)
  l32r    a14, .Lspi_w0_burst
.Lspi_burst_chunk:
  movi.n  a15, 0
  beq     a13, a15, .Lspi_burst_done
  ; Determine chunk size = min(remaining, 64).
  movi    a15, 64
  bltu    a13, a15, 1f
  movi    a15, 64
  j       2f
1:
  mov.n   a15, a13
2:
  ; Configure SPI_USER1_REG with (chunk*8 - 1) for both BITLEN fields.
  ;   value = ((chunk*8 - 1) << 17) | ((chunk*8 - 1) << 8)
  slli    a8, a15, 3                  ; a8 = chunk * 8
  addi    a8, a8, -1                  ; a8 = chunk*8 - 1
  slli    a9, a8, 17
  slli    a10, a8, 8
  or      a9, a9, a10
  l32r    a10, .Lspi_user1_burst_addr
  s32i.n  a9, a10, 0
  ; Copy `chunk` bytes from a12 (buf) into W0..W15. The CIR side
  ; guarantees buf alignment by allocating from the bump allocator,
  ; which hands out 4-byte-aligned blocks; we use l32i.n freely.
  ; Bytes that don't fill a full word are still copied with l8ui.
  mov.n   a8, a12                    ; a8 = src cursor in buf
  mov.n   a9, a14                    ; a9 = dst cursor in SPI_W
  mov.n   a11, a15                   ; a11 = bytes left in this chunk
.Lspi_burst_loadw:
  ; Word-copy as long as 4+ bytes remain in this chunk.
  movi    a10, 4
  bltu    a11, a10, .Lspi_burst_tail_in
  l32i.n  a10, a8, 0
  s32i.n  a10, a9, 0
  addi    a8, a8, 4
  addi    a9, a9, 4
  addi    a11, a11, -4
  j       .Lspi_burst_loadw
.Lspi_burst_tail_in:
  ; 0..3-byte tail. Pack remaining bytes into one word, little-end
  ; ordered, then store. BITLEN was set to (chunk*8 - 1) so the
  ; peripheral only shifts the exact number of bits requested — any
  ; high-byte slack in the packed word is harmless.
  ;
  ; A.1.2: this block previously used a13 as a scratch register for
  ; byte loads + comparison literals — but a13 holds bytes-remaining
  ; across the outer chunk loop. Any burst with `length % 4 != 0`
  ; clobbered the counter, then a stray `l32r a13, .Lspi_w0_burst`
  ; "restored" it to the MMIO base address instead of the counter.
  ; Outer loop then read a wild value and either hung or scribbled
  ; garbage into MMIO. The 6-byte cmd-stream burst in cssc_tft_show
  ; hit this on every frame. Fix: scratch in a3 (caller-save, free
  ; throughout this routine), drop the bogus l32r entirely.
  beqz    a11, .Lspi_burst_kick
  movi.n  a10, 0                     ; packed word accumulator
  l8ui    a3, a8, 0
  or      a10, a10, a3
  movi    a3, 2
  blt     a11, a3, .Lspi_burst_tail_store
  l8ui    a3, a8, 1
  slli    a3, a3, 8
  or      a10, a10, a3
  movi    a3, 3
  blt     a11, a3, .Lspi_burst_tail_store
  l8ui    a3, a8, 2
  slli    a3, a3, 16
  or      a10, a10, a3
.Lspi_burst_tail_store:
  s32i.n  a10, a9, 0
.Lspi_burst_kick:
  ; Start the transaction and poll for completion.
  l32r    a8, .Lspi_cmd_burst_addr
  movi    a9, 0x40000                ; SPI_USR
  s32i.n  a9, a8, 0
.Lspi_burst_wait:
  l32i.n  a10, a8, 0
  bnez    a10, .Lspi_burst_wait
  ; Read W0..W15 back into buf. We re-derive the byte cursor as
  ;   buf_cursor_at_chunk_start = buf_cursor - chunk
  ; since a12 still points at the chunk start.
  mov.n   a8, a12
  mov.n   a9, a14
  mov.n   a11, a15
.Lspi_burst_storew:
  movi    a10, 4
  bltu    a11, a10, .Lspi_burst_tail_out
  l32i.n  a10, a9, 0
  s32i.n  a10, a8, 0
  addi    a8, a8, 4
  addi    a9, a9, 4
  addi    a11, a11, -4
  bnez    a11, .Lspi_burst_storew
  j       .Lspi_burst_next
.Lspi_burst_tail_out:
  beqz    a11, .Lspi_burst_next
  l32i.n  a10, a9, 0
.Lspi_burst_tail_byte:
  s8i     a10, a8, 0
  srli    a10, a10, 8
  addi    a8, a8, 1
  addi    a11, a11, -1
  bnez    a11, .Lspi_burst_tail_byte
.Lspi_burst_next:
  add     a12, a12, a15              ; buf cursor += chunk
  sub     a13, a13, a15              ; remaining -= chunk
  j       .Lspi_burst_chunk
.Lspi_burst_done:
  mov.n   a2, a6                     ; return original length
  movi.n  a3, 0
  l32i.n  a15, a1, 12
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .literal_position
  .literal .Lspi_w0_burst,         __PROFILE_SPI_W0__
  .literal .Lspi_user1_burst_addr, __PROFILE_SPI_USER1__
  .literal .Lspi_cmd_burst_addr,   __PROFILE_SPI_CMD__
  .size cssc_spi_transfer_burst, .-cssc_spi_transfer_burst

  ; ===========================================================================
  ; D4 — UART1 (0x60000F00). TX-only on GPIO2 — useful as a debug channel
  ; or as a side-channel to another MCU. Receive lives only on UART0.
  ; ===========================================================================

  .global cssc_uart_new
  .type   cssc_uart_new, @function
cssc_uart_new:
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  s32i.n  a12, a1, 8
  mov.n   a12, a2                  ; bus_id (0 or 1)
  movi.n  a2, 8
  call0   cssc_obj_alloc
  s32i.n  a12, a2, 0
  movi.n  a8, 0
  s32i.n  a8, a2, 4                ; default baud — set by begin
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_uart_new, .-cssc_uart_new

  .global cssc_uart_free
  .type   cssc_uart_free, @function
cssc_uart_free:
  ret.n
  .size cssc_uart_free, .-cssc_uart_free

  .global cssc_uart_begin
  .type   cssc_uart_begin, @function
cssc_uart_begin:
  ; in: a2 = handle, a4 = baud (i64 lo)
  ; ESP8266 UART clock = 80 MHz; UART_CLKDIV = 80_000_000 / baud.
  ; UART1_CLKDIV_REG = 0x60000F14.
  s32i.n  a4, a2, 4                ; persist baud
  ; Compute divider via __divsi3.
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  l32r    a8, .Luart_clk_addr
  l32i.n  a8, a8, 0                ; a8 = 80_000_000
  mov.n   a2, a8
  mov.n   a3, a4
  call0   __divsi3                 ; a2 = 80M / baud
  l32r    a8, .Luart1_clkdiv_addr
  s32i.n  a2, a8, 0
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
  .literal_position
  .literal .Luart_clk_addr,     .Luart_clk_val
  .literal .Luart1_clkdiv_addr, __PROFILE_UART1_CLKDIV__
  .section .rodata
  .align 4
.Luart_clk_val:
  .word __PROFILE_UART_CLK_HZ__
  .text
  .size cssc_uart_begin, .-cssc_uart_begin

  .global cssc_uart_write
  .type   cssc_uart_write, @function
cssc_uart_write:
  ; in: a2 = handle, a4 = byte (i64 lo). UART1 TX FIFO at 0x60000F00.
  l32r    a8, .Luart1_tx_addr
  s8i     a4, a8, 0
  memw
  ret.n
  .literal_position
  .literal .Luart1_tx_addr, __PROFILE_UART1_TX__
  .size cssc_uart_write, .-cssc_uart_write

  .global cssc_uart_read
  .type   cssc_uart_read, @function
cssc_uart_read:
  ; UART1 RX not connected on ESP8266 (the chip has no RX line wired
  ; through to GPIO2). Return 0 as a deterministic placeholder.
  movi.n  a2, 0
  movi.n  a3, 0
  ret.n
  .size cssc_uart_read, .-cssc_uart_read

  ; ===========================================================================
  ; D5 — ADC, PWM, Timer.
  ;
  ; ESP8266 ADC: 10-bit, single channel (TOUT pin). Reading requires the
  ; ROM-resident `system_adc_read` thunk at 0x40006A14 — we call into
  ; it (CALL0) and grab the i32 return.
  ;
  ; PWM: chip has no native PWM block. The SDK provides software PWM
  ; via FRC1 timer interrupts. For now cssc_pwm_duty is a no-op stub;
  ; a real port lands once interrupt-vector emission is wired.
  ;
  ; Timer: FRC1 hardware timer at 0x60000600. FRC1_LOAD_REG (0x600),
  ; FRC1_COUNT_REG (0x604), FRC1_CTRL_REG (0x608), FRC1_INT_REG (0x60C).
  ; ===========================================================================

  .global cssc_adc_new
  .type   cssc_adc_new, @function
cssc_adc_new:
  ; in:  a2:a3 = channel (i64 lo:hi); ESP8266 ignores it (TOUT-only),
  ;        ESP32 uses bits 0..2 to pick SAR_ADC1 channel 0..7.
  ; out: a2:a3 = handle (8 bytes: i32 channel, i32 reserved)
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8                ; preserve channel across alloc
  mov.n   a12, a2                   ; a12 = channel
  movi.n  a2, 8
  call0   cssc_obj_alloc
  s32i.n  a12, a2, 0                ; handle[0] = channel
  movi.n  a8, 0
  s32i.n  a8, a2, 4                 ; handle[4] = reserved (zeroed)
  movi.n  a3, 0
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_adc_new, .-cssc_adc_new

  .global cssc_adc_free
  .type   cssc_adc_free, @function
cssc_adc_free:
  ret.n
  .size cssc_adc_free, .-cssc_adc_free

  .global cssc_adc_read
  .type   cssc_adc_read, @function
cssc_adc_read:
  ; in:  a2 = handle
  ; out: a2:a3 = i64 sample (low = raw 12-bit reading on ESP32 or
  ;             10-bit on ESP8266; high = 0)
  ;
  ; Forwards the channel field in handle[0] as the first arg into the
  ; profile-specific read target. On ESP8266 the substitution makes
  ; that target the bootrom thunk at 0x40006A14 (which ignores its
  ; arg — TOUT-only). On ESP32 it's `cssc_adc_esp32_read` further
  ; below — a hand-coded SAR_ADC1 sequencer that uses the channel.
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  l32i.n  a2, a2, 0                ; a2 = channel (replaces handle ptr)
  l32r    a8, .Ladc_rom_addr
  callx0  a8                       ; reads sample → a2 (callee zeroes a3
                                   ; for cssc_adc_esp32_read; ESP8266
                                   ; bootrom leaves a3 garbage so we
                                   ; defensively zero it after).
  movi.n  a3, 0
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
  .literal_position
  .literal .Ladc_rom_addr, __PROFILE_ADC_READ_TARGET__
  .size cssc_adc_read, .-cssc_adc_read

  ; --- ESP32 SAR_ADC1 12-bit measurement sequencer ------------------------
  ; In:  a2 = channel (0..7 for SAR_ADC1)
  ; Out: a2:a3 = i64 sample (low = 12-bit raw, high = 0)
  ;
  ; Programs SENS_SAR_MEAS_START1_REG (0x3FF48854):
  ;   bit 12      EN_PAD_FORCE      — SW controls pad selection
  ;   bit 13      START_FORCE       — SW controls start trigger
  ;   bit 14      START_SAR         — write 1 to kick a measurement
  ;   bit 15      DONE_SAR          — bootrom sets when result ready
  ;   bits 11:0   EN_PAD            — channel-select bitmap (1 of 8 set)
  ;   bits 31:16  DATA_SAR          — 16-bit raw result (12 useful bits)
  ;
  ; This is a polling implementation — the SAR finishes in ~20 µs at
  ; default clkdiv, well under the bootrom WDT timeout. F1b' adds the
  ; RTC_IO MUX setup that switches the channel's GPIO away from the
  ; digital subsystem; for now we assume the user hasn't reconfigured
  ; the pin to digital mode (which is the freshly-booted state).
  .global cssc_adc_esp32_read
  .type   cssc_adc_esp32_read, @function
cssc_adc_esp32_read:
  l32r    a8, .Lsar_meas_start1
  ; Build config: (1 << channel) | START_FORCE (0x2000) | EN_PAD_FORCE (0x1000)
  movi.n  a9, 1
  ssl     a2                       ; SAR = channel
  sll     a10, a9                  ; a10 = 1 << channel
  movi    a11, 0x3000              ; START_FORCE | EN_PAD_FORCE
  or      a10, a10, a11
  s32i.n  a10, a8, 0               ; clear START_SAR, set FORCEs + pad
  ; Set START_SAR (bit 14) to kick the measurement.
  movi    a11, 0x4000
  or      a10, a10, a11
  s32i.n  a10, a8, 0
.Lsar_wait:
  l32i.n  a9, a8, 0
  bbci    a9, 15, .Lsar_wait       ; loop while DONE_SAR (bit 15) clear
  ; Result is in bits 31:16. Shift right by 16 to land it in a2[15:0].
  srli    a2, a9, 16
  movi.n  a3, 0
  ret.n
  .literal_position
  .literal .Lsar_meas_start1, 0x3FF48854
  .size cssc_adc_esp32_read, .-cssc_adc_esp32_read

  .global cssc_pwm_new
  .type   cssc_pwm_new, @function
cssc_pwm_new:
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  movi.n  a2, 16
  call0   cssc_obj_alloc
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_pwm_new, .-cssc_pwm_new

  .global cssc_pwm_free
  .type   cssc_pwm_free, @function
cssc_pwm_free:
  ret.n
  .size cssc_pwm_free, .-cssc_pwm_free

  .global cssc_pwm_duty
  .type   cssc_pwm_duty, @function
cssc_pwm_duty:
  ; Software PWM requires FRC1 interrupt handler — queued for Phase
  ; D5b. For now persist the duty value so user code that reads
  ; back the configured duty sees it.
  s32i.n  a4, a2, 12
  ret.n
  .size cssc_pwm_duty, .-cssc_pwm_duty

  .global cssc_timer_new
  .type   cssc_timer_new, @function
cssc_timer_new:
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  movi.n  a2, 16
  call0   cssc_obj_alloc
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_timer_new, .-cssc_timer_new

  .global cssc_timer_free
  .type   cssc_timer_free, @function
cssc_timer_free:
  ret.n
  .size cssc_timer_free, .-cssc_timer_free

  .global cssc_timer_start
  .type   cssc_timer_start, @function
cssc_timer_start:
  ; FRC1 ctrl: enable + auto-reload + clock=5MHz divider (DIV16).
  l32r    a8, .Lfrc1_load_addr
  l32r    a9, .Lfrc1_load_val
  l32i.n  a9, a9, 0
  s32i.n  a9, a8, 0
  l32r    a8, .Lfrc1_ctrl_addr
  l32r    a9, .Lfrc1_ctrl_val
  l32i.n  a9, a9, 0
  s32i.n  a9, a8, 0
  ret.n
  .literal_position
  .literal .Lfrc1_load_addr, __PROFILE_FRC1_LOAD__
  .literal .Lfrc1_load_val,  .Lfrc1_load_val_d
  .literal .Lfrc1_ctrl_addr, __PROFILE_FRC1_CTRL__
  .literal .Lfrc1_ctrl_val,  .Lfrc1_ctrl_val_d
  .section .rodata
  .align 4
.Lfrc1_load_val_d:
  .word 0x000F4240                 ; 1_000_000 µs reload
.Lfrc1_ctrl_val_d:
  .word 0x000000C0                 ; enable + auto-reload + 256-prescale
  .text
  .size cssc_timer_start, .-cssc_timer_start

  .global cssc_timer_stop
  .type   cssc_timer_stop, @function
cssc_timer_stop:
  l32r    a8, .Lfrc1_ctrl_addr_b
  movi.n  a9, 0
  s32i.n  a9, a8, 0
  ret.n
  .literal_position
  .literal .Lfrc1_ctrl_addr_b, __PROFILE_FRC1_CTRL__
  .size cssc_timer_stop, .-cssc_timer_stop

  .global cssc_timer_read
  .type   cssc_timer_read, @function
cssc_timer_read:
  l32r    a8, .Lfrc1_count_addr
  l32i.n  a2, a8, 0
  movi.n  a3, 0
  ret.n
  .literal_position
  .literal .Lfrc1_count_addr, __PROFILE_FRC1_COUNT__
  .size cssc_timer_read, .-cssc_timer_read

  ; ===========================================================================
  ; E2 — video / matrix / framebuffer / console.
  ;
  ; ESP8266 has no built-in display surface. These types exist on host
  ; as Win32 windows / SDL surfaces; on bare metal we keep the handles
  ; and persist the configured dimensions so user code observes
  ; consistent reads, but no rendering happens. Real chips with
  ; attached displays go through #tft / #oled (Phase E1).
  ; ===========================================================================

  .global cssc_video_new
  .type   cssc_video_new, @function
cssc_video_new:
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  movi.n  a2, 16
  call0   cssc_obj_alloc
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_video_new, .-cssc_video_new
  .global cssc_video_free
cssc_video_free:  ret.n
  .global cssc_video_begin
cssc_video_begin: ret.n
  .global cssc_video_close
cssc_video_close: ret.n
  .global cssc_video_clear
cssc_video_clear: ret.n
  .global cssc_video_present
cssc_video_present: ret.n
  .global cssc_video_is_open
cssc_video_is_open:
  movi.n  a2, 0
  movi.n  a3, 0
  ret.n

  .global cssc_matrix_new
cssc_matrix_new:
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  movi.n  a2, 12
  call0   cssc_obj_alloc
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
  .global cssc_matrix_free
cssc_matrix_free: ret.n
  .global cssc_matrix_fill
cssc_matrix_fill: ret.n
  .global cssc_matrix_pixel
cssc_matrix_pixel: ret.n
  .global cssc_matrix_show
cssc_matrix_show: ret.n

  .global cssc_framebuffer_new
cssc_framebuffer_new:
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  movi.n  a2, 8
  call0   cssc_obj_alloc
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
  .global cssc_framebuffer_free
cssc_framebuffer_free: ret.n
  .global cssc_framebuffer_fill
cssc_framebuffer_fill: ret.n
  .global cssc_framebuffer_pixel
cssc_framebuffer_pixel: ret.n
  .global cssc_framebuffer_present
cssc_framebuffer_present: ret.n

  .global cssc_console_new
cssc_console_new:
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  movi.n  a2, 8
  call0   cssc_obj_alloc
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
  .global cssc_console_free
cssc_console_free: ret.n
  .global cssc_console_write
cssc_console_write:
  ; Forward writes to UART0 stdout (cssc_uart_putc) for visibility.
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  ; a4 = cssc_str* (string). Load size + data ptr, byte-stream through UART.
  l32i.n  a12, a4, 8               ; data ptr
  l32i.n  a13, a4, 0               ; size
con_loop:
  movi.n  a8, 0
  beq     a13, a8, con_done
  l8ui    a2, a12, 0
  call0   cssc_uart_putc
  addi    a12, a12, 1
  addi    a13, a13, -1
  j       con_loop
con_done:
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
  .global cssc_console_clear
cssc_console_clear: ret.n
  .global cssc_console_close
cssc_console_close: ret.n

  ; ===========================================================================
  ; E1 — SSD1306 OLED driver (also serves SH1106, ILI9341, ST7735, ST7789
  ; via per-controller branches in cssc_tft_begin). Bus: I2C for SSD1306/
  ; SH1106; SPI for ILI9341/ST7735/ST7789. The handle records which bus.
  ;
  ; OLED handle layout (32 bytes):
  ;   off 0:  i32 ctrl_id           (1=SSD1306, 2=SH1106, 3=ILI9341, ...)
  ;   off 4:  i32 width
  ;   off 8:  i32 height
  ;   off 12: i32 sda_pin   (I2C) OR sck_pin (SPI)
  ;   off 16: i32 scl_pin   (I2C) OR mosi_pin (SPI)
  ;   off 20: i32 i2c_addr  (default 0x3C for SSD1306)
  ;   off 24: i32 fb_ptr    (pointer to framebuffer in arena)
  ;   off 28: i32 fb_size   (bytes — width*height/8 for monochrome)
  ;
  ; The 5x7 font table at .Lfont5x7_table is embedded as a 96 × 5-byte
  ; block (ASCII 0x20..0x7F). Each character is 5 vertical columns of
  ; 7 bits (MSB top, bit 7 unused). The default block is all zeros so
  ; .text() renders blank rectangles until a font is dropped in — see
  ; the rodata block; a follow-up phase replaces it with a real font.
  ; ===========================================================================

  .global cssc_tft_new
  .type   cssc_tft_new, @function
cssc_tft_new:
  ; in:  a2 = ctrl_id (i64 lo), a4 = w (i64 lo), a6 = h (i64 lo)
  ; out: a2 = pointer to 32-byte handle
  ;
  ; Frame layout (locals + saved regs, 32 bytes total):
  ;   [a1,  0]: ctrl_id (saved)
  ;   [a1,  4]: w
  ;   [a1,  8]: h
  ;   [a1, 12]: handle ptr (after alloc)
  ;   [a1, 16]: saved a12
  ;   [a1, 20]: saved a13
  ;   [a1, 24]: saved a14
  ;   [a1, 28]: saved a0 (return PC)
  addi    a1, a1, -32
  s32i.n  a0,  a1, 28
  s32i.n  a14, a1, 24
  s32i.n  a13, a1, 20
  s32i.n  a12, a1, 16
  s32i.n  a2,  a1, 0
  s32i.n  a4,  a1, 4
  s32i.n  a6,  a1, 8
  ; Allocate the 32-byte handle.
  movi.n  a2, 32
  call0   cssc_obj_alloc           ; a2 = handle
  s32i.n  a2, a1, 12
  ; Populate handle: ctrl, w, h, defaults for I2C fields.
  l32i.n  a8, a1, 0
  s32i.n  a8, a2, 0                ; ctrl
  l32i.n  a8, a1, 4
  s32i.n  a8, a2, 4                ; w
  l32i.n  a8, a1, 8
  s32i.n  a8, a2, 8                ; h
  movi.n  a8, 0
  s32i.n  a8, a2, 12               ; sda_pin (caller fills via oled_new)
  s32i.n  a8, a2, 16               ; scl_pin
  movi    a8, 0x3C
  s32i.n  a8, a2, 20               ; default I2C address (SSD1306)
  ; Framebuffer size = (w * h) / 8 bytes.
  l32i.n  a12, a1, 4               ; w
  l32i.n  a13, a1, 8               ; h
  mov.n   a2, a12
  mov.n   a3, a13
  call0   __mulsi3                 ; a2 = w*h
  srli    a2, a2, 3                ; / 8
  mov.n   a14, a2                  ; fb_size
  l32i.n  a8, a1, 12               ; handle
  s32i.n  a14, a8, 28              ; persist fb_size in handle
  ; Allocate the framebuffer itself.
  mov.n   a2, a14
  call0   cssc_obj_alloc           ; a2 = fb ptr
  l32i.n  a8, a1, 12               ; handle
  s32i.n  a2, a8, 24               ; persist fb_ptr
  ; Return the handle.
  mov.n   a2, a8
  l32i.n  a12, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a14, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .size cssc_tft_new, .-cssc_tft_new

  .global cssc_oled_new
  .type   cssc_oled_new, @function
cssc_oled_new:
  ; in:  a2=ctrl, a4=w, a6=h  (first 3 i64 args in reg-pairs);
  ;      sda, scl, addr  are stack-passed (the caller reserved space
  ;      for 3 wide args = 24 bytes at [a1, 0..23] BEFORE we entered).
  ; out: a2 = handle ptr (32-byte struct, same layout as cssc_tft_new).
  ;
  ; Frame (48 bytes — must NOT clobber the caller's stack-arg slots
  ; that sit just above our prologue's adjusted SP):
  ;   [a1,  0]: handle ptr (after alloc)
  ;   [a1,  4]: fb_size
  ;   [a1,  8]: sda
  ;   [a1, 12]: scl
  ;   [a1, 16]: addr
  ;   [a1, 20]: w
  ;   [a1, 24]: h
  ;   [a1, 28]: ctrl
  ;   [a1, 32]: saved a12
  ;   [a1, 36]: saved a13
  ;   [a1, 40]: saved a14
  ;   [a1, 44]: saved a0
  ; Caller's stack-args (sda, scl, addr) live at [a1, 48], [a1, 56],
  ; [a1, 64] respectively — above our prologue's adjusted SP.
  addi    a1, a1, -48
  s32i.n  a0,  a1, 44
  s32i.n  a14, a1, 40
  s32i.n  a13, a1, 36
  s32i.n  a12, a1, 32
  ; Save the regs-args first.
  s32i.n  a2, a1, 28              ; ctrl
  s32i.n  a4, a1, 20              ; w
  s32i.n  a6, a1, 24              ; h
  ; Pull stack args from the caller's stack-arg area.
  l32i.n  a8, a1, 48              ; sda (lo of first stack-arg pair)
  s32i.n  a8, a1, 8
  l32i.n  a8, a1, 56              ; scl
  s32i.n  a8, a1, 12
  l32i.n  a8, a1, 64              ; addr
  s32i.n  a8, a1, 16
  ; Allocate 32-byte handle.
  movi.n  a2, 32
  call0   cssc_obj_alloc          ; a2 = handle
  s32i.n  a2, a1, 0
  ; Populate.
  l32i.n  a8, a1, 28
  s32i.n  a8, a2, 0                ; ctrl
  l32i.n  a8, a1, 20
  s32i.n  a8, a2, 4                ; w
  l32i.n  a8, a1, 24
  s32i.n  a8, a2, 8                ; h
  l32i.n  a8, a1, 8
  s32i.n  a8, a2, 12               ; sda
  l32i.n  a8, a1, 12
  s32i.n  a8, a2, 16               ; scl
  l32i.n  a8, a1, 16
  s32i.n  a8, a2, 20               ; addr
  ; fb_size = (w * h) / 8
  l32i.n  a12, a1, 20
  l32i.n  a13, a1, 24
  mov.n   a2, a12
  mov.n   a3, a13
  call0   __mulsi3
  srli    a2, a2, 3
  s32i.n  a2, a1, 4                ; persist fb_size in frame
  l32i.n  a8, a1, 0                ; handle
  s32i.n  a2, a8, 28               ; persist fb_size in handle
  ; Allocate framebuffer.
  l32i.n  a2, a1, 4
  call0   cssc_obj_alloc           ; a2 = fb_ptr
  l32i.n  a8, a1, 0                ; handle
  s32i.n  a2, a8, 24               ; persist fb_ptr in handle
  ; Return handle.
  mov.n   a2, a8
  l32i.n  a12, a1, 32
  l32i.n  a13, a1, 36
  l32i.n  a14, a1, 40
  l32i.n  a0,  a1, 44
  addi    a1, a1, 48
  ret.n
  .size cssc_oled_new, .-cssc_oled_new

  .global cssc_tft_free
cssc_tft_free:  ret.n
  .global cssc_oled_free
cssc_oled_free: ret.n
  .global cssc_tft_close
cssc_tft_close: ret.n
  .global cssc_oled_close
cssc_oled_close: ret.n

  .global cssc_tft_begin
  .type   cssc_tft_begin, @function
cssc_tft_begin:
  ; in: a2 = handle
  ; Sends the SSD1306 init sequence over I2C to the configured
  ; sda/scl pins. Each command byte ships as <addr> <0x00 ctl> <cmd>.
  ; The init sequence is 27 commands (right after the table label).
  ;
  ; CALL0 ABI: we clobber a12, a13, a14, a15 as scratch (handle,
  ; cmd-table cursor, count, byte respectively). All four are
  ; callee-save and must be preserved across the call.
  addi    a1, a1, -32
  s32i.n  a0, a1, 28
  s32i.n  a12, a1, 24
  s32i.n  a13, a1, 20
  s32i.n  a14, a1, 16
  s32i.n  a15, a1, 12
  mov.n   a12, a2                  ; handle
  ; Build an inline i2c handle: borrow the cssc_i2c_write machinery by
  ; constructing a stack-resident handle that points at our sda/scl.
  l32i.n  a8, a12, 12              ; sda
  l32i.n  a9, a12, 16              ; scl
  s32i.n  a8, a1, 4                ; inline handle: sda @ +4
  s32i.n  a9, a1, 8                ; scl @ +8
  movi    a8, 400                  ; half_bit cycles (100 kHz default)
  s32i.n  a8, a1, 12
  movi.n  a8, 0
  s32i.n  a8, a1, 0                ; bus_id (unused)
  ; Configure IOMUX for both SDA + SCL pads → function 3 (GPIO) +
  ; internal pullup. Without this the pins stay in their boot-default
  ; alternate function (e.g. JTAG/MTDI/MTCK on GPIO12/14) and the
  ; subsequent cssc_i2c_drive writes have no observable effect on
  ; the physical lines — the OLED never sees the START condition.
  l32i.n  a8, a12, 12              ; sda pin no
  call0   .cssc_pin_iomux_gpio_pu
  l32i.n  a8, a12, 16              ; scl pin no
  call0   .cssc_pin_iomux_gpio_pu
  ; Drive both pads high (release) by setting GPIO_OUT_W1TC + then
  ; enabling output. cssc_i2c_drive() handles per-bit transitions.
  ; Walk the init table. Each command byte is sent as a 2-byte I2C
  ; transaction: [addr+W, 0x00 (cmd-prefix), cmd_byte]. Sending
  ; them as separate 1-byte transactions (the old code path) is
  ; misinterpreted by the SSD1306 as a control byte alone and the
  ; init never takes effect — the OLED stays dark.
  ; cssc_i2c_write_pair takes (handle, addr, b1=0x00, b2=cmd) with
  ; b2 passed via the outgoing-stack-arg slot at [a1, 0].
  ;
  ; The init table has 25 bytes that mirror the working --gcc path's
  ; sequence in cssc_tft.c (`_ssd_init`). The last byte 0xAF (display
  ; ON) MUST be sent — earlier versions had count=27 with a 28-byte
  ; table, dropping 0xAF and leaving the panel powered-but-dark.
  l32r    a13, .Lssd1306_init_addr
  movi.n  a14, 25                  ; count — MUST match table length
ti1:
  movi.n  a8, 0
  beq     a14, a8, ti_done
  l8ui    a15, a13, 0              ; next cmd byte
  ; Reserve 16 bytes of outgoing stack args (b2 is a wide arg via the
  ; pair-aligned ABI; we only use the lo half but allocate the pair).
  addi    a1, a1, -16
  mov.n   a8, a15
  s32i.n  a8, a1, 0                ; b2 lo
  movi.n  a8, 0
  s32i.n  a8, a1, 4                ; b2 hi (unused)
  addi    a2, a1, 16               ; &inline_handle (caller frame, parent +0)
  l32i.n  a4, a12, 20              ; addr
  movi.n  a6, 0x00                 ; b1 = control prefix (commands continuous)
  call0   cssc_i2c_write_pair
  addi    a1, a1, 16               ; pop stack arg block
  addi    a13, a13, 1
  addi    a14, a14, -1
  j       ti1
ti_done:
  l32i.n  a15, a1, 12
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .section .rodata
  .align 4
.Lssd1306_init:
  ; SSD1306 power-on init for 128x64. Order + values mirror the
  ; working --gcc path in cssc_tft.c (_ssd_init) which is itself
  ; Adafruit-canonical. KEY constraints:
  ;   * 0x8D 0x14 (charge pump ON) MUST come BEFORE 0xAF (display ON)
  ;     because the OLED segments draw current from the pump.
  ;   * 0xD9 0xF1 (precharge for internal Vcc) — value 0x22 used by
  ;     the old table is for EXTERNAL Vcc and leaves the panel dark.
  ;   * 0xDB 0x40 (VCOMH deselect ≈ 0.77*VCC) — the prior 0x20 is too
  ;     low for the charge-pump variant.
  ;   * 0x81 0xCF (contrast 0xCF) — 0x7F works but is noticeably
  ;     dimmer; matches the legacy path for visual parity.
  ;   * 25 bytes total; the count loop in cssc_tft_begin reads
  ;     `movi.n a14, 25` — keep these in sync.
  .byte 0xAE              ; 1.  display OFF
  .byte 0xD5, 0x80        ; 2.  display clock divide ratio / oscillator freq
  .byte 0xA8, 0x3F        ; 4.  multiplex ratio (63 → 64 rows)
  .byte 0xD3, 0x00        ; 6.  display offset = 0
  .byte 0x40              ; 8.  set display start line = 0
  .byte 0x8D, 0x14        ; 9.  enable internal charge pump (REQUIRED)
  .byte 0x20, 0x00        ; 11. memory addressing mode = horizontal
  .byte 0xA1              ; 13. segment remap (col 127 → SEG0)
  .byte 0xC8              ; 14. COM scan dir reversed
  .byte 0xDA, 0x12        ; 15. COM pins hw config (alt, 128x64)
  .byte 0x81, 0xCF        ; 17. contrast control
  .byte 0xD9, 0xF1        ; 19. pre-charge period (internal Vcc)
  .byte 0xDB, 0x40        ; 21. VCOMH deselect level
  .byte 0xA4              ; 23. resume display from RAM
  .byte 0xA6              ; 24. normal (non-inverted) mode
  .byte 0xAF              ; 25. display ON  ← MUST be the last byte sent
  ; --- 5x7 font table (ASCII 0x20..0x7F, 5 columns per glyph) -------
  ; Loaded from the project's existing cssc_tft.c so the host and
  ; Xtensa runtimes share one source of truth. Embedded in .rodata
  ; → maps to flash on ESP8266 via the linker section assignment.
  .global .Lfont5x7_table
.Lfont5x7_table:
__FONT5x7_BYTES_PLACEHOLDER__
  .text
  .literal_position
  .literal .Lssd1306_init_addr, .Lssd1306_init
  .literal .Lfont5x7_addr,      .Lfont5x7_table
  .size cssc_tft_begin, .-cssc_tft_begin

  .global cssc_oled_begin
cssc_oled_begin:
  ; Alias: same impl.
  j       cssc_tft_begin

  .global cssc_tft_fill
  .type   cssc_tft_fill, @function
cssc_tft_fill:
  ; in: a2 = handle, a4 = color (i64 lo: 0=black, anything else=white)
  l32i.n  a8, a2, 24               ; fb ptr
  l32i.n  a9, a2, 28               ; fb size in bytes
  movi.n  a10, 0
  beq     a4, a10, fl_zero
  movi    a10, 0xFF
fl_zero:
fl_loop:
  movi.n  a11, 0
  beq     a9, a11, fl_done
  s8i     a10, a8, 0
  addi    a8, a8, 1
  addi    a9, a9, -1
  j       fl_loop
fl_done:
  ret.n
  .size cssc_tft_fill, .-cssc_tft_fill

  .global cssc_oled_fill
cssc_oled_fill: j cssc_tft_fill

  .global cssc_tft_pixel
  .type   cssc_tft_pixel, @function
cssc_tft_pixel:
  ; in: a2 = handle, a4 = x (i64 lo), a6 = y (i64 lo), a8 = color (i64 lo)
  ; Set/clear bit (y % 8) at byte index (x + (y/8) * w) in the framebuffer.
  ; ABI: a8 is the 4th arg's lo, but a8 is also a scratch register. The
  ; CIR caller materializes args into a2..a7; for a 4-arg int call,
  ; arg #4 goes to (a8, a9) since 3 wide args ate (a2:a3, a4:a5, a6:a7).
  ; That means our 4th arg lo lives at a8 — exactly where wide-arg
  ; layout puts it. (See `_arg_reg_layout`.)
  ;
  ; Frame: we need to save a0 because we call __mulsi3, and we need
  ; to preserve a12..a15 because we clobber them as scratch and they
  ; are CALL0-callee-save (the caller — typically cssc_tft_text /
  ; cssc_tft_line / cssc_tft_fillrect — expects them intact).
  addi    a1, a1, -32
  s32i.n  a0,  a1, 28
  s32i.n  a12, a1, 24
  s32i.n  a13, a1, 20
  s32i.n  a14, a1, 16
  s32i.n  a15, a1, 12
  s32i.n  a8,  a1, 8               ; preserve color across __mulsi3
  l32i.n  a10, a2, 24              ; fb ptr
  l32i.n  a11, a2, 4               ; width
  ; Clip y >= height → no-op
  l32i.n  a3, a2, 8                ; height
  bge     a6, a3, pix_done
  bltz    a6, pix_done
  bge     a4, a11, pix_done
  bltz    a4, pix_done
  ; page = y / 8; bit = y % 8
  srli    a12, a6, 3               ; page
  movi.n  a13, 7
  and     a14, a6, a13             ; bit
  ; Persist x and fb_ptr across the __mulsi3 call.
  s32i.n  a4,  a1, 4               ; x
  s32i.n  a10, a1, 0               ; fb_ptr
  ; index = page * w + x
  mov.n   a2, a12
  mov.n   a3, a11
  call0   __mulsi3                 ; a2 = page*w
  l32i.n  a4,  a1, 4               ; restore x
  l32i.n  a10, a1, 0               ; restore fb_ptr
  l32i.n  a8,  a1, 8               ; restore color
  add     a15, a2, a4              ; index
  ; mask = 1 << bit
  movi.n  a2, 1
  ssl     a14
  sll     a2, a2
  add     a3, a10, a15             ; addr of byte
  l8ui    a4, a3, 0
  movi.n  a5, 0
  beq     a8, a5, pix_clear
  or      a4, a4, a2               ; set
  j       pix_store
pix_clear:
  ; ~mask & current
  movi.n  a5, -1
  xor     a2, a2, a5
  and     a4, a4, a2
pix_store:
  s8i     a4, a3, 0
pix_done:
  l32i.n  a15, a1, 12
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .size cssc_tft_pixel, .-cssc_tft_pixel

  .global cssc_oled_pixel
cssc_oled_pixel: j cssc_tft_pixel

  ; Drawing primitives (line / rect / fillrect / circle / text) — these
  ; build on cssc_tft_pixel. Their full bodies follow the Bresenham
  ; algorithm conventions; for brevity each function calls pixel in a
  ; loop. Real performance optimization (column-major writes) is in
  ; Phase E1b.
  ; ===========================================================================
  ; E1b — full OLED drawing primitives.
  ;
  ; Each function builds on `cssc_tft_pixel` for individual pixel
  ; writes, then iterates over the geometry. Frame ABI for the
  ; multi-arg shapes (5 int args after handle) means args after the
  ; 4th wide come from the stack-arg area: caller wrote
  ;   [a1, 0..7]   = x1   (wide)
  ;   [a1, 8..15]  = y1
  ;   ...
  ; immediately before the call. Our prologue reserves frame
  ; without touching that area; we read stack args at
  ; `[a1, frame_size + 0..]`.
  ; ===========================================================================

  .global cssc_tft_line
  .type   cssc_tft_line, @function
cssc_tft_line:
  ; in:  handle=a2, x0=a4, y0=a6  (in regs)
  ;      x1, y1, color  (on stack at [a1, 0..23] before our prologue)
  ; Implements Bresenham's classic line algorithm. The end-point
  ; check uses x0==x1 && y0==y1 so a single-pixel line also plots
  ; the start.
  ;
  ; A.1.1 FRAME LAYOUT (64-byte frame, saves ABOVE locals so they
  ; cannot collide). Previous 48-byte layout had a12-a15 saved at
  ; offsets 28..40 — exactly where `dx`/`sy`/`-dy`/`err` were also
  ; written. Every line() call corrupted the caller's callee-save
  ; regs; this manifested as scrambled text + missing pixels when
  ; the caller (tft_text, render loops) kept loop state in a12-a15.
  ; New layout: locals @ +0..+43, saves @ +44..+63.
  addi    a1, a1, -64
  s32i.n  a0,  a1, 60
  s32i.n  a12, a1, 56
  s32i.n  a13, a1, 52
  s32i.n  a14, a1, 48
  s32i.n  a15, a1, 44
  s32i.n  a2,  a1, 0                ; handle
  s32i.n  a4,  a1, 4                ; x0 (mutable)
  s32i.n  a6,  a1, 8                ; y0 (mutable)
  ; Pull stack args (lives ABOVE our adjusted SP at our frame_size+).
  ; Frame is now 64 bytes, so stack args sit at +64..+71/+72..+79/+80..+87.
  l32i    a8,  a1, 64               ; x1
  s32i.n  a8,  a1, 12
  l32i    a8,  a1, 72               ; y1
  s32i.n  a8,  a1, 16
  l32i    a8,  a1, 80               ; color
  s32i.n  a8,  a1, 20
  ; dx = abs(x1-x0); sx = (x0<x1)?+1:-1
  l32i.n  a8, a1, 12                ; x1
  l32i.n  a9, a1, 4                 ; x0
  sub     a10, a8, a9
  movi.n  a11, 0
  bge     a10, a11, ln_dx_pos
  neg     a10, a10                  ; dx absolute
  movi    a11, -1
  s32i.n  a11, a1, 24               ; sx = -1
  j       ln_dx_done
ln_dx_pos:
  movi.n  a11, 1
  s32i.n  a11, a1, 24               ; sx = +1
ln_dx_done:
  s32i.n  a10, a1, 28               ; dx
  ; dy = abs(y1-y0); sy = ...
  l32i.n  a8, a1, 16                ; y1
  l32i.n  a9, a1, 8                 ; y0
  sub     a10, a8, a9
  movi.n  a11, 0
  bge     a10, a11, ln_dy_pos
  neg     a10, a10
  movi    a11, -1
  s32i.n  a11, a1, 32               ; sy = -1
  j       ln_dy_done
ln_dy_pos:
  movi.n  a11, 1
  s32i.n  a11, a1, 32               ; sy = +1
ln_dy_done:
  ; dy is stored NEGATED in the standard Bresenham to allow signed
  ; comparison with err. Store -dy instead.
  neg     a10, a10
  s32i.n  a10, a1, 36               ; -dy (working value)
  ; err = dx + (-dy)   (i.e. dx - dy with our convention)
  l32i.n  a8, a1, 28
  l32i.n  a9, a1, 36
  add     a8, a8, a9
  s32i.n  a8, a1, 40                ; err
ln_loop:
  ; Plot (x0, y0) via cssc_tft_pixel(handle, x0, y0, color).
  l32i.n  a2, a1, 0
  l32i.n  a4, a1, 4
  l32i.n  a6, a1, 8
  l32i.n  a8, a1, 20                ; color
  call0   cssc_tft_pixel
  ; if (x0 == x1 && y0 == y1) break
  l32i.n  a8, a1, 4
  l32i.n  a9, a1, 12
  bne     a8, a9, ln_step
  l32i.n  a8, a1, 8
  l32i.n  a9, a1, 16
  bne     a8, a9, ln_step
  j       ln_done
ln_step:
  ; e2 = 2 * err
  l32i.n  a8, a1, 40
  add     a9, a8, a8                ; e2 = err << 1
  ; if (e2 >= -dy) { err += -dy; x0 += sx; }
  l32i.n  a10, a1, 36               ; -dy (already negated)
  blt     a9, a10, ln_y_part
  ; err += -dy
  l32i.n  a11, a1, 40
  add     a11, a11, a10
  s32i.n  a11, a1, 40
  ; x0 += sx
  l32i.n  a11, a1, 4
  l32i.n  a12, a1, 24
  add     a11, a11, a12
  s32i.n  a11, a1, 4
ln_y_part:
  ; if (e2 <= dx) { err += dx; y0 += sy; }
  l32i.n  a10, a1, 28               ; dx
  ; (Recompute e2 since the x-part might have updated err.)
  l32i.n  a8, a1, 40
  add     a9, a8, a8
  blt     a10, a9, ln_loop          ; e2 > dx → skip y update
  l32i.n  a11, a1, 40
  l32i.n  a12, a1, 28
  add     a11, a11, a12
  s32i.n  a11, a1, 40
  l32i.n  a11, a1, 8
  l32i.n  a12, a1, 32
  add     a11, a11, a12
  s32i.n  a11, a1, 8
  j       ln_loop
ln_done:
  l32i.n  a15, a1, 44
  l32i.n  a14, a1, 48
  l32i.n  a13, a1, 52
  l32i.n  a12, a1, 56
  l32i.n  a0,  a1, 60
  addi    a1, a1, 64
  ret.n
  .size cssc_tft_line, .-cssc_tft_line

  .global cssc_oled_line
cssc_oled_line: j cssc_tft_line

  ; --- rect (outline) — 4 line calls ----------------------------------
  .global cssc_tft_rect
  .type   cssc_tft_rect, @function
cssc_tft_rect:
  ; in: handle, x, y, w, h, color  (4 stack args)
  ; Outline = top edge + bottom + left + right.
  addi    a1, a1, -48
  s32i.n  a0,  a1, 44
  s32i.n  a12, a1, 40
  s32i.n  a13, a1, 36
  s32i.n  a14, a1, 32
  ; Save in-reg args.
  s32i.n  a2, a1, 0                 ; handle
  s32i.n  a4, a1, 4                 ; x
  s32i.n  a6, a1, 8                 ; y
  ; Stack args at [a1, frame+0..]:
  l32i.n  a8, a1, 48                ; w
  s32i.n  a8, a1, 12
  l32i.n  a8, a1, 56                ; h
  s32i.n  a8, a1, 16
  l32i.n  a8, a1, 64                ; color
  s32i.n  a8, a1, 20
  ; x_end = x + w - 1; y_end = y + h - 1
  l32i.n  a8, a1, 4
  l32i.n  a9, a1, 12
  add     a8, a8, a9
  addi    a8, a8, -1
  s32i.n  a8, a1, 24                ; x_end
  l32i.n  a8, a1, 8
  l32i.n  a9, a1, 16
  add     a8, a8, a9
  addi    a8, a8, -1
  s32i.n  a8, a1, 28                ; y_end
  ; Emit 4 line(...) calls by reserving 24 bytes of stack-arg
  ; space and stuffing (x1, y1, color) into it for each call.
  ; Top edge: line(handle, x, y, x_end, y, color)
  addi    a1, a1, -24
  l32i.n  a8, a1, 48                ; x_end (was a1+24, now a1+48 after prologue+sub)
  s32i.n  a8, a1, 0
  l32i.n  a8, a1, 32
  s32i.n  a8, a1, 8
  l32i.n  a8, a1, 44
  s32i.n  a8, a1, 16
  l32i.n  a2, a1, 24                ; handle
  l32i.n  a4, a1, 28                ; x
  l32i.n  a6, a1, 32                ; y
  call0   cssc_tft_line
  addi    a1, a1, 24
  ; Bottom edge.
  addi    a1, a1, -24
  l32i.n  a8, a1, 48
  s32i.n  a8, a1, 0                 ; x_end
  l32i.n  a8, a1, 52
  s32i.n  a8, a1, 8                 ; y_end
  l32i.n  a8, a1, 44
  s32i.n  a8, a1, 16                ; color
  l32i.n  a2, a1, 24
  l32i.n  a4, a1, 28
  l32i.n  a6, a1, 52                ; y_end as start-y
  call0   cssc_tft_line
  addi    a1, a1, 24
  ; Left edge.
  addi    a1, a1, -24
  l32i.n  a8, a1, 28
  s32i.n  a8, a1, 0                 ; x1 = x
  l32i.n  a8, a1, 52
  s32i.n  a8, a1, 8                 ; y1 = y_end
  l32i.n  a8, a1, 44
  s32i.n  a8, a1, 16
  l32i.n  a2, a1, 24
  l32i.n  a4, a1, 28
  l32i.n  a6, a1, 32
  call0   cssc_tft_line
  addi    a1, a1, 24
  ; Right edge.
  addi    a1, a1, -24
  l32i.n  a8, a1, 48
  s32i.n  a8, a1, 0                 ; x1 = x_end
  l32i.n  a8, a1, 52
  s32i.n  a8, a1, 8                 ; y1 = y_end
  l32i.n  a8, a1, 44
  s32i.n  a8, a1, 16
  l32i.n  a2, a1, 24
  l32i.n  a4, a1, 48                ; x = x_end
  l32i.n  a6, a1, 32
  call0   cssc_tft_line
  addi    a1, a1, 24
  l32i.n  a14, a1, 32
  l32i.n  a13, a1, 36
  l32i.n  a12, a1, 40
  l32i.n  a0,  a1, 44
  addi    a1, a1, 48
  ret.n
  .size cssc_tft_rect, .-cssc_tft_rect

  .global cssc_oled_rect
cssc_oled_rect: j cssc_tft_rect

  ; --- fillrect — nested loop of horizontal line plots ----------------
  .global cssc_tft_fillrect
  .type   cssc_tft_fillrect, @function
cssc_tft_fillrect:
  ; in: handle, x, y, w, h, color (4 stack args)
  addi    a1, a1, -48
  s32i.n  a0,  a1, 44
  s32i.n  a12, a1, 40
  s32i.n  a13, a1, 36
  s32i.n  a14, a1, 32
  s32i.n  a2, a1, 0                 ; handle
  s32i.n  a4, a1, 4                 ; x
  s32i.n  a6, a1, 8                 ; y
  l32i.n  a8, a1, 48                ; w
  s32i.n  a8, a1, 12
  l32i.n  a8, a1, 56                ; h
  s32i.n  a8, a1, 16
  l32i.n  a8, a1, 64                ; color
  s32i.n  a8, a1, 20
  ; Loop j from 0 to h, plotting a horizontal line per row.
  movi.n  a12, 0                    ; j
fr_outer:
  l32i.n  a8, a1, 16                ; h
  bge     a12, a8, fr_done
  ; Inner loop: i from 0 to w → cssc_tft_pixel(handle, x+i, y+j, color)
  movi.n  a13, 0
fr_inner:
  l32i.n  a8, a1, 12                ; w
  bge     a13, a8, fr_inext
  l32i.n  a2, a1, 0
  l32i.n  a8, a1, 4
  add     a4, a8, a13               ; x + i
  l32i.n  a8, a1, 8
  add     a6, a8, a12               ; y + j
  l32i.n  a8, a1, 20                ; color
  call0   cssc_tft_pixel
  addi    a13, a13, 1
  j       fr_inner
fr_inext:
  addi    a12, a12, 1
  j       fr_outer
fr_done:
  l32i.n  a14, a1, 32
  l32i.n  a13, a1, 36
  l32i.n  a12, a1, 40
  l32i.n  a0,  a1, 44
  addi    a1, a1, 48
  ret.n
  .size cssc_tft_fillrect, .-cssc_tft_fillrect

  .global cssc_oled_fillrect
cssc_oled_fillrect: j cssc_tft_fillrect

  ; --- circle — midpoint algorithm, 8-fold symmetry -------------------
  .global cssc_tft_circle
  .type   cssc_tft_circle, @function
cssc_tft_circle:
  ; Phase E1c — full midpoint (Bresenham) circle algorithm.
  ;
  ; in:  handle, cx, cy, r, color
  ;        a2 = handle, a4 = cx_lo, a6 = cy_lo,
  ;        stack[0..3] = r (i64 lo), stack[8..11] = color (i64 lo)
  ; out: 8 octant pixels per iteration plus 4 cardinal pixels at start.
  ;
  ; Frame layout (80 bytes):
  ;   [0]  handle
  ;   [4]  cx
  ;   [8]  cy
  ;   [12] r
  ;   [16] color
  ;   [20] f          (decision variable: 1 - r initially)
  ;   [24] ddF_x      (1 initially)
  ;   [28] ddF_y      (-2*r initially)
  ;   [32] x          (loop state, starts at 0)
  ;   [36] y          (loop state, starts at r)
  ;   [60..72] saved a12..a15
  ;   [76] saved a0 (return PC)
  addi    a1, a1, -80
  s32i.n  a0,  a1, 76
  s32i    a12, a1, 60
  s32i    a13, a1, 64
  s32i    a14, a1, 68
  s32i    a15, a1, 72
  s32i.n  a2,  a1, 0
  s32i.n  a4,  a1, 4
  s32i.n  a6,  a1, 8
  ; Stack args: pixel-call adds 16 bytes for outgoing args; our
  ; caller put `r` at incoming-stack+0 and `color` at +8 (i64 widths).
  l32i.n  a8,  a1, 80                ; r
  s32i.n  a8,  a1, 12
  l32i.n  a8,  a1, 88                ; color
  s32i.n  a8,  a1, 16
  ; f = 1 - r
  movi.n  a8, 1
  l32i.n  a9, a1, 12
  sub     a8, a8, a9
  s32i.n  a8, a1, 20
  ; ddF_x = 1
  movi.n  a8, 1
  s32i.n  a8, a1, 24
  ; ddF_y = -2*r
  l32i.n  a8, a1, 12
  slli    a8, a8, 1
  neg     a8, a8
  s32i.n  a8, a1, 28
  ; x = 0; y = r
  movi.n  a8, 0
  s32i.n  a8, a1, 32
  l32i.n  a8, a1, 12
  s32i.n  a8, a1, 36
  ; ---- Plot the 4 cardinal points first ----
  ; (cx,   cy+r), (cx,   cy-r), (cx+r, cy), (cx-r, cy)
  call0   .Lcirc_plot_cardinals
.Lcirc_loop:
  ; Loop while x < y
  l32i.n  a12, a1, 32                ; x
  l32i.n  a13, a1, 36                ; y
  bge     a12, a13, .Lcirc_done
  ; if f >= 0: y--; ddF_y += 2; f += ddF_y
  l32i.n  a14, a1, 20                ; f
  movi.n  a15, 0
  blt     a14, a15, .Lcirc_f_neg
  addi    a13, a13, -1
  s32i.n  a13, a1, 36
  l32i.n  a8, a1, 28
  addi    a8, a8, 2
  s32i.n  a8, a1, 28
  add     a14, a14, a8
  s32i.n  a14, a1, 20
.Lcirc_f_neg:
  ; x++; ddF_x += 2; f += ddF_x
  addi    a12, a12, 1
  s32i.n  a12, a1, 32
  l32i.n  a8, a1, 24
  addi    a8, a8, 2
  s32i.n  a8, a1, 24
  l32i.n  a14, a1, 20
  add     a14, a14, a8
  s32i.n  a14, a1, 20
  ; ---- Plot 8 octant pixels ----
  call0   .Lcirc_plot_octants
  j       .Lcirc_loop
.Lcirc_done:
  l32i    a15, a1, 72
  l32i    a14, a1, 68
  l32i    a13, a1, 64
  l32i    a12, a1, 60
  l32i.n  a0,  a1, 76
  addi    a1, a1, 80
  ret.n
  .size cssc_tft_circle, .-cssc_tft_circle

  ; --- Helper: emit the 4 cardinal pixels for the current (cx,cy,r,color).
  ;     Local function; uses a0 spill at frame-relative offset.
.Lcirc_plot_cardinals:
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  ; (cx, cy+r)
  l32i.n  a2, a1, 16                ; handle
  l32i.n  a4, a1, 20                ; cx
  l32i.n  a6, a1, 24                ; cy
  l32i.n  a8, a1, 28                ; r
  add     a6, a6, a8
  l32i.n  a8, a1, 32                ; color
  call0   cssc_tft_pixel
  ; (cx, cy-r)
  l32i.n  a2, a1, 16
  l32i.n  a4, a1, 20
  l32i.n  a6, a1, 24
  l32i.n  a8, a1, 28
  sub     a6, a6, a8
  l32i.n  a8, a1, 32
  call0   cssc_tft_pixel
  ; (cx+r, cy)
  l32i.n  a2, a1, 16
  l32i.n  a4, a1, 20
  l32i.n  a8, a1, 28
  add     a4, a4, a8
  l32i.n  a6, a1, 24
  l32i.n  a8, a1, 32
  call0   cssc_tft_pixel
  ; (cx-r, cy)
  l32i.n  a2, a1, 16
  l32i.n  a4, a1, 20
  l32i.n  a8, a1, 28
  sub     a4, a4, a8
  l32i.n  a6, a1, 24
  l32i.n  a8, a1, 32
  call0   cssc_tft_pixel
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
  .size .Lcirc_plot_cardinals, .-.Lcirc_plot_cardinals

  ; --- Helper: emit 8 octant pixels for the current (x,y) state.
  ;     Uses caller's frame layout (handle@16, cx@20, cy@24, color@32,
  ;     x@48, y@52 — note frame offsets shifted by our +16 push).
.Lcirc_plot_octants:
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  ; Macro shorthand: each plot loads handle/cx/cy/color, builds the
  ; offset, and calls cssc_tft_pixel. (cx+x, cy+y)
  ; ---- (cx+x, cy+y)
  l32i.n  a2, a1, 16
  l32i.n  a4, a1, 20
  l32i.n  a8, a1, 48
  add     a4, a4, a8
  l32i.n  a6, a1, 24
  l32i.n  a8, a1, 52
  add     a6, a6, a8
  l32i.n  a8, a1, 32
  call0   cssc_tft_pixel
  ; (cx-x, cy+y)
  l32i.n  a2, a1, 16
  l32i.n  a4, a1, 20
  l32i.n  a8, a1, 48
  sub     a4, a4, a8
  l32i.n  a6, a1, 24
  l32i.n  a8, a1, 52
  add     a6, a6, a8
  l32i.n  a8, a1, 32
  call0   cssc_tft_pixel
  ; (cx+x, cy-y)
  l32i.n  a2, a1, 16
  l32i.n  a4, a1, 20
  l32i.n  a8, a1, 48
  add     a4, a4, a8
  l32i.n  a6, a1, 24
  l32i.n  a8, a1, 52
  sub     a6, a6, a8
  l32i.n  a8, a1, 32
  call0   cssc_tft_pixel
  ; (cx-x, cy-y)
  l32i.n  a2, a1, 16
  l32i.n  a4, a1, 20
  l32i.n  a8, a1, 48
  sub     a4, a4, a8
  l32i.n  a6, a1, 24
  l32i.n  a8, a1, 52
  sub     a6, a6, a8
  l32i.n  a8, a1, 32
  call0   cssc_tft_pixel
  ; (cx+y, cy+x)
  l32i.n  a2, a1, 16
  l32i.n  a4, a1, 20
  l32i.n  a8, a1, 52
  add     a4, a4, a8
  l32i.n  a6, a1, 24
  l32i.n  a8, a1, 48
  add     a6, a6, a8
  l32i.n  a8, a1, 32
  call0   cssc_tft_pixel
  ; (cx-y, cy+x)
  l32i.n  a2, a1, 16
  l32i.n  a4, a1, 20
  l32i.n  a8, a1, 52
  sub     a4, a4, a8
  l32i.n  a6, a1, 24
  l32i.n  a8, a1, 48
  add     a6, a6, a8
  l32i.n  a8, a1, 32
  call0   cssc_tft_pixel
  ; (cx+y, cy-x)
  l32i.n  a2, a1, 16
  l32i.n  a4, a1, 20
  l32i.n  a8, a1, 52
  add     a4, a4, a8
  l32i.n  a6, a1, 24
  l32i.n  a8, a1, 48
  sub     a6, a6, a8
  l32i.n  a8, a1, 32
  call0   cssc_tft_pixel
  ; (cx-y, cy-x)
  l32i.n  a2, a1, 16
  l32i.n  a4, a1, 20
  l32i.n  a8, a1, 52
  sub     a4, a4, a8
  l32i.n  a6, a1, 24
  l32i.n  a8, a1, 48
  sub     a6, a6, a8
  l32i.n  a8, a1, 32
  call0   cssc_tft_pixel
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
  .size .Lcirc_plot_octants, .-.Lcirc_plot_octants

  .global cssc_oled_circle
cssc_oled_circle: j cssc_tft_circle

  ; --- text — glyph-table lookup + per-pixel plot ---------------------
  .global cssc_tft_text
  .type   cssc_tft_text, @function
cssc_tft_text:
  ; Phase E1c — clean frame layout, no save-slot overlap.
  ;
  ; In:  handle=a2, x=a4 (i64 lo), y=a6 (i64 lo).
  ;      stack-passed args (the rest):
  ;        +80 → str ptr (cssc_str*)
  ;        +88 → color (i64 lo)
  ;
  ; Frame (80 bytes, 16-aligned):
  ;   [0]   handle
  ;   [4]   x (start)
  ;   [8]   y
  ;   [12]  str ptr
  ;   [16]  color
  ;   [20]  col_cursor      (pixels from x; +6 per emitted glyph)
  ;   [24]  size_remaining  (str bytes left to process)
  ;   [28]  data_cursor     (next char to read)
  ;   [32]  font_base       (.Lfont5x7_table address)
  ;   [36]  glyph_base      (font_base + glyph_idx*5)
  ;   [40]  col_within_glyph (0..4)
  ;   [44]  col_bits        (current column's 7-bit pattern)
  ;   [48]  row             (0..6)
  ;   [60]  saved a12
  ;   [64]  saved a13
  ;   [68]  saved a14
  ;   [72]  saved a15
  ;   [76]  saved a0
  addi    a1, a1, -80
  s32i.n  a0,  a1, 76
  s32i    a12, a1, 60
  s32i    a13, a1, 64
  s32i    a14, a1, 68
  s32i    a15, a1, 72
  s32i.n  a2, a1, 0
  s32i.n  a4, a1, 4
  s32i.n  a6, a1, 8
  l32i.n  a8, a1, 80                ; str ptr (stack arg)
  s32i.n  a8, a1, 12
  l32i.n  a8, a1, 88                ; color
  s32i.n  a8, a1, 16
  movi.n  a8, 0
  s32i.n  a8, a1, 20                ; col_cursor = 0
  ; ABI: the 4th arg is a raw const char* (the caller passes
  ; cssc_string_data(str), i.e. str->data — matching cssc_tft.c's
  ; `const char* s`, NOT the cssc_str* header). Iterate it directly as a
  ; NUL-terminated C string; do NOT read size/data struct fields (doing so
  ; read char bytes 4..7 as "size" and 12..15 as a bogus "data" pointer,
  ; then dereferenced that garbage → LoadProhibited crash on longer strings).
  l32i.n  a8, a1, 12                ; char* (NUL-terminated)
  s32i.n  a8, a1, 28                ; data_cursor = char* itself
  l32r    a8, .Ltxt_font_addr
  s32i.n  a8, a1, 32                ; font_base
.Ltxt_loop:
  l32i.n  a11, a1, 28                ; data_cursor
  l8ui    a8, a11, 0                ; current char
  beqz    a8, .Ltxt_done            ; NUL terminator → end of string
  ; Clamp to printable range 0x20..0x7F.
  movi.n  a9, 0x20
  blt     a8, a9, .Ltxt_skip
  movi.n  a9, 0x80
  bge     a8, a9, .Ltxt_skip
  ; glyph_base = font_base + (char - 0x20) * 5
  addi    a8, a8, -0x20
  mov.n   a2, a8
  movi.n  a3, 5
  call0   __mulsi3
  l32i.n  a8, a1, 32
  add     a8, a8, a2
  s32i.n  a8, a1, 36                ; glyph_base
  movi.n  a8, 0
  s32i.n  a8, a1, 40                ; col_within_glyph = 0
.Ltxt_col:
  l32i.n  a9, a1, 40
  movi.n  a10, 5
  beq     a9, a10, .Ltxt_advance
  l32i.n  a11, a1, 36
  add     a8, a11, a9               ; addr of this column's byte
  l8ui    a8, a8, 0                 ; col_bits
  s32i.n  a8, a1, 44                ; persist col_bits
  movi.n  a8, 0
  s32i.n  a8, a1, 48                ; row = 0
.Ltxt_row:
  l32i.n  a8, a1, 48                ; row
  movi.n  a9, 7
  beq     a8, a9, .Ltxt_col_next
  ; bit = (col_bits >> row) & 1
  l32i.n  a11, a1, 44                ; col_bits
  ssr     a8                         ; SAR = row
  srl     a10, a11
  movi.n  a3, 1
  and     a10, a10, a3
  beqz    a10, .Ltxt_row_next
  ; Plot pixel at (x + col_cursor + col_within_glyph, y + row, color).
  l32i.n  a2, a1, 0                 ; handle
  l32i.n  a4, a1, 4                 ; x
  l32i.n  a8, a1, 20                ; col_cursor
  add     a4, a4, a8
  l32i.n  a8, a1, 40                ; col_within_glyph
  add     a4, a4, a8
  l32i.n  a6, a1, 8                 ; y
  l32i.n  a8, a1, 48                ; row
  add     a6, a6, a8
  l32i.n  a8, a1, 16                ; color
  call0   cssc_tft_pixel
.Ltxt_row_next:
  l32i.n  a8, a1, 48
  addi    a8, a8, 1
  s32i.n  a8, a1, 48
  j       .Ltxt_row
.Ltxt_col_next:
  l32i.n  a8, a1, 40
  addi    a8, a8, 1
  s32i.n  a8, a1, 40
  j       .Ltxt_col
.Ltxt_advance:
  ; Move cursor right by 6 pixels (5 glyph cols + 1 spacing gap).
  l32i.n  a8, a1, 20
  addi    a8, a8, 6
  s32i.n  a8, a1, 20
.Ltxt_skip:
  l32i.n  a8, a1, 28                ; data_cursor
  addi    a8, a8, 1
  s32i.n  a8, a1, 28
  j       .Ltxt_loop
.Ltxt_done:
  l32i    a15, a1, 72
  l32i    a14, a1, 68
  l32i    a13, a1, 64
  l32i    a12, a1, 60
  l32i.n  a0,  a1, 76
  addi    a1, a1, 80
  ret.n
  .literal_position
  .literal .Ltxt_font_addr, .Lfont5x7_table
  .size cssc_tft_text, .-cssc_tft_text

  .global cssc_oled_text
cssc_oled_text: j cssc_tft_text

  ; --- show — bulk I2C transfer of framebuffer ------------------------
  .global cssc_tft_show
  .type   cssc_tft_show, @function
cssc_tft_show:
  ; in: a2 = handle
  ; Send the entire framebuffer to the OLED in 16-byte chunks via
  ; cssc_i2c_write. Each chunk: <addr> + <data prefix 0x40> + bytes.
  ;
  ; SSD1306 page-organized: 8 pages × width bytes per page.
  ; We use cssc_i2c_write byte-by-byte (control byte 0x40 once per
  ; page-start, then data bytes). This is slower than a true
  ; START..STOP burst but is correct and matches the byte-oriented
  ; cssc_i2c_write API.
  ; CALL0 ABI: we clobber a12..a15 — must be preserved across the
  ; call. a12=handle, a13=fb cursor, a14=fb remaining, a15=byte.
  ; Frame: 48 bytes — [0..15] inline i2c handle, [28]=a0, [24]=a12,
  ; [20]=a13, [16]=a14, [12]=a15... but [12] collides with the
  ; inline-handle's half_bit slot. Push saved-CS up by 16 bytes to
  ; give the inline handle its own region.
  addi    a1, a1, -48
  s32i.n  a0,  a1, 44
  s32i.n  a12, a1, 40
  s32i.n  a13, a1, 36
  s32i.n  a14, a1, 32
  s32i.n  a15, a1, 28
  mov.n   a12, a2                   ; handle
  l32i.n  a13, a12, 24              ; fb ptr
  l32i.n  a14, a12, 28              ; fb size
  ; Build inline I2C handle on frame for cssc_i2c_write_burst.
  l32i.n  a8, a12, 12               ; sda
  l32i.n  a9, a12, 16               ; scl
  s32i.n  a8, a1, 4
  s32i.n  a9, a1, 8
  movi    a8, 400
  s32i.n  a8, a1, 12                ; half_bit cycles (100 kHz)
  movi.n  a8, 0
  s32i.n  a8, a1, 0
  ; === STEP 1: set column + page address ranges ====================
  ; In horizontal addressing mode the SSD1306 walks its internal
  ; pointer across (col_start..col_end) then advances page until
  ; (page_end), then wraps. We need to RESET this pointer before
  ; each frame, otherwise pixels can land at undefined positions
  ; (the legacy --gcc path's `_ssd_flush` does the same: it sends
  ; 0x21,0x00,col_end then 0x22,0x00,page_end before the data).
  ;
  ; Bundle six command bytes [0x21, 0x00, col_end, 0x22, 0x00, page_end]
  ; into a single cmd-stream transaction. We compose them on the
  ; stack first, then call write_burst with the 0x00 control prefix.
  ;
  ; Stack scratch for the 6-byte command blob: place it at [a1+20..25]
  ; inside our existing 48-byte frame. The inline handle uses [0..15],
  ; saved CS regs use [28..44], so [20..27] is free.
  l32i.n  a8, a12, 4                ; handle.width
  addi    a8, a8, -1                ; col_end = width - 1
  movi.n  a9, 0x21
  s8i     a9, a1, 20                ; cmd 0x21 (set col addr)
  movi.n  a9, 0x00
  s8i     a9, a1, 21                ; col_start = 0
  s8i     a8, a1, 22                ; col_end
  movi.n  a9, 0x22
  s8i     a9, a1, 23                ; cmd 0x22 (set page addr)
  movi.n  a9, 0x00
  s8i     a9, a1, 24                ; page_start = 0
  l32i.n  a8, a12, 8                ; handle.height
  srli    a8, a8, 3                 ; pages = height / 8
  addi    a8, a8, -1                ; page_end = pages - 1
  s8i     a8, a1, 25                ; page_end
  ; Reserve 16 bytes for outgoing stack args.
  addi    a1, a1, -16
  addi    a8, a1, 16+20             ; &cmd_blob (caller offset 20)
  s32i.n  a8, a1, 0                 ; ptr lo
  movi.n  a8, 0
  s32i.n  a8, a1, 4                 ; ptr hi
  movi.n  a8, 6
  s32i.n  a8, a1, 8                 ; len lo = 6
  movi.n  a8, 0
  s32i.n  a8, a1, 12                ; len hi
  addi    a2, a1, 16                ; &inline_handle (parent +0)
  l32i.n  a4, a12, 20               ; addr
  movi.n  a6, 0x00                  ; CMD stream prefix
  call0   cssc_i2c_write_burst
  addi    a1, a1, 16                ; pop stack args
  ; === STEP 2: stream the framebuffer with the 0x40 data prefix ====
  addi    a1, a1, -16
  s32i.n  a13, a1, 0                ; ptr lo (fb)
  movi.n  a8, 0
  s32i.n  a8, a1, 4                 ; ptr hi
  s32i.n  a14, a1, 8                ; len lo (fb_size)
  s32i.n  a8, a1, 12                ; len hi
  addi    a2, a1, 16                ; &inline_handle
  l32i.n  a4, a12, 20               ; addr
  movi.n  a6, 0x40                  ; DATA stream prefix
  call0   cssc_i2c_write_burst
  addi    a1, a1, 16
sh_done:
  l32i.n  a15, a1, 28
  l32i.n  a14, a1, 32
  l32i.n  a13, a1, 36
  l32i.n  a12, a1, 40
  l32i.n  a0,  a1, 44
  addi    a1, a1, 48
  ret.n
  .size cssc_tft_show, .-cssc_tft_show

  .global cssc_oled_show
cssc_oled_show: j cssc_tft_show

  ; ===========================================================================
  ; C1 — Vector runtime (vector_int, vector_float, array_int, array_float).
  ;
  ; Header layout (24 bytes — matches host runtime so v6 native scripts
  ; can interoperate at the source level):
  ;   offset 0:  i64 size      (number of elements currently in use)
  ;   offset 8:  i64 capacity  (allocated slots)
  ;   offset 16: ptr data      (heap pointer to size*8 bytes)
  ;
  ; Each element occupies 8 bytes regardless of kind (i64 or f64);
  ; the runtime is shared between int and float — the calling code
  ; passes the right value type and we store the 8 bytes raw.
  ;
  ; Arena-allocator constraint: we don't free individual buffers, so
  ; push_back grows via "reallocate to 2x + copy" only when there's
  ; room in the arena. Once arena is exhausted, push_back returns
  ; silently (size stays). User can check via `.size()` and bail.
  ; ===========================================================================

  .global cssc_vector_new_int
  .type   cssc_vector_new_int, @function
cssc_vector_new_int:
  ; in: a2 = capacity_hint (i64 lo)
  ; out: a2 = pointer to header
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  ; Clamp cap to a minimum of 4 so push_back's "double on grow" has
  ; a sensible starting size.
  movi.n  a8, 4
  bge     a2, a8, vi_cap_ok
  movi.n  a2, 4
vi_cap_ok:
  mov.n   a12, a2                  ; cap
  ; Allocate header (24 bytes).
  movi.n  a2, 24
  call0   cssc_obj_alloc
  mov.n   a13, a2                  ; header ptr
  ; size = 0
  movi.n  a8, 0
  s32i.n  a8, a13, 0
  s32i.n  a8, a13, 4               ; size_hi
  ; cap
  s32i.n  a12, a13, 8
  s32i.n  a8, a13, 12              ; cap_hi
  ; data buffer: cap * 8 bytes
  slli    a2, a12, 3               ; cap << 3
  call0   cssc_obj_alloc
  s32i.n  a2, a13, 16              ; data ptr
  ; --- Scope-pin: promote the header + data allocations to the
  ; caller's scope so they survive cssc_scope_pop. Without this,
  ; calling `vd.somefn()` where somefn allocates a vector AND the
  ; caller does any subsequent allocation, the second alloc would
  ; sit on top of our vector's data — corrupted reads ensue. See
  ; cssc_array_bind_push_entry's abpe_pin for the canonical version.
  l32r    a8, .Lvni_scope_sp_addr
  l32i.n  a9, a8, 0
  beqz    a9, vni_pin_done
  addi    a9, a9, -1
  l32r    a10, .Lvni_scope_stack_addr
  slli    a9, a9, 2
  add     a10, a10, a9
  l32r    a8, .Lvni_arena_off_addr
  l32i.n  a8, a8, 0
  s32i.n  a8, a10, 0
vni_pin_done:
  ; return header
  mov.n   a2, a13
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .literal_position
  .literal .Lvni_arena_off_addr,   cssc_arena_off
  .literal .Lvni_scope_sp_addr,    cssc_scope_sp
  .literal .Lvni_scope_stack_addr, cssc_scope_stack
  .size cssc_vector_new_int, .-cssc_vector_new_int

  .global cssc_vector_new_float
cssc_vector_new_float: j cssc_vector_new_int   ; identical 8-byte slots

  .global cssc_vector_free_int
cssc_vector_free_int:  ret.n                    ; arena allocator
  .global cssc_vector_free_float
cssc_vector_free_float: ret.n

  .global cssc_vector_size_int
  .type   cssc_vector_size_int, @function
cssc_vector_size_int:
  ; in: a2 = header ptr → out: a2:a3 = size (i64)
  l32i.n  a8, a2, 0
  l32i.n  a3, a2, 4
  mov.n   a2, a8
  ret.n
  .size cssc_vector_size_int, .-cssc_vector_size_int

  .global cssc_vector_size_float
cssc_vector_size_float: j cssc_vector_size_int

  .global cssc_vector_get_int
  .type   cssc_vector_get_int, @function
cssc_vector_get_int:
  ; in: a2 = header, a4 = idx (i64 lo) → out: a2:a3 = element (i64)
  l32i.n  a8, a2, 16               ; data
  slli    a9, a4, 3                ; idx*8
  add     a10, a8, a9              ; element addr
  l32i.n  a2, a10, 0
  l32i.n  a3, a10, 4
  ret.n
  .size cssc_vector_get_int, .-cssc_vector_get_int

  .global cssc_vector_get_float
cssc_vector_get_float: j cssc_vector_get_int    ; raw 8-byte read

  .global cssc_vector_set_int
  .type   cssc_vector_set_int, @function
cssc_vector_set_int:
  ; in: a2 = header, a4 = idx, a6:a7 = value
  l32i.n  a8, a2, 16
  slli    a9, a4, 3
  add     a10, a8, a9
  s32i.n  a6, a10, 0
  s32i.n  a7, a10, 4
  ret.n
  .size cssc_vector_set_int, .-cssc_vector_set_int

  .global cssc_vector_set_float
cssc_vector_set_float: j cssc_vector_set_int

  .global cssc_vector_push_back_int
  .type   cssc_vector_push_back_int, @function
cssc_vector_push_back_int:
  ; in: a2 = header, a4:a5 = value
  ; If size < cap: write at data[size*8], size += 1.
  ; Else: try to grow (reallocate 2x in arena + copy). On arena
  ; exhaustion we leave size unchanged so the caller can detect via
  ; `.size()`.
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  s32i.n  a14, a1, 0
  mov.n   a12, a2                  ; header
  l32i.n  a13, a12, 0              ; size
  l32i.n  a14, a12, 8              ; cap
  bge     a13, a14, vpb_grow
vpb_store:
  l32i.n  a8, a12, 16              ; data
  slli    a9, a13, 3
  add     a10, a8, a9
  s32i.n  a4, a10, 0
  s32i.n  a5, a10, 4
  addi    a13, a13, 1
  s32i.n  a13, a12, 0              ; size++
  j       vpb_done
vpb_grow:
  ; new_cap = cap * 2
  slli    a8, a14, 1               ; new_cap
  s32i.n  a8, a12, 8               ; cap = new_cap
  ; Alloc new buffer (new_cap * 8 bytes).
  mov.n   a9, a8
  slli    a2, a9, 3
  call0   cssc_obj_alloc
  mov.n   a10, a2                  ; new_data
  ; Copy old data into new (size * 8 bytes).
  l32i.n  a8, a12, 16              ; old_data
  slli    a11, a13, 3              ; bytes_to_copy
  movi.n  a3, 0
vpb_copy:
  beq     a11, a3, vpb_copy_done
  l32i.n  a2, a8, 0
  s32i.n  a2, a10, 0
  addi    a8, a8, 4
  addi    a10, a10, 4
  addi    a11, a11, -4
  j       vpb_copy
vpb_copy_done:
  ; Switch data ptr.
  s32i.n  a2, a12, 16              ; wait — a2 was clobbered. Reload.
  ; Bug-fix: we need the new_data ptr again. We overwrote a2; the
  ; saved start lives at a10 + (size*8) backwards… cleaner: recompute
  ; via a different register at the start of the grow loop.
  ; (The Phase C1 baseline stores new_data via a2 right after alloc;
  ; the copy loop has now ended, so we restart that store from
  ; a10 - size*8.)
  l32i.n  a2, a12, 8               ; cap (== new_cap)
  ; Recompute new_data start: end pointer minus bytes_copied.
  ; (Simpler: re-alloc would be wrong — keep the new_data we wrote
  ;  via the copy. Recompute from a10 = end-of-copy.)
  slli    a11, a13, 3              ; bytes_copied
  sub     a10, a10, a11            ; rewound to start
  s32i.n  a10, a12, 16
  j       vpb_store
vpb_done:
  ; --- Scope-pin (only meaningful on the grow path which allocated a
  ; fresh data buffer; on the no-grow path the alloc was skipped and
  ; the pin is a no-op against `cssc_arena_off`). Cheap enough to do
  ; unconditionally — 7 instructions whose worst case writes the
  ; current cursor to scope_stack[sp-1] when no growth occurred.
  l32r    a8, .Lvpb_scope_sp_addr
  l32i.n  a9, a8, 0
  beqz    a9, vpb_pin_done
  addi    a9, a9, -1
  l32r    a10, .Lvpb_scope_stack_addr
  slli    a9, a9, 2
  add     a10, a10, a9
  l32r    a8, .Lvpb_arena_off_addr
  l32i.n  a8, a8, 0
  s32i.n  a8, a10, 0
vpb_pin_done:
  l32i.n  a14, a1, 0
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
  .literal_position
  .literal .Lvpb_arena_off_addr,   cssc_arena_off
  .literal .Lvpb_scope_sp_addr,    cssc_scope_sp
  .literal .Lvpb_scope_stack_addr, cssc_scope_stack
  .size cssc_vector_push_back_int, .-cssc_vector_push_back_int

  .global cssc_vector_push_back_float
cssc_vector_push_back_float: j cssc_vector_push_back_int

  ; Phase A.6 — CIR lowering emits `cssc_vector_push_<rt>` (no `_back`)
  ; for both `vec.push_back(x)` method dispatch AND `_init_vector`
  ; pushes during literal-init. Provide single-jump thunks to the
  ; existing `_back` variants so the linker resolves cleanly.
  .global cssc_vector_push_int
cssc_vector_push_int: j cssc_vector_push_back_int

  .global cssc_vector_push_float
cssc_vector_push_float: j cssc_vector_push_back_int

  ; ===========================================================================
  ; Phase 5b — `array<string>` Xtensa runtime
  ;
  ; Layout reuses the cssc_vec_int header (size, cap, data). Each entry
  ; occupies 8 bytes for storage uniformity, but the actual payload is a
  ; 4-byte cssc_str* in the LOW half; the HIGH half is always 0. This
  ; matches the host x86_64 runtime's 8-byte slot stride and lets new /
  ; size / pop reuse the int helpers via thunks.
  ;
  ; The container OWNS one refcount per stored entry — push doesn't
  ; retain (caller transfers ownership); free walks and cssc_releases
  ; each live entry before reclaiming the arena.
  ; ===========================================================================

  .global cssc_vector_new_string
cssc_vector_new_string: j cssc_vector_new_int       ; same 24-byte header

  .global cssc_vector_size_string
cssc_vector_size_string: j cssc_vector_size_int     ; same i64 size load

  ; cssc_vector_push_string(header, str_ptr): adopts the caller's
  ; cssc_str* refcount, stores at data[size*8] (lo) / 0 (hi), bumps
  ; size. Grows via cssc_obj_alloc when size == cap.
  ;
  ; CALL0 ABI on Xtensa LX106 (NO pair-align for ptr — pair-align
  ; only applies to width-2 args = i64/f64/csscval). For (PTR, PTR)
  ; the layout is:
  ;   a2 = header   (arg 0, width 1)
  ;   a3 = str_ptr  (arg 1, width 1) — NOT a4 (that would be the
  ;                                    layout for the i64 variant
  ;                                    cssc_vector_push_int).
  ;
  ; Earlier this function mistakenly read a4, treating PTR like i64.
  ; The chip survived display.begin (a2-only) but Display_run's first
  ; array_string deref crashed via corrupted entry pointers — a4 at
  ; entry happened to alias another caller-save reg holding garbage.
  ;
  ; Save the input ptr in a13 (callee-save) so it survives the grow
  ; path's cssc_obj_alloc call. (Caller-save a3 would be clobbered.)
  .global cssc_vector_push_string
  .type   cssc_vector_push_string, @function
cssc_vector_push_string:
  ; Frame (32 bytes):
  ;   [0..3]   = scratch (new_data ptr across copy loop)
  ;   [4..7]   = saved a15
  ;   [8..11]  = saved a14
  ;   [12..15] = saved a13
  ;   [16..19] = saved a12
  ;   [20..23] = saved a0
  ;   [24..31] = padding (16-byte aligned)
  addi    a1, a1, -32
  s32i.n  a0,  a1, 20
  s32i.n  a12, a1, 16
  s32i.n  a13, a1, 12
  s32i.n  a14, a1, 8
  s32i.n  a15, a1, 4
  mov.n   a12, a2                  ; header
  mov.n   a13, a3                  ; str_ptr (preserved across call0)
  l32i.n  a14, a12, 8              ; cap (callee-save reg)
  l32i.n  a8, a12, 0               ; size
  bge     a8, a14, vps_grow
vps_store:
  l32i.n  a9, a12, 16              ; data
  l32i.n  a8, a12, 0               ; size (re-read; may have been updated by grow)
  slli    a10, a8, 3               ; idx * 8
  add     a11, a9, a10             ; entry addr
  s32i.n  a13, a11, 0              ; ptr lo (from preserved a13)
  movi.n  a9, 0
  s32i.n  a9, a11, 4               ; hi = 0
  addi    a8, a8, 1
  s32i.n  a8, a12, 0               ; size++
  j       vps_done
vps_grow:
  ; new_cap = cap * 2
  slli    a8, a14, 1               ; new_cap (cap is in a14, callee-save)
  s32i.n  a8, a12, 8               ; header.cap = new_cap
  ; alloc new buffer (new_cap * 8 bytes)
  slli    a2, a8, 3
  call0   cssc_obj_alloc           ; clobbers a2-a11; a12-a15 preserved
  ; After the call: a2 = new_data. Snapshot in a15 (callee-save) and
  ; in the dedicated frame slot [0..3] so the copy loop can clobber
  ; a10 freely.
  mov.n   a15, a2                  ; new_data
  s32i.n  a15, a1, 0               ; park new_data start for later rewind
  ; Re-read size + old-data from the header for the copy.
  l32i.n  a11, a12, 0              ; size
  slli    a11, a11, 3              ; bytes to copy = size * 8
  l32i.n  a8, a12, 16              ; old data ptr
  mov.n   a10, a15                 ; write cursor = new_data
vps_copy:
  movi.n  a3, 0
  beq     a11, a3, vps_copy_done
  l32i.n  a2, a8, 0
  s32i.n  a2, a10, 0
  addi    a8, a8, 4
  addi    a10, a10, 4
  addi    a11, a11, -4
  j       vps_copy
vps_copy_done:
  l32i.n  a10, a1, 0               ; reload new_data start
  s32i.n  a10, a12, 16             ; header.data = new_data
  j       vps_store
vps_done:
  ; Scope-pin so the arena allocation survives the caller's scope_pop.
  l32r    a8, .Lvps_scope_sp_addr
  l32i.n  a9, a8, 0
  beqz    a9, vps_pin_done
  addi    a9, a9, -1
  l32r    a10, .Lvps_scope_stack_addr
  slli    a9, a9, 2
  add     a10, a10, a9
  l32r    a8, .Lvps_arena_off_addr
  l32i.n  a8, a8, 0
  s32i.n  a8, a10, 0
vps_pin_done:
  l32i.n  a15, a1, 4
  l32i.n  a14, a1, 8
  l32i.n  a13, a1, 12
  l32i.n  a12, a1, 16
  l32i.n  a0,  a1, 20
  addi    a1, a1, 32
  ret.n
  .literal_position
  .literal .Lvps_arena_off_addr,   cssc_arena_off
  .literal .Lvps_scope_sp_addr,    cssc_scope_sp
  .literal .Lvps_scope_stack_addr, cssc_scope_stack
  .size cssc_vector_push_string, .-cssc_vector_push_string

  ; cssc_vector_get_string(header, idx) → ptr
  ;   in: a2 = header, a4 = idx (i64 lo)
  ;   out: a2 = cssc_str* (entry's lo half)
  .global cssc_vector_get_string
  .type   cssc_vector_get_string, @function
cssc_vector_get_string:
  l32i.n  a8, a2, 16               ; data
  slli    a9, a4, 3                ; idx * 8
  add     a10, a8, a9
  l32i.n  a2, a10, 0               ; ptr (lo half)
  ret.n
  .size cssc_vector_get_string, .-cssc_vector_get_string

  ; cssc_vector_set_string(header, idx, str): release old, store new.
  ;   in: a2 = header, a4 = idx (i64 lo), a6 = cssc_str* (a7 ignored)
  .global cssc_vector_set_string
  .type   cssc_vector_set_string, @function
cssc_vector_set_string:
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  mov.n   a12, a2                  ; header
  mov.n   a13, a6                  ; new ptr
  l32i.n  a8, a12, 16              ; data
  slli    a9, a4, 3
  add     a10, a8, a9              ; entry addr
  ; release old
  l32i.n  a2, a10, 0
  s32i.n  a10, a1, 0               ; save entry addr across call
  call0   cssc_release
  l32i.n  a10, a1, 0
  ; store new
  s32i.n  a13, a10, 0
  movi.n  a8, 0
  s32i.n  a8, a10, 4
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_vector_set_string, .-cssc_vector_set_string

  ; cssc_vector_null_at_string(header, idx): cssc_release entry, store NULL.
  ;   in: a2 = header, a4 = idx (i64 lo)
  .global cssc_vector_null_at_string
  .type   cssc_vector_null_at_string, @function
cssc_vector_null_at_string:
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  l32i.n  a8, a2, 0                ; size
  ; bounds check: idx >= 0 && idx < size; out-of-bounds → no-op
  bltz    a4, vnas_done
  bge     a4, a8, vnas_done
  l32i.n  a8, a2, 16               ; data
  slli    a9, a4, 3
  add     a10, a8, a9              ; entry addr
  s32i.n  a10, a1, 0               ; save across call
  l32i.n  a2, a10, 0               ; ptr to release
  call0   cssc_release
  l32i.n  a10, a1, 0
  movi.n  a8, 0
  s32i.n  a8, a10, 0               ; null lo
  s32i.n  a8, a10, 4               ; null hi
vnas_done:
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_vector_null_at_string, .-cssc_vector_null_at_string

  ; cssc_vector_null_all_string(header): release every entry; size unchanged.
  ;   in: a2 = header
  ;
  ; Frame (32 bytes — clean layout, no slot reuse):
  ;   [0..3]   = saved a14 (entry addr scratch survives call0)
  ;   [4..7]   = saved a13 (size — preserved for the caller)
  ;   [8..11]  = saved a12 (header — used throughout the loop)
  ;   [12..15] = saved a0  (return PC)
  ;   [16..19] = cursor i (mutable loop var; lives ABOVE saved-CS regs
  ;                       so call0 cssc_release can never clobber it
  ;                       and the epilogue's `l32i a13, a1, 4` reads
  ;                       the genuine saved a13, never the scratch i.)
  .global cssc_vector_null_all_string
  .type   cssc_vector_null_all_string, @function
cssc_vector_null_all_string:
  addi    a1, a1, -32
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  s32i.n  a14, a1, 0
  mov.n   a12, a2                  ; header (callee-save → survives cssc_release)
  l32i.n  a13, a12, 0              ; size (callee-save → survives cssc_release)
  movi.n  a8, 0
  s32i.n  a8, a1, 16               ; i = 0  (loop cursor in dedicated slot)
vnaa_loop:
  l32i.n  a8, a1, 16               ; reload i
  bge     a8, a13, vnaa_done       ; while (i < size)
  ; entry_addr = data + i*8
  l32i.n  a9, a12, 16              ; data ptr
  slli    a10, a8, 3
  add     a14, a9, a10             ; entry addr → callee-save a14
  ; cssc_release(entry_addr.lo)
  l32i.n  a2, a14, 0
  call0   cssc_release
  ; null both halves; a14 still holds entry addr (preserved across call0).
  movi.n  a9, 0
  s32i.n  a9, a14, 0
  s32i.n  a9, a14, 4
  ; i++
  l32i.n  a8, a1, 16
  addi    a8, a8, 1
  s32i.n  a8, a1, 16
  j       vnaa_loop
vnaa_done:
  l32i.n  a14, a1, 0
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 32
  ret.n
  .size cssc_vector_null_all_string, .-cssc_vector_null_all_string

  ; cssc_vector_clear_string(header): release every entry + size = 0.
  .global cssc_vector_clear_string
  .type   cssc_vector_clear_string, @function
cssc_vector_clear_string:
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  s32i.n  a12, a1, 8
  mov.n   a12, a2
  call0   cssc_vector_null_all_string
  movi.n  a8, 0
  s32i.n  a8, a12, 0               ; size = 0
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_vector_clear_string, .-cssc_vector_clear_string

  ; cssc_array_string_free / cssc_vector_free_string: walk + release every
  ; entry. Arena allocator → header + data themselves are reclaimed by
  ; the surrounding cssc_scope_pop, so we just decrement refcounts.
  .global cssc_array_string_free
  .type   cssc_array_string_free, @function
cssc_array_string_free:
  beqz    a2, vfs_null
  ; Delegate to null_all (it walks size entries and releases each).
  j       cssc_vector_null_all_string
vfs_null:
  ret.n
  .size cssc_array_string_free, .-cssc_array_string_free

  .global cssc_vector_free_string
cssc_vector_free_string: j cssc_array_string_free

  ; Phase A.2: pop_back_string TRANSFERS ownership — vector forgets the
  ; entry (size -= 1, slot ptr nulled WITHOUT release) so the returned
  ; ptr keeps its existing refcount and lands in the caller as a live
  ; owner. Caller must cssc_release the result when done. Returns 0
  ; (NULL) on empty.
  .global cssc_vector_pop_back_string
  .type   cssc_vector_pop_back_string, @function
cssc_vector_pop_back_string:
  ; in: a2 = header. out: a2 = popped cssc_str* (or 0 if empty).
  l32i.n  a8, a2, 0                ; size
  movi.n  a9, 0
  beq     a8, a9, vpsps_empty
  addi    a8, a8, -1
  s32i.n  a8, a2, 0                ; size -= 1
  l32i.n  a10, a2, 16              ; data table
  slli    a11, a8, 2               ; idx * 4 (ptr stride on LX106)
  add     a10, a10, a11            ; &data[new_size]
  l32i.n  a2, a10, 0               ; load cssc_str*
  movi.n  a9, 0
  s32i.n  a9, a10, 0               ; vector forgets — no release
  ret.n
vpsps_empty:
  movi.n  a2, 0
  ret.n
  .size cssc_vector_pop_back_string, .-cssc_vector_pop_back_string

  .global cssc_vector_pop_back_int
  .type   cssc_vector_pop_back_int, @function
cssc_vector_pop_back_int:
  ; in: a2 = header → out: a2:a3 = popped element (i64) or 0 if empty
  l32i.n  a8, a2, 0
  movi.n  a9, 0
  beq     a8, a9, vpop_empty
  addi    a8, a8, -1
  s32i.n  a8, a2, 0                ; size--
  l32i.n  a10, a2, 16
  slli    a11, a8, 3
  add     a10, a10, a11
  l32i.n  a3, a10, 4
  l32i.n  a2, a10, 0
  ret.n
vpop_empty:
  movi.n  a2, 0
  movi.n  a3, 0
  ret.n
  .size cssc_vector_pop_back_int, .-cssc_vector_pop_back_int

  .global cssc_vector_pop_back_float
cssc_vector_pop_back_float: j cssc_vector_pop_back_int

  .global cssc_vector_clear_int
  .type   cssc_vector_clear_int, @function
cssc_vector_clear_int:
  ; in: a2 = header. Just zero the size field — data buffer kept.
  movi.n  a8, 0
  s32i.n  a8, a2, 0
  s32i.n  a8, a2, 4
  ret.n
  .size cssc_vector_clear_int, .-cssc_vector_clear_int

  .global cssc_vector_clear_float
cssc_vector_clear_float: j cssc_vector_clear_int

  ; ===========================================================================
  ; Phase A.1 — vector<bool> + array<bool>.
  ;
  ; Header layout reuses cssc_vector_new_int's 24-byte header (size, cap,
  ; data) but `data` points to a flat byte array — 1 byte per element,
  ; not 8. Push/get/set work on bytes; pop returns the popped byte's
  ; low bit. CALL0 ABI with pair-align: each arg gets a pair slot, the
  ; bool value lives in the low half of its pair (a4 for arg-1).
  ; ===========================================================================

  .global cssc_vector_new_bool
  .type   cssc_vector_new_bool, @function
cssc_vector_new_bool:
  ; in: a2 = capacity_hint (low half of the i64 pair slot).
  ; out: a2 = header ptr.
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  movi.n  a8, 4
  bge     a2, a8, vnb_cap_ok
  movi.n  a2, 4
vnb_cap_ok:
  mov.n   a12, a2                  ; cap (element count = byte count)
  movi.n  a2, 24
  call0   cssc_obj_alloc
  mov.n   a13, a2                  ; header ptr
  movi.n  a8, 0
  s32i.n  a8, a13, 0               ; size_lo
  s32i.n  a8, a13, 4               ; size_hi
  s32i.n  a12, a13, 8              ; cap_lo
  s32i.n  a8, a13, 12              ; cap_hi
  mov.n   a2, a12                  ; bytes = cap (1 byte per element)
  call0   cssc_obj_alloc
  s32i.n  a2, a13, 16              ; data ptr
  ; Scope-pin so the header survives cssc_scope_pop.
  l32r    a8, .Lvnb_scope_sp_addr
  l32i.n  a9, a8, 0
  beqz    a9, vnb_pin_done
  addi    a9, a9, -1
  l32r    a10, .Lvnb_scope_stack_addr
  slli    a9, a9, 2
  add     a10, a10, a9
  l32r    a8, .Lvnb_arena_off_addr
  l32i.n  a8, a8, 0
  s32i.n  a8, a10, 0
vnb_pin_done:
  mov.n   a2, a13
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .literal_position
  .literal .Lvnb_arena_off_addr,   cssc_arena_off
  .literal .Lvnb_scope_sp_addr,    cssc_scope_sp
  .literal .Lvnb_scope_stack_addr, cssc_scope_stack
  .size cssc_vector_new_bool, .-cssc_vector_new_bool

  .global cssc_vector_free_bool
cssc_vector_free_bool: ret.n               ; arena allocator — no-op

  .global cssc_array_bool_free
cssc_array_bool_free: ret.n                ; immutable alias — same arena, same no-op

  .global cssc_vector_size_bool
cssc_vector_size_bool: j cssc_vector_size_int  ; size field at +0 is shared

  .global cssc_vector_push_bool
  .type   cssc_vector_push_bool, @function
cssc_vector_push_bool:
  ; in: a2 = header (PTR, width=1); a3 = i1 val (BOOL, width=1).
  ; Per `_arg_reg_layout`, single-width args pack consecutively into
  ; the ARG_REGS table — there is NO pair-align skip between two
  ; width-1 args. (Pair-align ONLY kicks in for i64/f64/csscval.)
  ; If size < cap: write at data[size], size += 1.
  ; Else: alloc 2*cap buffer, byte-copy old → new, then store.
  ; Labels namespaced `vpbb_*` (vector_push_back_bool) to avoid the
  ; collision with cssc_vector_push_back_int's `vpb_*` labels.
  ; Frame 32 bytes — saves a0,a12-a15 (callee-save; we clobber a15
  ; in the grow path so it MUST be spilled).
  addi    a1, a1, -32
  s32i.n  a0,  a1, 20
  s32i.n  a12, a1, 16
  s32i.n  a13, a1, 12
  s32i.n  a14, a1, 8
  s32i.n  a15, a1, 4
  mov.n   a12, a2                  ; header (callee-save)
  mov.n   a13, a3                  ; val byte (callee-save) — i1 in a3
  l32i.n  a8,  a12, 0              ; size
  l32i.n  a14, a12, 8              ; cap (callee-save)
  bge     a8,  a14, vpbb_grow
vpbb_store:
  l32i.n  a8,  a12, 0              ; reload size (after potential grow)
  l32i.n  a9,  a12, 16             ; data ptr
  add     a10, a9,  a8             ; &data[size] (1 byte/elem)
  s8i     a13, a10, 0              ; store low byte
  addi    a8, a8, 1
  s32i.n  a8, a12, 0               ; size += 1
  j       vpbb_done
vpbb_grow:
  slli    a8, a14, 1               ; new_cap = cap * 2
  s32i.n  a8, a12, 8               ; header.cap = new_cap
  mov.n   a2, a8                   ; bytes = new_cap (1 byte/elem)
  movi.n  a3, 0                    ; size hi-half must be 0 (cssc_obj_alloc
                                   ; reads i64 lo via a2 only, but a3 still
                                   ; gets pulled in as i64.hi for the ABI;
                                   ; uninitialised a3 from the caller's
                                   ; pair-align skip can hold garbage that
                                   ; the audit pass would flag).
  call0   cssc_obj_alloc           ; a2 = new_data (clobbers a3-a11)
  ; Snapshot new_data for the post-copy header update.
  mov.n   a15, a2
  l32i.n  a11, a12, 0              ; old size = bytes to copy
  l32i.n  a8,  a12, 16             ; old data
  mov.n   a10, a15                 ; write cursor
vpbb_copy:
  movi.n  a9, 0
  beq     a11, a9, vpbb_copy_done
  l8ui    a3, a8, 0
  s8i     a3, a10, 0
  addi    a8, a8, 1
  addi    a10, a10, 1
  addi    a11, a11, -1
  j       vpbb_copy
vpbb_copy_done:
  s32i.n  a15, a12, 16             ; header.data = new_data
  j       vpbb_store
vpbb_done:
  l32i.n  a15, a1, 4
  l32i.n  a14, a1, 8
  l32i.n  a13, a1, 12
  l32i.n  a12, a1, 16
  l32i.n  a0,  a1, 20
  addi    a1, a1, 32
  ret.n
  .size cssc_vector_push_bool, .-cssc_vector_push_bool

  .global cssc_vector_get_bool
  .type   cssc_vector_get_bool, @function
cssc_vector_get_bool:
  ; in: a2 = header (PTR width=1), a4 = idx (INT64 width=2 — pair-aligned
  ;     to even slot after the width-1 PTR consumes a2, so it lands at
  ;     a4:a5, a3 is the pair-align skip).
  ; out: a2 = i1 val (zero-extended to i32).
  l32i.n  a8, a2, 16               ; data
  add     a10, a8, a4              ; &data[idx]
  l8ui    a2, a10, 0               ; zero-extend the low byte
  ret.n
  .size cssc_vector_get_bool, .-cssc_vector_get_bool

  .global cssc_vector_set_bool
  .type   cssc_vector_set_bool, @function
cssc_vector_set_bool:
  ; in: a2 = header (PTR), a4 = idx (INT64 pair-aligned to a4:a5,
  ;     a3 is the pair-align skip), a6 = i1 val (BOOL width=1 — after
  ;     the INT64 pair, used = 4, so BOOL lands at a6 with no skip).
  l32i.n  a8, a2, 16               ; data
  add     a10, a8, a4              ; &data[idx]
  s8i     a6, a10, 0
  ret.n
  .size cssc_vector_set_bool, .-cssc_vector_set_bool

  .global cssc_vector_pop_back_bool
  .type   cssc_vector_pop_back_bool, @function
cssc_vector_pop_back_bool:
  ; in: a2 = header. out: a2 = popped value (i1 zext to i32) or 0 if empty.
  l32i.n  a8, a2, 0                ; size
  movi.n  a9, 0
  beq     a8, a9, vpopb_empty
  addi    a8, a8, -1
  s32i.n  a8, a2, 0                ; size -= 1
  l32i.n  a9, a2, 16               ; data
  add     a10, a9, a8              ; &data[new_size]
  l8ui    a2, a10, 0               ; zext byte to i32
  ret.n
vpopb_empty:
  movi.n  a2, 0
  ret.n
  .size cssc_vector_pop_back_bool, .-cssc_vector_pop_back_bool

  .global cssc_vector_clear_bool
cssc_vector_clear_bool: j cssc_vector_clear_int  ; size field at +0 is shared

  ; ===========================================================================
  ; C2 — map_si (string→int hash table) + bind_ss (ordered string-pair list).
  ;
  ; map_si layout (32 bytes):
  ;   off 0:  i64 size       (entries in use)
  ;   off 8:  i64 bucket_cnt (power-of-2 number of buckets)
  ;   off 16: ptr buckets    (bucket_cnt * 16 bytes each: key_ptr, value_lo)
  ;   off 24: i64 _padding   (so header is 32 bytes total)
  ;
  ; Each bucket: 16 bytes — [ptr key | i64 value]. Empty buckets have
  ; key_ptr = NULL. Probe sequence is linear; we accept the simpler
  ; clustering trade-off versus the small bucket count we need.
  ;
  ; FNV-1a 32-bit hash:
  ;   hash = 0x811C9DC5
  ;   for each byte b: hash = (hash XOR b) * 0x01000193
  ; ===========================================================================

  .global cssc_map_si_new
  .type   cssc_map_si_new, @function
cssc_map_si_new:
  ; in: a2 = capacity_hint (assumed power-of-2, min 8)
  ; out: a2 = header ptr (single 32-byte alloc, no leak)
  ;
  ; A.1.3: the original code allocated the header twice — the first
  ; 32-byte block got clobbered before the bucket buffer alloc finished,
  ; so every map_si_new permanently leaked 32 bytes from the arena.
  ; Fixed by stashing the header pointer in a13 (callee-save, preserved
  ; across cssc_obj_alloc) for the duration of the bucket-buffer alloc.
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  ; Floor cap at 8.
  movi.n  a8, 8
  bge     a2, a8, ms_cap_ok
  movi.n  a2, 8
ms_cap_ok:
  mov.n   a12, a2                  ; a12 = bucket_cnt (callee-save)
  ; Allocate header (32 bytes), keep ptr in a13.
  movi.n  a2, 32
  call0   cssc_obj_alloc
  mov.n   a13, a2                  ; a13 = header ptr (callee-save)
  ; Allocate bucket buffer (cnt * 16 bytes); a2 returns ptr.
  slli    a2, a12, 4
  call0   cssc_obj_alloc
  ; Now write the header fields once. a13 is still the same header.
  movi.n  a9, 0
  s32i.n  a9,  a13, 0              ; size = 0
  s32i.n  a9,  a13, 4
  s32i.n  a12, a13, 8              ; bucket_cnt
  s32i.n  a9,  a13, 12
  s32i.n  a2,  a13, 16             ; bucket ptr
  s32i.n  a9,  a13, 20
  ; --- Scope-pin: header + bucket buffer both live on the bump arena.
  ; Pin them to the caller's scope so a subsequent allocation (in the
  ; same label / method body) doesn't roll the arena cursor past us
  ; and corrupt later reads of map members.
  l32r    a8, .Lmsn_scope_sp_addr
  l32i.n  a9, a8, 0
  beqz    a9, msn_pin_done
  addi    a9, a9, -1
  l32r    a10, .Lmsn_scope_stack_addr
  slli    a9, a9, 2
  add     a10, a10, a9
  l32r    a8, .Lmsn_arena_off_addr
  l32i.n  a8, a8, 0
  s32i.n  a8, a10, 0
msn_pin_done:
  ; Return the (only) header.
  mov.n   a2, a13
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .literal_position
  .literal .Lmsn_arena_off_addr,   cssc_arena_off
  .literal .Lmsn_scope_sp_addr,    cssc_scope_sp
  .literal .Lmsn_scope_stack_addr, cssc_scope_stack
  .size cssc_map_si_new, .-cssc_map_si_new

  .global cssc_map_si_free
cssc_map_si_free: ret.n

  .global cssc_map_si_size
  .type   cssc_map_si_size, @function
cssc_map_si_size:
  l32i.n  a8, a2, 0
  l32i.n  a3, a2, 4
  mov.n   a2, a8
  ret.n
  .size cssc_map_si_size, .-cssc_map_si_size

  ; Internal: FNV-1a hash of a cssc_str.
  ;   in: a2 = cssc_str* key
  ;   out: a2 = 32-bit hash
.global ._cssc_fnv1a
.type ._cssc_fnv1a, @function
._cssc_fnv1a:
  ; CALL0 ABI: we use a12 (loop terminator constant) and a13 (current
  ; byte) as scratch. Both are callee-save; the prior frame saved a0
  ; only and leaked corruption back to callers (cssc_map_si_set/get/has).
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  ; size
  l32i.n  a8, a2, 0                ; size
  ; data
  l32i.n  a9, a2, 8                ; data ptr
  ; hash init = 0x811C9DC5
  l32r    a10, .Lfnv_offset_basis
  l32r    a11, .Lfnv_prime
fnv_loop:
  movi.n  a12, 0
  beq     a8, a12, fnv_done
  l8ui    a13, a9, 0
  xor     a10, a10, a13
  ; hash *= prime
  mov.n   a2, a10
  mov.n   a3, a11
  call0   __mulsi3
  mov.n   a10, a2
  addi    a9, a9, 1
  addi    a8, a8, -1
  j       fnv_loop
fnv_done:
  mov.n   a2, a10
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .literal_position
  .literal .Lfnv_offset_basis, 0x811C9DC5
  .literal .Lfnv_prime,        0x01000193
  .size ._cssc_fnv1a, .-._cssc_fnv1a

  ; Internal: 32-bit fmix (murmur3) used by all integer-keyed maps.
  ; Xtensa bucket selection only consumes the low 32 bits anyway, so
  ; we operate purely on a2 (key_lo) and discard the high half.
  ;   in:  a2 = key_lo (low 32 bits of i64 key)
  ;   out: a2 = hash32
  ; Body:  x ^= x>>16; x *= 0x85ebca6b; x ^= x>>13;
  ;        x *= 0xc2b2ae35; x ^= x>>16;
.global ._cssc_splitmix32
.type ._cssc_splitmix32, @function
._cssc_splitmix32:
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  ; round 1
  srli    a8, a2, 16
  xor     a2, a2, a8
  l32r    a3, .Lsplmx_mul1            ; 0x85ebca6b
  call0   __mulsi3                    ; a2 = a2 * a3
  srli    a8, a2, 13
  xor     a2, a2, a8
  ; round 2
  l32r    a3, .Lsplmx_mul2            ; 0xc2b2ae35
  call0   __mulsi3
  srli    a8, a2, 16
  xor     a2, a2, a8
  l32i.n  a0, a1, 12
  addi    a1, a1, 16
  ret.n
  .literal_position
  .literal .Lsplmx_mul1, 0x85ebca6b
  .literal .Lsplmx_mul2, 0xc2b2ae35
  .size ._cssc_splitmix32, .-._cssc_splitmix32

  .global cssc_map_si_set
  .type   cssc_map_si_set, @function
cssc_map_si_set:
  ; in: a2 = header, a4 = key cssc_str*, a6:a7 = value (i64)
  ; Hash, linear-probe to find an empty bucket OR a matching key,
  ; install. Resize is NOT implemented in Phase C2 — caller must
  ; size the map appropriately.
  addi    a1, a1, -32
  s32i.n  a0, a1, 28
  s32i.n  a12, a1, 24
  s32i.n  a13, a1, 20
  s32i.n  a14, a1, 16
  s32i.n  a15, a1, 12
  mov.n   a12, a2                  ; header
  mov.n   a13, a4                  ; key
  ; Save value temporarily on stack (we'll need to clobber a6/a7).
  s32i.n  a6, a1, 0
  s32i.n  a7, a1, 4
  ; hash
  mov.n   a2, a13
  call0   ._cssc_fnv1a             ; a2 = hash
  mov.n   a14, a2                  ; hash
  l32i.n  a15, a12, 8              ; bucket_cnt
  addi    a8, a15, -1              ; mask = cnt-1
  and     a14, a14, a8             ; first slot
  l32i.n  a9, a12, 16              ; buckets ptr
  ; iterate
  mov.n   a10, a14                 ; probe idx
ms_probe:
  slli    a11, a10, 4              ; bucket offset
  add     a2, a9, a11              ; bucket addr
  l32i.n  a3, a2, 0                ; key_ptr
  movi.n  a4, 0
  beq     a3, a4, ms_install       ; empty slot → install
  ; If keys equal byte-by-byte, replace value.
  mov.n   a4, a3                   ; existing key
  mov.n   a3, a13                  ; our key
  ; cssc_string_eq(a, b) returns 0/1 in a2.
  s32i.n  a2, a1, 8                ; preserve bucket addr
  mov.n   a2, a4
  mov.n   a3, a13
  call0   cssc_string_eq
  movi.n  a5, 0
  beq     a2, a5, ms_advance
  ; equal → reuse bucket
  l32i.n  a2, a1, 8                ; bucket addr back
  j       ms_write_value
ms_advance:
  l32i.n  a2, a1, 8
  addi    a10, a10, 1
  ; modulo cnt: AND with mask. cnt is power-of-2 so this works.
  l32i.n  a8, a12, 8
  addi    a8, a8, -1
  and     a10, a10, a8
  bne     a10, a14, ms_probe       ; full pass without empty → full map
  ; Map full — drop silently (caller can pre-size). On embedded
  ; this is preferable to a panic.
  j       ms_done
ms_install:
  ; bucket at a2; install key + value.
  s32i.n  a13, a2, 0               ; key
  ; increment size
  l32i.n  a8, a12, 0
  addi    a8, a8, 1
  s32i.n  a8, a12, 0
ms_write_value:
  ; value bytes from frame.
  l32i.n  a8, a1, 0
  s32i.n  a8, a2, 8
  l32i.n  a8, a1, 4
  s32i.n  a8, a2, 12
ms_done:
  l32i.n  a15, a1, 12
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0, a1, 28
  addi    a1, a1, 32
  ret.n
  .size cssc_map_si_set, .-cssc_map_si_set

  .global cssc_map_si_get
  .type   cssc_map_si_get, @function
cssc_map_si_get:
  ; in: a2 = header, a4 = key → out: a2:a3 = value (0 if not found)
  ; CALL0 ABI: we clobber a12/a13/a14. Bigger frame so the
  ; per-call scratch slots ([+0] saved idx, [+4] saved bucket
  ; addr during cssc_string_eq) don't overlap the callee-save
  ; spill slots.
  addi    a1, a1, -32
  s32i.n  a0,  a1, 28
  s32i.n  a12, a1, 24
  s32i.n  a13, a1, 20
  s32i.n  a14, a1, 16
  mov.n   a12, a2
  mov.n   a13, a4
  mov.n   a2, a13
  call0   ._cssc_fnv1a
  l32i.n  a8, a12, 8
  addi    a9, a8, -1
  and     a2, a2, a9               ; idx
  mov.n   a14, a2                  ; first idx
  l32i.n  a10, a12, 16             ; buckets
mg_probe:
  slli    a11, a2, 4
  add     a3, a10, a11
  l32i.n  a4, a3, 0                ; key_ptr
  movi.n  a5, 0
  beq     a4, a5, mg_miss
  ; cssc_string_eq
  s32i.n  a2, a1, 0
  s32i.n  a3, a1, 4                ; bucket addr
  mov.n   a2, a4
  mov.n   a3, a13
  call0   cssc_string_eq
  movi.n  a5, 0
  beq     a2, a5, mg_next
  l32i.n  a3, a1, 4
  l32i.n  a2, a3, 8                ; value lo
  l32i.n  a3, a3, 12               ; value hi
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
mg_next:
  l32i.n  a2, a1, 0
  addi    a2, a2, 1
  l32i.n  a8, a12, 8
  addi    a8, a8, -1
  and     a2, a2, a8
  bne     a2, a14, mg_probe
mg_miss:
  movi.n  a2, 0
  movi.n  a3, 0
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .size cssc_map_si_get, .-cssc_map_si_get

  .global cssc_map_si_has
  .type   cssc_map_si_has, @function
cssc_map_si_has:
  ; in: a2 = header, a4 = key → out: a2 = i1 (1 if present)
  ; Reuses cssc_map_si_get and checks bucket presence rather than
  ; value (handles the "value happens to be 0" case correctly).
  ; CALL0 ABI: we clobber a12/a13/a14, so we need an extended frame
  ; that saves all three plus the scratch slot for the idx
  ; preserved across the cssc_string_eq call.
  addi    a1, a1, -32
  s32i.n  a0,  a1, 28
  s32i.n  a12, a1, 24
  s32i.n  a13, a1, 20
  s32i.n  a14, a1, 16
  mov.n   a12, a2
  mov.n   a13, a4
  mov.n   a2, a13
  call0   ._cssc_fnv1a
  l32i.n  a8, a12, 8
  addi    a9, a8, -1
  and     a2, a2, a9
  mov.n   a14, a2
  l32i.n  a10, a12, 16
mh_probe:
  slli    a11, a2, 4
  add     a3, a10, a11
  l32i.n  a4, a3, 0
  movi.n  a5, 0
  beq     a4, a5, mh_miss
  s32i.n  a2, a1, 0
  mov.n   a2, a4
  mov.n   a3, a13
  call0   cssc_string_eq
  movi.n  a5, 0
  beq     a2, a5, mh_next
  movi.n  a2, 1
  movi.n  a3, 0
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
mh_next:
  l32i.n  a2, a1, 0
  addi    a2, a2, 1
  l32i.n  a8, a12, 8
  addi    a8, a8, -1
  and     a2, a2, a8
  bne     a2, a14, mh_probe
mh_miss:
  movi.n  a2, 0
  movi.n  a3, 0
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .size cssc_map_si_has, .-cssc_map_si_has

  ; ===========================================================================
  ; map_ss — string→string hash table. Refcounted values.
  ;
  ; Header (32 B): { i64 size, i64 bucket_cnt, ptr buckets, i64 pad }
  ; Entry (16 B): { ptr key_cssc_str, ptr val_cssc_str, i64 _pad }
  ; Empty slot iff key==NULL. cssc_release called on val on overwrite,
  ; free walk, and null_at/null_all.
  ; CALL0 ABI per cir_lower: a2=m, a3=key_data_ptr (cssc_str*),
  ; a4:a5=key_len (i64), a6=val_ptr (cssc_str*).
  ; NOTE: like map_si, the "key" arg is treated as a cssc_str* directly
  ; (the key_len i64 in a4:a5 is ignored — we hash via ._cssc_fnv1a
  ; which reads size+data from the cssc_str header).
  ; ===========================================================================

  .global cssc_map_ss_new
  .type   cssc_map_ss_new, @function
cssc_map_ss_new:
  ; in: a2 = cap_hint  out: a2 = header ptr
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  movi.n  a8, 8
  bge     a2, a8, mssn_cap_ok
  movi.n  a2, 8
mssn_cap_ok:
  mov.n   a12, a2                  ; bucket_cnt
  movi.n  a2, 32
  call0   cssc_obj_alloc
  mov.n   a13, a2                  ; header ptr
  slli    a2, a12, 4               ; entries bytes = cnt * 16
  call0   cssc_obj_alloc
  movi.n  a9, 0
  s32i.n  a9,  a13, 0              ; size lo
  s32i.n  a9,  a13, 4              ; size hi
  s32i.n  a12, a13, 8              ; bucket_cnt
  s32i.n  a9,  a13, 12
  s32i.n  a2,  a13, 16             ; entries ptr
  s32i.n  a9,  a13, 20
  mov.n   a2, a13
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_map_ss_new, .-cssc_map_ss_new

  .global cssc_map_ss_free
  .type   cssc_map_ss_free, @function
cssc_map_ss_free:
  ; Arena allocator never reclaims memory, BUT we MUST release every
  ; non-NULL value cssc_str* so the refcount cascade fires.
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  s32i.n  a14, a1, 0
  beqz    a2, mssf_done
  mov.n   a12, a2                  ; header
  l32i.n  a13, a12, 8              ; bucket_cnt
  l32i.n  a14, a12, 16             ; entries
  movi.n  a8, 0                    ; i
mssf_loop:
  bge     a8, a13, mssf_done
  s32i.n  a8, a1, 0                ; spill i (a8 caller-save across call)
  slli    a9, a8, 4
  add     a9, a14, a9              ; &entries[i]
  l32i.n  a10, a9, 0               ; key
  beqz    a10, mssf_next
  l32i.n  a2,  a9, 4               ; val
  call0   cssc_release
mssf_next:
  l32i.n  a8, a1, 0
  addi    a8, a8, 1
  j       mssf_loop
mssf_done:
  l32i.n  a14, a1, 0
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_map_ss_free, .-cssc_map_ss_free

  .global cssc_map_ss_size
  .type   cssc_map_ss_size, @function
cssc_map_ss_size:
  l32i.n  a8, a2, 0
  l32i.n  a3, a2, 4
  mov.n   a2, a8
  ret.n
  .size cssc_map_ss_size, .-cssc_map_ss_size

  .global cssc_map_ss_set
  .type   cssc_map_ss_set, @function
cssc_map_ss_set:
  ; in: a2=header, a3=key (cssc_str*), a4:a5=key_len (ignored),
  ;     a6=val (cssc_str*).
  addi    a1, a1, -32
  s32i.n  a0,  a1, 28
  s32i.n  a12, a1, 24
  s32i.n  a13, a1, 20
  s32i.n  a14, a1, 16
  s32i.n  a15, a1, 12
  mov.n   a12, a2                  ; header
  mov.n   a13, a3                  ; key
  s32i.n  a6,  a1, 0               ; stash val ptr
  ; hash(key)
  mov.n   a2, a13
  call0   ._cssc_fnv1a
  l32i.n  a8, a12, 8               ; bucket_cnt
  addi    a9, a8, -1
  and     a14, a2, a9              ; first idx
  l32i.n  a15, a12, 16             ; entries
  mov.n   a10, a14
msss_probe:
  slli    a11, a10, 4
  add     a2,  a15, a11            ; bucket addr
  l32i.n  a3,  a2, 0               ; existing key
  beqz    a3, msss_install
  ; compare keys
  s32i.n  a2, a1, 4                ; preserve bucket addr
  s32i.n  a10, a1, 8               ; preserve probe idx
  mov.n   a2, a3
  mov.n   a3, a13
  call0   cssc_string_eq
  l32i.n  a10, a1, 8
  beqz    a2, msss_advance
  ; equal — release old val, store new
  l32i.n  a2, a1, 4                ; bucket addr
  l32i.n  a3, a2, 4                ; old val
  beqz    a3, msss_no_old_release
  mov.n   a15, a2                  ; preserve bucket across release
  mov.n   a2, a3
  call0   cssc_release
  mov.n   a2, a15                  ; restore bucket addr
  l32i.n  a15, a12, 16             ; reload entries for cleanliness
msss_no_old_release:
  l32i.n  a8, a1, 0                ; new val
  s32i.n  a8, a2, 4
  j       msss_done
msss_advance:
  l32i.n  a8, a12, 8
  addi    a8, a8, -1
  addi    a10, a10, 1
  and     a10, a10, a8
  bne     a10, a14, msss_probe
  j       msss_done
msss_install:
  s32i.n  a13, a2, 0               ; key
  l32i.n  a8,  a1, 0               ; val
  s32i.n  a8,  a2, 4
  ; size += 1
  l32i.n  a9, a12, 0
  addi    a9, a9, 1
  s32i.n  a9, a12, 0
msss_done:
  l32i.n  a15, a1, 12
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .size cssc_map_ss_set, .-cssc_map_ss_set

  .global cssc_map_ss_get
  .type   cssc_map_ss_get, @function
cssc_map_ss_get:
  ; in: a2=header, a3=key (cssc_str*), a4:a5=key_len (ignored)
  ; out: a2 = val cssc_str* (0 on miss)
  addi    a1, a1, -32
  s32i.n  a0,  a1, 28
  s32i.n  a12, a1, 24
  s32i.n  a13, a1, 20
  s32i.n  a14, a1, 16
  mov.n   a12, a2
  mov.n   a13, a3
  mov.n   a2, a13
  call0   ._cssc_fnv1a
  l32i.n  a8, a12, 8
  addi    a9, a8, -1
  and     a2, a2, a9
  mov.n   a14, a2                  ; first idx
  l32i.n  a10, a12, 16             ; entries
mssg_probe:
  slli    a11, a2, 4
  add     a3, a10, a11
  l32i.n  a4, a3, 0                ; key
  beqz    a4, mssg_miss
  s32i.n  a2, a1, 0
  s32i.n  a3, a1, 4
  mov.n   a2, a4
  mov.n   a3, a13
  call0   cssc_string_eq
  beqz    a2, mssg_next
  l32i.n  a3, a1, 4
  l32i.n  a2, a3, 4                ; val ptr
  movi.n  a3, 0
  j       mssg_ret
mssg_next:
  l32i.n  a2, a1, 0
  l32i.n  a8, a12, 8
  addi    a8, a8, -1
  addi    a2, a2, 1
  and     a2, a2, a8
  bne     a2, a14, mssg_probe
mssg_miss:
  movi.n  a2, 0
  movi.n  a3, 0
mssg_ret:
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .size cssc_map_ss_get, .-cssc_map_ss_get

  .global cssc_map_ss_has
  .type   cssc_map_ss_has, @function
cssc_map_ss_has:
  addi    a1, a1, -32
  s32i.n  a0,  a1, 28
  s32i.n  a12, a1, 24
  s32i.n  a13, a1, 20
  s32i.n  a14, a1, 16
  mov.n   a12, a2
  mov.n   a13, a3
  mov.n   a2, a13
  call0   ._cssc_fnv1a
  l32i.n  a8, a12, 8
  addi    a9, a8, -1
  and     a2, a2, a9
  mov.n   a14, a2
  l32i.n  a10, a12, 16
mssh_probe:
  slli    a11, a2, 4
  add     a3, a10, a11
  l32i.n  a4, a3, 0
  beqz    a4, mssh_miss
  s32i.n  a2, a1, 0
  mov.n   a2, a4
  mov.n   a3, a13
  call0   cssc_string_eq
  beqz    a2, mssh_next
  movi.n  a2, 1
  movi.n  a3, 0
  j       mssh_ret
mssh_next:
  l32i.n  a2, a1, 0
  l32i.n  a8, a12, 8
  addi    a8, a8, -1
  addi    a2, a2, 1
  and     a2, a2, a8
  bne     a2, a14, mssh_probe
mssh_miss:
  movi.n  a2, 0
  movi.n  a3, 0
mssh_ret:
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .size cssc_map_ss_has, .-cssc_map_ss_has

  ; ===========================================================================
  ; map_is — int→string hash table. Refcounted values.
  ;
  ; Header (32 B): { i64 size, i64 bucket_cnt, ptr entries, i64 pad }
  ; Entry (16 B): { i64 key (8), ptr val_cssc_str (4), i32 state (4) }
  ; state: 0=empty, 1=occupied.
  ; CALL0 ABI per cir_lower: set: a2=m, a4:a5=key, a6=val_ptr
  ;                          get/has: a2=m, a4:a5=key
  ; ===========================================================================

  .global cssc_map_is_new
  .type   cssc_map_is_new, @function
cssc_map_is_new:
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  movi.n  a8, 8
  bge     a2, a8, misn_cap_ok
  movi.n  a2, 8
misn_cap_ok:
  mov.n   a12, a2
  movi.n  a2, 32
  call0   cssc_obj_alloc
  mov.n   a13, a2
  slli    a2, a12, 4
  call0   cssc_obj_alloc
  movi.n  a9, 0
  s32i.n  a9,  a13, 0
  s32i.n  a9,  a13, 4
  s32i.n  a12, a13, 8
  s32i.n  a9,  a13, 12
  s32i.n  a2,  a13, 16
  s32i.n  a9,  a13, 20
  ; zero state bytes — already zero from arena (cssc_obj_alloc bumps
  ; into pre-cleared bss arena). Skip explicit memset.
  mov.n   a2, a13
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_map_is_new, .-cssc_map_is_new

  .global cssc_map_is_free
  .type   cssc_map_is_free, @function
cssc_map_is_free:
  ; Walk all entries, release any occupied val.
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  s32i.n  a14, a1, 0
  beqz    a2, misf_done
  mov.n   a12, a2
  l32i.n  a13, a12, 8              ; bucket_cnt
  l32i.n  a14, a12, 16             ; entries
  movi.n  a8, 0
misf_loop:
  bge     a8, a13, misf_done
  s32i.n  a8, a1, 0
  slli    a9, a8, 4
  add     a9, a14, a9
  l32i.n  a10, a9, 12              ; state
  beqz    a10, misf_next
  l32i.n  a2,  a9, 8               ; val ptr
  beqz    a2, misf_next
  call0   cssc_release
misf_next:
  l32i.n  a8, a1, 0
  addi    a8, a8, 1
  j       misf_loop
misf_done:
  l32i.n  a14, a1, 0
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_map_is_free, .-cssc_map_is_free

  .global cssc_map_is_size
  .type   cssc_map_is_size, @function
cssc_map_is_size:
  l32i.n  a8, a2, 0
  l32i.n  a3, a2, 4
  mov.n   a2, a8
  ret.n
  .size cssc_map_is_size, .-cssc_map_is_size

  .global cssc_map_is_set
  .type   cssc_map_is_set, @function
cssc_map_is_set:
  ; in: a2=header, a4:a5=key (i64), a6=val (cssc_str*)
  addi    a1, a1, -32
  s32i.n  a0,  a1, 28
  s32i.n  a12, a1, 24
  s32i.n  a13, a1, 20
  s32i.n  a14, a1, 16
  s32i.n  a15, a1, 12
  mov.n   a12, a2                  ; header
  s32i.n  a4, a1, 0                ; key_lo
  s32i.n  a5, a1, 4                ; key_hi
  s32i.n  a6, a1, 8                ; val
  ; hash(key_lo)
  mov.n   a2, a4
  call0   ._cssc_splitmix32
  l32i.n  a8, a12, 8               ; bucket_cnt
  addi    a9, a8, -1
  and     a14, a2, a9              ; first idx
  l32i.n  a15, a12, 16             ; entries
  mov.n   a13, a14                 ; probe idx
miss_probe:
  slli    a11, a13, 4
  add     a2, a15, a11             ; bucket addr
  l32i.n  a3, a2, 12               ; state
  beqz    a3, miss_install
  ; check key equality (both 64 bits)
  l32i.n  a4, a2, 0                ; key_lo
  l32i.n  a5, a2, 4                ; key_hi
  l32i.n  a8, a1, 0
  l32i.n  a9, a1, 4
  bne     a4, a8, miss_advance
  bne     a5, a9, miss_advance
  ; key match — release old val if any, store new
  l32i.n  a3, a2, 8                ; old val
  beqz    a3, miss_no_old
  s32i.n  a2, a1, 12               ; preserve bucket
  mov.n   a2, a3
  call0   cssc_release
  l32i.n  a2, a1, 12               ; restore bucket
miss_no_old:
  l32i.n  a8, a1, 8                ; new val
  s32i.n  a8, a2, 8
  j       miss_done
miss_advance:
  l32i.n  a8, a12, 8
  addi    a8, a8, -1
  addi    a13, a13, 1
  and     a13, a13, a8
  bne     a13, a14, miss_probe
  j       miss_done
miss_install:
  l32i.n  a8, a1, 0
  s32i.n  a8, a2, 0                ; key_lo
  l32i.n  a8, a1, 4
  s32i.n  a8, a2, 4                ; key_hi
  l32i.n  a8, a1, 8
  s32i.n  a8, a2, 8                ; val
  movi.n  a8, 1
  s32i.n  a8, a2, 12               ; state = 1
  l32i.n  a9, a12, 0
  addi    a9, a9, 1
  s32i.n  a9, a12, 0
miss_done:
  l32i.n  a15, a1, 12
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .size cssc_map_is_set, .-cssc_map_is_set

  .global cssc_map_is_get
  .type   cssc_map_is_get, @function
cssc_map_is_get:
  ; in: a2=header, a4:a5=key  out: a2 = val (0 on miss)
  addi    a1, a1, -32
  s32i.n  a0,  a1, 28
  s32i.n  a12, a1, 24
  s32i.n  a13, a1, 20
  s32i.n  a14, a1, 16
  mov.n   a12, a2
  s32i.n  a4, a1, 0
  s32i.n  a5, a1, 4
  mov.n   a2, a4
  call0   ._cssc_splitmix32
  l32i.n  a8, a12, 8
  addi    a9, a8, -1
  and     a13, a2, a9
  mov.n   a14, a13                 ; first idx
  l32i.n  a10, a12, 16
misg_probe:
  slli    a11, a13, 4
  add     a3, a10, a11
  l32i.n  a4, a3, 12               ; state
  beqz    a4, misg_miss
  l32i.n  a5, a3, 0                ; key_lo
  l32i.n  a6, a3, 4                ; key_hi
  l32i.n  a8, a1, 0
  l32i.n  a9, a1, 4
  bne     a5, a8, misg_next
  bne     a6, a9, misg_next
  l32i.n  a2, a3, 8                ; val
  movi.n  a3, 0
  j       misg_ret
misg_next:
  l32i.n  a8, a12, 8
  addi    a8, a8, -1
  addi    a13, a13, 1
  and     a13, a13, a8
  bne     a13, a14, misg_probe
misg_miss:
  movi.n  a2, 0
  movi.n  a3, 0
misg_ret:
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .size cssc_map_is_get, .-cssc_map_is_get

  .global cssc_map_is_has
  .type   cssc_map_is_has, @function
cssc_map_is_has:
  addi    a1, a1, -32
  s32i.n  a0,  a1, 28
  s32i.n  a12, a1, 24
  s32i.n  a13, a1, 20
  s32i.n  a14, a1, 16
  mov.n   a12, a2
  s32i.n  a4, a1, 0
  s32i.n  a5, a1, 4
  mov.n   a2, a4
  call0   ._cssc_splitmix32
  l32i.n  a8, a12, 8
  addi    a9, a8, -1
  and     a13, a2, a9
  mov.n   a14, a13
  l32i.n  a10, a12, 16
mish_probe:
  slli    a11, a13, 4            ; entry_offset = slot * 16 (entry_size)
  add     a3, a10, a11
  l32i.n  a4, a3, 12
  beqz    a4, mish_miss
  l32i.n  a5, a3, 0
  l32i.n  a6, a3, 4
  l32i.n  a8, a1, 0
  l32i.n  a9, a1, 4
  bne     a5, a8, mish_next
  bne     a6, a9, mish_next
  movi.n  a2, 1
  movi.n  a3, 0
  j       mish_ret
mish_next:
  l32i.n  a8, a12, 8
  addi    a8, a8, -1
  addi    a13, a13, 1
  and     a13, a13, a8
  bne     a13, a14, mish_probe
mish_miss:
  movi.n  a2, 0
  movi.n  a3, 0
mish_ret:
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .size cssc_map_is_has, .-cssc_map_is_has

  ; ===========================================================================
  ; map_ii — int→int hash table. POD values.
  ;
  ; Header (32 B): { i64 size, i64 bucket_cnt, ptr entries, i64 pad }
  ; Entry (24 B): { i64 key, i64 val, i64 state }
  ; state: 0=empty, 1=occupied.
  ; CALL0 ABI: set: a2=m, a4:a5=key, a6:a7=val
  ;            get/has: a2=m, a4:a5=key
  ; ===========================================================================

  .global cssc_map_ii_new
  .type   cssc_map_ii_new, @function
cssc_map_ii_new:
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  movi.n  a8, 8
  bge     a2, a8, miin_cap_ok
  movi.n  a2, 8
miin_cap_ok:
  mov.n   a12, a2
  movi.n  a2, 32
  call0   cssc_obj_alloc
  mov.n   a13, a2
  ; entries = cnt * 24
  slli    a2, a12, 3               ; cnt * 8
  slli    a3, a12, 4               ; cnt * 16
  add     a2, a2, a3               ; cnt * 24
  call0   cssc_obj_alloc
  movi.n  a9, 0
  s32i.n  a9,  a13, 0
  s32i.n  a9,  a13, 4
  s32i.n  a12, a13, 8
  s32i.n  a9,  a13, 12
  s32i.n  a2,  a13, 16
  s32i.n  a9,  a13, 20
  mov.n   a2, a13
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_map_ii_new, .-cssc_map_ii_new

  .global cssc_map_ii_free
cssc_map_ii_free: ret.n              ; POD values, arena handles it

  .global cssc_map_ii_size
  .type   cssc_map_ii_size, @function
cssc_map_ii_size:
  l32i.n  a8, a2, 0
  l32i.n  a3, a2, 4
  mov.n   a2, a8
  ret.n
  .size cssc_map_ii_size, .-cssc_map_ii_size

  ; Internal: compute &entries[idx] for 24-byte stride entries.
  ; in: a3 = entries ptr, a10 = idx -> a3 = bucket addr
  ; Uses a8, a11 as scratch. Caller-side inline.

  .global cssc_map_ii_set
  .type   cssc_map_ii_set, @function
cssc_map_ii_set:
  ; in: a2=header, a4:a5=key, a6:a7=val
  ; 48-byte frame: [0:key_lo 4:key_hi 8:val_lo 12:val_hi 16:_ 20:_ 24:_
  ;                 28:a15 32:a14 36:a13 40:a12 44:a0]
  addi    a1, a1, -48
  s32i.n  a0,  a1, 44
  s32i.n  a12, a1, 40
  s32i.n  a13, a1, 36
  s32i.n  a14, a1, 32
  s32i.n  a15, a1, 28
  mov.n   a12, a2
  s32i.n  a4, a1, 0                 ; key_lo
  s32i.n  a5, a1, 4                 ; key_hi
  s32i.n  a6, a1, 8                 ; val_lo
  s32i.n  a7, a1, 12                ; val_hi
  mov.n   a2, a4
  call0   ._cssc_splitmix32
  l32i.n  a8, a12, 8
  addi    a9, a8, -1
  and     a14, a2, a9
  l32i.n  a15, a12, 16             ; entries
  mov.n   a13, a14
miiset_probe:
  ; offset = idx * 24 = idx*8 + idx*16
  slli    a8, a13, 3
  slli    a11, a13, 4
  add     a11, a11, a8             ; idx*24
  add     a2, a15, a11             ; bucket addr
  l32i.n  a3, a2, 16               ; state
  beqz    a3, miiset_install
  l32i.n  a4, a2, 0
  l32i.n  a5, a2, 4
  l32i.n  a8, a1, 0
  l32i.n  a9, a1, 4
  bne     a4, a8, miiset_advance
  bne     a5, a9, miiset_advance
  ; key match — overwrite val
  l32i.n  a8, a1, 8
  s32i.n  a8, a2, 8
  l32i.n  a8, a1, 12
  s32i.n  a8, a2, 12
  j       miiset_done
miiset_advance:
  l32i.n  a8, a12, 8
  addi    a8, a8, -1
  addi    a13, a13, 1
  and     a13, a13, a8
  bne     a13, a14, miiset_probe
  j       miiset_done
miiset_install:
  l32i.n  a8, a1, 0
  s32i.n  a8, a2, 0
  l32i.n  a8, a1, 4
  s32i.n  a8, a2, 4
  l32i.n  a8, a1, 8
  s32i.n  a8, a2, 8
  l32i.n  a8, a1, 12
  s32i.n  a8, a2, 12
  movi.n  a8, 1
  s32i.n  a8, a2, 16
  l32i.n  a9, a12, 0
  addi    a9, a9, 1
  s32i.n  a9, a12, 0
miiset_done:
  l32i.n  a15, a1, 28
  l32i.n  a14, a1, 32
  l32i.n  a13, a1, 36
  l32i.n  a12, a1, 40
  l32i.n  a0,  a1, 44
  addi    a1, a1, 48
  ret.n
  .size cssc_map_ii_set, .-cssc_map_ii_set

  .global cssc_map_ii_get
  .type   cssc_map_ii_get, @function
cssc_map_ii_get:
  ; in: a2=header, a4:a5=key  out: a2:a3 = val (0:0 on miss)
  addi    a1, a1, -32
  s32i.n  a0,  a1, 28
  s32i.n  a12, a1, 24
  s32i.n  a13, a1, 20
  s32i.n  a14, a1, 16
  mov.n   a12, a2
  s32i.n  a4, a1, 0
  s32i.n  a5, a1, 4
  mov.n   a2, a4
  call0   ._cssc_splitmix32
  l32i.n  a8, a12, 8
  addi    a9, a8, -1
  and     a13, a2, a9
  mov.n   a14, a13
  l32i.n  a10, a12, 16
miig_probe:
  slli    a8, a13, 3
  slli    a11, a13, 4
  add     a11, a11, a8
  add     a3, a10, a11             ; bucket
  l32i.n  a4, a3, 16               ; state
  beqz    a4, miig_miss
  l32i.n  a5, a3, 0
  l32i.n  a6, a3, 4
  l32i.n  a8, a1, 0
  l32i.n  a9, a1, 4
  bne     a5, a8, miig_next
  bne     a6, a9, miig_next
  l32i.n  a2, a3, 8
  l32i.n  a3, a3, 12
  j       miig_ret
miig_next:
  l32i.n  a8, a12, 8
  addi    a8, a8, -1
  addi    a13, a13, 1
  and     a13, a13, a8
  bne     a13, a14, miig_probe
miig_miss:
  movi.n  a2, 0
  movi.n  a3, 0
miig_ret:
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .size cssc_map_ii_get, .-cssc_map_ii_get

  .global cssc_map_ii_has
  .type   cssc_map_ii_has, @function
cssc_map_ii_has:
  addi    a1, a1, -32
  s32i.n  a0,  a1, 28
  s32i.n  a12, a1, 24
  s32i.n  a13, a1, 20
  s32i.n  a14, a1, 16
  mov.n   a12, a2
  s32i.n  a4, a1, 0
  s32i.n  a5, a1, 4
  mov.n   a2, a4
  call0   ._cssc_splitmix32
  l32i.n  a8, a12, 8
  addi    a9, a8, -1
  and     a13, a2, a9
  mov.n   a14, a13
  l32i.n  a10, a12, 16
miih_probe:
  slli    a8, a13, 3
  slli    a11, a13, 4
  add     a11, a11, a8
  add     a3, a10, a11
  l32i.n  a4, a3, 16
  beqz    a4, miih_miss
  l32i.n  a5, a3, 0
  l32i.n  a6, a3, 4
  l32i.n  a8, a1, 0
  l32i.n  a9, a1, 4
  bne     a5, a8, miih_next
  bne     a6, a9, miih_next
  movi.n  a2, 1
  movi.n  a3, 0
  j       miih_ret
miih_next:
  l32i.n  a8, a12, 8
  addi    a8, a8, -1
  addi    a13, a13, 1
  and     a13, a13, a8
  bne     a13, a14, miih_probe
miih_miss:
  movi.n  a2, 0
  movi.n  a3, 0
miih_ret:
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .size cssc_map_ii_has, .-cssc_map_ii_has

  ; ===========================================================================
  ; map_sf — string→f64 hash table. POD values.
  ;
  ; Header (32 B): { i64 size, i64 bucket_cnt, ptr entries, i64 pad }
  ; Entry (16 B): { ptr key_cssc_str (4), pad (4), f64 val (8) }
  ; State-by-sentinel: key==NULL means empty.
  ; CALL0 ABI: set: a2=m, a3=key_ptr, a4:a5=key_len(ignored), a6:a7=val
  ;            get: a2=m, a3=key_ptr, a4:a5=key_len → a2:a3 = f64
  ; ===========================================================================

  .global cssc_map_sf_new
  .type   cssc_map_sf_new, @function
cssc_map_sf_new:
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  movi.n  a8, 8
  bge     a2, a8, msfn_cap_ok
  movi.n  a2, 8
msfn_cap_ok:
  mov.n   a12, a2
  movi.n  a2, 32
  call0   cssc_obj_alloc
  mov.n   a13, a2
  slli    a2, a12, 4               ; cnt * 16
  call0   cssc_obj_alloc
  movi.n  a9, 0
  s32i.n  a9,  a13, 0
  s32i.n  a9,  a13, 4
  s32i.n  a12, a13, 8
  s32i.n  a9,  a13, 12
  s32i.n  a2,  a13, 16
  s32i.n  a9,  a13, 20
  mov.n   a2, a13
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_map_sf_new, .-cssc_map_sf_new

  .global cssc_map_sf_free
cssc_map_sf_free: ret.n              ; POD val, arena handles memory

  .global cssc_map_sf_size
  .type   cssc_map_sf_size, @function
cssc_map_sf_size:
  l32i.n  a8, a2, 0
  l32i.n  a3, a2, 4
  mov.n   a2, a8
  ret.n
  .size cssc_map_sf_size, .-cssc_map_sf_size

  .global cssc_map_sf_set
  .type   cssc_map_sf_set, @function
cssc_map_sf_set:
  ; in: a2=hdr, a3=key (cssc_str*), a4:a5=key_len(ignored), a6:a7=val (f64)
  ; 48-byte frame: [0:val_lo 4:val_hi 8:bucket 12:probe_idx
  ;                 16:_ 20:_ 24:_ 28:a15 32:a14 36:a13 40:a12 44:a0]
  addi    a1, a1, -48
  s32i.n  a0,  a1, 44
  s32i.n  a12, a1, 40
  s32i.n  a13, a1, 36
  s32i.n  a14, a1, 32
  s32i.n  a15, a1, 28
  mov.n   a12, a2
  mov.n   a13, a3
  s32i.n  a6, a1, 0                 ; val_lo
  s32i.n  a7, a1, 4                 ; val_hi
  mov.n   a2, a13
  call0   ._cssc_fnv1a
  l32i.n  a8, a12, 8
  addi    a9, a8, -1
  and     a14, a2, a9
  l32i.n  a15, a12, 16
  mov.n   a10, a14
msfs_probe:
  slli    a11, a10, 4
  add     a2, a15, a11
  l32i.n  a3, a2, 0                 ; key
  beqz    a3, msfs_install
  s32i.n  a2, a1, 8                 ; preserve bucket
  s32i.n  a10, a1, 12               ; preserve probe idx
  mov.n   a2, a3
  mov.n   a3, a13
  call0   cssc_string_eq
  l32i.n  a10, a1, 12
  beqz    a2, msfs_advance
  ; equal — overwrite val
  l32i.n  a2, a1, 8                 ; bucket
  l32i.n  a8, a1, 0
  s32i.n  a8, a2, 8
  l32i.n  a8, a1, 4
  s32i.n  a8, a2, 12
  j       msfs_done
msfs_advance:
  l32i.n  a8, a12, 8
  addi    a8, a8, -1
  addi    a10, a10, 1
  and     a10, a10, a8
  bne     a10, a14, msfs_probe
  j       msfs_done
msfs_install:
  s32i.n  a13, a2, 0
  movi.n  a8, 0
  s32i.n  a8, a2, 4                 ; pad
  l32i.n  a8, a1, 0
  s32i.n  a8, a2, 8
  l32i.n  a8, a1, 4
  s32i.n  a8, a2, 12
  l32i.n  a9, a12, 0
  addi    a9, a9, 1
  s32i.n  a9, a12, 0
msfs_done:
  l32i.n  a15, a1, 28
  l32i.n  a14, a1, 32
  l32i.n  a13, a1, 36
  l32i.n  a12, a1, 40
  l32i.n  a0,  a1, 44
  addi    a1, a1, 48
  ret.n
  .size cssc_map_sf_set, .-cssc_map_sf_set

  .global cssc_map_sf_get
  .type   cssc_map_sf_get, @function
cssc_map_sf_get:
  ; in: a2=hdr, a3=key  out: a2:a3 = f64 (0.0 on miss)
  addi    a1, a1, -32
  s32i.n  a0,  a1, 28
  s32i.n  a12, a1, 24
  s32i.n  a13, a1, 20
  s32i.n  a14, a1, 16
  mov.n   a12, a2
  mov.n   a13, a3
  mov.n   a2, a13
  call0   ._cssc_fnv1a
  l32i.n  a8, a12, 8
  addi    a9, a8, -1
  and     a2, a2, a9
  mov.n   a14, a2
  l32i.n  a10, a12, 16
msfg_probe:
  slli    a11, a2, 4
  add     a3, a10, a11
  l32i.n  a4, a3, 0
  beqz    a4, msfg_miss
  s32i.n  a2, a1, 0
  s32i.n  a3, a1, 4
  mov.n   a2, a4
  mov.n   a3, a13
  call0   cssc_string_eq
  beqz    a2, msfg_next
  l32i.n  a3, a1, 4
  l32i.n  a2, a3, 8
  l32i.n  a3, a3, 12
  j       msfg_ret
msfg_next:
  l32i.n  a2, a1, 0
  l32i.n  a8, a12, 8
  addi    a8, a8, -1
  addi    a2, a2, 1
  and     a2, a2, a8
  bne     a2, a14, msfg_probe
msfg_miss:
  movi.n  a2, 0
  movi.n  a3, 0
msfg_ret:
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .size cssc_map_sf_get, .-cssc_map_sf_get

  .global cssc_map_sf_has
  .type   cssc_map_sf_has, @function
cssc_map_sf_has:
  addi    a1, a1, -32
  s32i.n  a0,  a1, 28
  s32i.n  a12, a1, 24
  s32i.n  a13, a1, 20
  s32i.n  a14, a1, 16
  mov.n   a12, a2
  mov.n   a13, a3
  mov.n   a2, a13
  call0   ._cssc_fnv1a
  l32i.n  a8, a12, 8
  addi    a9, a8, -1
  and     a2, a2, a9
  mov.n   a14, a2
  l32i.n  a10, a12, 16
msfh_probe:
  slli    a11, a2, 4
  add     a3, a10, a11
  l32i.n  a4, a3, 0
  beqz    a4, msfh_miss
  s32i.n  a2, a1, 0
  mov.n   a2, a4
  mov.n   a3, a13
  call0   cssc_string_eq
  beqz    a2, msfh_next
  movi.n  a2, 1
  movi.n  a3, 0
  j       msfh_ret
msfh_next:
  l32i.n  a2, a1, 0
  l32i.n  a8, a12, 8
  addi    a8, a8, -1
  addi    a2, a2, 1
  and     a2, a2, a8
  bne     a2, a14, msfh_probe
msfh_miss:
  movi.n  a2, 0
  movi.n  a3, 0
msfh_ret:
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .size cssc_map_sf_has, .-cssc_map_sf_has

  ; ===========================================================================
  ; map_if — int→f64 hash table. POD values.
  ;
  ; Header (32 B): { i64 size, i64 bucket_cnt, ptr entries, i64 pad }
  ; Entry (24 B): { i64 key, f64 val, i64 state }
  ; state: 0=empty, 1=occupied.
  ; CALL0 ABI: set: a2=m, a4:a5=key, a6:a7=val (f64 same regs as i64)
  ;            get: a2=m, a4:a5=key → a2:a3 = f64
  ; ===========================================================================

  .global cssc_map_if_new
  .type   cssc_map_if_new, @function
cssc_map_if_new:
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  movi.n  a8, 8
  bge     a2, a8, mifn_cap_ok
  movi.n  a2, 8
mifn_cap_ok:
  mov.n   a12, a2
  movi.n  a2, 32
  call0   cssc_obj_alloc
  mov.n   a13, a2
  slli    a2, a12, 3
  slli    a3, a12, 4
  add     a2, a2, a3               ; cnt * 24
  call0   cssc_obj_alloc
  movi.n  a9, 0
  s32i.n  a9,  a13, 0
  s32i.n  a9,  a13, 4
  s32i.n  a12, a13, 8
  s32i.n  a9,  a13, 12
  s32i.n  a2,  a13, 16
  s32i.n  a9,  a13, 20
  mov.n   a2, a13
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_map_if_new, .-cssc_map_if_new

  .global cssc_map_if_free
cssc_map_if_free: ret.n              ; POD val

  .global cssc_map_if_size
  .type   cssc_map_if_size, @function
cssc_map_if_size:
  l32i.n  a8, a2, 0
  l32i.n  a3, a2, 4
  mov.n   a2, a8
  ret.n
  .size cssc_map_if_size, .-cssc_map_if_size

  .global cssc_map_if_set
  .type   cssc_map_if_set, @function
cssc_map_if_set:
  ; in: a2=hdr, a4:a5=key, a6:a7=val (f64)
  addi    a1, a1, -48
  s32i.n  a0,  a1, 44
  s32i.n  a12, a1, 40
  s32i.n  a13, a1, 36
  s32i.n  a14, a1, 32
  s32i.n  a15, a1, 28
  mov.n   a12, a2
  s32i.n  a4, a1, 0
  s32i.n  a5, a1, 4
  s32i.n  a6, a1, 8
  s32i.n  a7, a1, 12
  mov.n   a2, a4
  call0   ._cssc_splitmix32
  l32i.n  a8, a12, 8
  addi    a9, a8, -1
  and     a14, a2, a9
  l32i.n  a15, a12, 16
  mov.n   a13, a14
mifset_probe:
  slli    a8, a13, 3
  slli    a11, a13, 4
  add     a11, a11, a8
  add     a2, a15, a11
  l32i.n  a3, a2, 16
  beqz    a3, mifset_install
  l32i.n  a4, a2, 0
  l32i.n  a5, a2, 4
  l32i.n  a8, a1, 0
  l32i.n  a9, a1, 4
  bne     a4, a8, mifset_advance
  bne     a5, a9, mifset_advance
  l32i.n  a8, a1, 8
  s32i.n  a8, a2, 8
  l32i.n  a8, a1, 12
  s32i.n  a8, a2, 12
  j       mifset_done
mifset_advance:
  l32i.n  a8, a12, 8
  addi    a8, a8, -1
  addi    a13, a13, 1
  and     a13, a13, a8
  bne     a13, a14, mifset_probe
  j       mifset_done
mifset_install:
  l32i.n  a8, a1, 0
  s32i.n  a8, a2, 0
  l32i.n  a8, a1, 4
  s32i.n  a8, a2, 4
  l32i.n  a8, a1, 8
  s32i.n  a8, a2, 8
  l32i.n  a8, a1, 12
  s32i.n  a8, a2, 12
  movi.n  a8, 1
  s32i.n  a8, a2, 16
  l32i.n  a9, a12, 0
  addi    a9, a9, 1
  s32i.n  a9, a12, 0
mifset_done:
  l32i.n  a15, a1, 28
  l32i.n  a14, a1, 32
  l32i.n  a13, a1, 36
  l32i.n  a12, a1, 40
  l32i.n  a0,  a1, 44
  addi    a1, a1, 48
  ret.n
  .size cssc_map_if_set, .-cssc_map_if_set

  .global cssc_map_if_get
  .type   cssc_map_if_get, @function
cssc_map_if_get:
  ; in: a2=hdr, a4:a5=key  out: a2:a3 = f64 val
  addi    a1, a1, -32
  s32i.n  a0,  a1, 28
  s32i.n  a12, a1, 24
  s32i.n  a13, a1, 20
  s32i.n  a14, a1, 16
  mov.n   a12, a2
  s32i.n  a4, a1, 0
  s32i.n  a5, a1, 4
  mov.n   a2, a4
  call0   ._cssc_splitmix32
  l32i.n  a8, a12, 8
  addi    a9, a8, -1
  and     a13, a2, a9
  mov.n   a14, a13
  l32i.n  a10, a12, 16
mifg_probe:
  slli    a8, a13, 3
  slli    a11, a13, 4
  add     a11, a11, a8
  add     a3, a10, a11
  l32i.n  a4, a3, 16
  beqz    a4, mifg_miss
  l32i.n  a5, a3, 0
  l32i.n  a6, a3, 4
  l32i.n  a8, a1, 0
  l32i.n  a9, a1, 4
  bne     a5, a8, mifg_next
  bne     a6, a9, mifg_next
  l32i.n  a2, a3, 8
  l32i.n  a3, a3, 12
  j       mifg_ret
mifg_next:
  l32i.n  a8, a12, 8
  addi    a8, a8, -1
  addi    a13, a13, 1
  and     a13, a13, a8
  bne     a13, a14, mifg_probe
mifg_miss:
  movi.n  a2, 0
  movi.n  a3, 0
mifg_ret:
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .size cssc_map_if_get, .-cssc_map_if_get

  .global cssc_map_if_has
  .type   cssc_map_if_has, @function
cssc_map_if_has:
  addi    a1, a1, -32
  s32i.n  a0,  a1, 28
  s32i.n  a12, a1, 24
  s32i.n  a13, a1, 20
  s32i.n  a14, a1, 16
  mov.n   a12, a2
  s32i.n  a4, a1, 0
  s32i.n  a5, a1, 4
  mov.n   a2, a4
  call0   ._cssc_splitmix32
  l32i.n  a8, a12, 8
  addi    a9, a8, -1
  and     a13, a2, a9
  mov.n   a14, a13
  l32i.n  a10, a12, 16
mifh_probe:
  slli    a8, a13, 3
  slli    a11, a13, 4
  add     a11, a11, a8
  add     a3, a10, a11
  l32i.n  a4, a3, 16
  beqz    a4, mifh_miss
  l32i.n  a5, a3, 0
  l32i.n  a6, a3, 4
  l32i.n  a8, a1, 0
  l32i.n  a9, a1, 4
  bne     a5, a8, mifh_next
  bne     a6, a9, mifh_next
  movi.n  a2, 1
  movi.n  a3, 0
  j       mifh_ret
mifh_next:
  l32i.n  a8, a12, 8
  addi    a8, a8, -1
  addi    a13, a13, 1
  and     a13, a13, a8
  bne     a13, a14, mifh_probe
mifh_miss:
  movi.n  a2, 0
  movi.n  a3, 0
mifh_ret:
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .size cssc_map_if_has, .-cssc_map_if_has

  ; ===========================================================================
  ; bind_ss — ordered (key, value) string-pair list. Simpler than map:
  ; linear probe over an array of pair entries, retains insertion order.
  ; Layout (24 bytes):
  ;   off 0:  i64 size
  ;   off 8:  i64 cap
  ;   off 16: ptr entries (each entry: 8-byte key_ptr + 8-byte val_ptr)
  ; ===========================================================================

  .global cssc_bind_ss_new
  .type   cssc_bind_ss_new, @function
cssc_bind_ss_new:
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  s32i.n  a12, a1, 8
  movi.n  a8, 4
  bge     a2, a8, bs_cap_ok
  movi.n  a2, 4
bs_cap_ok:
  mov.n   a12, a2
  movi.n  a2, 24
  call0   cssc_obj_alloc
  movi.n  a8, 0
  s32i.n  a8, a2, 0
  s32i.n  a8, a2, 4
  s32i.n  a12, a2, 8
  s32i.n  a8, a2, 12
  ; entries buffer (cap * 16 bytes)
  slli    a3, a12, 4
  s32i.n  a2, a1, 0                ; save header
  mov.n   a2, a3
  call0   cssc_obj_alloc
  mov.n   a8, a2                   ; entries ptr
  l32i.n  a2, a1, 0                ; header
  s32i.n  a8, a2, 16
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_bind_ss_new, .-cssc_bind_ss_new

  .global cssc_bind_ss_free
cssc_bind_ss_free: ret.n

  .global cssc_bind_ss_size
cssc_bind_ss_size:
  l32i.n  a8, a2, 0
  l32i.n  a3, a2, 4
  mov.n   a2, a8
  ret.n

  .global cssc_bind_ss_push_back
  .type   cssc_bind_ss_push_back, @function
cssc_bind_ss_push_back:
  ; in: a2 = header, a4 = key, a6 = value (both cssc_str*)
  l32i.n  a8, a2, 0                ; size
  l32i.n  a9, a2, 8                ; cap
  bge     a8, a9, bp_full
  l32i.n  a10, a2, 16              ; entries
  slli    a11, a8, 4               ; size * 16
  add     a11, a10, a11
  s32i.n  a4, a11, 0
  s32i.n  a6, a11, 8
  addi    a8, a8, 1
  s32i.n  a8, a2, 0
bp_full:
  ret.n
  .size cssc_bind_ss_push_back, .-cssc_bind_ss_push_back

  ; ===========================================================================
  ; array<bind> runtime — heterogeneous N-cell tuple array.
  ;
  ; cssc_array_bind layout (16 bytes):
  ;   off 0:  i32 refcount
  ;   off 4:  i32 size
  ;   off 8:  i32 cap
  ;   off 12: ptr entries          -- ptr[size] of cssc_bind_entry*
  ;
  ; cssc_bind_entry layout (16 bytes):
  ;   off 0:  i32 refcount         -- always 1; entries owned by the array
  ;   off 4:  i32 ncells
  ;   off 8:  ptr vals             -- i32[ncells] (LX106 ptrs are 32-bit;
  ;                                   the host's i64 cell collapses to its
  ;                                   low half on Xtensa)
  ;   off 12: ptr tags             -- i8[ncells]
  ;
  ; Builder buffer layout from cssc_array_bind_cells_new(ncells):
  ;   off 0:   i32 ncells
  ;   off 4:   i32 padding
  ;   off 8:   i64 vals[ncells]    -- only lo halves are used on LX106
  ;   off 8+8N: i8 tags[ncells]
  ; ===========================================================================

  .global cssc_array_bind_new
  .type   cssc_array_bind_new, @function
cssc_array_bind_new:
  ; in: a2:a3 = cap_hint (i64); only lo half consulted
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  s32i.n  a12, a1, 8
  movi.n  a8, 4
  bge     a2, a8, ab_capok
  movi.n  a2, 4
ab_capok:
  mov.n   a12, a2                  ; preserve cap
  movi.n  a2, 16                   ; size of header
  call0   cssc_obj_alloc
  movi.n  a8, 1
  s32i.n  a8, a2, 0                ; refcount = 1
  movi.n  a8, 0
  s32i.n  a8, a2, 4                ; size = 0
  s32i.n  a12, a2, 8               ; cap
  s32i.n  a8, a2, 12               ; entries = NULL initially
  ; entries buffer = cap * 4 bytes (one ptr per slot)
  slli    a3, a12, 2
  s32i.n  a2, a1, 0
  mov.n   a2, a3
  call0   cssc_obj_alloc
  mov.n   a8, a2
  l32i.n  a2, a1, 0
  s32i.n  a8, a2, 12
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_array_bind_new, .-cssc_array_bind_new

  .global cssc_array_bind_size
  .type   cssc_array_bind_size, @function
cssc_array_bind_size:
  ; in: a2 = header; out: a2 = size_lo, a3 = 0 (i64 return)
  l32i.n  a2, a2, 4
  movi.n  a3, 0
  ret.n
  .size cssc_array_bind_size, .-cssc_array_bind_size

  ; -------- builder buffer helpers --------

  .global cssc_array_bind_cells_new
  .type   cssc_array_bind_cells_new, @function
cssc_array_bind_cells_new:
  ; in: a2:a3 = ncells (i64); out: a2 = buf ptr
  ;
  ; Builder buffer layout (header + body):
  ;   [+0 ] u32 ncells     ; total flat cell count
  ;   [+4 ] u32 pair_width ; cells per pair (0 = flat array_literal,
  ;                        ; N>0 = structured bind_literal with N
  ;                        ; cells per pair). Default 0 — caller must
  ;                        ; call cssc_array_bind_cells_set_pair_width
  ;                        ; before push_back/from_buf if the literal
  ;                        ; was a `;`-separated bind_literal.
  ;   [+8 ] i64 vals[ncells]
  ;   [+8 + 8*ncells] i8 tags[ncells]
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  s32i.n  a12, a1, 8
  mov.n   a12, a2                  ; ncells -> a12
  ; total bytes = 8 + 8*n + n = 8 + 9*n
  slli    a8, a12, 3               ; 8*n
  add     a8, a8, a12              ; 9*n
  addi    a8, a8, 8                ; 8 + 9*n
  mov.n   a2, a8
  call0   cssc_obj_alloc
  s32i.n  a12, a2, 0               ; store ncells
  movi.n  a8, 0
  s32i.n  a8, a2, 4                ; pair_width = 0 (flat by default)
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_array_bind_cells_new, .-cssc_array_bind_cells_new

  ; Set the pair_width on a builder buffer. Called by the CIR lowering
  ; right after `cells_new` whenever the source literal used the
  ; structured `{k, v; k, v}` form. Idempotent — re-calling overwrites.
  .global cssc_array_bind_cells_set_pair_width
  .type   cssc_array_bind_cells_set_pair_width, @function
cssc_array_bind_cells_set_pair_width:
  ; in: a2 = buf, a4:a5 = pair_width (i64); only lo half consulted
  beqz    a2, abcspw_done
  s32i.n  a4, a2, 4                ; pair_width slot
abcspw_done:
  ret.n
  .size cssc_array_bind_cells_set_pair_width, .-cssc_array_bind_cells_set_pair_width

  .global cssc_array_bind_cells_set_val
  .type   cssc_array_bind_cells_set_val, @function
cssc_array_bind_cells_set_val:
  ; in: a2 = buf, a4:a5 = idx (lo:hi), a6:a7 = val (lo:hi); LX106 uses lo only
  slli    a8, a4, 3                ; idx * 8
  addi    a8, a8, 8                ; +8 header
  add     a8, a2, a8
  s32i.n  a6, a8, 0                ; store val_lo
  s32i.n  a7, a8, 4                ; store val_hi (typically 0)
  ret.n
  .size cssc_array_bind_cells_set_val, .-cssc_array_bind_cells_set_val

  .global cssc_array_bind_cells_set_tag
  .type   cssc_array_bind_cells_set_tag, @function
cssc_array_bind_cells_set_tag:
  ; in: a2 = buf, a4:a5 = idx, a6:a7 = tag; lo halves only
  l32i.n  a8, a2, 0                ; ncells
  slli    a9, a8, 3                ; 8 * ncells
  addi    a9, a9, 8                ; tag_base = 8 + 8*ncells
  add     a9, a2, a9
  add     a9, a9, a4               ; +idx (1 byte/tag)
  s8i     a6, a9, 0                ; store tag_lo byte
  ret.n
  .size cssc_array_bind_cells_set_tag, .-cssc_array_bind_cells_set_tag

  ; -------- push_back: copy builder buf into a fresh entry --------

  .global cssc_array_bind_push_back
  .type   cssc_array_bind_push_back, @function
cssc_array_bind_push_back:
  ; in: a2 = array hdr, a4:a5 = ncells (i64), a6 = builder buf ptr
  ; layout: lo of ncells in a4; preserve callee-saves while we work.
  ;
  ; The bind_entry struct is 20 bytes:
  ;   [+0 ] u32 refcount
  ;   [+4 ] u32 ncells       (total flat cell count)
  ;   [+8 ] ptr vals_i64
  ;   [+12] ptr tags_i8
  ;   [+16] u32 pair_width   (0 = flat / array_literal; N>0 = structured
  ;                            / bind_literal — the `;`-separated form
  ;                            had N cells per pair).
  ; pair_width is sourced from the builder buf's matching slot (+4) so
  ; chained `i[N][M]` access at the lowering layer can compute the right
  ; flat index via `cssc_bind_entry_pair_cell_val(ent, N, M)` without
  ; the compiler having to remember the literal shape at every call site.
  addi    a1, a1, -32
  s32i.n  a0,  a1, 28
  s32i.n  a12, a1, 24              ; array hdr
  s32i.n  a13, a1, 20              ; ncells
  s32i.n  a14, a1, 16              ; builder buf
  s32i.n  a15, a1, 12              ; new entry ptr
  mov.n   a12, a2
  mov.n   a13, a4
  mov.n   a14, a6
  ; allocate entry (20 bytes — includes pair_width)
  movi.n  a2, 20
  call0   cssc_obj_alloc
  mov.n   a15, a2
  movi.n  a8, 1
  s32i.n  a8, a15, 0               ; refcount = 1
  s32i.n  a13, a15, 4              ; ncells
  ; Copy pair_width from builder buf (+4) into entry (+16).
  l32i.n  a8, a14, 4               ; buf.pair_width
  s32i.n  a8, a15, 16              ; entry.pair_width
  ; allocate vals buffer (8 * ncells bytes)
  slli    a2, a13, 3
  call0   cssc_obj_alloc
  s32i.n  a2, a15, 8
  ; allocate tags buffer (ncells bytes)
  mov.n   a2, a13
  call0   cssc_obj_alloc
  s32i.n  a2, a15, 12
  ; --- copy vals (8 * ncells bytes) from builder+8 to entry.vals ---
  l32i.n  a8, a15, 8               ; dst = vals ptr
  addi    a9, a14, 8               ; src = buf + 8 (skip [ncells][pad])
  movi.n  a10, 0                   ; i = 0
  slli    a11, a13, 3              ; nbytes = ncells * 8
abp_vcopy:
  bge     a10, a11, abp_vdone
  add     a3, a9, a10
  l8ui    a4, a3, 0
  add     a3, a8, a10
  s8i     a4, a3, 0
  addi    a10, a10, 1
  j       abp_vcopy
abp_vdone:
  ; --- copy tags (ncells bytes) from builder+8+8*ncells ---
  l32i.n  a8, a15, 12              ; dst = tags ptr
  slli    a9, a13, 3               ; 8*ncells
  addi    a9, a9, 8                ; +8 header
  add     a9, a14, a9              ; src = buf + 8 + 8*ncells
  movi.n  a10, 0
abp_tcopy:
  bge     a10, a13, abp_tdone
  add     a3, a9, a10
  l8ui    a4, a3, 0
  add     a3, a8, a10
  s8i     a4, a3, 0
  addi    a10, a10, 1
  j       abp_tcopy
abp_tdone:
  ; --- append entry-ptr to array.entries ---
  l32i.n  a8, a12, 4               ; size
  l32i.n  a9, a12, 8               ; cap
  bge     a8, a9, abp_no_grow      ; (grow path: do nothing here, drop on the floor)
  l32i.n  a10, a12, 12             ; entries
  slli    a11, a8, 2               ; size * 4
  add     a11, a10, a11
  s32i.n  a15, a11, 0              ; entries[size] = entry
  addi    a8, a8, 1
  s32i.n  a8, a12, 4
abp_no_grow:
  ; free builder buffer (it was the runtime's now)
  mov.n   a2, a14
  call0   cssc_obj_free
  ; --- Scope-pin: the new entry + its vals/tags buffers were
  ; bump-allocated; without pinning, the caller's cssc_scope_pop would
  ; reclaim that memory and the next allocation (e.g. a transient
  ; string in the next tick) would overwrite our entries[size].
  ; Mirrors cssc_array_bind_push_entry's abpe_pin block.
  l32r    a8, .Labp_scope_sp_addr
  l32i.n  a9, a8, 0
  beqz    a9, abp_pin_done
  addi    a9, a9, -1
  l32r    a10, .Labp_scope_stack_addr
  slli    a9, a9, 2
  add     a10, a10, a9
  l32r    a8, .Labp_arena_off_addr
  l32i.n  a8, a8, 0
  s32i.n  a8, a10, 0
abp_pin_done:
  ; restore + return
  l32i.n  a15, a1, 12
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .literal_position
  .literal .Labp_arena_off_addr,   cssc_arena_off
  .literal .Labp_scope_sp_addr,    cssc_scope_sp
  .literal .Labp_scope_stack_addr, cssc_scope_stack
  .size cssc_array_bind_push_back, .-cssc_array_bind_push_back

  ; -------- retain / release / clear --------

  ; ---- bind_entry: standalone heterogeneous record ----
  ; Builds a cssc_bind_entry from a builder buffer (cells_new layout).
  ; Frame: a0@28, a12@24=ncells, a13@20=buf, a14@16=entry, a15@12=vals.
  .global cssc_bind_entry_from_buf
  .type   cssc_bind_entry_from_buf, @function
cssc_bind_entry_from_buf:
  ; in: a2:a3 = n (i64; only lo half consulted), a4 = buf (ptr)
  ;
  ; Argument-register placement follows the CSSC-Xtensa CALL0
  ; convention: every i64 arg occupies 2 registers, every ptr
  ; (or smaller scalar) occupies 1. So for `(n: i64, buf: ptr)`
  ; n lands in a2:a3 and buf in a4. A previous version of this
  ; runtime read buf from a6, which silently aliased to whatever
  ; the caller had spilled in that register — typically the byte
  ; count or tag of the LAST cell, producing a tiny integer value
  ; (e.g. 0xb) that subsequently got dereferenced in `bef_vcopy`
  ; and crashed at excvaddr=0xb. (`Buffer.push_back(&localmap)`
  ; in user code surfaces this every time a heap-bind pushes
  ; into an array<bind>.) Read from a4 instead.
  addi    a1, a1, -32
  s32i.n  a0,  a1, 28
  s32i.n  a12, a1, 24
  s32i.n  a13, a1, 20
  s32i.n  a14, a1, 16
  s32i.n  a15, a1, 12
  mov.n   a12, a2                   ; n -> a12
  mov.n   a13, a4                   ; buf -> a13
  ; allocate entry (20 bytes — includes pair_width at +16)
  movi.n  a2, 20
  call0   cssc_obj_alloc
  mov.n   a14, a2                   ; entry ptr
  movi.n  a8, 1
  s32i.n  a8, a14, 0                ; refcount = 1
  s32i.n  a12, a14, 4               ; ncells
  ; Copy pair_width from builder buf (+4) into entry (+16). For
  ; array_literal sources this stays 0 (cells_new init); for
  ; bind_literal the lowering called set_pair_width earlier.
  l32i.n  a8, a13, 4                ; buf.pair_width
  s32i.n  a8, a14, 16               ; entry.pair_width
  ; allocate vals (8*n)
  slli    a2, a12, 3
  call0   cssc_obj_alloc
  mov.n   a15, a2                   ; vals ptr
  s32i.n  a15, a14, 8
  ; allocate tags (n)
  mov.n   a2, a12
  call0   cssc_obj_alloc
  s32i.n  a2, a14, 12               ; tags ptr; reuse a2 below
  ; copy vals: 8*n bytes from buf+8 to vals
  mov.n   a3, a2                    ; tags ptr stashed in a3 for after
  addi    a9, a13, 8                ; src = buf + 8
  mov.n   a8, a15                   ; dst = vals
  slli    a10, a12, 3               ; nbytes = 8*n
  movi.n  a11, 0                    ; i
bef_vcopy:
  bge     a11, a10, bef_vdone
  add     a4, a9, a11
  l8ui    a5, a4, 0
  add     a4, a8, a11
  s8i     a5, a4, 0
  addi    a11, a11, 1
  j       bef_vcopy
bef_vdone:
  ; copy tags: n bytes from buf+8+8*n to tags
  slli    a9, a12, 3                ; 8*n
  addi    a9, a9, 8                 ; +8
  add     a9, a13, a9               ; src
  mov.n   a8, a3                    ; dst = tags
  movi.n  a11, 0
bef_tcopy:
  bge     a11, a12, bef_tdone
  add     a4, a9, a11
  l8ui    a5, a4, 0
  add     a4, a8, a11
  s8i     a5, a4, 0
  addi    a11, a11, 1
  j       bef_tcopy
bef_tdone:
  ; free buf, return entry
  mov.n   a2, a13
  call0   cssc_obj_free
  ; --- Scope-pin: the entry + vals + tags allocations all live on the
  ; bump arena. Pin them to the caller's scope so the next
  ; cssc_scope_pop doesn't reclaim them. Without this, a heap-bind
  ; literal (`#heap[bind, N] m = {a, b; c, d};`) silently has its
  ; cells overwritten by the next allocation in the same label body.
  l32r    a8, .Lbef_scope_sp_addr
  l32i.n  a9, a8, 0
  beqz    a9, bef_pin_done
  addi    a9, a9, -1
  l32r    a10, .Lbef_scope_stack_addr
  slli    a9, a9, 2
  add     a10, a10, a9
  l32r    a8, .Lbef_arena_off_addr
  l32i.n  a8, a8, 0
  s32i.n  a8, a10, 0
bef_pin_done:
  mov.n   a2, a14                   ; return entry
  l32i.n  a15, a1, 12
  l32i.n  a14, a1, 16
  l32i.n  a13, a1, 20
  l32i.n  a12, a1, 24
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .literal_position
  .literal .Lbef_arena_off_addr,   cssc_arena_off
  .literal .Lbef_scope_sp_addr,    cssc_scope_sp
  .literal .Lbef_scope_stack_addr, cssc_scope_stack
  .size cssc_bind_entry_from_buf, .-cssc_bind_entry_from_buf

  ; ---- push_entry: clone bind_entry into array_bind ----
  .global cssc_array_bind_push_entry
  .type   cssc_array_bind_push_entry, @function
cssc_array_bind_push_entry:
  ; in: a2 = array hdr (ptr), a3 = source bind_entry (ptr)
  ;
  ; CSSC-Xtensa CALL0 convention treats each ptr arg as occupying a
  ; single register. With two ptr args back-to-back the second goes in
  ; a3 (immediately after a2), NOT in a4. (Compare cssc_array_bind_
  ; push_back which has signature `(arr, ncells: i64, buf)`: the i64
  ; consumes a4:a5, so buf ends up in a6 — that one's correct as
  ; declared. The bug is purely in the ptr-ptr signature here.) A
  ; previous version of this runtime expected the source entry in a4,
  ; which meant `Buffer.push_back(&localmap)` got garbage (whatever
  ; the caller had set up for the next callee or left in a4 from a
  ; previous l32i) and either dropped silently (`beqz a4` matched 0)
  ; or cloned a bogus entry whose `vals`/`tags` offsets pointed at
  ; freed/unmapped memory.
  addi    a1, a1, -48
  s32i.n  a0,  a1, 44
  s32i.n  a12, a1, 40               ; array hdr
  s32i.n  a13, a1, 36               ; source entry
  s32i.n  a14, a1, 32               ; new entry ptr
  s32i.n  a15, a1, 28               ; n (ncells)
  ; Inner-loop spill slots at +0..+15 (16 bytes for four 32-bit
  ; values: i, tags ptr, vals ptr, &vals[i] for cssc_string_copy
  ; write-back). Bumped frame from 32 to 48 to fit the extra slot.
  beqz    a2, abpe_done
  beqz    a3, abpe_done
  mov.n   a12, a2
  mov.n   a13, a3
  l32i.n  a15, a13, 4               ; n = src.ncells
  ; allocate new entry (20 bytes — includes pair_width)
  movi.n  a2, 20
  call0   cssc_obj_alloc
  mov.n   a14, a2
  movi.n  a8, 1
  s32i.n  a8, a14, 0                ; refcount = 1
  s32i.n  a15, a14, 4                ; ncells = src.ncells
  ; Copy pair_width from src entry (+16) → dst entry (+16). Clones
  ; preserve the literal shape so chained `i[N][M]` semantics carry
  ; through Buffer.push_back(handle) the same as direct push_back.
  l32i.n  a8, a13, 16               ; src.pair_width
  s32i.n  a8, a14, 16               ; dst.pair_width
  ; allocate dst vals (8*n)
  slli    a2, a15, 3
  call0   cssc_obj_alloc
  s32i.n  a2, a14, 8
  ; allocate dst tags (n)
  mov.n   a2, a15
  call0   cssc_obj_alloc
  s32i.n  a2, a14, 12
  ; copy vals
  l32i.n  a8, a14, 8                ; dst vals
  l32i.n  a9, a13, 8                ; src vals
  slli    a10, a15, 3
  movi.n  a11, 0
abpe_vcopy:
  bge     a11, a10, abpe_vdone
  add     a4, a9, a11
  l8ui    a5, a4, 0
  add     a4, a8, a11
  s8i     a5, a4, 0
  addi    a11, a11, 1
  j       abpe_vcopy
abpe_vdone:
  ; copy tags
  l32i.n  a8, a14, 12               ; dst tags
  l32i.n  a9, a13, 12               ; src tags
  movi.n  a11, 0
abpe_tcopy:
  bge     a11, a15, abpe_tdone
  add     a4, a9, a11
  l8ui    a5, a4, 0
  add     a4, a8, a11
  s8i     a5, a4, 0
  addi    a11, a11, 1
  j       abpe_tcopy
abpe_tdone:
  ; Deep-clone string cells (tag == 3) instead of merely retaining
  ; them. Background: the source cssc_str header + its byte data
  ; live in the caller-label's arena scope (e.g. addframe's
  ; #heap[bind, 328] localmap built `{&y, &displaytxt}` which
  ; cssc_string_copy'd displaytxt into addframe's scope). A bare
  ; `cssc_retain` only bumps the refcount field — the BYTES are
  ; still at their original arena offset. When addframe's
  ; scope_pop rolls the cursor back, subsequent allocations
  ; overwrite those bytes; the array's clone still points at
  ; the same offset and reads back garbage on later iterations.
  ;
  ; The fix: for each STRING cell, run cssc_string_copy on the
  ; source ptr — that makes a fresh cssc_str + new byte copy
  ; in the current arena position. The fresh allocation gets
  ; pinned to the caller's scope by the `abpe_pin` block below,
  ; so it survives even when the original source memory is
  ; reused. Stash the new ptr back into the cloned vals[i] so
  ; later reads of `entry.vals[i]` find the durable copy.
  l32i.n  a8, a14, 12               ; tags
  l32i.n  a9, a14, 8                ; vals
  movi.n  a11, 0
abpe_rloop:
  bge     a11, a15, abpe_rdone
  add     a4, a8, a11
  l8ui    a5, a4, 0
  movi.n  a6, 3
  bne     a5, a6, abpe_rstep
  slli    a4, a11, 3
  add     a4, a9, a4                ; &vals[i]
  l32i.n  a2, a4, 0                 ; source string ptr
  s32i.n  a11, a1, 0                ; spill i
  s32i.n  a8, a1, 4                 ; spill tags ptr
  s32i.n  a9, a1, 8                 ; spill vals ptr
  s32i.n  a4, a1, 12                ; spill &vals[i] for post-call write-back
  call0   cssc_string_copy          ; a2 ← fresh cssc_str* (deep copy)
  l32i.n  a4, a1, 12                ; restore &vals[i]
  s32i.n  a2, a4, 0                 ; vals[i] = fresh ptr (overwrite the
                                    ;   src ptr we byte-copied earlier)
  l32i.n  a11, a1, 0
  l32i.n  a8, a1, 4
  l32i.n  a9, a1, 8
abpe_rstep:
  addi    a11, a11, 1
  j       abpe_rloop
abpe_rdone:
  ; append a14 (new entry) to array entries[]
  l32i.n  a8, a12, 4                ; size
  l32i.n  a9, a12, 8                ; cap
  bge     a8, a9, abpe_pin          ; full → drop on the floor (mirrors push_back)
  l32i.n  a10, a12, 12              ; entries ptr
  slli    a11, a8, 2
  add     a11, a10, a11
  s32i.n  a14, a11, 0
  addi    a8, a8, 1
  s32i.n  a8, a12, 4
abpe_pin:
  ; --- Pin allocations to caller's scope ---
  ;
  ; The entry struct + its vals/tags arrays we just allocated via
  ; cssc_obj_alloc are bump-allocated. The cursor has advanced past
  ; them. But push_entry is typically called from a label-method
  ; (e.g. `cssc_obj_VideoDriver_addframe`) which runs inside its own
  ; arena scope. When THAT label returns, its `cssc_scope_pop`
  ; restores the arena cursor to the value saved at the label's
  ; entry — which is BELOW where our entry/vals/tags now live.
  ; Subsequent allocations (e.g. transient strings during the next
  ; tick) overwrite our memory, so `array.entries[i]` ends up
  ; pointing at stale data. The user-visible symptom is `i[0]`/`i[1]`
  ; reading garbage from `entry.vals_ptr` — typically a small int
  ; like 0x1 (refcount byte of an overwriting cssc_str), and the
  ; subsequent `l32i a2, a10, 0` faults with excvaddr=0x1.
  ;
  ; Fix: write the current cursor back into the TOP of the scope
  ; stack. That "promotes" our allocations from the most-recently-
  ; pushed scope to before-our-allocations — effectively rebasing
  ; the caller's scope_pop target so it preserves what we wrote.
  ; If sp==0 (no scope active) this is a no-op.
  l32r    a8, .Lpe_scope_sp_addr
  l32i.n  a9, a8, 0                 ; sp
  beqz    a9, abpe_done             ; no scope active → nothing to pin to
  addi    a9, a9, -1                ; sp-1 (top entry)
  l32r    a10, .Lpe_scope_stack_addr
  slli    a9, a9, 2
  add     a10, a10, a9              ; &stack[sp-1]
  l32r    a8, .Lpe_arena_off_addr
  l32i.n  a8, a8, 0                 ; current cursor (post-our-allocs)
  s32i.n  a8, a10, 0                ; stack[sp-1] = current cursor
abpe_done:
  l32i.n  a15, a1, 28
  l32i.n  a14, a1, 32
  l32i.n  a13, a1, 36
  l32i.n  a12, a1, 40
  l32i.n  a0,  a1, 44
  addi    a1, a1, 48
  ret.n
  .literal_position
  .literal .Lpe_arena_off_addr,   cssc_arena_off
  .literal .Lpe_scope_sp_addr,    cssc_scope_sp
  .literal .Lpe_scope_stack_addr, cssc_scope_stack
  .size cssc_array_bind_push_entry, .-cssc_array_bind_push_entry

  ; ---- select-iteration helpers ----
  ; `cssc_array_bind_get_entry(arr, i)` — entries[i] or NULL
  .global cssc_array_bind_get_entry
  .type   cssc_array_bind_get_entry, @function
cssc_array_bind_get_entry:
  ; in: a2 = array hdr, a4:a5 = i (lo)
  beqz    a2, abge_null
  l32i.n  a8, a2, 4                 ; size
  bgeu    a4, a8, abge_null
  l32i.n  a9, a2, 12                ; entries ptr
  slli    a10, a4, 2
  add     a10, a9, a10
  l32i.n  a2, a10, 0                ; entries[i]
  movi.n  a3, 0
  ret.n
abge_null:
  movi.n  a2, 0
  movi.n  a3, 0
  ret.n
  .size cssc_array_bind_get_entry, .-cssc_array_bind_get_entry

  ; `cssc_bind_entry_cell_int(ent, i)` — vals[i] as i64 (lo:hi pair)
  .global cssc_bind_entry_cell_int
  .type   cssc_bind_entry_cell_int, @function
cssc_bind_entry_cell_int:
  ; in: a2 = entry, a4:a5 = i (lo); out: a2:a3 = i64
  beqz    a2, beci_zero
  l32i.n  a8, a2, 4
  bgeu    a4, a8, beci_zero
  l32i.n  a9, a2, 8                 ; vals ptr
  slli    a10, a4, 3                ; 8*i
  add     a10, a9, a10
  l32i.n  a2, a10, 0                ; lo
  l32i.n  a3, a10, 4                ; hi
  ret.n
beci_zero:
  movi.n  a2, 0
  movi.n  a3, 0
  ret.n
  .size cssc_bind_entry_cell_int, .-cssc_bind_entry_cell_int

  ; `cssc_bind_entry_cell_val(ent, i)` — vals[i] (raw bits) or NULL
  .global cssc_bind_entry_cell_val
  .type   cssc_bind_entry_cell_val, @function
cssc_bind_entry_cell_val:
  ; in: a2 = entry, a4:a5 = i (lo)
  beqz    a2, becv_null
  l32i.n  a8, a2, 4                 ; ncells
  bgeu    a4, a8, becv_null
  l32i.n  a9, a2, 8                 ; vals ptr (i64 array — we take lo 32 bits)
  slli    a10, a4, 3                ; 8*i
  add     a10, a9, a10
  l32i.n  a2, a10, 0                ; vals[i] lo
  movi.n  a3, 0
  ret.n
becv_null:
  movi.n  a2, 0
  movi.n  a3, 0
  ret.n
  .size cssc_bind_entry_cell_val, .-cssc_bind_entry_cell_val

  ; `cssc_bind_entry_pair_width(ent)` — read entry.pair_width. Returns 0
  ; for array_literal-shaped binds (flat access expected) and N>0 for
  ; bind_literal-shaped binds (structured access via `i[row][col]`
  ; lowered to vals[row * pair_width + col]). NULL-safe.
  .global cssc_bind_entry_pair_width
  .type   cssc_bind_entry_pair_width, @function
cssc_bind_entry_pair_width:
  ; in: a2 = entry; out: a2:a3 = pair_width (i64, lo:hi)
  beqz    a2, bepw_zero
  l32i.n  a2, a2, 16                ; entry.pair_width
  movi.n  a3, 0
  ret.n
bepw_zero:
  movi.n  a2, 0
  movi.n  a3, 0
  ret.n
  .size cssc_bind_entry_pair_width, .-cssc_bind_entry_pair_width

  ; `cssc_bind_entry_pair_cell_val(ent, row, col)` — structured access:
  ;   returns vals[row * pair_width + col] (lo 32 bits as ptr).
  ; If pair_width == 0 (flat bind), treats `row` as the flat index and
  ; ignores `col` — this lets chained access against a flat array_literal
  ; degrade gracefully to `i[row]` semantics rather than corrupting.
  ; NULL-safe. Out-of-range → NULL.
  .global cssc_bind_entry_pair_cell_val
  .type   cssc_bind_entry_pair_cell_val, @function
cssc_bind_entry_pair_cell_val:
  ; in: a2 = entry, a4:a5 = row (i64 lo), a6:a7 = col (i64 lo)
  ; out: a2 = vals[row * pw + col] (lo 32 bits)
  ;
  ; Frame: 16 B — needed because we call0 __mulsi3 (callee-clobbers
  ; a8..a11) and want to preserve a4/a6 across the multiply.
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  beqz    a2, becvp_null
  mov.n   a12, a2                   ; entry stashed for after multiply
  l32i.n  a8, a2, 16                ; pair_width
  bnez    a8, becvp_mul
  ; Flat path — pair_width == 0. Use row as the flat idx, ignore col.
  mov.n   a13, a4
  j       becvp_lookup
becvp_mul:
  ; Compute row * pair_width via __mulsi3 (libgcc thunk). LX106 has no
  ; native 32-bit multiplier; __mulsi3 takes (a2, a3) and returns a2.
  mov.n   a2, a4                    ; lhs = row
  mov.n   a3, a8                    ; rhs = pair_width
  call0   __mulsi3                  ; a2 = row * pair_width
  add     a13, a2, a6               ; a13 = row * pw + col
becvp_lookup:
  ; Bounds-check a13 against ncells.
  l32i.n  a8, a12, 4                ; ncells
  bgeu    a13, a8, becvp_null
  l32i.n  a9, a12, 8                ; vals ptr
  slli    a10, a13, 3               ; 8 * idx
  add     a10, a9, a10
  l32i.n  a2, a10, 0                ; vals[idx] lo
  movi.n  a3, 0
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
becvp_null:
  movi.n  a2, 0
  movi.n  a3, 0
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_bind_entry_pair_cell_val, .-cssc_bind_entry_pair_cell_val

  ; `cssc_bind_entry_pair_cell_int(ent, row, col)` — same as pair_cell_val
  ; but returns the full 64-bit cell value (lo:hi) suitable for int
  ; cells. Used by chained `i[row][col]` reads where the destination
  ; slot is an int slot.
  .global cssc_bind_entry_pair_cell_int
  .type   cssc_bind_entry_pair_cell_int, @function
cssc_bind_entry_pair_cell_int:
  ; in: a2 = entry, a4:a5 = row (i64 lo), a6:a7 = col (i64 lo)
  ; out: a2:a3 = i64 cell value
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  beqz    a2, becip_null
  mov.n   a12, a2                   ; entry stashed
  l32i.n  a8, a2, 16                ; pair_width
  bnez    a8, becip_mul
  ; Flat path.
  mov.n   a13, a4
  j       becip_lookup
becip_mul:
  mov.n   a2, a4
  mov.n   a3, a8
  call0   __mulsi3
  add     a13, a2, a6
becip_lookup:
  l32i.n  a8, a12, 4                ; ncells
  bgeu    a13, a8, becip_null
  l32i.n  a9, a12, 8                ; vals ptr
  slli    a10, a13, 3
  add     a10, a9, a10
  l32i.n  a2, a10, 0                ; lo
  l32i.n  a3, a10, 4                ; hi
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
becip_null:
  movi.n  a2, 0
  movi.n  a3, 0
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_bind_entry_pair_cell_int, .-cssc_bind_entry_pair_cell_int

  ; `cssc_bind_entry_cell_set(ent, idx, val_i64)` — flat-index write.
  ; Stores the raw 64-bit value at vals[idx]; tag is left UNCHANGED.
  ; NULL-safe + bounds-checked silent-ignore.
  .global cssc_bind_entry_cell_set
  .type   cssc_bind_entry_cell_set, @function
cssc_bind_entry_cell_set:
  ; in: a2 = entry, a4:a5 = idx (lo:hi), a6:a7 = val (lo:hi)
  beqz    a2, becs_done
  l32i.n  a8, a2, 4                 ; ncells
  bgeu    a4, a8, becs_done
  l32i.n  a9, a2, 8                 ; vals ptr
  slli    a10, a4, 3                ; 8 * idx
  add     a10, a9, a10
  s32i.n  a6, a10, 0                ; vals[idx] lo
  s32i.n  a7, a10, 4                ; vals[idx] hi
becs_done:
  ret.n
  .size cssc_bind_entry_cell_set, .-cssc_bind_entry_cell_set

  ; `cssc_bind_entry_pair_cell_set(ent, row, col, val_i64)` — structured
  ; write at vals[row * pair_width + col]. If pair_width == 0 the entry
  ; is flat — fall back to row as the linear index and ignore col.
  ; Tag UNCHANGED. NULL-safe + bounds-checked silent-ignore.
  .global cssc_bind_entry_pair_cell_set
  .type   cssc_bind_entry_pair_cell_set, @function
cssc_bind_entry_pair_cell_set:
  ; in: a2 = entry, a4:a5 = row, a6:a7 = col, a8:a9 = val
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8                ; stash entry across __mulsi3
  s32i.n  a13, a1, 4                ; stash val.lo
  s32i.n  a14, a1, 0                ; stash val.hi
  beqz    a2, becps_done
  mov.n   a12, a2                   ; entry
  mov.n   a13, a8                   ; val.lo
  mov.n   a14, a9                   ; val.hi
  l32i.n  a10, a12, 16              ; pair_width
  bnez    a10, becps_mul
  ; Flat path: idx = row, ignore col.
  mov.n   a11, a4
  j       becps_lookup
becps_mul:
  mov.n   a2, a4                    ; lhs = row
  mov.n   a3, a10                   ; rhs = pair_width
  call0   __mulsi3                  ; a2 = row * pair_width
  add     a11, a2, a6               ; a11 = idx = row*pw + col
becps_lookup:
  l32i.n  a10, a12, 4               ; ncells
  bgeu    a11, a10, becps_done
  l32i.n  a9, a12, 8                ; vals ptr
  slli    a8, a11, 3                ; 8 * idx
  add     a8, a9, a8                ; &vals[idx]
  s32i.n  a13, a8, 0                ; vals[idx] lo
  s32i.n  a14, a8, 4                ; vals[idx] hi
becps_done:
  l32i.n  a14, a1, 0
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_bind_entry_pair_cell_set, .-cssc_bind_entry_pair_cell_set

  .global cssc_array_bind_retain
  .type   cssc_array_bind_retain, @function
cssc_array_bind_retain:
  ; in: a2 = array; bumps refcount, no-op on null
  beqz    a2, abr_done
  l32i.n  a8, a2, 0
  addi    a8, a8, 1
  s32i.n  a8, a2, 0
abr_done:
  ret.n
  .size cssc_array_bind_retain, .-cssc_array_bind_retain

  .global cssc_bind_entry_free
  .type   cssc_bind_entry_free, @function
cssc_bind_entry_free:
  ; in: a2 = entry ptr; releases string cells, frees vals/tags/entry.
  ; frame layout (32 B): +0 spill_i, +4 free, +8 a14, +12 a13, +16 a12, +20 tags,
  ;                      +24 reserved, +28 a0
  addi    a1, a1, -32
  s32i.n  a0,  a1, 28
  s32i.n  a12, a1, 16
  s32i.n  a13, a1, 12
  s32i.n  a14, a1, 8
  beqz    a2, abef_done_pop
  mov.n   a12, a2                  ; entry
  l32i.n  a13, a12, 4              ; ncells
  l32i.n  a14, a12, 8              ; vals ptr
  l32i.n  a3,  a12, 12             ; tags ptr
  s32i.n  a3,  a1, 20              ; spill tags ptr
  movi.n  a8, 0                    ; i = 0
abef_loop:
  bge     a8, a13, abef_tail
  ; load tag[i]
  l32i.n  a3,  a1, 20
  add     a9, a3, a8
  l8ui    a10, a9, 0
  movi.n  a11, 3                   ; tag STRING
  bne     a10, a11, abef_step
  ; release string ptr at vals[i] (lo half)
  slli    a9, a8, 3
  add     a9, a14, a9
  l32i.n  a2, a9, 0
  s32i.n  a8, a1, 0                ; spill i in frame
  call0   cssc_release
  l32i.n  a8, a1, 0                ; restore i
abef_step:
  addi    a8, a8, 1
  j       abef_loop
abef_tail:
  ; free vals + tags + entry
  mov.n   a2, a14
  call0   cssc_obj_free
  l32i.n  a2, a1, 20               ; tags ptr (spilled)
  call0   cssc_obj_free
  mov.n   a2, a12
  call0   cssc_obj_free
abef_done_pop:
  l32i.n  a14, a1, 8
  l32i.n  a13, a1, 12
  l32i.n  a12, a1, 16
  l32i.n  a0,  a1, 28
  addi    a1, a1, 32
  ret.n
  .size cssc_bind_entry_free, .-cssc_bind_entry_free

  .global cssc_array_bind_release
  .type   cssc_array_bind_release, @function
cssc_array_bind_release:
  ; in: a2 = array hdr; dec refcount, free on 0 (releases entries).
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  beqz    a2, abrel_done_pop
  mov.n   a12, a2
  l32i.n  a8, a12, 0
  addi    a8, a8, -1
  s32i.n  a8, a12, 0
  bnez    a8, abrel_done_pop       ; refcount > 0 → defer
  ; refcount == 0 → free entries, then array
  l32i.n  a13, a12, 4              ; size
  l32i.n  a3,  a12, 12             ; entries
  movi.n  a8, 0
abrel_loop:
  bge     a8, a13, abrel_tail
  s32i.n  a8, a1, 0                ; spill i (entries iterator)
  slli    a9, a8, 2
  add     a9, a3, a9
  l32i.n  a2, a9, 0                ; entries[i]
  call0   cssc_bind_entry_free
  l32i.n  a8, a1, 0
  addi    a8, a8, 1
  j       abrel_loop
abrel_tail:
  l32i.n  a2, a12, 12              ; entries ptr
  call0   cssc_obj_free
  mov.n   a2, a12
  call0   cssc_obj_free
abrel_done_pop:
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_array_bind_release, .-cssc_array_bind_release

  .global cssc_array_bind_clear
  .type   cssc_array_bind_clear, @function
cssc_array_bind_clear:
  ; in: a2 = array; free each entry, reset size to 0.
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  beqz    a2, abc_done_pop
  mov.n   a12, a2
  l32i.n  a13, a12, 4              ; size
  l32i.n  a3,  a12, 12             ; entries
  movi.n  a8, 0
abc_loop:
  bge     a8, a13, abc_tail
  s32i.n  a8, a1, 0
  slli    a9, a8, 2
  add     a9, a3, a9
  l32i.n  a2, a9, 0
  call0   cssc_bind_entry_free
  l32i.n  a8, a1, 0
  addi    a8, a8, 1
  j       abc_loop
abc_tail:
  movi.n  a8, 0
  s32i.n  a8, a12, 4               ; size = 0
abc_done_pop:
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_array_bind_clear, .-cssc_array_bind_clear

  ; -------- bit-cast / zext helpers (used by bind cell lowering) --------

  .global __cssc_bitcast_ptr_i64
  .type   __cssc_bitcast_ptr_i64, @function
__cssc_bitcast_ptr_i64:
  ; in: a2 = ptr (32-bit); out: a2:a3 = i64 zero-extended
  movi.n  a3, 0
  ret.n
  .size __cssc_bitcast_ptr_i64, .-__cssc_bitcast_ptr_i64

  .global __cssc_bitcast_f64_i64
  .type   __cssc_bitcast_f64_i64, @function
__cssc_bitcast_f64_i64:
  ; in: a2:a3 = f64 bits (already a pair on LX106 softfloat); out: a2:a3
  ret.n
  .size __cssc_bitcast_f64_i64, .-__cssc_bitcast_f64_i64

  .global __cssc_bitcast_i64_f64
  .type   __cssc_bitcast_i64_f64, @function
__cssc_bitcast_i64_f64:
  ; in: a2:a3 = i64 bits; out: a2:a3 = f64. On LX106 the softfloat ABI
  ; carries doubles as two i32s in the same register pair, so this is
  ; a no-op move at the asm level.
  ret.n
  .size __cssc_bitcast_i64_f64, .-__cssc_bitcast_i64_f64

  .global __cssc_zext_i32_i64
  .type   __cssc_zext_i32_i64, @function
__cssc_zext_i32_i64:
  ; in: a2 = i32 value; out: a2:a3 = i64 zero-extended
  movi.n  a3, 0
  ret.n
  .size __cssc_zext_i32_i64, .-__cssc_zext_i32_i64

  .global __cssc_zext_i1_i64
  .type   __cssc_zext_i1_i64, @function
__cssc_zext_i1_i64:
  ; in: a2 = bool (0/1); out: a2:a3 = i64 zero-extended
  movi.n  a3, 0
  ret.n
  .size __cssc_zext_i1_i64, .-__cssc_zext_i1_i64

  .global __cssc_int_to_ptr
  .type   __cssc_int_to_ptr, @function
__cssc_int_to_ptr:
  ; in: a2:a3 = i64 (lo:hi); LX106 ptr is 32-bit so we keep lo only
  ret.n
  .size __cssc_int_to_ptr, .-__cssc_int_to_ptr

  ; ===========================================================================
  ; #delmember runtime helpers — release one or every entry's heap
  ; content while keeping the container's size/cap intact. The "_at"
  ; variants take a 64-bit index in (a4:a5) following the CALL0 i64
  ; pair-passing convention; LX106 collapses to the low half (a4) since
  ; sizes never exceed 2^31 on the 80 KiB SRAM chip.
  ; ===========================================================================

  .global cssc_array_bind_null_at
  .type   cssc_array_bind_null_at, @function
cssc_array_bind_null_at:
  ; in: a2 = array hdr, a4:a5 = i (i64)
  addi    a1, a1, -16
  s32i.n  a0, a1, 12
  s32i.n  a12, a1, 8
  beqz    a2, abnat_done
  mov.n   a12, a4                   ; i
  l32i.n  a8, a2, 4                 ; size
  bgeu    a12, a8, abnat_done
  l32i.n  a9, a2, 12                ; entries ptr
  slli    a10, a12, 2               ; i * 4
  add     a10, a9, a10
  l32i.n  a3, a10, 0                ; entries[i]
  ; spill a10 (slot ptr) so we can restore it after the call
  s32i.n  a10, a1, 4
  mov.n   a2, a3
  call0   cssc_bind_entry_free
  l32i.n  a10, a1, 4
  movi.n  a8, 0
  s32i.n  a8, a10, 0                ; entries[i] = NULL
abnat_done:
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_array_bind_null_at, .-cssc_array_bind_null_at

  .global cssc_array_bind_null_all
  .type   cssc_array_bind_null_all, @function
cssc_array_bind_null_all:
  ; in: a2 = array hdr
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  beqz    a2, abnal_done
  mov.n   a12, a2
  l32i.n  a13, a12, 4               ; size
  l32i.n  a3,  a12, 12              ; entries ptr
  movi.n  a8, 0
abnal_loop:
  bge     a8, a13, abnal_done
  s32i.n  a8, a1, 0                 ; spill i
  slli    a9, a8, 2
  add     a9, a3, a9
  l32i.n  a2, a9, 0
  s32i.n  a9, a1, 4                 ; spill slot ptr
  call0   cssc_bind_entry_free
  l32i.n  a9, a1, 4
  movi.n  a10, 0
  s32i.n  a10, a9, 0                ; entries[i] = NULL
  l32i.n  a8, a1, 0
  addi    a8, a8, 1
  j       abnal_loop
abnal_done:
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_array_bind_null_all, .-cssc_array_bind_null_all

  ; ---- vector<int> ----
  ; Layout (24 bytes header): { i64 size, i64 cap, ptr data }. LX106
  ; treats i64 as low+high i32 pair stored at offsets 0/4 and 8/12.

  .global cssc_vector_int_null_at
  .type   cssc_vector_int_null_at, @function
cssc_vector_int_null_at:
  ; in: a2 = vec, a4:a5 = i (use lo half)
  beqz    a2, vinat_done
  l32i.n  a8, a2, 0                 ; size_lo (i64 lo)
  bgeu    a4, a8, vinat_done
  l32i.n  a9, a2, 16                ; data ptr
  slli    a10, a4, 3                ; i * 8
  add     a10, a9, a10
  movi.n  a8, 0
  s32i.n  a8, a10, 0
  s32i.n  a8, a10, 4
vinat_done:
  ret.n
  .size cssc_vector_int_null_at, .-cssc_vector_int_null_at

  .global cssc_vector_int_null_all
  .type   cssc_vector_int_null_all, @function
cssc_vector_int_null_all:
  ; in: a2 = vec — zero data[0..size*8)
  beqz    a2, vinal_done
  l32i.n  a8, a2, 0                 ; size
  l32i.n  a9, a2, 16                ; data ptr
  slli    a8, a8, 3                 ; size * 8
  movi.n  a10, 0
vinal_loop:
  beqz    a8, vinal_done
  s8i     a10, a9, 0
  addi    a9, a9, 1
  addi    a8, a8, -1
  j       vinal_loop
vinal_done:
  ret.n
  .size cssc_vector_int_null_all, .-cssc_vector_int_null_all

  .global cssc_vector_float_null_at
  .type   cssc_vector_float_null_at, @function
cssc_vector_float_null_at:
  j       cssc_vector_int_null_at   ; same 8-byte-stride zero-store path
  .size cssc_vector_float_null_at, .-cssc_vector_float_null_at

  .global cssc_vector_float_null_all
  .type   cssc_vector_float_null_all, @function
cssc_vector_float_null_all:
  j       cssc_vector_int_null_all
  .size cssc_vector_float_null_all, .-cssc_vector_float_null_all

  ; ---- map<string, int> ----
  ; Layout shares the vec_int shell. Each entry is 16 bytes:
  ;   off 0: ptr key (cssc_str*)
  ;   off 8: i64 val
  ; Wiping one entry calls cssc_release on the key, zeros key+val.

  .global cssc_map_si_null_at
  .type   cssc_map_si_null_at, @function
cssc_map_si_null_at:
  ; in: a2 = map, a4:a5 = i (lo)
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  beqz    a2, msnat_done
  l32i.n  a8, a2, 0                 ; size
  bgeu    a4, a8, msnat_done
  l32i.n  a9, a2, 16                ; entries ptr
  slli    a10, a4, 4                ; i * 16
  add     a12, a9, a10              ; &entries[i]
  l32i.n  a2, a12, 0                ; key ptr
  call0   cssc_release
  movi.n  a8, 0
  s32i.n  a8, a12, 0                ; key = NULL
  s32i.n  a8, a12, 8                ; val_lo = 0
  s32i.n  a8, a12, 12               ; val_hi = 0
msnat_done:
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_map_si_null_at, .-cssc_map_si_null_at

  .global cssc_map_si_null_all
  .type   cssc_map_si_null_all, @function
cssc_map_si_null_all:
  ; in: a2 = map
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  beqz    a2, msnal_done
  mov.n   a12, a2
  l32i.n  a13, a12, 0               ; size
  l32i.n  a3,  a12, 16              ; entries
  movi.n  a8, 0                     ; i
msnal_loop:
  bge     a8, a13, msnal_done
  s32i.n  a8, a1, 0
  slli    a9, a8, 4
  add     a9, a3, a9                ; &entries[i]
  s32i.n  a9, a1, 4
  l32i.n  a2, a9, 0
  call0   cssc_release
  l32i.n  a9, a1, 4
  movi.n  a10, 0
  s32i.n  a10, a9, 0
  s32i.n  a10, a9, 8
  s32i.n  a10, a9, 12
  l32i.n  a8, a1, 0
  addi    a8, a8, 1
  j       msnal_loop
msnal_done:
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_map_si_null_all, .-cssc_map_si_null_all

  ; ---- map<string, string> (16-B entries: key, val, _pad) ----

  .global cssc_map_ss_null_at
  .type   cssc_map_ss_null_at, @function
cssc_map_ss_null_at:
  ; in: a2 = map, a4:a5 = i
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  beqz    a2, msssnat_done
  l32i.n  a8, a2, 8                 ; bucket_cnt
  bgeu    a4, a8, msssnat_done
  l32i.n  a9, a2, 16                ; entries ptr
  slli    a10, a4, 4
  add     a12, a9, a10              ; &entries[i]
  l32i.n  a3, a12, 0                ; key (sentinel state)
  beqz    a3, msssnat_done          ; empty — nothing to do
  l32i.n  a2, a12, 4                ; val ptr
  beqz    a2, msssnat_zero
  call0   cssc_release
msssnat_zero:
  movi.n  a8, 0
  s32i.n  a8, a12, 4                ; val = NULL (key + state preserved)
msssnat_done:
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_map_ss_null_at, .-cssc_map_ss_null_at

  .global cssc_map_ss_null_all
  .type   cssc_map_ss_null_all, @function
cssc_map_ss_null_all:
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  beqz    a2, msssnal_done
  mov.n   a12, a2
  l32i.n  a13, a12, 8               ; bucket_cnt
  l32i.n  a3,  a12, 16              ; entries
  movi.n  a8, 0
msssnal_loop:
  bge     a8, a13, msssnal_done
  s32i.n  a8, a1, 0
  slli    a9, a8, 4
  add     a9, a3, a9
  s32i.n  a9, a1, 4
  l32i.n  a10, a9, 0                ; key
  beqz    a10, msssnal_next
  l32i.n  a2, a9, 4                 ; val
  beqz    a2, msssnal_skip_release
  call0   cssc_release
msssnal_skip_release:
  l32i.n  a9, a1, 4
  movi.n  a10, 0
  s32i.n  a10, a9, 4
msssnal_next:
  l32i.n  a8, a1, 0
  addi    a8, a8, 1
  j       msssnal_loop
msssnal_done:
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_map_ss_null_all, .-cssc_map_ss_null_all

  ; ---- map<int, string> (16-B entries: key, val, state) ----

  .global cssc_map_is_null_at
  .type   cssc_map_is_null_at, @function
cssc_map_is_null_at:
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  beqz    a2, misnat_done
  l32i.n  a8, a2, 8
  bgeu    a4, a8, misnat_done
  l32i.n  a9, a2, 16
  slli    a10, a4, 4
  add     a12, a9, a10              ; &entries[i]
  l32i.n  a3, a12, 12               ; state
  beqz    a3, misnat_done
  l32i.n  a2, a12, 8                ; val ptr
  beqz    a2, misnat_zero
  call0   cssc_release
misnat_zero:
  movi.n  a8, 0
  s32i.n  a8, a12, 8                ; val = NULL (key+state preserved)
misnat_done:
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_map_is_null_at, .-cssc_map_is_null_at

  .global cssc_map_is_null_all
  .type   cssc_map_is_null_all, @function
cssc_map_is_null_all:
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  beqz    a2, misnal_done
  mov.n   a12, a2
  l32i.n  a13, a12, 8
  l32i.n  a3,  a12, 16
  movi.n  a8, 0
misnal_loop:
  bge     a8, a13, misnal_done
  s32i.n  a8, a1, 0
  slli    a9, a8, 4
  add     a9, a3, a9
  s32i.n  a9, a1, 4
  l32i.n  a10, a9, 12               ; state
  beqz    a10, misnal_next
  l32i.n  a2, a9, 8                 ; val
  beqz    a2, misnal_skip_release
  call0   cssc_release
misnal_skip_release:
  l32i.n  a9, a1, 4
  movi.n  a10, 0
  s32i.n  a10, a9, 8
misnal_next:
  l32i.n  a8, a1, 0
  addi    a8, a8, 1
  j       misnal_loop
misnal_done:
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_map_is_null_all, .-cssc_map_is_null_all

  ; ---- map<int, int> (24-B entries: key, val, state) ----

  .global cssc_map_ii_null_at
  .type   cssc_map_ii_null_at, @function
cssc_map_ii_null_at:
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  beqz    a2, miinat_done
  l32i.n  a8, a2, 8                 ; bucket_cnt
  bgeu    a4, a8, miinat_done
  l32i.n  a9, a2, 16                ; entries
  slli    a10, a4, 3                ; i*8
  slli    a11, a4, 4                ; i*16
  add     a10, a10, a11             ; i*24
  add     a9, a9, a10               ; &entries[i]
  l32i.n  a3, a9, 16                ; state
  beqz    a3, miinat_done
  movi.n  a8, 0
  s32i.n  a8, a9, 8                 ; val_lo = 0
  s32i.n  a8, a9, 12                ; val_hi = 0
miinat_done:
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_map_ii_null_at, .-cssc_map_ii_null_at

  .global cssc_map_ii_null_all
  .type   cssc_map_ii_null_all, @function
cssc_map_ii_null_all:
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  beqz    a2, miinal_done
  mov.n   a12, a2
  l32i.n  a13, a12, 8
  l32i.n  a3,  a12, 16
  movi.n  a8, 0
miinal_loop:
  bge     a8, a13, miinal_done
  slli    a9, a8, 3
  slli    a10, a8, 4
  add     a9, a9, a10               ; i*24
  add     a9, a3, a9
  l32i.n  a11, a9, 16               ; state
  beqz    a11, miinal_next
  movi.n  a10, 0
  s32i.n  a10, a9, 8
  s32i.n  a10, a9, 12
miinal_next:
  addi    a8, a8, 1
  j       miinal_loop
miinal_done:
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_map_ii_null_all, .-cssc_map_ii_null_all

  ; ---- map<string, f64> (16-B entries: key, _pad, val_f64) ----

  .global cssc_map_sf_null_at
  .type   cssc_map_sf_null_at, @function
cssc_map_sf_null_at:
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  beqz    a2, msfnat_done
  l32i.n  a8, a2, 8
  bgeu    a4, a8, msfnat_done
  l32i.n  a9, a2, 16
  slli    a10, a4, 4
  add     a9, a9, a10
  l32i.n  a3, a9, 0                 ; key
  beqz    a3, msfnat_done
  movi.n  a8, 0
  s32i.n  a8, a9, 8                 ; val_lo
  s32i.n  a8, a9, 12                ; val_hi
msfnat_done:
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_map_sf_null_at, .-cssc_map_sf_null_at

  .global cssc_map_sf_null_all
  .type   cssc_map_sf_null_all, @function
cssc_map_sf_null_all:
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  beqz    a2, msfnal_done
  mov.n   a12, a2
  l32i.n  a13, a12, 8
  l32i.n  a3,  a12, 16
  movi.n  a8, 0
msfnal_loop:
  bge     a8, a13, msfnal_done
  slli    a9, a8, 4
  add     a9, a3, a9
  l32i.n  a10, a9, 0                ; key
  beqz    a10, msfnal_next
  movi.n  a10, 0
  s32i.n  a10, a9, 8
  s32i.n  a10, a9, 12
msfnal_next:
  addi    a8, a8, 1
  j       msfnal_loop
msfnal_done:
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_map_sf_null_all, .-cssc_map_sf_null_all

  ; ---- map<int, f64> (24-B entries: key, val_f64, state) ----

  .global cssc_map_if_null_at
  .type   cssc_map_if_null_at, @function
cssc_map_if_null_at:
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  beqz    a2, mifnat_done
  l32i.n  a8, a2, 8
  bgeu    a4, a8, mifnat_done
  l32i.n  a9, a2, 16
  slli    a10, a4, 3
  slli    a11, a4, 4
  add     a10, a10, a11
  add     a9, a9, a10
  l32i.n  a3, a9, 16                ; state
  beqz    a3, mifnat_done
  movi.n  a8, 0
  s32i.n  a8, a9, 8
  s32i.n  a8, a9, 12
mifnat_done:
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_map_if_null_at, .-cssc_map_if_null_at

  .global cssc_map_if_null_all
  .type   cssc_map_if_null_all, @function
cssc_map_if_null_all:
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  beqz    a2, mifnal_done
  mov.n   a12, a2
  l32i.n  a13, a12, 8
  l32i.n  a3,  a12, 16
  movi.n  a8, 0
mifnal_loop:
  bge     a8, a13, mifnal_done
  slli    a9, a8, 3
  slli    a10, a8, 4
  add     a9, a9, a10
  add     a9, a3, a9
  l32i.n  a11, a9, 16               ; state
  beqz    a11, mifnal_next
  movi.n  a10, 0
  s32i.n  a10, a9, 8
  s32i.n  a10, a9, 12
mifnal_next:
  addi    a8, a8, 1
  j       mifnal_loop
mifnal_done:
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_map_if_null_all, .-cssc_map_if_null_all

  ; ---- bind<string, string> ----
  ; Entry stride 16 bytes: { ptr key, ptr val }. Wipe both strings.

  .global cssc_bind_ss_null_at
  .type   cssc_bind_ss_null_at, @function
cssc_bind_ss_null_at:
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  beqz    a2, bsnat_done
  l32i.n  a8, a2, 0
  bgeu    a4, a8, bsnat_done
  l32i.n  a9, a2, 16
  slli    a10, a4, 4
  add     a12, a9, a10
  l32i.n  a2, a12, 0
  call0   cssc_release
  movi.n  a8, 0
  s32i.n  a8, a12, 0
  l32i.n  a2, a12, 8
  call0   cssc_release
  movi.n  a8, 0
  s32i.n  a8, a12, 8
bsnat_done:
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_bind_ss_null_at, .-cssc_bind_ss_null_at

  .global cssc_bind_ss_null_all
  .type   cssc_bind_ss_null_all, @function
cssc_bind_ss_null_all:
  addi    a1, a1, -16
  s32i.n  a0,  a1, 12
  s32i.n  a12, a1, 8
  s32i.n  a13, a1, 4
  beqz    a2, bsnal_done
  mov.n   a12, a2
  l32i.n  a13, a12, 0
  l32i.n  a3,  a12, 16
  movi.n  a8, 0
bsnal_loop:
  bge     a8, a13, bsnal_done
  s32i.n  a8, a1, 0
  slli    a9, a8, 4
  add     a9, a3, a9
  s32i.n  a9, a1, 4
  l32i.n  a2, a9, 0
  call0   cssc_release
  l32i.n  a9, a1, 4
  movi.n  a10, 0
  s32i.n  a10, a9, 0
  l32i.n  a2, a9, 8
  call0   cssc_release
  l32i.n  a9, a1, 4
  movi.n  a10, 0
  s32i.n  a10, a9, 8
  l32i.n  a8, a1, 0
  addi    a8, a8, 1
  j       bsnal_loop
bsnal_done:
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 8
  l32i.n  a0,  a1, 12
  addi    a1, a1, 16
  ret.n
  .size cssc_bind_ss_null_all, .-cssc_bind_ss_null_all

  .global cssc_pin_pullup
  .type   cssc_pin_pullup, @function
cssc_pin_pullup:
  ; in: a2 = handle, a4 = enable (0/1)  [pair-aligned CALL0 ABI:
  ; `(ptr, i64)` → a2 = ptr, a3 = pair-align skip, a4:a5 = i64]
  ; Set/clear bit 7 of the IOMUX register for this pin.
  ; CALL0 ABI: we clobber a12 and a13, so we have to save/restore
  ; them. (a8..a11 are caller-save scratch and need no preserve.)
  addi    a1, a1, -16
  s32i.n  a12, a1, 0
  s32i.n  a13, a1, 4
  l32i.n  a8, a2, 0              ; pin_no
  l32r    a9, .Lpinpu_iomux_addr
  slli    a10, a8, 2
  add     a9, a9, a10
  l32i.n  a11, a9, 0             ; current IOMUX value
  ; Pullup bit is bit 7.
  movi.n  a12, 0x80
  movi.n  a13, 0
  beq     a4, a13, pin_pu_off
  or      a11, a11, a12
  j       pin_pu_store
pin_pu_off:
  ; mask = ~0x80 = 0xFFFFFF7F
  l32r    a13, .Lpinpu_mask_addr
  l32i.n  a13, a13, 0
  and     a11, a11, a13
pin_pu_store:
  s32i.n  a11, a9, 0
  l32i.n  a13, a1, 4
  l32i.n  a12, a1, 0
  addi    a1, a1, 16
  ret.n
  .literal_position
  .literal .Lpinpu_iomux_addr, .Liomux_table
  .literal .Lpinpu_mask_addr,  .Lpinpu_mask_val
  .section .rodata
  .align 4
.Lpinpu_mask_val:
  .word 0xFFFFFF7F
  .text
  .size cssc_pin_pullup, .-cssc_pin_pullup

'''
    # Inline the font5x7 table from the project's own cssc_tft.c so
    # host and Xtensa runtimes share one source of truth. The font
    # text is generated programmatically from the existing C array.
    asm = _runtime_text.replace(
        '__FONT5x7_BYTES_PLACEHOLDER__',
        _font5x7_asm(),
    )
    # Per-chip MMIO + clock substitution. Every peripheral register
    # address and timing constant lives in `_PROFILES[profile]`; the
    # runtime template carries `__PROFILE_<KEY>__` placeholders that
    # this pass rewrites. Result: identical hand-written asm text
    # serves every Xtensa variant.
    asm = _apply_profile_substitutions(asm, get_profile(profile))
    # Phase D.1: runtime tree-shake plumbing is in place (see
    # `_xtensa_tree_shake_runtime` below), but the closure walk over
    # hand-written asm is incomplete: peripheral families have
    # cross-family runtime dependencies (e.g. cssc_tft_show calls
    # cssc_i2c_write_burst when the OLED uses the I2C transport), and
    # data symbols (cssc_arena, .Liomux_table) are referenced via
    # literal-pool ptr-loads that span chunks. Until a proper closure
    # walk that follows `.literal`/`l32r` references AND tracks cross-
    # peripheral deps is implemented, the tree-shake is a no-op — the
    # full runtime is emitted and the linker's `--gc-sections` handles
    # what it can. Set `CSSC_XTENSA_TREE_SHAKE=1` in the environment to
    # opt into the experimental shake for empirical testing.
    if (requested_symbols is not None
            and os.environ.get('CSSC_XTENSA_TREE_SHAKE') == '1'):
        asm = _xtensa_tree_shake_runtime(asm, requested_symbols)
    return asm


# Always-keep set: every chunk the boot stub `_cssc_user_entry` calls
# unconditionally, plus the diag helpers that are emitted ONLY when
# --diag-mem / --diag-mem-trace are on but the asm text always emits
# their bodies (we let them stay; their byte cost is small).
_XT_CORE_RUNTIME_SYMS = frozenset({
    'cssc_runtime_init',
    'cssc_runtime_shutdown',
    'cssc_uart_putc',          # everything print-related calls this
    'cssc_panic',              # arena OOM / asserts
    'cssc_obj_alloc',          # every heap-kind allocates through this
    'cssc_obj_free',           # arena allocator stub — needed by release path
    # Internal helpers that almost every printer / stringify routes through
    # and that are NOT in user-visible external_calls. Listed here so the
    # closure walk finds them as roots even if no user-facing symbol
    # actually mentions them explicitly.
    'cssc_print_int_nonl',
    '.cssc_pin_iomux_gpio_pu',
    '.cssc_i2c_delay',
    '.cssc_i2c_drive',
    '.cssc_i2c_read_sda',
})


def _xtensa_tree_shake_runtime(asm: str, requested: Set[str]) -> str:
    """Phase D.1: drop runtime function chunks the user program doesn't
    reach.

    CONSERVATIVE STRATEGY: a full closure walk over the hand-written asm
    is error-prone — symbols can be reached via `l32r` literal-pool
    loads, indirect tables, or chains across functions that share
    literal pools. Any miss = link failure. So instead of trusting the
    closure, we only drop chunks whose names match a TARGETED ALLOWLIST
    of known-pure-stub peripheral helpers (cssc_<kind>_<verb> where
    <kind> is a peripheral the user code provably doesn't touch).

    A chunk is droppable only when ALL of these hold:
      * Its name starts with one of the peripheral prefixes (cssc_pin_,
        cssc_spi_, etc.) AND ends with a known-pure verb (_new, _free,
        _begin, _close, _write, _read, _pixel, _line, _rect, _fill,
        _show, _circle, _text, _fillrect, _toggle, _pullup, _mode,
        _transfer, _duty, _start, _stop, _clear, _present, _is_open).
      * NONE of its symbols are in `requested` (the user code calls them).
      * NONE of its symbols are in `_XT_CORE_RUNTIME_SYMS`.

    Everything else stays in the runtime. The linker's `--gc-sections`
    can still strip what it can; we just narrow the input.
    """
    lines = asm.split('\n')
    # Build chunk descriptors: list of (start_idx, end_idx, sym).
    # `end_idx` is exclusive — points at the line AFTER `.size SYM, .-SYM`.
    chunks: List[Tuple[int, int, str]] = []
    i = 0
    n_lines = len(lines)
    # Detect `.global SYM` followed (somewhere) by either `SYM:` label
    # or `.type SYM, @function`. We use `.global SYM` as the chunk start
    # because that's the canonical "this symbol begins here" marker the
    # template uses uniformly. End is the matching `.size SYM, .-SYM`.
    while i < n_lines:
        ln = lines[i].strip()
        if ln.startswith('.global '):
            sym = ln.split(None, 1)[1].strip().rstrip(',')
            # Scan forward for `.size SYM, .-SYM`. If absent (e.g. data
            # globals, `.global cssc_uart_putc` followed by a trivial
            # ret-only body without an explicit `.size`), the chunk
            # extends to the NEXT `.global` (any sym).
            size_marker = f'.size {sym}, .-{sym}'
            end_idx = -1
            j = i + 1
            while j < n_lines:
                jl = lines[j].strip()
                if jl.startswith(size_marker):
                    end_idx = j + 1
                    break
                if jl.startswith('.global ') and jl != ln:
                    end_idx = j  # next chunk starts here
                    break
                j += 1
            if end_idx < 0:
                end_idx = n_lines
            chunks.append((i, end_idx, sym))
            i = end_idx
            continue
        i += 1

    if not chunks:
        # Nothing to shake. Return unchanged.
        return asm

    # Conservative allowlist: chunks safe to drop must match this pattern.
    # The peripheral *stubs* are pure handle-allocators (`cssc_<kind>_new`
    # → `cssc_obj_alloc + ret.n`) or one-line writes. They don't call
    # other cssc_* helpers (verified by spot-grep), so dropping them
    # is link-safe without a closure walk.
    #
    # Specifically EXCLUDED from droppable: anything that draws to a
    # display (tft / oled / video / matrix / framebuffer / console),
    # because those routines internally call peripheral pixel helpers,
    # font tables, and shared literal pools — a closure walk would be
    # required to know which is safe. Until that lands, those stay in
    # the runtime. The user's actual size pain comes from the giant
    # font5x7 table inside the display group; tackling that needs the
    # rodata-shake pass (Phase D.2 future work).
    _PURE_STUB_KINDS = (
        'cssc_pin_',  'cssc_i2c_',  'cssc_spi_',
        'cssc_uart_', 'cssc_adc_',  'cssc_pwm_',
        'cssc_timer_',
    )
    # Within those kinds, ALL chunks are pure-stub on baremetal (the
    # runtime is the no-op shim from line 76-91 of the template comment).
    # A chunk is droppable iff its name starts with a stub kind AND is
    # neither in `requested` nor in `_XT_CORE_RUNTIME_SYMS`.
    keep: Set[str] = set(_XT_CORE_RUNTIME_SYMS) | set(requested)

    def _is_droppable(sym: str) -> bool:
        if sym in keep:
            return False
        if not sym.startswith(_PURE_STUB_KINDS):
            return False
        # Peripheral kinds: only drop if the user code references NONE
        # of that family's symbols. e.g. `cssc_pin_new` is droppable
        # only when no `cssc_pin_*` is in `requested`. Catches mixed
        # cases like the user touching `cssc_pin_write` (kept) but not
        # `cssc_pin_mode` (would otherwise be droppable in isolation).
        # The conservative rule keeps the whole peripheral family if
        # ANY symbol from it is touched.
        for kind in _PURE_STUB_KINDS:
            if sym.startswith(kind):
                family_used = any(r.startswith(kind) for r in requested)
                return not family_used
        return False

    # Emit: every line not inside a chunk is kept. Lines inside a chunk
    # are kept only if the chunk's sym is NOT droppable.
    kept_lines: List[str] = []
    cursor = 0
    for start, end, sym in chunks:
        if cursor < start:
            kept_lines.extend(lines[cursor:start])
        if _is_droppable(sym):
            kept_lines.append(f'  ; [tree-shake] dropped {sym!r} '
                              f'(lines {start+1}..{end})')
        else:
            kept_lines.extend(lines[start:end])
        cursor = end
    if cursor < n_lines:
        kept_lines.extend(lines[cursor:n_lines])
    return '\n'.join(kept_lines)


# ---------------------------------------------------------------------------
# Public entry — emit a full .s assembly for the given module.
# ---------------------------------------------------------------------------
def _emit_xtensa_global_init(em: 'XtensaEmitter', storage_ty: str,
                              init_const: str) -> None:
    """Emit `.data`-section initializer bytes for one module global.

    `storage_ty` is the LLVM-IR type string (`i64`, `i32`, `ptr`,
    `double`) and `init_const` is the LLVM-IR initializer text
    (`0`, `42`, `null`, `0x4024000000000000`).

    Xtensa is little-endian so `.word` writes LSB-first. i64
    becomes two `.word`s; i32/ptr is one. Anything more exotic
    is filled with zeros at the correct byte width — the runtime
    initialiser code (emitted into `cssc_runtime_init` for sector
    members) overrides at startup, so the .data init is just for
    safe link-time placement.
    """
    ty = storage_ty.strip().lower()
    if ty == 'i64' or ty == 'double':
        try:
            n = int(init_const, 0)
        except (ValueError, TypeError):
            n = 0
        lo = n & 0xFFFFFFFF
        hi = (n >> 32) & 0xFFFFFFFF
        em.emit(f'  .word   0x{lo:08x}    ; lo')
        em.emit(f'  .word   0x{hi:08x}    ; hi')
    elif ty in ('i32', 'ptr', 'i8*', 'i16'):
        if init_const.strip() in ('null', 'undef'):
            em.emit(f'  .word   0')
        else:
            try:
                n = int(init_const, 0) & 0xFFFFFFFF
            except (ValueError, TypeError):
                n = 0
            em.emit(f'  .word   0x{n:08x}')
    elif ty == 'i1' or ty == 'i8':
        try:
            n = int(init_const, 0) & 0xFF
        except (ValueError, TypeError):
            n = 0
        # Xtensa LX106 doesn't support `.byte` directly in DRAM
        # without alignment; pad with three zero bytes so the
        # global occupies the same 4-byte word the rest of the
        # codegen expects.
        em.emit(f'  .word   0x{n:08x}')
    else:
        # Unknown storage type — fall back to 8-byte zero. The
        # runtime init will set the actual value on startup.
        em.emit(f'  .word   0    ; storage_ty={storage_ty!r} (unknown)')
        em.emit(f'  .word   0')


def emit_program(module: Module,
                 runtime_symbols: Set[str],
                 profile: str = 'esp8266',
                 target_triple: Optional[str] = None,
                 *,
                 trace_mode: bool = False,
                 diag_mem: bool = False,
                 diag_mem_trace: bool = False) -> Tuple[str, str]:
    """Emit (user_asm, runtime_asm) for an Xtensa build.

    When `target_triple` is omitted it is taken from the active
    profile (`xtensa-none-elf` for ESP8266 / LX106, `xtensa-esp32-elf`
    for ESP32 / LX7). Callers that want to override the triple — for
    instance to point a downstream `clang --target=` at a custom
    sysroot — can still pass an explicit value.

    `trace_mode=True` enables function-entry UART tracing. Every
    emitter-produced user function (cssc_user_*, cssc_obj_*,
    cssc_sec_*) gets a `> name\\n` print injected just before its
    body runs. The chip then emits a live call trace over UART so
    crashes can be pinpointed to the exact function that held control
    — invaluable for diagnosing codegen-interaction bugs where the
    crash PC has been overwritten by the exception handler. See
    `cssc trace` CLI.

    Returns two assembly-text strings the caller writes to .s files
    and feeds to `xtensa-<variant>-elf-as`. The result is two .o
    files that the linker (`ld.lld -T cssc_<chip>.ld user.o
    runtime.o`) combines into the final ELF, which `esptool` then
    wraps as a flashable .bin.
    """
    prof = get_profile(profile)
    if target_triple is None:
        target_triple = prof['triple']
    em = XtensaEmitter()
    em._current_module = module
    em.profile_name = profile
    em.profile = prof
    em.trace_mode = trace_mode
    em.diag_mem = diag_mem
    em.diag_mem_trace = diag_mem_trace
    em.emit('  ; Xtensa LX106 assembly emitted by transembly/xtensa_lx106.py')
    em.emit(f'  ; module:  {module.name}')
    em.emit(f'  ; profile: {profile}')
    em.emit(f'  ; triple:  {target_triple}')
    em.emit('')

    # External symbols. We declare every runtime symbol the user
    # module references plus every libgcc thunk our codegen patterns
    # can call. The linker resolves these at link time; unreferenced
    # `.global` lines are harmless because we never `.extern` them
    # without a matching call.
    externals = set(runtime_symbols) | {
        '__mulsi3', '__divsi3', '__modsi3',   # i32 mul/div/mod
        '__muldi3', '__divdi3', '__moddi3',   # i64 mul/div/mod
        '__adddf3', '__subdf3', '__muldf3', '__divdf3',   # f64 arith
        '__eqdf2',  '__nedf2',  '__ltdf2',  '__gtdf2',
        '__ledf2',  '__gedf2',                # f64 comparisons
        '__floatsidf', '__fixdfsi',           # i32↔f64 conversion
        '__addsf3', '__subsf3', '__mulsf3', '__divsf3',   # f32 arith (ESP8266)
        '__eqsf2',  '__nesf2',  '__ltsf2',  '__gtsf2',
        '__lesf2',  '__gesf2',                # f32 comparisons (ESP8266)
        '__truncdfsf2', '__extendsfdf2',      # f64↔f32 conversion
    }
    if diag_mem:
        # Pull in the diag-mem helper symbol so the runtime emitter
        # includes its asm body (otherwise the runtime stripper would
        # treat it as unused). Also ensure the print helpers used by
        # cssc_diag_mem_check are linked.
        externals.add('cssc_diag_mem_check')
        externals.add('cssc_print_str')
        externals.add('cssc_print_int_nonl')   # the no-newline variant
    if diag_mem_trace:
        # The per-op trace helper. Same retention story as the diag-mem
        # helper above — the runtime stripper would drop it if no
        # `call0 cssc_diag_trace_op` site is visible at codegen time
        # (the emit-side wiring is conditional on this flag too).
        externals.add('cssc_diag_trace_op')
        externals.add('cssc_print_str')
        externals.add('cssc_print_int_nonl')
    for sym in sorted(externals):
        em.emit(f'  .global {sym}')

    em.emit('')

    # String pool: emit string-literal constants from each function.
    # MUST go into .rodata (→ DRAM in our linker script). ESP8266
    # IRAM only supports 32-bit aligned word loads — `l8ui` on IRAM
    # triggers a LoadStoreErrorCause (cause 3). cssc_string_lit
    # walks the literal byte-by-byte via l8ui, so the literal data
    # has to live in DRAM where byte loads work.
    em.emit('  .section .rodata')
    em.emit('  .align 4')
    for fn in module.functions:
        for label, text in fn.string_pool.items():
            escaped = (text
                       .replace('\\', '\\\\')
                       .replace('"', '\\"')
                       .replace('\n', '\\n')
                       .replace('\t', '\\t'))
            em.emit(f'{label}: .asciz "{escaped}"')
    em.emit('  .text')   # restore .text for the function emissions below
    em.emit('')

    # Module globals (Bug 4 fix): sector members + function-slot
    # globals (`cssc_g_<fname>`, `cssc_sec_<Sec>_<member>`) emitted
    # by cir_lower.py into `module.globals`. Host emits these via
    # `@sym = internal global …`; on Xtensa we materialise them as
    # `.data` storage so the linker resolves the symbols.
    mod_globals = getattr(module, 'globals', None) or []
    if mod_globals:
        em.emit('  ; --- module globals (sector members + promoted fn slots) ---')
        em.emit('  .section .data')
        em.emit('  .align 4')
        for sym, storage_ty, init_const in mod_globals:
            em.emit(f'  .global {sym}')
            em.emit(f'  .type   {sym}, @object')
            em.emit(f'{sym}:')
            _emit_xtensa_global_init(em, storage_ty, init_const)
            em.emit(f'  .size   {sym}, .-{sym}')
        em.emit('  .text')
        em.emit('')

    # Emit each user function.
    for fn in module.functions:
        em.emit_function(fn)

    # Trace-mode rodata: emit the `> fnname\n` strings collected by
    # `_emit_trace_enter`. They live in DRAM via .rodata so the
    # `cssc_print_str` byte-loads (`l8ui`) work — same byte-load
    # constraint as the regular string pool above.
    if em.trace_mode and em._trace_strings:
        em.emit('')
        em.emit('  ; --- trace-mode strings (--trace) ----------------')
        em.emit('  .section .rodata')
        em.emit('  .align 4')
        for label, text in em._trace_strings:
            escaped = (text
                       .replace('\\', '\\\\')
                       .replace('"', '\\"')
                       .replace('\n', '\\n')
                       .replace('\t', '\\t'))
            em.emit(f'{label}: .asciz "{escaped}"')
        em.emit('  .text')

    # Synthesize the program-entry shim that calls cssc_user_main.
    # This is the symbol the boot stub (esp_link.py) jumps to.
    em.emit('  .global _cssc_user_entry')
    em.emit('  .type   _cssc_user_entry, @function')
    em.emit('_cssc_user_entry:')
    em.emit('  addi    a1, a1, -16')
    em.emit('  s32i.n  a0, a1, 12')
    em.emit('  call0   cssc_runtime_init')
    em.emit('  call0   cssc_user_main')
    em.emit('  call0   cssc_runtime_shutdown')
    em.emit('  l32i.n  a0, a1, 12')
    em.emit('  addi    a1, a1, 16')
    em.emit('  ret.n')
    em.emit('  .size   _cssc_user_entry, .-_cssc_user_entry')

    # --diag-mem fn_id table — emit a comment block mapping fn_id
    # back to function symbol so the host-side post-processor can
    # show human-readable names in `[cssc-mem]` decode output. The
    # listener scans for `; DIAG-MEM-MAP fn=<id> => <name>` lines.
    if em.diag_mem and em._diag_mem_fn_ids:
        em.emit('')
        em.emit('  ; --- --diag-mem fn_id table (host-listener correlation) ---')
        for fn_name, fid in sorted(em._diag_mem_fn_ids.items(),
                                    key=lambda kv: kv[1]):
            em.emit(f'  ; DIAG-MEM-MAP fn={fid} => {fn_name}')
        em.emit('')

    # --diag-mem-trace op_id table — emit a comment block mapping
    # op_id back to (fn, src_line, op_kind). The host-side renderer
    # resolves the LAST op_id logged before a crash to a specific
    # source line + op kind ("LAST SUCCESSFUL OP: src=L37 kind=Call").
    # The driver (v6_driver.py) scans for `; DIAG-TRACE-MAP …` lines
    # and writes them to `<output>.diag-trace-map.txt` for the
    # diagnostics listener to load.
    if em.diag_mem_trace and em._trace_op_map:
        em.emit('')
        em.emit('  ; --- --diag-mem-trace op_id table '
                '(host-listener correlation) ---')
        for op_id, fn_name, src_line, op_kind in em._trace_op_map:
            em.emit(f'  ; DIAG-TRACE-MAP op={op_id} fn={fn_name} '
                    f'src=L{src_line} kind={op_kind}')
        em.emit('')

    user_asm = '\n'.join(em.lines) + '\n'
    # Phase D.1: pass the requested-runtime symbol set so the runtime
    # emitter can DROP function chunks that the user code never touches.
    # The set is built from every function's `external_calls` table + the
    # always-needed runtime entry symbols (cssc_runtime_init/shutdown,
    # cssc_uart_putc, the print/string/obj_alloc core).
    runtime_asm = emit_runtime_min(profile,
                                    requested_symbols=set(runtime_symbols))
    # Two post-processing passes:
    #   1. `_xtensa_add_function_alignment` inserts `.align 4` before
    #      every function label. Xtensa `call0` requires 4-byte
    #      aligned targets and GNU-as for Xtensa doesn't insert that
    #      automatically; getting this wrong produces "dangerous
    #      relocation: misaligned call target" at link time.
    #   2. `_xtensa_translate_comments` converts our `;` line
    #      comments to `#` (the actual GAS-Xtensa comment char) —
    #      keeps the Python source readable while feeding the
    #      assembler what it expects.
    # Third pass: widen narrow loads/stores whose offset is out of
    # range for the *.n form. `s32i.n / l32i.n` encode the offset as a
    # 4-bit unsigned multiple of 4 (range 0..60). Anything beyond that
    # is illegal — Xtensa as errors with "operand 3 of 's32i.n' has
    # invalid value". The emitter currently picks the narrow form
    # everywhere as a size optimisation, which breaks for big frames
    # (audit_corpus.cssc with 20+ slots crosses 1024). Rewrite the
    # offending instructions to the wide form (1-byte larger, but
    # supports 0..1020); offsets beyond 1020 still need addi-based
    # base-pointer adjustment which is a deeper codegen change.
    user_asm    = _xtensa_widen_narrow_mem_ops(user_asm)
    runtime_asm = _xtensa_widen_narrow_mem_ops(runtime_asm)
    user_asm    = _xtensa_translate_comments(_xtensa_add_function_alignment(user_asm))
    runtime_asm = _xtensa_translate_comments(_xtensa_add_function_alignment(runtime_asm))
    return user_asm, runtime_asm


def _xtensa_widen_narrow_mem_ops(text: str) -> str:
    """Rewrite `s32i.n REG, BASE, OFF` → `s32i REG, BASE, OFF` (and
    same for `l32i.n`) when OFF is out of the narrow form's range
    (0..60, multiples of 4). The wide form is one instruction byte
    larger but supports 0..1020.

    Offsets BEYOND 1020 split into an addmi-base sequence with the
    dedicated `WIDE_OFFSET_SCRATCH` register (a15):

        addmi  a15, BASE, OFF_HIGH    ; OFF_HIGH = k*256, ±32K
        s32i   REG, a15, OFF_LOW      ; OFF_LOW = OFF − OFF_HIGH, 0..1020

    THE SCRATCH REGISTER IS RESERVED ARCHITECTURALLY (see the partition
    block at the top of this file). `a15` is excluded from `ALLOC_REGS`
    AND from `HANDLER_SCRATCH`, AND it has no callee-save slot — the
    codegen NEVER writes a live value into it. The widening can
    therefore stomp on it with no preservation logic, no liveness
    analysis, no spill, and no per-op conflict scan. Any future code
    path that introduces a write to a15 outside this widener is a
    framework bug — `cssl_dev_audit` catches it via `WIDE_SCRATCH_ALIVE`.

    The fallback `movi + add` form (when OFF doesn't fit `addmi`'s
    ±32K reach, i.e. frames > 32 KB) also writes only `a15` — same
    safety guarantee.

    Idempotent. Skips lines already in the narrow-encodable range.
    """
    import re as __re
    pattern = getattr(_xtensa_widen_narrow_mem_ops, '_pat', None)
    if pattern is None:
        pattern = __re.compile(
            r'^(?P<indent>\s*)(?P<op>s32i|l32i)(?P<narrow>\.n)?(?P<sep>\s+)'
            r'(?P<reg>[a-zA-Z][a-zA-Z0-9]*),\s*'
            r'(?P<base>[a-zA-Z][a-zA-Z0-9]*),\s*'
            r'(?P<off>-?\d+)(?P<rest>.*)$'
        )
        _xtensa_widen_narrow_mem_ops._pat = pattern  # noqa
    scratch = WIDE_OFFSET_SCRATCH
    out: List[str] = []
    for line in text.split('\n'):
        m = pattern.match(line)
        if m is None:
            out.append(line)
            continue
        try:
            off = int(m.group('off'))
        except ValueError:
            out.append(line)
            continue
        op = m.group('op')
        narrow = m.group('narrow') is not None
        reg = m.group('reg')
        base = m.group('base')
        indent = m.group('indent')
        rest = m.group('rest')
        if narrow and 0 <= off <= 60:
            out.append(line)
            continue
        if 0 <= off <= 1020:
            out.append(f"{indent}{op}{m.group('sep')}{reg}, {base}, {off}{rest}")
            continue
        # > 1020 — addmi-split through the dedicated scratch a15.
        low = off & 0x3FF
        high = off - low
        if high <= 0 or high > 32512:
            # Frames beyond ~32 KB exceed `addmi`'s reach. Fall back to
            # `movi + add` (3-instruction form). Only the scratch is
            # written; reg/base survive untouched.
            out.append(f"{indent}movi    {scratch}, {off}{rest}")
            out.append(f"{indent}add     {scratch}, {base}, {scratch}")
            out.append(f"{indent}{op}     {reg}, {scratch}, 0")
        else:
            out.append(f"{indent}addmi   {scratch}, {base}, {high}{rest}")
            out.append(f"{indent}{op}     {reg}, {scratch}, {low}")
    return '\n'.join(out)


def _xtensa_add_function_alignment(text: str) -> str:
    """Insert `.align 4` before every Xtensa function label.

    Xtensa `call0` requires the target to be 4-byte aligned. GNU as
    for Xtensa doesn't auto-align function labels — it's the
    emitter's responsibility. We post-process the assembly text and
    align any `<sym>:` label that follows either of:
      * `.type <sym>, @function`   (the standard pattern)
      * `.global <sym>`             (covers bare-label stubs like
        `cssc_tft_free: ret.n` that skip the .type directive)

    Also handles same-line forms (`label: instruction`) by splitting
    them so the alignment can land before the label. The pass is
    idempotent — running it twice produces the same output.
    """
    out: List[str] = []
    pending_align = False
    last_globaled_sym: Optional[str] = None
    for line in text.split('\n'):
        stripped = line.strip()
        # ".type foo, @function" → next label needs aligning.
        if stripped.startswith('.type') and '@function' in stripped:
            pending_align = True
            out.append(line)
            continue
        # ".global foo" → the next `foo:` label needs aligning even
        # if no .type directive follows.
        if stripped.startswith('.global'):
            parts = stripped.split(None, 1)
            if len(parts) == 2:
                last_globaled_sym = parts[1].strip().rstrip(',')
            out.append(line)
            continue
        # Detect labels — possibly on the same line as an instruction.
        m_label = _LABEL_RE.match(line)
        if m_label is not None:
            sym = m_label.group('sym')
            indent = m_label.group('indent')
            rest = line[m_label.end():]
            needs_align = (
                pending_align
                or (last_globaled_sym is not None
                    and sym == last_globaled_sym)
            )
            if needs_align and not sym.startswith('.L'):
                # Avoid double-aligning if .align already precedes us.
                if not (out and out[-1].lstrip().startswith('.align')):
                    out.append(f'{indent}.align  4')
                if rest.strip():
                    # Same-line instruction → split onto two lines so
                    # the label stays on its own line.
                    out.append(f'{indent}{sym}:')
                    out.append(f'{indent}{rest.strip()}')
                else:
                    out.append(line)
                pending_align = False
                last_globaled_sym = None
                continue
        out.append(line)
    return '\n'.join(out)


# Match either `label:` on its own line or `label: instruction` —
# captures the indent, symbol, and lets the caller pull anything
# after the colon.
import re as _re
_LABEL_RE = _re.compile(r'^(?P<indent>\s*)(?P<sym>[A-Za-z_.][A-Za-z0-9_.]*):')


def _xtensa_translate_comments(text: str) -> str:
    """Convert `;`-style line comments to `#`-style for GAS-Xtensa.

    The rule is GAS-line-oriented: the first `;` on a line begins a
    comment, except inside a quoted string literal. We preserve string
    contents (handles `.asciz "a;b"`) while translating the comment
    character on every other line.

    Idempotent: running it twice produces the same output. We never
    touch `#`-comments that are already correct, and we never touch
    semicolons inside string literals.
    """
    out_lines: List[str] = []
    for line in text.split('\n'):
        in_str = False
        new_line_chars: List[str] = []
        i = 0
        translated = False
        while i < len(line):
            c = line[i]
            if c == '"' and (i == 0 or line[i-1] != '\\'):
                in_str = not in_str
                new_line_chars.append(c)
            elif c == ';' and not in_str and not translated:
                # Replace this `;` with `#`; the rest of the line is
                # comment text, so we keep going as-is but the first
                # `;` is now `#`.
                new_line_chars.append('#')
                translated = True
            else:
                new_line_chars.append(c)
            i += 1
        out_lines.append(''.join(new_line_chars))
    return '\n'.join(out_lines)


__all__ = ['emit_program', 'emit_runtime_min', 'supported_ops',
           'XtensaEmitter']
